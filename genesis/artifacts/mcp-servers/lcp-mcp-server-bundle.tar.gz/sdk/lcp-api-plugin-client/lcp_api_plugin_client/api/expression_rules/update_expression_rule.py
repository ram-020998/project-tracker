from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.expression_rule import ExpressionRule
from ...models.update_expression_rule_request import UpdateExpressionRuleRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    uuid: str,
    *,
    body: UpdateExpressionRuleRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/expression-rules/{uuid}".format(
            uuid=quote(str(uuid), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Error | ExpressionRule | None:
    if response.status_code == 200:
        response_200 = ExpressionRule.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | ExpressionRule]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateExpressionRuleRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | ExpressionRule]:
    """Update an existing expression rule

     Updates an existing Appian Expression Rule design object identified by its UUID.
    Supports partial updates - only the fields provided in the request body will be modified.

    **Implementation**: Backed by ExpressionRuleHandler.updateExpressionRule()

    **Behavior**:
    - Supports partial updates (only provided fields are modified)
    - At least one field must be provided for update
    - Updated expression rule is immediately available in Appian
    - Unchanged fields remain the same

    **Validation**:
    - UUID must correspond to an existing expression rule
    - Name cannot be empty if provided
    - Parameter names must be unique if inputs are provided

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (UpdateExpressionRuleRequest): Request body for updating an existing expression rule
            (at least one field required)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | ExpressionRule]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateExpressionRuleRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | ExpressionRule | None:
    """Update an existing expression rule

     Updates an existing Appian Expression Rule design object identified by its UUID.
    Supports partial updates - only the fields provided in the request body will be modified.

    **Implementation**: Backed by ExpressionRuleHandler.updateExpressionRule()

    **Behavior**:
    - Supports partial updates (only provided fields are modified)
    - At least one field must be provided for update
    - Updated expression rule is immediately available in Appian
    - Unchanged fields remain the same

    **Validation**:
    - UUID must correspond to an existing expression rule
    - Name cannot be empty if provided
    - Parameter names must be unique if inputs are provided

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (UpdateExpressionRuleRequest): Request body for updating an existing expression rule
            (at least one field required)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | ExpressionRule
    """

    return sync_detailed(
        uuid=uuid,
        client=client,
        body=body,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateExpressionRuleRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | ExpressionRule]:
    """Update an existing expression rule

     Updates an existing Appian Expression Rule design object identified by its UUID.
    Supports partial updates - only the fields provided in the request body will be modified.

    **Implementation**: Backed by ExpressionRuleHandler.updateExpressionRule()

    **Behavior**:
    - Supports partial updates (only provided fields are modified)
    - At least one field must be provided for update
    - Updated expression rule is immediately available in Appian
    - Unchanged fields remain the same

    **Validation**:
    - UUID must correspond to an existing expression rule
    - Name cannot be empty if provided
    - Parameter names must be unique if inputs are provided

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (UpdateExpressionRuleRequest): Request body for updating an existing expression rule
            (at least one field required)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | ExpressionRule]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateExpressionRuleRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | ExpressionRule | None:
    """Update an existing expression rule

     Updates an existing Appian Expression Rule design object identified by its UUID.
    Supports partial updates - only the fields provided in the request body will be modified.

    **Implementation**: Backed by ExpressionRuleHandler.updateExpressionRule()

    **Behavior**:
    - Supports partial updates (only provided fields are modified)
    - At least one field must be provided for update
    - Updated expression rule is immediately available in Appian
    - Unchanged fields remain the same

    **Validation**:
    - UUID must correspond to an existing expression rule
    - Name cannot be empty if provided
    - Parameter names must be unique if inputs are provided

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (UpdateExpressionRuleRequest): Request body for updating an existing expression rule
            (at least one field required)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | ExpressionRule
    """

    return (
        await asyncio_detailed(
            uuid=uuid,
            client=client,
            body=body,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
