from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_test_case_request import CreateTestCaseRequest
from ...models.error import Error
from ...models.test_case import TestCase
from ...types import UNSET, Response, Unset


def _get_kwargs(
    uuid: str,
    *,
    body: CreateTestCaseRequest | list[CreateTestCaseRequest],
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/expression-rules/{uuid}/test-cases".format(
            uuid=quote(str(uuid), safe=""),
        ),
    }

    if isinstance(body, CreateTestCaseRequest):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = []
        for body_type_1_item_data in body:
            body_type_1_item = body_type_1_item_data.to_dict()
            _kwargs["json"].append(body_type_1_item)

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | list[TestCase] | TestCase | None:
    if response.status_code == 201:

        def _parse_response_201(data: object) -> list[TestCase] | TestCase:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_0 = TestCase.from_dict(data)

                return response_201_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, list):
                raise TypeError()
            response_201_type_1 = []
            _response_201_type_1 = data
            for response_201_type_1_item_data in _response_201_type_1:
                response_201_type_1_item = TestCase.from_dict(response_201_type_1_item_data)

                response_201_type_1.append(response_201_type_1_item)

            return response_201_type_1

        response_201 = _parse_response_201(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = Error.from_dict(response.json())

        return response_404

    if response.status_code == 409:
        response_409 = Error.from_dict(response.json())

        return response_409

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | list[TestCase] | TestCase]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateTestCaseRequest | list[CreateTestCaseRequest],
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | list[TestCase] | TestCase]:
    """Create test case(s) for an expression rule

     Creates one or more test cases for the specified expression rule. Accepts either a single test case
    object or an array of test case objects for batch creation. The response shape mirrors the request:
    a single object when a single object is sent, or an array when an array is sent.

    **Batch behavior**: All test case names are validated for uniqueness (against each other and against
    existing test cases) before any are persisted. If any name conflicts, the entire batch is rejected.

    Returns 404 if the feature toggle is disabled. Returns 409 if a test case with the same name already
    exists.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateTestCaseRequest | list[CreateTestCaseRequest]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | list[TestCase] | TestCase]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateTestCaseRequest | list[CreateTestCaseRequest],
    x_appian_api_version: str | Unset = UNSET,
) -> Error | list[TestCase] | TestCase | None:
    """Create test case(s) for an expression rule

     Creates one or more test cases for the specified expression rule. Accepts either a single test case
    object or an array of test case objects for batch creation. The response shape mirrors the request:
    a single object when a single object is sent, or an array when an array is sent.

    **Batch behavior**: All test case names are validated for uniqueness (against each other and against
    existing test cases) before any are persisted. If any name conflicts, the entire batch is rejected.

    Returns 404 if the feature toggle is disabled. Returns 409 if a test case with the same name already
    exists.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateTestCaseRequest | list[CreateTestCaseRequest]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | list[TestCase] | TestCase
    """

    return sync_detailed(
        uuid=uuid,
        client=client,
        body=body,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateTestCaseRequest | list[CreateTestCaseRequest],
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | list[TestCase] | TestCase]:
    """Create test case(s) for an expression rule

     Creates one or more test cases for the specified expression rule. Accepts either a single test case
    object or an array of test case objects for batch creation. The response shape mirrors the request:
    a single object when a single object is sent, or an array when an array is sent.

    **Batch behavior**: All test case names are validated for uniqueness (against each other and against
    existing test cases) before any are persisted. If any name conflicts, the entire batch is rejected.

    Returns 404 if the feature toggle is disabled. Returns 409 if a test case with the same name already
    exists.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateTestCaseRequest | list[CreateTestCaseRequest]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | list[TestCase] | TestCase]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateTestCaseRequest | list[CreateTestCaseRequest],
    x_appian_api_version: str | Unset = UNSET,
) -> Error | list[TestCase] | TestCase | None:
    """Create test case(s) for an expression rule

     Creates one or more test cases for the specified expression rule. Accepts either a single test case
    object or an array of test case objects for batch creation. The response shape mirrors the request:
    a single object when a single object is sent, or an array when an array is sent.

    **Batch behavior**: All test case names are validated for uniqueness (against each other and against
    existing test cases) before any are persisted. If any name conflicts, the entire batch is rejected.

    Returns 404 if the feature toggle is disabled. Returns 409 if a test case with the same name already
    exists.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateTestCaseRequest | list[CreateTestCaseRequest]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | list[TestCase] | TestCase
    """

    return (
        await asyncio_detailed(
            uuid=uuid,
            client=client,
            body=body,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
