from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.list_application_folders_folder_type import ListApplicationFoldersFolderType
from ...models.paginated_folder_list import PaginatedFolderList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    app_uuid: str,
    *,
    query: str | Unset = UNSET,
    folder_type: ListApplicationFoldersFolderType | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    params: dict[str, Any] = {}

    params["query"] = query

    json_folder_type: str | Unset = UNSET
    if not isinstance(folder_type, Unset):
        json_folder_type = folder_type.value

    params["folderType"] = json_folder_type

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/applications/{app_uuid}/folders".format(
            app_uuid=quote(str(app_uuid), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | PaginatedFolderList | None:
    if response.status_code == 200:
        response_200 = PaginatedFolderList.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | PaginatedFolderList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    folder_type: ListApplicationFoldersFolderType | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | PaginatedFolderList]:
    """List folders in an application

     Retrieves a paginated list of folders within a specific Appian application with optional
    query-based filtering and folder type filtering. Folders are filtered by name if a query
    is provided, and can be further filtered by folder type (e.g., RULES_FOLDER, PROCESS_MODEL_FOLDER).

    **Implementation**: Backed by FolderHandler.listApplicationFolders()

    **Folder Types:**
    - KNOWLEDGE_CENTER - Root container for document folders
    - KNOWLEDGE_FOLDER - Folder within a Knowledge Center for documents
    - RULES_FOLDER - Folder for expression rules, interfaces, and constants
    - PROCESS_MODEL_FOLDER - Folder for process models

    Args:
        app_uuid (str):
        query (str | Unset):
        folder_type (ListApplicationFoldersFolderType | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | PaginatedFolderList]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        query=query,
        folder_type=folder_type,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    folder_type: ListApplicationFoldersFolderType | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | PaginatedFolderList | None:
    """List folders in an application

     Retrieves a paginated list of folders within a specific Appian application with optional
    query-based filtering and folder type filtering. Folders are filtered by name if a query
    is provided, and can be further filtered by folder type (e.g., RULES_FOLDER, PROCESS_MODEL_FOLDER).

    **Implementation**: Backed by FolderHandler.listApplicationFolders()

    **Folder Types:**
    - KNOWLEDGE_CENTER - Root container for document folders
    - KNOWLEDGE_FOLDER - Folder within a Knowledge Center for documents
    - RULES_FOLDER - Folder for expression rules, interfaces, and constants
    - PROCESS_MODEL_FOLDER - Folder for process models

    Args:
        app_uuid (str):
        query (str | Unset):
        folder_type (ListApplicationFoldersFolderType | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | PaginatedFolderList
    """

    return sync_detailed(
        app_uuid=app_uuid,
        client=client,
        query=query,
        folder_type=folder_type,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    folder_type: ListApplicationFoldersFolderType | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | PaginatedFolderList]:
    """List folders in an application

     Retrieves a paginated list of folders within a specific Appian application with optional
    query-based filtering and folder type filtering. Folders are filtered by name if a query
    is provided, and can be further filtered by folder type (e.g., RULES_FOLDER, PROCESS_MODEL_FOLDER).

    **Implementation**: Backed by FolderHandler.listApplicationFolders()

    **Folder Types:**
    - KNOWLEDGE_CENTER - Root container for document folders
    - KNOWLEDGE_FOLDER - Folder within a Knowledge Center for documents
    - RULES_FOLDER - Folder for expression rules, interfaces, and constants
    - PROCESS_MODEL_FOLDER - Folder for process models

    Args:
        app_uuid (str):
        query (str | Unset):
        folder_type (ListApplicationFoldersFolderType | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | PaginatedFolderList]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        query=query,
        folder_type=folder_type,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    folder_type: ListApplicationFoldersFolderType | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | PaginatedFolderList | None:
    """List folders in an application

     Retrieves a paginated list of folders within a specific Appian application with optional
    query-based filtering and folder type filtering. Folders are filtered by name if a query
    is provided, and can be further filtered by folder type (e.g., RULES_FOLDER, PROCESS_MODEL_FOLDER).

    **Implementation**: Backed by FolderHandler.listApplicationFolders()

    **Folder Types:**
    - KNOWLEDGE_CENTER - Root container for document folders
    - KNOWLEDGE_FOLDER - Folder within a Knowledge Center for documents
    - RULES_FOLDER - Folder for expression rules, interfaces, and constants
    - PROCESS_MODEL_FOLDER - Folder for process models

    Args:
        app_uuid (str):
        query (str | Unset):
        folder_type (ListApplicationFoldersFolderType | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | PaginatedFolderList
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            client=client,
            query=query,
            folder_type=folder_type,
            limit=limit,
            offset=offset,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
