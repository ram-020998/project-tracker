from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.constant import Constant
from ...models.error import Error
from ...models.update_constant_request import UpdateConstantRequest
from ...types import UNSET, Response, Unset


def _get_kwargs(
    uuid: str,
    *,
    body: UpdateConstantRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/constants/{uuid}".format(
            uuid=quote(str(uuid), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Constant | Error | None:
    if response.status_code == 200:
        response_200 = Constant.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Constant | Error]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConstantRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Constant | Error]:
    """Update an existing constant

     Updates an existing Appian Constant design object with new values. Supports partial
    updates, meaning only the fields provided in the request body will be updated, and
    other fields will retain their existing values.

    **Implementation**: Backed by ConstantFunctions.updateConstant()

    **Important**: When updating type and value together, the value must be compatible
    with the new type. If only value is updated, it must be compatible with the existing
    type. If only type is updated, the existing value must be compatible with the new type.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (UpdateConstantRequest): Request body for updating an existing constant. All fields
            are optional, but at
            least one field must be provided. Only the fields included in the request will
            be updated; other fields will retain their existing values.

            **Important**: When updating type and value together, the value must be compatible
            with the new type. If only value is updated, it must be compatible with the existing
            type. If only type is updated, the existing value must be compatible with the new type.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Constant | Error]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConstantRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Constant | Error | None:
    """Update an existing constant

     Updates an existing Appian Constant design object with new values. Supports partial
    updates, meaning only the fields provided in the request body will be updated, and
    other fields will retain their existing values.

    **Implementation**: Backed by ConstantFunctions.updateConstant()

    **Important**: When updating type and value together, the value must be compatible
    with the new type. If only value is updated, it must be compatible with the existing
    type. If only type is updated, the existing value must be compatible with the new type.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (UpdateConstantRequest): Request body for updating an existing constant. All fields
            are optional, but at
            least one field must be provided. Only the fields included in the request will
            be updated; other fields will retain their existing values.

            **Important**: When updating type and value together, the value must be compatible
            with the new type. If only value is updated, it must be compatible with the existing
            type. If only type is updated, the existing value must be compatible with the new type.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Constant | Error
    """

    return sync_detailed(
        uuid=uuid,
        client=client,
        body=body,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConstantRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Constant | Error]:
    """Update an existing constant

     Updates an existing Appian Constant design object with new values. Supports partial
    updates, meaning only the fields provided in the request body will be updated, and
    other fields will retain their existing values.

    **Implementation**: Backed by ConstantFunctions.updateConstant()

    **Important**: When updating type and value together, the value must be compatible
    with the new type. If only value is updated, it must be compatible with the existing
    type. If only type is updated, the existing value must be compatible with the new type.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (UpdateConstantRequest): Request body for updating an existing constant. All fields
            are optional, but at
            least one field must be provided. Only the fields included in the request will
            be updated; other fields will retain their existing values.

            **Important**: When updating type and value together, the value must be compatible
            with the new type. If only value is updated, it must be compatible with the existing
            type. If only type is updated, the existing value must be compatible with the new type.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Constant | Error]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConstantRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Constant | Error | None:
    """Update an existing constant

     Updates an existing Appian Constant design object with new values. Supports partial
    updates, meaning only the fields provided in the request body will be updated, and
    other fields will retain their existing values.

    **Implementation**: Backed by ConstantFunctions.updateConstant()

    **Important**: When updating type and value together, the value must be compatible
    with the new type. If only value is updated, it must be compatible with the existing
    type. If only type is updated, the existing value must be compatible with the new type.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (UpdateConstantRequest): Request body for updating an existing constant. All fields
            are optional, but at
            least one field must be provided. Only the fields included in the request will
            be updated; other fields will retain their existing values.

            **Important**: When updating type and value together, the value must be compatible
            with the new type. If only value is updated, it must be compatible with the existing
            type. If only type is updated, the existing value must be compatible with the new type.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Constant | Error
    """

    return (
        await asyncio_detailed(
            uuid=uuid,
            client=client,
            body=body,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
