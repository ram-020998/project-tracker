from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_application_request import CreateApplicationRequest
from ...models.create_application_response import CreateApplicationResponse
from ...models.error import Error
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: CreateApplicationRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/applications",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreateApplicationResponse | Error | None:
    if response.status_code == 201:
        response_201 = CreateApplicationResponse.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreateApplicationResponse | Error]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateApplicationRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[CreateApplicationResponse | Error]:
    """Creates an Appian application with all standard default objects, matching the
    Designer UI behavior. Includes security groups (registered as default admin/user groups),
    folders, knowledge center, and constants. The response includes UUIDs for all created objects.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateApplicationRequest): Request body for creating a new Appian application with
            default elements

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateApplicationResponse | Error]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateApplicationRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> CreateApplicationResponse | Error | None:
    """Creates an Appian application with all standard default objects, matching the
    Designer UI behavior. Includes security groups (registered as default admin/user groups),
    folders, knowledge center, and constants. The response includes UUIDs for all created objects.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateApplicationRequest): Request body for creating a new Appian application with
            default elements

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateApplicationResponse | Error
    """

    return sync_detailed(
        client=client,
        body=body,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateApplicationRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[CreateApplicationResponse | Error]:
    """Creates an Appian application with all standard default objects, matching the
    Designer UI behavior. Includes security groups (registered as default admin/user groups),
    folders, knowledge center, and constants. The response includes UUIDs for all created objects.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateApplicationRequest): Request body for creating a new Appian application with
            default elements

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateApplicationResponse | Error]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateApplicationRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> CreateApplicationResponse | Error | None:
    """Creates an Appian application with all standard default objects, matching the
    Designer UI behavior. Includes security groups (registered as default admin/user groups),
    folders, knowledge center, and constants. The response includes UUIDs for all created objects.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateApplicationRequest): Request body for creating a new Appian application with
            default elements

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateApplicationResponse | Error
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
