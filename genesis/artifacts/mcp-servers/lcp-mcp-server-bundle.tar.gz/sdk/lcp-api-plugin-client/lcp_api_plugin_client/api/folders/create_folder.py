from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_folder_request import CreateFolderRequest
from ...models.error import Error
from ...models.folder import Folder
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: CreateFolderRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/folders",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Error | Folder | None:
    if response.status_code == 201:
        response_201 = Folder.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Error | Folder]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | Folder]:
    """Create folder

     Creates a new folder in the Knowledge Center within a specified parent folder.
    The parent folder must exist and be a valid folder type. The folder name must
    be unique within the parent folder.

    **Implementation**: Backed by FolderHandler.createFolder()

    **Note**: Returns the created folder with generated UUID.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateFolderRequest): Request body for creating a new folder

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | Folder]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | Folder | None:
    """Create folder

     Creates a new folder in the Knowledge Center within a specified parent folder.
    The parent folder must exist and be a valid folder type. The folder name must
    be unique within the parent folder.

    **Implementation**: Backed by FolderHandler.createFolder()

    **Note**: Returns the created folder with generated UUID.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateFolderRequest): Request body for creating a new folder

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | Folder
    """

    return sync_detailed(
        client=client,
        body=body,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | Folder]:
    """Create folder

     Creates a new folder in the Knowledge Center within a specified parent folder.
    The parent folder must exist and be a valid folder type. The folder name must
    be unique within the parent folder.

    **Implementation**: Backed by FolderHandler.createFolder()

    **Note**: Returns the created folder with generated UUID.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateFolderRequest): Request body for creating a new folder

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | Folder]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateFolderRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | Folder | None:
    """Create folder

     Creates a new folder in the Knowledge Center within a specified parent folder.
    The parent folder must exist and be a valid folder type. The folder name must
    be unique within the parent folder.

    **Implementation**: Backed by FolderHandler.createFolder()

    **Note**: Returns the created folder with generated UUID.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateFolderRequest): Request body for creating a new folder

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | Folder
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
