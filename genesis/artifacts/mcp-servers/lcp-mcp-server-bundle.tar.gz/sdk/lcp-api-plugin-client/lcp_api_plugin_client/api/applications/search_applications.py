from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.paginated_application_list import PaginatedApplicationList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    params: dict[str, Any] = {}

    params["query"] = query

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/applications",
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | PaginatedApplicationList | None:
    if response.status_code == 200:
        response_200 = PaginatedApplicationList.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | PaginatedApplicationList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | PaginatedApplicationList]:
    r"""Search applications

     Searches for Appian applications using text matching against application names and descriptions.
    This endpoint uses ContentService to search the applications root folder, supporting wildcard
    patterns and pagination. The search is case-insensitive and matches partial text.

    **Implementation**: Backed by ApplicationCoreFunctions.searchApplications()

    **Wildcard Support**:
    - `*` matches any characters
    - `?` matches a single character
    - Examples: `*customer*` matches any app with \"customer\" in name/description

    **Note**: If query is empty or not provided, returns all applications in the system.

    Args:
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | PaginatedApplicationList]
    """

    kwargs = _get_kwargs(
        query=query,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | PaginatedApplicationList | None:
    r"""Search applications

     Searches for Appian applications using text matching against application names and descriptions.
    This endpoint uses ContentService to search the applications root folder, supporting wildcard
    patterns and pagination. The search is case-insensitive and matches partial text.

    **Implementation**: Backed by ApplicationCoreFunctions.searchApplications()

    **Wildcard Support**:
    - `*` matches any characters
    - `?` matches a single character
    - Examples: `*customer*` matches any app with \"customer\" in name/description

    **Note**: If query is empty or not provided, returns all applications in the system.

    Args:
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | PaginatedApplicationList
    """

    return sync_detailed(
        client=client,
        query=query,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | PaginatedApplicationList]:
    r"""Search applications

     Searches for Appian applications using text matching against application names and descriptions.
    This endpoint uses ContentService to search the applications root folder, supporting wildcard
    patterns and pagination. The search is case-insensitive and matches partial text.

    **Implementation**: Backed by ApplicationCoreFunctions.searchApplications()

    **Wildcard Support**:
    - `*` matches any characters
    - `?` matches a single character
    - Examples: `*customer*` matches any app with \"customer\" in name/description

    **Note**: If query is empty or not provided, returns all applications in the system.

    Args:
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | PaginatedApplicationList]
    """

    kwargs = _get_kwargs(
        query=query,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | PaginatedApplicationList | None:
    r"""Search applications

     Searches for Appian applications using text matching against application names and descriptions.
    This endpoint uses ContentService to search the applications root folder, supporting wildcard
    patterns and pagination. The search is case-insensitive and matches partial text.

    **Implementation**: Backed by ApplicationCoreFunctions.searchApplications()

    **Wildcard Support**:
    - `*` matches any characters
    - `?` matches a single character
    - Examples: `*customer*` matches any app with \"customer\" in name/description

    **Note**: If query is empty or not provided, returns all applications in the system.

    Args:
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | PaginatedApplicationList
    """

    return (
        await asyncio_detailed(
            client=client,
            query=query,
            limit=limit,
            offset=offset,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
