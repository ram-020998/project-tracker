from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.list_application_processes_status_filter import ListApplicationProcessesStatusFilter
from ...types import UNSET, Response, Unset


def _get_kwargs(
    app_uuid: str,
    *,
    status_filter: ListApplicationProcessesStatusFilter | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    params: dict[str, Any] = {}

    json_status_filter: str | Unset = UNSET
    if not isinstance(status_filter, Unset):
        json_status_filter = status_filter.value

    params["statusFilter"] = json_status_filter

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/applications/{app_uuid}/processes".format(
            app_uuid=quote(str(app_uuid), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Error | None:
    if response.status_code == 200:
        response_200 = Error.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Error]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    status_filter: ListApplicationProcessesStatusFilter | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error]:
    """List runtime process instances in an application

     Retrieves a paginated list of runtime process instances within a specific Appian application
    with optional status filtering. Process instances represent active or completed executions of
    process models.

    **Note**: This endpoint is currently implemented as a placeholder. The Appian Java API does not
    provide a direct method to query process instances by application.

    Args:
        app_uuid (str):
        status_filter (ListApplicationProcessesStatusFilter | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        status_filter=status_filter,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    status_filter: ListApplicationProcessesStatusFilter | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | None:
    """List runtime process instances in an application

     Retrieves a paginated list of runtime process instances within a specific Appian application
    with optional status filtering. Process instances represent active or completed executions of
    process models.

    **Note**: This endpoint is currently implemented as a placeholder. The Appian Java API does not
    provide a direct method to query process instances by application.

    Args:
        app_uuid (str):
        status_filter (ListApplicationProcessesStatusFilter | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error
    """

    return sync_detailed(
        app_uuid=app_uuid,
        client=client,
        status_filter=status_filter,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    status_filter: ListApplicationProcessesStatusFilter | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error]:
    """List runtime process instances in an application

     Retrieves a paginated list of runtime process instances within a specific Appian application
    with optional status filtering. Process instances represent active or completed executions of
    process models.

    **Note**: This endpoint is currently implemented as a placeholder. The Appian Java API does not
    provide a direct method to query process instances by application.

    Args:
        app_uuid (str):
        status_filter (ListApplicationProcessesStatusFilter | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        status_filter=status_filter,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    status_filter: ListApplicationProcessesStatusFilter | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | None:
    """List runtime process instances in an application

     Retrieves a paginated list of runtime process instances within a specific Appian application
    with optional status filtering. Process instances represent active or completed executions of
    process models.

    **Note**: This endpoint is currently implemented as a placeholder. The Appian Java API does not
    provide a direct method to query process instances by application.

    Args:
        app_uuid (str):
        status_filter (ListApplicationProcessesStatusFilter | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            client=client,
            status_filter=status_filter,
            limit=limit,
            offset=offset,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
