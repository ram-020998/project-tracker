from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.constant import Constant
from ...models.create_constant_request import CreateConstantRequest
from ...models.error import Error
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: CreateConstantRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/constants",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Constant | Error | None:
    if response.status_code == 201:
        response_201 = Constant.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Constant | Error]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateConstantRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Constant | Error]:
    """Create a new constant

     Creates a new Appian Constant design object with the specified name, type, and value.
    Constants are reusable values that can be referenced throughout an Appian application.

    **Implementation**: Backed by ConstantFunctions.createConstant()

    **Important**: This function uses Appian's Constant class (not FreeformRule) and stores
    values using TypedValue objects. The type parameter must match one of the supported
    constant types, and the value must be compatible with the specified type.

    **Storage**: Constants are created in the rules root folder (constants live in rules folder).

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateConstantRequest): Request body for creating a new constant. All fields except
            description, parentFolderUuid, and appUuid are required.

            The value must be compatible with the specified type.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the constant
            will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Constant | Error]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateConstantRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Constant | Error | None:
    """Create a new constant

     Creates a new Appian Constant design object with the specified name, type, and value.
    Constants are reusable values that can be referenced throughout an Appian application.

    **Implementation**: Backed by ConstantFunctions.createConstant()

    **Important**: This function uses Appian's Constant class (not FreeformRule) and stores
    values using TypedValue objects. The type parameter must match one of the supported
    constant types, and the value must be compatible with the specified type.

    **Storage**: Constants are created in the rules root folder (constants live in rules folder).

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateConstantRequest): Request body for creating a new constant. All fields except
            description, parentFolderUuid, and appUuid are required.

            The value must be compatible with the specified type.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the constant
            will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Constant | Error
    """

    return sync_detailed(
        client=client,
        body=body,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateConstantRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Constant | Error]:
    """Create a new constant

     Creates a new Appian Constant design object with the specified name, type, and value.
    Constants are reusable values that can be referenced throughout an Appian application.

    **Implementation**: Backed by ConstantFunctions.createConstant()

    **Important**: This function uses Appian's Constant class (not FreeformRule) and stores
    values using TypedValue objects. The type parameter must match one of the supported
    constant types, and the value must be compatible with the specified type.

    **Storage**: Constants are created in the rules root folder (constants live in rules folder).

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateConstantRequest): Request body for creating a new constant. All fields except
            description, parentFolderUuid, and appUuid are required.

            The value must be compatible with the specified type.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the constant
            will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Constant | Error]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateConstantRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Constant | Error | None:
    """Create a new constant

     Creates a new Appian Constant design object with the specified name, type, and value.
    Constants are reusable values that can be referenced throughout an Appian application.

    **Implementation**: Backed by ConstantFunctions.createConstant()

    **Important**: This function uses Appian's Constant class (not FreeformRule) and stores
    values using TypedValue objects. The type parameter must match one of the supported
    constant types, and the value must be compatible with the specified type.

    **Storage**: Constants are created in the rules root folder (constants live in rules folder).

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateConstantRequest): Request body for creating a new constant. All fields except
            description, parentFolderUuid, and appUuid are required.

            The value must be compatible with the specified type.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the constant
            will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Constant | Error
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
