from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.get_application_response import GetApplicationResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    app_uuid: str,
    *,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/applications/{app_uuid}".format(
            app_uuid=quote(str(app_uuid), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | GetApplicationResponse | None:
    if response.status_code == 200:
        response_200 = GetApplicationResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | GetApplicationResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | GetApplicationResponse]:
    """Get an application

     Retrieves a single Appian application by UUID, including the UUIDs of its default objects
    (administrator and user security groups).
    Returns 403 if the application is not found or the caller lacks access.

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | GetApplicationResponse]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | GetApplicationResponse | None:
    """Get an application

     Retrieves a single Appian application by UUID, including the UUIDs of its default objects
    (administrator and user security groups).
    Returns 403 if the application is not found or the caller lacks access.

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | GetApplicationResponse
    """

    return sync_detailed(
        app_uuid=app_uuid,
        client=client,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | GetApplicationResponse]:
    """Get an application

     Retrieves a single Appian application by UUID, including the UUIDs of its default objects
    (administrator and user security groups).
    Returns 403 if the application is not found or the caller lacks access.

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | GetApplicationResponse]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | GetApplicationResponse | None:
    """Get an application

     Retrieves a single Appian application by UUID, including the UUIDs of its default objects
    (administrator and user security groups).
    Returns 403 if the application is not found or the caller lacks access.

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | GetApplicationResponse
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            client=client,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
