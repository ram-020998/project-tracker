from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.list_application_ai_skills_response_200 import ListApplicationAiSkillsResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    app_uuid: str,
    *,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["query"] = query

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/applications/{app_uuid}/ai-skills".format(
            app_uuid=quote(str(app_uuid), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | ListApplicationAiSkillsResponse200 | None:
    if response.status_code == 200:
        response_200 = ListApplicationAiSkillsResponse200.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = cast(Any, None)
        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | ListApplicationAiSkillsResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[Any | ListApplicationAiSkillsResponse200]:
    """List AI skills in an application

     Retrieves a paginated list of AI skills within a specific Appian application
    with optional search filtering.

    Args:
        app_uuid (str):
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ListApplicationAiSkillsResponse200]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        query=query,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Any | ListApplicationAiSkillsResponse200 | None:
    """List AI skills in an application

     Retrieves a paginated list of AI skills within a specific Appian application
    with optional search filtering.

    Args:
        app_uuid (str):
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ListApplicationAiSkillsResponse200
    """

    return sync_detailed(
        app_uuid=app_uuid,
        client=client,
        query=query,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[Any | ListApplicationAiSkillsResponse200]:
    """List AI skills in an application

     Retrieves a paginated list of AI skills within a specific Appian application
    with optional search filtering.

    Args:
        app_uuid (str):
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ListApplicationAiSkillsResponse200]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        query=query,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Any | ListApplicationAiSkillsResponse200 | None:
    """List AI skills in an application

     Retrieves a paginated list of AI skills within a specific Appian application
    with optional search filtering.

    Args:
        app_uuid (str):
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ListApplicationAiSkillsResponse200
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            client=client,
            query=query,
            limit=limit,
            offset=offset,
        )
    ).parsed
