from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.interface_design_object import InterfaceDesignObject
from ...types import UNSET, Response, Unset


def _get_kwargs(
    uuid: str,
    *,
    expand: str | Unset = UNSET,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    params: dict[str, Any] = {}

    params["expand"] = expand

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/interfaces/{uuid}".format(
            uuid=quote(str(uuid), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | InterfaceDesignObject | None:
    if response.status_code == 200:
        response_200 = InterfaceDesignObject.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = Error.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | InterfaceDesignObject]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    expand: str | Unset = UNSET,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | InterfaceDesignObject]:
    """Get interface by UUID

    Args:
        uuid (str):
        expand (str | Unset):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | InterfaceDesignObject]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        expand=expand,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    expand: str | Unset = UNSET,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | InterfaceDesignObject | None:
    """Get interface by UUID

    Args:
        uuid (str):
        expand (str | Unset):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | InterfaceDesignObject
    """

    return sync_detailed(
        uuid=uuid,
        client=client,
        expand=expand,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    expand: str | Unset = UNSET,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | InterfaceDesignObject]:
    """Get interface by UUID

    Args:
        uuid (str):
        expand (str | Unset):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | InterfaceDesignObject]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        expand=expand,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    expand: str | Unset = UNSET,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | InterfaceDesignObject | None:
    """Get interface by UUID

    Args:
        uuid (str):
        expand (str | Unset):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | InterfaceDesignObject
    """

    return (
        await asyncio_detailed(
            uuid=uuid,
            client=client,
            expand=expand,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
