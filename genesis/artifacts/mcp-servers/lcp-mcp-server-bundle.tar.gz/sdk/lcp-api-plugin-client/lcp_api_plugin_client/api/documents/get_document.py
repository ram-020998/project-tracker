from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.document import Document
from ...models.error import Error
from ...types import UNSET, Response, Unset


def _get_kwargs(
    uuid: str,
    *,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/documents/{uuid}".format(
            uuid=quote(str(uuid), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Document | Error | None:
    if response.status_code == 200:
        response_200 = Document.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Document | Error]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Document | Error]:
    """Get document metadata

     Retrieves detailed metadata for a single document identified by its UUID.
    Returns only metadata; use /documents/{uuid}/content to retrieve
    the actual file content.

    **Implementation**: Backed by DocumentHandler.getDocument()

    **Note**: Some fields (size, mimeType, timestamps) may be null due to
    Appian Content API limitations.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Document | Error]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Document | Error | None:
    """Get document metadata

     Retrieves detailed metadata for a single document identified by its UUID.
    Returns only metadata; use /documents/{uuid}/content to retrieve
    the actual file content.

    **Implementation**: Backed by DocumentHandler.getDocument()

    **Note**: Some fields (size, mimeType, timestamps) may be null due to
    Appian Content API limitations.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Document | Error
    """

    return sync_detailed(
        uuid=uuid,
        client=client,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Document | Error]:
    """Get document metadata

     Retrieves detailed metadata for a single document identified by its UUID.
    Returns only metadata; use /documents/{uuid}/content to retrieve
    the actual file content.

    **Implementation**: Backed by DocumentHandler.getDocument()

    **Note**: Some fields (size, mimeType, timestamps) may be null due to
    Appian Content API limitations.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Document | Error]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Document | Error | None:
    """Get document metadata

     Retrieves detailed metadata for a single document identified by its UUID.
    Returns only metadata; use /documents/{uuid}/content to retrieve
    the actual file content.

    **Implementation**: Backed by DocumentHandler.getDocument()

    **Note**: Some fields (size, mimeType, timestamps) may be null due to
    Appian Content API limitations.

    Args:
        uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Document | Error
    """

    return (
        await asyncio_detailed(
            uuid=uuid,
            client=client,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
