from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.add_objects_to_application_response import AddObjectsToApplicationResponse
from ...models.design_object_reference import DesignObjectReference
from ...models.error import Error
from ...types import UNSET, Response, Unset


def _get_kwargs(
    app_uuid: str,
    *,
    body: list[DesignObjectReference],
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/applications/{app_uuid}/objects".format(
            app_uuid=quote(str(app_uuid), safe=""),
        ),
    }

    _kwargs["json"] = []
    for body_item_data in body:
        body_item = body_item_data.to_dict()
        _kwargs["json"].append(body_item)

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AddObjectsToApplicationResponse | Error | None:
    if response.status_code == 200:
        response_200 = AddObjectsToApplicationResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AddObjectsToApplicationResponse | Error]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: list[DesignObjectReference],
    x_appian_api_version: str | Unset = UNSET,
) -> Response[AddObjectsToApplicationResponse | Error]:
    """Add design objects to application

     Adds existing design objects to an application by UUID and type. This operation enables
    programmatic composition of applications by adding process models, expression rules,
    interfaces, record types, sites, constants, data types, and groups to application containers.

    **Supported Object Types:**
    - PROCESS_MODEL - Process model design objects
    - EXPRESSION_RULE - Expression rule design objects
    - INTERFACE - Interface design objects
    - RECORD_TYPE - Record type design objects
    - SITE - Site design objects
    - CONSTANT - Constant design objects
    - DATA_TYPE - Data type design objects
    - GROUP - Group design objects

    **Idempotency:** This operation is idempotent. Adding an object that is already a member
    of the application will not cause an error.

    **Implementation:** Backed by ApplicationCoreFunctions.addObjectsToApplication()

    Uses ExtendedApplicationService.updateAssociatedObjects() to add objects in batch operations
    grouped by Appian type for efficiency. Objects are validated before adding to ensure they
    exist and are of supported types.

    **Batch Operations:** Objects are automatically grouped by type and added in batch calls:
    - PROCESS_MODEL → Type.PROCESS_MODEL
    - RECORD_TYPE → Type.RECORD_TYPE
    - SITE → Type.SITE
    - GROUP → Type.GROUP
    - EXPRESSION_RULE, INTERFACE, CONSTANT, DATA_TYPE → Type.CONTENT (grouped together)

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (list[DesignObjectReference]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AddObjectsToApplicationResponse | Error]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: list[DesignObjectReference],
    x_appian_api_version: str | Unset = UNSET,
) -> AddObjectsToApplicationResponse | Error | None:
    """Add design objects to application

     Adds existing design objects to an application by UUID and type. This operation enables
    programmatic composition of applications by adding process models, expression rules,
    interfaces, record types, sites, constants, data types, and groups to application containers.

    **Supported Object Types:**
    - PROCESS_MODEL - Process model design objects
    - EXPRESSION_RULE - Expression rule design objects
    - INTERFACE - Interface design objects
    - RECORD_TYPE - Record type design objects
    - SITE - Site design objects
    - CONSTANT - Constant design objects
    - DATA_TYPE - Data type design objects
    - GROUP - Group design objects

    **Idempotency:** This operation is idempotent. Adding an object that is already a member
    of the application will not cause an error.

    **Implementation:** Backed by ApplicationCoreFunctions.addObjectsToApplication()

    Uses ExtendedApplicationService.updateAssociatedObjects() to add objects in batch operations
    grouped by Appian type for efficiency. Objects are validated before adding to ensure they
    exist and are of supported types.

    **Batch Operations:** Objects are automatically grouped by type and added in batch calls:
    - PROCESS_MODEL → Type.PROCESS_MODEL
    - RECORD_TYPE → Type.RECORD_TYPE
    - SITE → Type.SITE
    - GROUP → Type.GROUP
    - EXPRESSION_RULE, INTERFACE, CONSTANT, DATA_TYPE → Type.CONTENT (grouped together)

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (list[DesignObjectReference]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AddObjectsToApplicationResponse | Error
    """

    return sync_detailed(
        app_uuid=app_uuid,
        client=client,
        body=body,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: list[DesignObjectReference],
    x_appian_api_version: str | Unset = UNSET,
) -> Response[AddObjectsToApplicationResponse | Error]:
    """Add design objects to application

     Adds existing design objects to an application by UUID and type. This operation enables
    programmatic composition of applications by adding process models, expression rules,
    interfaces, record types, sites, constants, data types, and groups to application containers.

    **Supported Object Types:**
    - PROCESS_MODEL - Process model design objects
    - EXPRESSION_RULE - Expression rule design objects
    - INTERFACE - Interface design objects
    - RECORD_TYPE - Record type design objects
    - SITE - Site design objects
    - CONSTANT - Constant design objects
    - DATA_TYPE - Data type design objects
    - GROUP - Group design objects

    **Idempotency:** This operation is idempotent. Adding an object that is already a member
    of the application will not cause an error.

    **Implementation:** Backed by ApplicationCoreFunctions.addObjectsToApplication()

    Uses ExtendedApplicationService.updateAssociatedObjects() to add objects in batch operations
    grouped by Appian type for efficiency. Objects are validated before adding to ensure they
    exist and are of supported types.

    **Batch Operations:** Objects are automatically grouped by type and added in batch calls:
    - PROCESS_MODEL → Type.PROCESS_MODEL
    - RECORD_TYPE → Type.RECORD_TYPE
    - SITE → Type.SITE
    - GROUP → Type.GROUP
    - EXPRESSION_RULE, INTERFACE, CONSTANT, DATA_TYPE → Type.CONTENT (grouped together)

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (list[DesignObjectReference]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AddObjectsToApplicationResponse | Error]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: list[DesignObjectReference],
    x_appian_api_version: str | Unset = UNSET,
) -> AddObjectsToApplicationResponse | Error | None:
    """Add design objects to application

     Adds existing design objects to an application by UUID and type. This operation enables
    programmatic composition of applications by adding process models, expression rules,
    interfaces, record types, sites, constants, data types, and groups to application containers.

    **Supported Object Types:**
    - PROCESS_MODEL - Process model design objects
    - EXPRESSION_RULE - Expression rule design objects
    - INTERFACE - Interface design objects
    - RECORD_TYPE - Record type design objects
    - SITE - Site design objects
    - CONSTANT - Constant design objects
    - DATA_TYPE - Data type design objects
    - GROUP - Group design objects

    **Idempotency:** This operation is idempotent. Adding an object that is already a member
    of the application will not cause an error.

    **Implementation:** Backed by ApplicationCoreFunctions.addObjectsToApplication()

    Uses ExtendedApplicationService.updateAssociatedObjects() to add objects in batch operations
    grouped by Appian type for efficiency. Objects are validated before adding to ensure they
    exist and are of supported types.

    **Batch Operations:** Objects are automatically grouped by type and added in batch calls:
    - PROCESS_MODEL → Type.PROCESS_MODEL
    - RECORD_TYPE → Type.RECORD_TYPE
    - SITE → Type.SITE
    - GROUP → Type.GROUP
    - EXPRESSION_RULE, INTERFACE, CONSTANT, DATA_TYPE → Type.CONTENT (grouped together)

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (list[DesignObjectReference]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AddObjectsToApplicationResponse | Error
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            client=client,
            body=body,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
