from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_interface_request import CreateInterfaceRequest
from ...models.error import Error
from ...models.interface_design_object import InterfaceDesignObject
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: CreateInterfaceRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/interfaces",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | InterfaceDesignObject | None:
    if response.status_code == 201:
        response_201 = InterfaceDesignObject.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = Error.from_dict(response.json())

        return response_401

    if response.status_code == 409:
        response_409 = Error.from_dict(response.json())

        return response_409

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | InterfaceDesignObject]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateInterfaceRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | InterfaceDesignObject]:
    """Create a new interface

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateInterfaceRequest): Request body for creating a new interface.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the interface
            will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | InterfaceDesignObject]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateInterfaceRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | InterfaceDesignObject | None:
    """Create a new interface

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateInterfaceRequest): Request body for creating a new interface.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the interface
            will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | InterfaceDesignObject
    """

    return sync_detailed(
        client=client,
        body=body,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateInterfaceRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | InterfaceDesignObject]:
    """Create a new interface

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateInterfaceRequest): Request body for creating a new interface.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the interface
            will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | InterfaceDesignObject]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateInterfaceRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | InterfaceDesignObject | None:
    """Create a new interface

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateInterfaceRequest): Request body for creating a new interface.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the interface
            will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | InterfaceDesignObject
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
