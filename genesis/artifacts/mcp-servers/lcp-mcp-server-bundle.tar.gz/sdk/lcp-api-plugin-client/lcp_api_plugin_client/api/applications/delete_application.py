from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...types import UNSET, Response, Unset


def _get_kwargs(
    app_uuid: str,
    *,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/applications/{app_uuid}".format(
            app_uuid=quote(str(app_uuid), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | Error | None:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | Error]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Any | Error]:
    """Delete an application

     Permanently deletes an Appian application container by UUID. This removes the application container
    only — all design objects (records, interfaces, process models, constants, groups, folders, sites,
    etc.) that were part of the application are preserved and become unassociated.

    This operation cannot be undone.

    **Implementation**: Backed by ApplicationHandler.deleteApplication()

    **Behavior**:
    - Resolves UUID to application via ApplicationService.getApplicationByUuid()
    - Uses ApplicationService.delete() to permanently remove the application container
    - Returns 204 No Content on successful deletion
    - Returns 403 if application not found or no access

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | Error]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Any | Error | None:
    """Delete an application

     Permanently deletes an Appian application container by UUID. This removes the application container
    only — all design objects (records, interfaces, process models, constants, groups, folders, sites,
    etc.) that were part of the application are preserved and become unassociated.

    This operation cannot be undone.

    **Implementation**: Backed by ApplicationHandler.deleteApplication()

    **Behavior**:
    - Resolves UUID to application via ApplicationService.getApplicationByUuid()
    - Uses ApplicationService.delete() to permanently remove the application container
    - Returns 204 No Content on successful deletion
    - Returns 403 if application not found or no access

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | Error
    """

    return sync_detailed(
        app_uuid=app_uuid,
        client=client,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Any | Error]:
    """Delete an application

     Permanently deletes an Appian application container by UUID. This removes the application container
    only — all design objects (records, interfaces, process models, constants, groups, folders, sites,
    etc.) that were part of the application are preserved and become unassociated.

    This operation cannot be undone.

    **Implementation**: Backed by ApplicationHandler.deleteApplication()

    **Behavior**:
    - Resolves UUID to application via ApplicationService.getApplicationByUuid()
    - Uses ApplicationService.delete() to permanently remove the application container
    - Returns 204 No Content on successful deletion
    - Returns 403 if application not found or no access

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | Error]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Any | Error | None:
    """Delete an application

     Permanently deletes an Appian application container by UUID. This removes the application container
    only — all design objects (records, interfaces, process models, constants, groups, folders, sites,
    etc.) that were part of the application are preserved and become unassociated.

    This operation cannot be undone.

    **Implementation**: Backed by ApplicationHandler.deleteApplication()

    **Behavior**:
    - Resolves UUID to application via ApplicationService.getApplicationByUuid()
    - Uses ApplicationService.delete() to permanently remove the application container
    - Returns 204 No Content on successful deletion
    - Returns 403 if application not found or no access

    Args:
        app_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | Error
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            client=client,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
