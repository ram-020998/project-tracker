from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.test_case import TestCase
from ...types import UNSET, Response, Unset


def _get_kwargs(
    uuid: str,
    test_case_uuid: str,
    *,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/expression-rules/{uuid}/test-cases/{test_case_uuid}".format(
            uuid=quote(str(uuid), safe=""),
            test_case_uuid=quote(str(test_case_uuid), safe=""),
        ),
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Error | TestCase | None:
    if response.status_code == 200:
        response_200 = TestCase.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 404:
        response_404 = Error.from_dict(response.json())

        return response_404

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Error | TestCase]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    uuid: str,
    test_case_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | TestCase]:
    """Get a single test case for an expression rule

    Args:
        uuid (str):
        test_case_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | TestCase]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        test_case_uuid=test_case_uuid,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    uuid: str,
    test_case_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | TestCase | None:
    """Get a single test case for an expression rule

    Args:
        uuid (str):
        test_case_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | TestCase
    """

    return sync_detailed(
        uuid=uuid,
        test_case_uuid=test_case_uuid,
        client=client,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    uuid: str,
    test_case_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | TestCase]:
    """Get a single test case for an expression rule

    Args:
        uuid (str):
        test_case_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | TestCase]
    """

    kwargs = _get_kwargs(
        uuid=uuid,
        test_case_uuid=test_case_uuid,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    uuid: str,
    test_case_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | TestCase | None:
    """Get a single test case for an expression rule

    Args:
        uuid (str):
        test_case_uuid (str):
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | TestCase
    """

    return (
        await asyncio_detailed(
            uuid=uuid,
            test_case_uuid=test_case_uuid,
            client=client,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
