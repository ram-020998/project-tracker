from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.paginated_interface_list import PaginatedInterfaceList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    app_uuid: str,
    *,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    params: dict[str, Any] = {}

    params["query"] = query

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/applications/{app_uuid}/interfaces".format(
            app_uuid=quote(str(app_uuid), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | PaginatedInterfaceList | None:
    if response.status_code == 200:
        response_200 = PaginatedInterfaceList.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | PaginatedInterfaceList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | PaginatedInterfaceList]:
    """List interfaces in an application

     Retrieves a paginated list of interfaces within a specific Appian application with optional
    search filtering. Interfaces are SAIL-based user interface definitions used to create forms,
    dashboards, and other UI components.

    **Implementation**: Backed by ApplicationCoreFunctions.listApplicationInterfaces()

    Args:
        app_uuid (str):
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | PaginatedInterfaceList]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        query=query,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | PaginatedInterfaceList | None:
    """List interfaces in an application

     Retrieves a paginated list of interfaces within a specific Appian application with optional
    search filtering. Interfaces are SAIL-based user interface definitions used to create forms,
    dashboards, and other UI components.

    **Implementation**: Backed by ApplicationCoreFunctions.listApplicationInterfaces()

    Args:
        app_uuid (str):
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | PaginatedInterfaceList
    """

    return sync_detailed(
        app_uuid=app_uuid,
        client=client,
        query=query,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | PaginatedInterfaceList]:
    """List interfaces in an application

     Retrieves a paginated list of interfaces within a specific Appian application with optional
    search filtering. Interfaces are SAIL-based user interface definitions used to create forms,
    dashboards, and other UI components.

    **Implementation**: Backed by ApplicationCoreFunctions.listApplicationInterfaces()

    Args:
        app_uuid (str):
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | PaginatedInterfaceList]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        query=query,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    query: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | PaginatedInterfaceList | None:
    """List interfaces in an application

     Retrieves a paginated list of interfaces within a specific Appian application with optional
    search filtering. Interfaces are SAIL-based user interface definitions used to create forms,
    dashboards, and other UI components.

    **Implementation**: Backed by ApplicationCoreFunctions.listApplicationInterfaces()

    Args:
        app_uuid (str):
        query (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | PaginatedInterfaceList
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            client=client,
            query=query,
            limit=limit,
            offset=offset,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
