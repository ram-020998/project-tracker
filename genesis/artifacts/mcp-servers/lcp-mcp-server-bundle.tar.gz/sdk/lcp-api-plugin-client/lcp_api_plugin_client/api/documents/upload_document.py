from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_document_request import CreateDocumentRequest
from ...models.document import Document
from ...models.error import Error
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: CreateDocumentRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/documents",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Document | Error | None:
    if response.status_code == 201:
        response_201 = Document.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = Error.from_dict(response.json())

        return response_403

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Document | Error]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateDocumentRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Document | Error]:
    """Upload document

     Uploads a new document with file content to a folder in the Knowledge Center.
    The parent folder must exist and be a valid folder type. The file content must
    be provided as a base64-encoded string.

    **Implementation**: Backed by DocumentHandler.uploadDocument()

    **Note**: Returns the created document with generated UUID and file size.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateDocumentRequest): Request body for uploading a new document

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Document | Error]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateDocumentRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Document | Error | None:
    """Upload document

     Uploads a new document with file content to a folder in the Knowledge Center.
    The parent folder must exist and be a valid folder type. The file content must
    be provided as a base64-encoded string.

    **Implementation**: Backed by DocumentHandler.uploadDocument()

    **Note**: Returns the created document with generated UUID and file size.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateDocumentRequest): Request body for uploading a new document

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Document | Error
    """

    return sync_detailed(
        client=client,
        body=body,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateDocumentRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Document | Error]:
    """Upload document

     Uploads a new document with file content to a folder in the Knowledge Center.
    The parent folder must exist and be a valid folder type. The file content must
    be provided as a base64-encoded string.

    **Implementation**: Backed by DocumentHandler.uploadDocument()

    **Note**: Returns the created document with generated UUID and file size.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateDocumentRequest): Request body for uploading a new document

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Document | Error]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateDocumentRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Document | Error | None:
    """Upload document

     Uploads a new document with file content to a folder in the Knowledge Center.
    The parent folder must exist and be a valid folder type. The file content must
    be provided as a base64-encoded string.

    **Implementation**: Backed by DocumentHandler.uploadDocument()

    **Note**: Returns the created document with generated UUID and file size.

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateDocumentRequest): Request body for uploading a new document

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Document | Error
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
