from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.error import Error
from ...models.paginated_group_list import PaginatedGroupList
from ...types import UNSET, Response, Unset


def _get_kwargs(
    app_uuid: str,
    *,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    params: dict[str, Any] = {}

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/applications/{app_uuid}/groups".format(
            app_uuid=quote(str(app_uuid), safe=""),
        ),
        "params": params,
    }

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Error | PaginatedGroupList | None:
    if response.status_code == 200:
        response_200 = PaginatedGroupList.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | PaginatedGroupList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | PaginatedGroupList]:
    """List groups with permissions in an application

     Retrieves a paginated list of groups that have permissions within a specific Appian application.
    Groups control access to application resources and define security roles.

    **Implementation**: Backed by GroupHandler.listApplicationGroups()

    Args:
        app_uuid (str):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | PaginatedGroupList]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | PaginatedGroupList | None:
    """List groups with permissions in an application

     Retrieves a paginated list of groups that have permissions within a specific Appian application.
    Groups control access to application resources and define security roles.

    **Implementation**: Backed by GroupHandler.listApplicationGroups()

    Args:
        app_uuid (str):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | PaginatedGroupList
    """

    return sync_detailed(
        app_uuid=app_uuid,
        client=client,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | PaginatedGroupList]:
    """List groups with permissions in an application

     Retrieves a paginated list of groups that have permissions within a specific Appian application.
    Groups control access to application resources and define security roles.

    **Implementation**: Backed by GroupHandler.listApplicationGroups()

    Args:
        app_uuid (str):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | PaginatedGroupList]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        limit=limit,
        offset=offset,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | PaginatedGroupList | None:
    """List groups with permissions in an application

     Retrieves a paginated list of groups that have permissions within a specific Appian application.
    Groups control access to application resources and define security roles.

    **Implementation**: Backed by GroupHandler.listApplicationGroups()

    Args:
        app_uuid (str):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        x_appian_api_version (str | Unset):  Example: 2026-01-08.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | PaginatedGroupList
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            client=client,
            limit=limit,
            offset=offset,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
