from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_expression_rule_request import CreateExpressionRuleRequest
from ...models.error import Error
from ...models.expression_rule import ExpressionRule
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: CreateExpressionRuleRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    if not isinstance(x_appian_api_version, Unset):
        headers["X-Appian-Api-Version"] = x_appian_api_version

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/expression-rules",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Error | ExpressionRule | None:
    if response.status_code == 201:
        response_201 = ExpressionRule.from_dict(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = Error.from_dict(response.json())

        return response_400

    if response.status_code == 500:
        response_500 = Error.from_dict(response.json())

        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Error | ExpressionRule]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateExpressionRuleRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | ExpressionRule]:
    """Create a new expression rule

     Creates a new Appian Expression Rule design object with the provided name, description,
    SAIL expression, and input parameters.

    **Implementation**: Backed by ExpressionRuleHandler.createExpressionRule()

    **Behavior**:
    - Creates expression rule in the rules root folder
    - Generates UUID automatically
    - Expression and inputs are optional (can be added later via PUT)
    - Expression rule is immediately available for use in Appian

    **Validation**:
    - Name is required and must be non-empty
    - Parameter names must be unique within the expression rule
    - Parameter type must be a valid Appian type

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateExpressionRuleRequest): Request body for creating a new expression rule.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the expression
            rule will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | ExpressionRule]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CreateExpressionRuleRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | ExpressionRule | None:
    """Create a new expression rule

     Creates a new Appian Expression Rule design object with the provided name, description,
    SAIL expression, and input parameters.

    **Implementation**: Backed by ExpressionRuleHandler.createExpressionRule()

    **Behavior**:
    - Creates expression rule in the rules root folder
    - Generates UUID automatically
    - Expression and inputs are optional (can be added later via PUT)
    - Expression rule is immediately available for use in Appian

    **Validation**:
    - Name is required and must be non-empty
    - Parameter names must be unique within the expression rule
    - Parameter type must be a valid Appian type

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateExpressionRuleRequest): Request body for creating a new expression rule.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the expression
            rule will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | ExpressionRule
    """

    return sync_detailed(
        client=client,
        body=body,
        x_appian_api_version=x_appian_api_version,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CreateExpressionRuleRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Response[Error | ExpressionRule]:
    """Create a new expression rule

     Creates a new Appian Expression Rule design object with the provided name, description,
    SAIL expression, and input parameters.

    **Implementation**: Backed by ExpressionRuleHandler.createExpressionRule()

    **Behavior**:
    - Creates expression rule in the rules root folder
    - Generates UUID automatically
    - Expression and inputs are optional (can be added later via PUT)
    - Expression rule is immediately available for use in Appian

    **Validation**:
    - Name is required and must be non-empty
    - Parameter names must be unique within the expression rule
    - Parameter type must be a valid Appian type

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateExpressionRuleRequest): Request body for creating a new expression rule.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the expression
            rule will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Error | ExpressionRule]
    """

    kwargs = _get_kwargs(
        body=body,
        x_appian_api_version=x_appian_api_version,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CreateExpressionRuleRequest,
    x_appian_api_version: str | Unset = UNSET,
) -> Error | ExpressionRule | None:
    """Create a new expression rule

     Creates a new Appian Expression Rule design object with the provided name, description,
    SAIL expression, and input parameters.

    **Implementation**: Backed by ExpressionRuleHandler.createExpressionRule()

    **Behavior**:
    - Creates expression rule in the rules root folder
    - Generates UUID automatically
    - Expression and inputs are optional (can be added later via PUT)
    - Expression rule is immediately available for use in Appian

    **Validation**:
    - Name is required and must be non-empty
    - Parameter names must be unique within the expression rule
    - Parameter type must be a valid Appian type

    Args:
        x_appian_api_version (str | Unset):  Example: 2026-01-08.
        body (CreateExpressionRuleRequest): Request body for creating a new expression rule.

            Either `parentFolderUuid` or `appUuid` must be provided to determine where the expression
            rule will be created.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Error | ExpressionRule
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            x_appian_api_version=x_appian_api_version,
        )
    ).parsed
