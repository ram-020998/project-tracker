from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.role_entry import RoleEntry


T = TypeVar("T", bound="SecurityUpdateRequest")


@_attrs_define
class SecurityUpdateRequest:
    """
    Attributes:
        roles (list[RoleEntry]):
        inherit_security (bool | Unset): For content-backed objects (constants, expression rules, interfaces, documents,
            folders), whether this object inherits security from its parent. Ignored for non-content objects.
             Default: True.
    """

    roles: list[RoleEntry]
    inherit_security: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        roles = []
        for roles_item_data in self.roles:
            roles_item = roles_item_data.to_dict()
            roles.append(roles_item)

        inherit_security = self.inherit_security

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "roles": roles,
            }
        )
        if inherit_security is not UNSET:
            field_dict["inheritSecurity"] = inherit_security

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.role_entry import RoleEntry

        d = dict(src_dict)
        roles = []
        _roles = d.pop("roles")
        for roles_item_data in _roles:
            roles_item = RoleEntry.from_dict(roles_item_data)

            roles.append(roles_item)

        inherit_security = d.pop("inheritSecurity", UNSET)

        security_update_request = cls(
            roles=roles,
            inherit_security=inherit_security,
        )

        security_update_request.additional_properties = d
        return security_update_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
