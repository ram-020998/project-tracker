from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="UpdateProcessModelRequestNameType1")


@_attrs_define
class UpdateProcessModelRequestNameType1:
    """Localized process model name (object). Keys are locale codes (e.g., en_US, de_DE, ja_JP), values are the localized
    names. Use this to provide names in multiple languages.

        Example:
            {'en_US': 'Updated Order Approval Process', 'de_DE': 'Aktualisierter Bestellgenehmigungsprozess', 'ja_JP':
                '更新された注文承認プロセス'}

    """

    additional_properties: dict[str, str] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        update_process_model_request_name_type_1 = cls()

        update_process_model_request_name_type_1.additional_properties = d
        return update_process_model_request_name_type_1

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> str:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: str) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
