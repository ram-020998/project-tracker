from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AddObjectsToApplicationResponse")


@_attrs_define
class AddObjectsToApplicationResponse:
    """
    Attributes:
        success (bool): True if all objects were added successfully, false if any errors occurred
        objects_added (int): Number of objects successfully added to the application
        message (str): Human-readable result message
        errors (list[str] | Unset): Array of error messages (only present if any objects failed to add)
    """

    success: bool
    objects_added: int
    message: str
    errors: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        success = self.success

        objects_added = self.objects_added

        message = self.message

        errors: list[str] | Unset = UNSET
        if not isinstance(self.errors, Unset):
            errors = self.errors

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "success": success,
                "objectsAdded": objects_added,
                "message": message,
            }
        )
        if errors is not UNSET:
            field_dict["errors"] = errors

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        success = d.pop("success")

        objects_added = d.pop("objectsAdded")

        message = d.pop("message")

        errors = cast(list[str], d.pop("errors", UNSET))

        add_objects_to_application_response = cls(
            success=success,
            objects_added=objects_added,
            message=message,
            errors=errors,
        )

        add_objects_to_application_response.additional_properties = d
        return add_objects_to_application_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
