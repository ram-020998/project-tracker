from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.web_api_request_body_type import WebApiRequestBodyType
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateWebAPIRequest")


@_attrs_define
class CreateWebAPIRequest:
    """
    Attributes:
        name (str):
        url_alias (str):
        http_method (str):
        description (None | str | Unset):
        expression (None | str | Unset):
        request_body_type (WebApiRequestBodyType | Unset): How the Web API handles request body content
        app_uuid (None | str | Unset): UUID of the application to add this Web API to (optional). When provided, the Web
            API is created and automatically added to the application.
    """

    name: str
    url_alias: str
    http_method: str
    description: None | str | Unset = UNSET
    expression: None | str | Unset = UNSET
    request_body_type: WebApiRequestBodyType | Unset = UNSET
    app_uuid: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        url_alias = self.url_alias

        http_method = self.http_method

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        expression: None | str | Unset
        if isinstance(self.expression, Unset):
            expression = UNSET
        else:
            expression = self.expression

        request_body_type: str | Unset = UNSET
        if not isinstance(self.request_body_type, Unset):
            request_body_type = self.request_body_type.value

        app_uuid: None | str | Unset
        if isinstance(self.app_uuid, Unset):
            app_uuid = UNSET
        else:
            app_uuid = self.app_uuid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "urlAlias": url_alias,
                "httpMethod": http_method,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if expression is not UNSET:
            field_dict["expression"] = expression
        if request_body_type is not UNSET:
            field_dict["requestBodyType"] = request_body_type
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        url_alias = d.pop("urlAlias")

        http_method = d.pop("httpMethod")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expression = _parse_expression(d.pop("expression", UNSET))

        _request_body_type = d.pop("requestBodyType", UNSET)
        request_body_type: WebApiRequestBodyType | Unset
        if isinstance(_request_body_type, Unset):
            request_body_type = UNSET
        else:
            request_body_type = WebApiRequestBodyType(_request_body_type)

        def _parse_app_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        app_uuid = _parse_app_uuid(d.pop("appUuid", UNSET))

        create_web_api_request = cls(
            name=name,
            url_alias=url_alias,
            http_method=http_method,
            description=description,
            expression=expression,
            request_body_type=request_body_type,
            app_uuid=app_uuid,
        )

        create_web_api_request.additional_properties = d
        return create_web_api_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
