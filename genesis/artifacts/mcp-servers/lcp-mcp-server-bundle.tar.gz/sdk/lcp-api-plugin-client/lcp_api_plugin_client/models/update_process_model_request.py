from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.form_config import FormConfig
    from ..models.process_model_lane import ProcessModelLane
    from ..models.process_model_node_input import ProcessModelNodeInput
    from ..models.process_variable_definition import ProcessVariableDefinition
    from ..models.update_process_model_request_description_type_1 import UpdateProcessModelRequestDescriptionType1
    from ..models.update_process_model_request_name_type_1 import UpdateProcessModelRequestNameType1


T = TypeVar("T", bound="UpdateProcessModelRequest")


@_attrs_define
class UpdateProcessModelRequest:
    """Request body for updating an existing process model. At least one field must be provided.
    Only the fields provided will be updated; other fields remain unchanged.

        Attributes:
            version_id (str | Unset): Version ID for optimistic concurrency control. If provided, validates against current
                version.
            name (str | Unset | UpdateProcessModelRequestNameType1): Process model name. Can be either a simple string (uses
                site primary locale) or a locale map for multi-language support. Cannot be empty if provided.
            description (str | Unset | UpdateProcessModelRequestDescriptionType1): Process model description. Can be either
                a simple string (uses site primary locale) or a locale map for multi-language support.
            process_variables (list[ProcessVariableDefinition] | Unset): Process variables (PVs) - replaces all existing
                variables
            nodes (list[ProcessModelNodeInput] | Unset): Process model nodes - replaces all existing nodes
            start_form (FormConfig | None | Unset): Start form configuration. Set to null to clear. Omit to preserve current
                value.
            lanes (list[ProcessModelLane] | None | Unset): Replaces all existing lanes. Node lane indices should reference
                the updated array.
    """

    version_id: str | Unset = UNSET
    name: str | Unset | UpdateProcessModelRequestNameType1 = UNSET
    description: str | Unset | UpdateProcessModelRequestDescriptionType1 = UNSET
    process_variables: list[ProcessVariableDefinition] | Unset = UNSET
    nodes: list[ProcessModelNodeInput] | Unset = UNSET
    start_form: FormConfig | None | Unset = UNSET
    lanes: list[ProcessModelLane] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.form_config import FormConfig
        from ..models.update_process_model_request_description_type_1 import UpdateProcessModelRequestDescriptionType1
        from ..models.update_process_model_request_name_type_1 import UpdateProcessModelRequestNameType1

        version_id = self.version_id

        name: dict[str, Any] | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        elif isinstance(self.name, UpdateProcessModelRequestNameType1):
            name = self.name.to_dict()
        else:
            name = self.name

        description: dict[str, Any] | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        elif isinstance(self.description, UpdateProcessModelRequestDescriptionType1):
            description = self.description.to_dict()
        else:
            description = self.description

        process_variables: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.process_variables, Unset):
            process_variables = []
            for process_variables_item_data in self.process_variables:
                process_variables_item = process_variables_item_data.to_dict()
                process_variables.append(process_variables_item)

        nodes: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.nodes, Unset):
            nodes = []
            for nodes_item_data in self.nodes:
                nodes_item = nodes_item_data.to_dict()
                nodes.append(nodes_item)

        start_form: dict[str, Any] | None | Unset
        if isinstance(self.start_form, Unset):
            start_form = UNSET
        elif isinstance(self.start_form, FormConfig):
            start_form = self.start_form.to_dict()
        else:
            start_form = self.start_form

        lanes: list[dict[str, Any]] | None | Unset
        if isinstance(self.lanes, Unset):
            lanes = UNSET
        elif isinstance(self.lanes, list):
            lanes = []
            for lanes_type_0_item_data in self.lanes:
                lanes_type_0_item = lanes_type_0_item_data.to_dict()
                lanes.append(lanes_type_0_item)

        else:
            lanes = self.lanes

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if process_variables is not UNSET:
            field_dict["processVariables"] = process_variables
        if nodes is not UNSET:
            field_dict["nodes"] = nodes
        if start_form is not UNSET:
            field_dict["startForm"] = start_form
        if lanes is not UNSET:
            field_dict["lanes"] = lanes

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.form_config import FormConfig
        from ..models.process_model_lane import ProcessModelLane
        from ..models.process_model_node_input import ProcessModelNodeInput
        from ..models.process_variable_definition import ProcessVariableDefinition
        from ..models.update_process_model_request_description_type_1 import UpdateProcessModelRequestDescriptionType1
        from ..models.update_process_model_request_name_type_1 import UpdateProcessModelRequestNameType1

        d = dict(src_dict)
        version_id = d.pop("versionId", UNSET)

        def _parse_name(data: object) -> str | Unset | UpdateProcessModelRequestNameType1:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                name_type_1 = UpdateProcessModelRequestNameType1.from_dict(data)

                return name_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(str | Unset | UpdateProcessModelRequestNameType1, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_description(data: object) -> str | Unset | UpdateProcessModelRequestDescriptionType1:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                description_type_1 = UpdateProcessModelRequestDescriptionType1.from_dict(data)

                return description_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(str | Unset | UpdateProcessModelRequestDescriptionType1, data)

        description = _parse_description(d.pop("description", UNSET))

        _process_variables = d.pop("processVariables", UNSET)
        process_variables: list[ProcessVariableDefinition] | Unset = UNSET
        if _process_variables is not UNSET:
            process_variables = []
            for process_variables_item_data in _process_variables:
                process_variables_item = ProcessVariableDefinition.from_dict(process_variables_item_data)

                process_variables.append(process_variables_item)

        _nodes = d.pop("nodes", UNSET)
        nodes: list[ProcessModelNodeInput] | Unset = UNSET
        if _nodes is not UNSET:
            nodes = []
            for nodes_item_data in _nodes:
                nodes_item = ProcessModelNodeInput.from_dict(nodes_item_data)

                nodes.append(nodes_item)

        def _parse_start_form(data: object) -> FormConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                start_form_type_1 = FormConfig.from_dict(data)

                return start_form_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(FormConfig | None | Unset, data)

        start_form = _parse_start_form(d.pop("startForm", UNSET))

        def _parse_lanes(data: object) -> list[ProcessModelLane] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                lanes_type_0 = []
                _lanes_type_0 = data
                for lanes_type_0_item_data in _lanes_type_0:
                    lanes_type_0_item = ProcessModelLane.from_dict(lanes_type_0_item_data)

                    lanes_type_0.append(lanes_type_0_item)

                return lanes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ProcessModelLane] | None | Unset, data)

        lanes = _parse_lanes(d.pop("lanes", UNSET))

        update_process_model_request = cls(
            version_id=version_id,
            name=name,
            description=description,
            process_variables=process_variables,
            nodes=nodes,
            start_form=start_form,
            lanes=lanes,
        )

        update_process_model_request.additional_properties = d
        return update_process_model_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
