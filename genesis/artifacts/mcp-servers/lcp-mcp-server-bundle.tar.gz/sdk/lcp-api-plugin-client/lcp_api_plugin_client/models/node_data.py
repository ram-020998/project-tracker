from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.node_input_output import NodeInputOutput


T = TypeVar("T", bound="NodeData")


@_attrs_define
class NodeData:
    """Activity node data (Data tab) — inputs, outputs, and custom parameters.

    Attributes:
        inputs (list[NodeInputOutput] | None | Unset): Schema-defined input ACPs (partial update on write)
        custom_inputs (list[NodeInputOutput] | None | Unset): Custom input ACPs (full replacement on write)
        outputs (list[NodeInputOutput] | None | Unset): Schema-defined output ACPs (partial update on write)
        custom_outputs (list[NodeInputOutput] | None | Unset): Custom output ACPs (full replacement on write)
    """

    inputs: list[NodeInputOutput] | None | Unset = UNSET
    custom_inputs: list[NodeInputOutput] | None | Unset = UNSET
    outputs: list[NodeInputOutput] | None | Unset = UNSET
    custom_outputs: list[NodeInputOutput] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        inputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.inputs, Unset):
            inputs = UNSET
        elif isinstance(self.inputs, list):
            inputs = []
            for inputs_type_0_item_data in self.inputs:
                inputs_type_0_item = inputs_type_0_item_data.to_dict()
                inputs.append(inputs_type_0_item)

        else:
            inputs = self.inputs

        custom_inputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.custom_inputs, Unset):
            custom_inputs = UNSET
        elif isinstance(self.custom_inputs, list):
            custom_inputs = []
            for custom_inputs_type_0_item_data in self.custom_inputs:
                custom_inputs_type_0_item = custom_inputs_type_0_item_data.to_dict()
                custom_inputs.append(custom_inputs_type_0_item)

        else:
            custom_inputs = self.custom_inputs

        outputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.outputs, Unset):
            outputs = UNSET
        elif isinstance(self.outputs, list):
            outputs = []
            for outputs_type_0_item_data in self.outputs:
                outputs_type_0_item = outputs_type_0_item_data.to_dict()
                outputs.append(outputs_type_0_item)

        else:
            outputs = self.outputs

        custom_outputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.custom_outputs, Unset):
            custom_outputs = UNSET
        elif isinstance(self.custom_outputs, list):
            custom_outputs = []
            for custom_outputs_type_0_item_data in self.custom_outputs:
                custom_outputs_type_0_item = custom_outputs_type_0_item_data.to_dict()
                custom_outputs.append(custom_outputs_type_0_item)

        else:
            custom_outputs = self.custom_outputs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if inputs is not UNSET:
            field_dict["inputs"] = inputs
        if custom_inputs is not UNSET:
            field_dict["customInputs"] = custom_inputs
        if outputs is not UNSET:
            field_dict["outputs"] = outputs
        if custom_outputs is not UNSET:
            field_dict["customOutputs"] = custom_outputs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.node_input_output import NodeInputOutput

        d = dict(src_dict)

        def _parse_inputs(data: object) -> list[NodeInputOutput] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                inputs_type_0 = []
                _inputs_type_0 = data
                for inputs_type_0_item_data in _inputs_type_0:
                    inputs_type_0_item = NodeInputOutput.from_dict(inputs_type_0_item_data)

                    inputs_type_0.append(inputs_type_0_item)

                return inputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[NodeInputOutput] | None | Unset, data)

        inputs = _parse_inputs(d.pop("inputs", UNSET))

        def _parse_custom_inputs(data: object) -> list[NodeInputOutput] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                custom_inputs_type_0 = []
                _custom_inputs_type_0 = data
                for custom_inputs_type_0_item_data in _custom_inputs_type_0:
                    custom_inputs_type_0_item = NodeInputOutput.from_dict(custom_inputs_type_0_item_data)

                    custom_inputs_type_0.append(custom_inputs_type_0_item)

                return custom_inputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[NodeInputOutput] | None | Unset, data)

        custom_inputs = _parse_custom_inputs(d.pop("customInputs", UNSET))

        def _parse_outputs(data: object) -> list[NodeInputOutput] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                outputs_type_0 = []
                _outputs_type_0 = data
                for outputs_type_0_item_data in _outputs_type_0:
                    outputs_type_0_item = NodeInputOutput.from_dict(outputs_type_0_item_data)

                    outputs_type_0.append(outputs_type_0_item)

                return outputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[NodeInputOutput] | None | Unset, data)

        outputs = _parse_outputs(d.pop("outputs", UNSET))

        def _parse_custom_outputs(data: object) -> list[NodeInputOutput] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                custom_outputs_type_0 = []
                _custom_outputs_type_0 = data
                for custom_outputs_type_0_item_data in _custom_outputs_type_0:
                    custom_outputs_type_0_item = NodeInputOutput.from_dict(custom_outputs_type_0_item_data)

                    custom_outputs_type_0.append(custom_outputs_type_0_item)

                return custom_outputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[NodeInputOutput] | None | Unset, data)

        custom_outputs = _parse_custom_outputs(d.pop("customOutputs", UNSET))

        node_data = cls(
            inputs=inputs,
            custom_inputs=custom_inputs,
            outputs=outputs,
            custom_outputs=custom_outputs,
        )

        node_data.additional_properties = d
        return node_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
