from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.constant_type import ConstantType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rest_metadata_type_0 import RestMetadataType0


T = TypeVar("T", bound="Constant")


@_attrs_define
class Constant:
    """An Appian Constant design object. Constants are reusable values that can be
    referenced throughout an Appian application, providing a centralized way to
    manage configuration values and reference data.

    **Implementation**: Backed by ConstantFunctions and uses the Constant class
    (not FreeformRule) with TypedValue storage.

        Attributes:
            uuid (str): Appian UUID for the constant in Appian's custom format.
                This is NOT a standard UUID and cannot be parsed by standard UUID libraries.
                 Example: _a-0000ed97-98a4-8000-9bb5-011c48011c48_105467.
            name (str): Constant name (typically uppercase with underscores) Example: MAX_RETRY_COUNT.
            type_ (ConstantType): The data type of the constant value. Must be one of the supported types.
                 Example: INTEGER.
            value (bool | float | int | list[float | int | str] | str): The actual value stored in the constant. The type of
                this value depends
                on the constant's type field:
                - TEXT: string
                - NUMBER: number (decimal)
                - INTEGER: integer
                - BOOLEAN: boolean
                - DATE: string (ISO date format)
                - DATETIME: string (ISO datetime format)
                - TIME: string (ISO time format)
                - USER: string (username)
                - GROUP: integer (group ID)
                - FOLDER: integer (folder ID)
                - DOCUMENT: integer (document ID)
                - PROCESS_MODEL: process model UUID string
                 Example: 3.
            description (str | Unset): Human-readable description (empty string if not provided) Example: Maximum number of
                retry attempts.
            multiple (bool | Unset): True if this is a list-typed constant (e.g., List of Text).
            parent_folder_uuid (None | str | Unset): UUID of the parent folder (rules root folder) Example:
                _a-0000ed97-98a4-8000-9bb5-011c48011c48_100001.
            version_id (None | str | Unset): Version ID for optimistic concurrency control. Include in PUT/DELETE requests
                to prevent stale writes.
            field_rest (None | RestMetadataType0 | Unset): Response metadata including the Designer URL for this object.
                Present on get, create, and update responses for design objects.
    """

    uuid: str
    name: str
    type_: ConstantType
    value: bool | float | int | list[float | int | str] | str
    description: str | Unset = UNSET
    multiple: bool | Unset = UNSET
    parent_folder_uuid: None | str | Unset = UNSET
    version_id: None | str | Unset = UNSET
    field_rest: None | RestMetadataType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rest_metadata_type_0 import RestMetadataType0

        uuid = self.uuid

        name = self.name

        type_ = self.type_.value

        value: bool | float | int | list[float | int | str] | str
        if isinstance(self.value, list):
            value = []
            for value_type_4_item_data in self.value:
                value_type_4_item: float | int | str
                value_type_4_item = value_type_4_item_data
                value.append(value_type_4_item)

        else:
            value = self.value

        description = self.description

        multiple = self.multiple

        parent_folder_uuid: None | str | Unset
        if isinstance(self.parent_folder_uuid, Unset):
            parent_folder_uuid = UNSET
        else:
            parent_folder_uuid = self.parent_folder_uuid

        version_id: None | str | Unset
        if isinstance(self.version_id, Unset):
            version_id = UNSET
        else:
            version_id = self.version_id

        field_rest: dict[str, Any] | None | Unset
        if isinstance(self.field_rest, Unset):
            field_rest = UNSET
        elif isinstance(self.field_rest, RestMetadataType0):
            field_rest = self.field_rest.to_dict()
        else:
            field_rest = self.field_rest

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "name": name,
                "type": type_,
                "value": value,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if multiple is not UNSET:
            field_dict["multiple"] = multiple
        if parent_folder_uuid is not UNSET:
            field_dict["parentFolderUuid"] = parent_folder_uuid
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if field_rest is not UNSET:
            field_dict["_rest"] = field_rest

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rest_metadata_type_0 import RestMetadataType0

        d = dict(src_dict)
        uuid = d.pop("uuid")

        name = d.pop("name")

        type_ = ConstantType(d.pop("type"))

        def _parse_value(data: object) -> bool | float | int | list[float | int | str] | str:
            try:
                if not isinstance(data, list):
                    raise TypeError()
                value_type_4 = []
                _value_type_4 = data
                for value_type_4_item_data in _value_type_4:

                    def _parse_value_type_4_item(data: object) -> float | int | str:
                        return cast(float | int | str, data)

                    value_type_4_item = _parse_value_type_4_item(value_type_4_item_data)

                    value_type_4.append(value_type_4_item)

                return value_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(bool | float | int | list[float | int | str] | str, data)

        value = _parse_value(d.pop("value"))

        description = d.pop("description", UNSET)

        multiple = d.pop("multiple", UNSET)

        def _parse_parent_folder_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_folder_uuid = _parse_parent_folder_uuid(d.pop("parentFolderUuid", UNSET))

        def _parse_version_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version_id = _parse_version_id(d.pop("versionId", UNSET))

        def _parse_field_rest(data: object) -> None | RestMetadataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_rest_metadata_type_0 = RestMetadataType0.from_dict(data)

                return componentsschemas_rest_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RestMetadataType0 | Unset, data)

        field_rest = _parse_field_rest(d.pop("_rest", UNSET))

        constant = cls(
            uuid=uuid,
            name=name,
            type_=type_,
            value=value,
            description=description,
            multiple=multiple,
            parent_folder_uuid=parent_folder_uuid,
            version_id=version_id,
            field_rest=field_rest,
        )

        constant.additional_properties = d
        return constant

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
