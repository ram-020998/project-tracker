from enum import Enum


class RecordActionDialogHeight(str, Enum):
    AUTO = "AUTO"
    EXTRA_TALL = "EXTRA_TALL"
    FIT = "FIT"
    MEDIUM = "MEDIUM"
    SHORT = "SHORT"
    TALL = "TALL"

    def __str__(self) -> str:
        return str(self.value)
