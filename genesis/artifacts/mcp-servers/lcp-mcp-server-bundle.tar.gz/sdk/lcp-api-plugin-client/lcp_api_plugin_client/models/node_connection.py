from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="NodeConnection")


@_attrs_define
class NodeConnection:
    """An outgoing connection (flow/arrow) from a process node to a target node.
    Direction is always from the owning node to `targetNodeId`.

        Attributes:
            target_node_id (int): ID of the node this connection points to. Must already exist in the process model.
                Example: 2.
            activity_chained (bool): Whether the flow is activity-chained. When true, on form submit the engine follows
                this connection and runs the next node synchronously while the user waits — as if part
                of a wizard — until the process ends, a non-chained connection is reached, or another
                attended node is encountered. Required so the connection's chaining behavior is always
                an explicit decision.
            overrides_assignment (bool | Unset): When chained, whether to override the assignment of the next attended
                activity so it
                is shown to the current user. Only meaningful when `activityChained` is true.
                 Default: False.
            synchronize_data (bool | Unset): Whether to synchronize process variables across this flow. Default: False.
            label (str | Unset): Optional flow label shown on the connection. Example: Approved.
    """

    target_node_id: int
    activity_chained: bool
    overrides_assignment: bool | Unset = False
    synchronize_data: bool | Unset = False
    label: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        target_node_id = self.target_node_id

        activity_chained = self.activity_chained

        overrides_assignment = self.overrides_assignment

        synchronize_data = self.synchronize_data

        label = self.label

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "targetNodeId": target_node_id,
                "activityChained": activity_chained,
            }
        )
        if overrides_assignment is not UNSET:
            field_dict["overridesAssignment"] = overrides_assignment
        if synchronize_data is not UNSET:
            field_dict["synchronizeData"] = synchronize_data
        if label is not UNSET:
            field_dict["label"] = label

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        target_node_id = d.pop("targetNodeId")

        activity_chained = d.pop("activityChained")

        overrides_assignment = d.pop("overridesAssignment", UNSET)

        synchronize_data = d.pop("synchronizeData", UNSET)

        label = d.pop("label", UNSET)

        node_connection = cls(
            target_node_id=target_node_id,
            activity_chained=activity_chained,
            overrides_assignment=overrides_assignment,
            synchronize_data=synchronize_data,
            label=label,
        )

        node_connection.additional_properties = d
        return node_connection

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
