from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_record_type_request_source_type import CreateRecordTypeRequestSourceType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.record_type_field_definition import RecordTypeFieldDefinition


T = TypeVar("T", bound="CreateRecordTypeRequest")


@_attrs_define
class CreateRecordTypeRequest:
    """Request body for creating a new record type with flattened source configuration.

    Attributes:
        name (str): The singular name of the record type Example: Customer.
        source_type (CreateRecordTypeRequestSourceType): The type of data source. DATABASE connects to or creates a
            database table (use createTable to control DDL). Example: DATABASE.
        create_table (bool | Unset): When true, Appian creates the database table (mirrors the 'Create Table' checkbox
            in Appian Designer). When false, returns an error — non-CDM tables are not yet supported. Default: True.
            Example: True.
        table_name (str | Unset): CDM: table name to create (defaults to snake_case of record type name). DATABASE:
            existing table name to connect to. Example: customers.
        data_source_uuid (str | Unset): DATABASE: UUID of the data source containing the table. CDM: auto-resolved if
            omitted. Example: jdbc/Appian.
        schema (str | Unset): DATABASE: schema name. CDM: auto-resolved if omitted. Example: public.
        description (str | Unset): A text description of the record type's purpose Example: Customer records.
        plural_name (str | Unset): The plural form of the record type name (auto-derived if not provided) Example:
            Customers.
        app_uuid (str | Unset): Application UUID (optional). When provided, the record type is added to the application
            and is given the same security role map. Example: app-uuid-123.
        fields (list[RecordTypeFieldDefinition] | Unset): Field definitions for the record type
    """

    name: str
    source_type: CreateRecordTypeRequestSourceType
    create_table: bool | Unset = True
    table_name: str | Unset = UNSET
    data_source_uuid: str | Unset = UNSET
    schema: str | Unset = UNSET
    description: str | Unset = UNSET
    plural_name: str | Unset = UNSET
    app_uuid: str | Unset = UNSET
    fields: list[RecordTypeFieldDefinition] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        source_type = self.source_type.value

        create_table = self.create_table

        table_name = self.table_name

        data_source_uuid = self.data_source_uuid

        schema = self.schema

        description = self.description

        plural_name = self.plural_name

        app_uuid = self.app_uuid

        fields: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.fields, Unset):
            fields = []
            for fields_item_data in self.fields:
                fields_item = fields_item_data.to_dict()
                fields.append(fields_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "sourceType": source_type,
            }
        )
        if create_table is not UNSET:
            field_dict["createTable"] = create_table
        if table_name is not UNSET:
            field_dict["tableName"] = table_name
        if data_source_uuid is not UNSET:
            field_dict["dataSourceUuid"] = data_source_uuid
        if schema is not UNSET:
            field_dict["schema"] = schema
        if description is not UNSET:
            field_dict["description"] = description
        if plural_name is not UNSET:
            field_dict["pluralName"] = plural_name
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid
        if fields is not UNSET:
            field_dict["fields"] = fields

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.record_type_field_definition import RecordTypeFieldDefinition

        d = dict(src_dict)
        name = d.pop("name")

        source_type = CreateRecordTypeRequestSourceType(d.pop("sourceType"))

        create_table = d.pop("createTable", UNSET)

        table_name = d.pop("tableName", UNSET)

        data_source_uuid = d.pop("dataSourceUuid", UNSET)

        schema = d.pop("schema", UNSET)

        description = d.pop("description", UNSET)

        plural_name = d.pop("pluralName", UNSET)

        app_uuid = d.pop("appUuid", UNSET)

        _fields = d.pop("fields", UNSET)
        fields: list[RecordTypeFieldDefinition] | Unset = UNSET
        if _fields is not UNSET:
            fields = []
            for fields_item_data in _fields:
                fields_item = RecordTypeFieldDefinition.from_dict(fields_item_data)

                fields.append(fields_item)

        create_record_type_request = cls(
            name=name,
            source_type=source_type,
            create_table=create_table,
            table_name=table_name,
            data_source_uuid=data_source_uuid,
            schema=schema,
            description=description,
            plural_name=plural_name,
            app_uuid=app_uuid,
            fields=fields,
        )

        create_record_type_request.additional_properties = d
        return create_record_type_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
