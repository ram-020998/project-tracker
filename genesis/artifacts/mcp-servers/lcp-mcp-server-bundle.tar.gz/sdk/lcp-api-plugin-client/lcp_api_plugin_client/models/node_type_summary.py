from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.node_type_summary_assignment import NodeTypeSummaryAssignment
from ..models.node_type_summary_category import NodeTypeSummaryCategory
from ..types import UNSET, Unset

T = TypeVar("T", bound="NodeTypeSummary")


@_attrs_define
class NodeTypeSummary:
    """Summary of an available node type.

    Attributes:
        type_ (str | Unset): Schema local ID (e.g., "internal3.sendemail3")
        type_name (str | Unset): Display name (e.g., "Send E-Mail")
        category (NodeTypeSummaryCategory | Unset):
        assignment (NodeTypeSummaryAssignment | Unset):
        deprecated (bool | Unset): True if this node type is deprecated. Prefer the non-deprecated equivalent.
    """

    type_: str | Unset = UNSET
    type_name: str | Unset = UNSET
    category: NodeTypeSummaryCategory | Unset = UNSET
    assignment: NodeTypeSummaryAssignment | Unset = UNSET
    deprecated: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        type_name = self.type_name

        category: str | Unset = UNSET
        if not isinstance(self.category, Unset):
            category = self.category.value

        assignment: str | Unset = UNSET
        if not isinstance(self.assignment, Unset):
            assignment = self.assignment.value

        deprecated = self.deprecated

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if type_name is not UNSET:
            field_dict["typeName"] = type_name
        if category is not UNSET:
            field_dict["category"] = category
        if assignment is not UNSET:
            field_dict["assignment"] = assignment
        if deprecated is not UNSET:
            field_dict["deprecated"] = deprecated

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = d.pop("type", UNSET)

        type_name = d.pop("typeName", UNSET)

        _category = d.pop("category", UNSET)
        category: NodeTypeSummaryCategory | Unset
        if isinstance(_category, Unset):
            category = UNSET
        else:
            category = NodeTypeSummaryCategory(_category)

        _assignment = d.pop("assignment", UNSET)
        assignment: NodeTypeSummaryAssignment | Unset
        if isinstance(_assignment, Unset):
            assignment = UNSET
        else:
            assignment = NodeTypeSummaryAssignment(_assignment)

        deprecated = d.pop("deprecated", UNSET)

        node_type_summary = cls(
            type_=type_,
            type_name=type_name,
            category=category,
            assignment=assignment,
            deprecated=deprecated,
        )

        node_type_summary.additional_properties = d
        return node_type_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
