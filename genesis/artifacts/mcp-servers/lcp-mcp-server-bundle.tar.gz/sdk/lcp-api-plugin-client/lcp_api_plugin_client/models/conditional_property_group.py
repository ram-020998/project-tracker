from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.conditional_property_group_when import ConditionalPropertyGroupWhen
    from ..models.property_descriptor import PropertyDescriptor


T = TypeVar("T", bound="ConditionalPropertyGroup")


@_attrs_define
class ConditionalPropertyGroup:
    """A conditional branch of properties that applies when a condition is met.

    Attributes:
        when (ConditionalPropertyGroupWhen): Condition map (e.g., {"authType": "API_KEY"}) Example: {'authType':
            'API_KEY'}.
        properties (list[PropertyDescriptor]): Properties available when the condition is met
    """

    when: ConditionalPropertyGroupWhen
    properties: list[PropertyDescriptor]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        when = self.when.to_dict()

        properties = []
        for properties_item_data in self.properties:
            properties_item = properties_item_data.to_dict()
            properties.append(properties_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "when": when,
                "properties": properties,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.conditional_property_group_when import ConditionalPropertyGroupWhen
        from ..models.property_descriptor import PropertyDescriptor

        d = dict(src_dict)
        when = ConditionalPropertyGroupWhen.from_dict(d.pop("when"))

        properties = []
        _properties = d.pop("properties")
        for properties_item_data in _properties:
            properties_item = PropertyDescriptor.from_dict(properties_item_data)

            properties.append(properties_item)

        conditional_property_group = cls(
            when=when,
            properties=properties,
        )

        conditional_property_group.additional_properties = d
        return conditional_property_group

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
