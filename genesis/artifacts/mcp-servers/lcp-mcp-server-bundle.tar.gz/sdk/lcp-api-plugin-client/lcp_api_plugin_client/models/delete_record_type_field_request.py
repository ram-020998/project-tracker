from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="DeleteRecordTypeFieldRequest")


@_attrs_define
class DeleteRecordTypeFieldRequest:
    """Request body for deleting a field from a record type.

    Attributes:
        update_table (bool | Unset): When true, Appian ALTERs the database table to drop the column (mirrors the 'Update
            Table' checkbox in Appian Designer). When false, returns an error — non-CDM operations are not yet supported.
            Default: True. Example: True.
    """

    update_table: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        update_table = self.update_table

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if update_table is not UNSET:
            field_dict["updateTable"] = update_table

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        update_table = d.pop("updateTable", UNSET)

        delete_record_type_field_request = cls(
            update_table=update_table,
        )

        delete_record_type_field_request.additional_properties = d
        return delete_record_type_field_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
