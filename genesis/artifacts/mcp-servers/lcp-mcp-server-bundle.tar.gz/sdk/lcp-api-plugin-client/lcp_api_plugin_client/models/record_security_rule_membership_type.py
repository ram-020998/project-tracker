from enum import Enum


class RecordSecurityRuleMembershipType(str, Enum):
    FIELDS = "FIELDS"
    GROUPS = "GROUPS"
    RELATED_RECORDS = "RELATED_RECORDS"

    def __str__(self) -> str:
        return str(self.value)
