from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.record_type_source_type import RecordTypeSourceType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.record_security_rule import RecordSecurityRule
    from ..models.record_type_field_detail import RecordTypeFieldDetail
    from ..models.record_type_relationship_detail import RecordTypeRelationshipDetail
    from ..models.rest_metadata_type_0 import RestMetadataType0


T = TypeVar("T", bound="RecordType")


@_attrs_define
class RecordType:
    """Comprehensive record type metadata

    Attributes:
        uuid (str | Unset): The universally unique identifier of the record type Example: abc-123-def-456.
        name (str | Unset): The display name of the record type Example: Customer.
        description (None | str | Unset): A text description of the record type's purpose Example: Customer records.
        plural_name (None | str | Unset): The plural form of the record type name Example: Customers.
        type_reference (None | str | Unset): Type reference string for this record type, usable as the `type` field when
            creating expression rule inputs, interface inputs, or process model variables. Format:
            {urn:com:appian:recordtype:datatype}<uuid>. Null if the type reference cannot be resolved.
             Example: {urn:com:appian:recordtype:datatype}abc-123-def-456.
        source_type (RecordTypeSourceType | Unset): The type of data source backing this record type Example: DATABASE.
        table_name (None | str | Unset): Database table name. Only present for DATABASE-backed record types. Example:
            customer.
        data_source_uuid (None | str | Unset): Data source UUID. Only present for DATABASE-backed record types. Example:
            jdbc/Appian.
        schema (None | str | Unset): Database schema name. Only present when explicitly set. Example: public.
        fields (list[RecordTypeFieldDetail] | None | Unset): All source and custom fields defined on this record type
        relationships (list[RecordTypeRelationshipDetail] | None | Unset): Relationships to other record types
        has_record_events (bool | Unset): Whether this record type has record events configured
        security_rules (list[RecordSecurityRule] | None | Unset): Record-level security rules in evaluation order (first
            match wins), or null if none configured
        security_expression (None | str | Unset): SAIL expression for record-level security, or null if not configured
        title_expression (None | str | Unset): SAIL expression for the record title, or null if not configured
        hide_record_header (bool | None | Unset): Whether the default record header is hidden on record views. Null if
            no detail view is configured.
        hide_news_view (bool | Unset): Whether the News view tab is hidden on this record type.
        hide_related_actions_view (bool | Unset): Whether the Related Actions view tab is hidden on this record type.
        version_id (None | str | Unset): Version ID for optimistic concurrency control. Include in PUT/DELETE requests
            to prevent stale writes.
        field_rest (None | RestMetadataType0 | Unset): Response metadata including the Designer URL for this object.
            Present on get, create, and update responses for design objects.
    """

    uuid: str | Unset = UNSET
    name: str | Unset = UNSET
    description: None | str | Unset = UNSET
    plural_name: None | str | Unset = UNSET
    type_reference: None | str | Unset = UNSET
    source_type: RecordTypeSourceType | Unset = UNSET
    table_name: None | str | Unset = UNSET
    data_source_uuid: None | str | Unset = UNSET
    schema: None | str | Unset = UNSET
    fields: list[RecordTypeFieldDetail] | None | Unset = UNSET
    relationships: list[RecordTypeRelationshipDetail] | None | Unset = UNSET
    has_record_events: bool | Unset = UNSET
    security_rules: list[RecordSecurityRule] | None | Unset = UNSET
    security_expression: None | str | Unset = UNSET
    title_expression: None | str | Unset = UNSET
    hide_record_header: bool | None | Unset = UNSET
    hide_news_view: bool | Unset = UNSET
    hide_related_actions_view: bool | Unset = UNSET
    version_id: None | str | Unset = UNSET
    field_rest: None | RestMetadataType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rest_metadata_type_0 import RestMetadataType0

        uuid = self.uuid

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        plural_name: None | str | Unset
        if isinstance(self.plural_name, Unset):
            plural_name = UNSET
        else:
            plural_name = self.plural_name

        type_reference: None | str | Unset
        if isinstance(self.type_reference, Unset):
            type_reference = UNSET
        else:
            type_reference = self.type_reference

        source_type: str | Unset = UNSET
        if not isinstance(self.source_type, Unset):
            source_type = self.source_type.value

        table_name: None | str | Unset
        if isinstance(self.table_name, Unset):
            table_name = UNSET
        else:
            table_name = self.table_name

        data_source_uuid: None | str | Unset
        if isinstance(self.data_source_uuid, Unset):
            data_source_uuid = UNSET
        else:
            data_source_uuid = self.data_source_uuid

        schema: None | str | Unset
        if isinstance(self.schema, Unset):
            schema = UNSET
        else:
            schema = self.schema

        fields: list[dict[str, Any]] | None | Unset
        if isinstance(self.fields, Unset):
            fields = UNSET
        elif isinstance(self.fields, list):
            fields = []
            for fields_type_0_item_data in self.fields:
                fields_type_0_item = fields_type_0_item_data.to_dict()
                fields.append(fields_type_0_item)

        else:
            fields = self.fields

        relationships: list[dict[str, Any]] | None | Unset
        if isinstance(self.relationships, Unset):
            relationships = UNSET
        elif isinstance(self.relationships, list):
            relationships = []
            for relationships_type_0_item_data in self.relationships:
                relationships_type_0_item = relationships_type_0_item_data.to_dict()
                relationships.append(relationships_type_0_item)

        else:
            relationships = self.relationships

        has_record_events = self.has_record_events

        security_rules: list[dict[str, Any]] | None | Unset
        if isinstance(self.security_rules, Unset):
            security_rules = UNSET
        elif isinstance(self.security_rules, list):
            security_rules = []
            for security_rules_type_0_item_data in self.security_rules:
                security_rules_type_0_item = security_rules_type_0_item_data.to_dict()
                security_rules.append(security_rules_type_0_item)

        else:
            security_rules = self.security_rules

        security_expression: None | str | Unset
        if isinstance(self.security_expression, Unset):
            security_expression = UNSET
        else:
            security_expression = self.security_expression

        title_expression: None | str | Unset
        if isinstance(self.title_expression, Unset):
            title_expression = UNSET
        else:
            title_expression = self.title_expression

        hide_record_header: bool | None | Unset
        if isinstance(self.hide_record_header, Unset):
            hide_record_header = UNSET
        else:
            hide_record_header = self.hide_record_header

        hide_news_view = self.hide_news_view

        hide_related_actions_view = self.hide_related_actions_view

        version_id: None | str | Unset
        if isinstance(self.version_id, Unset):
            version_id = UNSET
        else:
            version_id = self.version_id

        field_rest: dict[str, Any] | None | Unset
        if isinstance(self.field_rest, Unset):
            field_rest = UNSET
        elif isinstance(self.field_rest, RestMetadataType0):
            field_rest = self.field_rest.to_dict()
        else:
            field_rest = self.field_rest

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if plural_name is not UNSET:
            field_dict["pluralName"] = plural_name
        if type_reference is not UNSET:
            field_dict["typeReference"] = type_reference
        if source_type is not UNSET:
            field_dict["sourceType"] = source_type
        if table_name is not UNSET:
            field_dict["tableName"] = table_name
        if data_source_uuid is not UNSET:
            field_dict["dataSourceUuid"] = data_source_uuid
        if schema is not UNSET:
            field_dict["schema"] = schema
        if fields is not UNSET:
            field_dict["fields"] = fields
        if relationships is not UNSET:
            field_dict["relationships"] = relationships
        if has_record_events is not UNSET:
            field_dict["hasRecordEvents"] = has_record_events
        if security_rules is not UNSET:
            field_dict["securityRules"] = security_rules
        if security_expression is not UNSET:
            field_dict["securityExpression"] = security_expression
        if title_expression is not UNSET:
            field_dict["titleExpression"] = title_expression
        if hide_record_header is not UNSET:
            field_dict["hideRecordHeader"] = hide_record_header
        if hide_news_view is not UNSET:
            field_dict["hideNewsView"] = hide_news_view
        if hide_related_actions_view is not UNSET:
            field_dict["hideRelatedActionsView"] = hide_related_actions_view
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if field_rest is not UNSET:
            field_dict["_rest"] = field_rest

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.record_security_rule import RecordSecurityRule
        from ..models.record_type_field_detail import RecordTypeFieldDetail
        from ..models.record_type_relationship_detail import RecordTypeRelationshipDetail
        from ..models.rest_metadata_type_0 import RestMetadataType0

        d = dict(src_dict)
        uuid = d.pop("uuid", UNSET)

        name = d.pop("name", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_plural_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        plural_name = _parse_plural_name(d.pop("pluralName", UNSET))

        def _parse_type_reference(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        type_reference = _parse_type_reference(d.pop("typeReference", UNSET))

        _source_type = d.pop("sourceType", UNSET)
        source_type: RecordTypeSourceType | Unset
        if isinstance(_source_type, Unset):
            source_type = UNSET
        else:
            source_type = RecordTypeSourceType(_source_type)

        def _parse_table_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        table_name = _parse_table_name(d.pop("tableName", UNSET))

        def _parse_data_source_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        data_source_uuid = _parse_data_source_uuid(d.pop("dataSourceUuid", UNSET))

        def _parse_schema(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        schema = _parse_schema(d.pop("schema", UNSET))

        def _parse_fields(data: object) -> list[RecordTypeFieldDetail] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                fields_type_0 = []
                _fields_type_0 = data
                for fields_type_0_item_data in _fields_type_0:
                    fields_type_0_item = RecordTypeFieldDetail.from_dict(fields_type_0_item_data)

                    fields_type_0.append(fields_type_0_item)

                return fields_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[RecordTypeFieldDetail] | None | Unset, data)

        fields = _parse_fields(d.pop("fields", UNSET))

        def _parse_relationships(data: object) -> list[RecordTypeRelationshipDetail] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                relationships_type_0 = []
                _relationships_type_0 = data
                for relationships_type_0_item_data in _relationships_type_0:
                    relationships_type_0_item = RecordTypeRelationshipDetail.from_dict(relationships_type_0_item_data)

                    relationships_type_0.append(relationships_type_0_item)

                return relationships_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[RecordTypeRelationshipDetail] | None | Unset, data)

        relationships = _parse_relationships(d.pop("relationships", UNSET))

        has_record_events = d.pop("hasRecordEvents", UNSET)

        def _parse_security_rules(data: object) -> list[RecordSecurityRule] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                security_rules_type_0 = []
                _security_rules_type_0 = data
                for security_rules_type_0_item_data in _security_rules_type_0:
                    security_rules_type_0_item = RecordSecurityRule.from_dict(security_rules_type_0_item_data)

                    security_rules_type_0.append(security_rules_type_0_item)

                return security_rules_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[RecordSecurityRule] | None | Unset, data)

        security_rules = _parse_security_rules(d.pop("securityRules", UNSET))

        def _parse_security_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        security_expression = _parse_security_expression(d.pop("securityExpression", UNSET))

        def _parse_title_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title_expression = _parse_title_expression(d.pop("titleExpression", UNSET))

        def _parse_hide_record_header(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        hide_record_header = _parse_hide_record_header(d.pop("hideRecordHeader", UNSET))

        hide_news_view = d.pop("hideNewsView", UNSET)

        hide_related_actions_view = d.pop("hideRelatedActionsView", UNSET)

        def _parse_version_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version_id = _parse_version_id(d.pop("versionId", UNSET))

        def _parse_field_rest(data: object) -> None | RestMetadataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_rest_metadata_type_0 = RestMetadataType0.from_dict(data)

                return componentsschemas_rest_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RestMetadataType0 | Unset, data)

        field_rest = _parse_field_rest(d.pop("_rest", UNSET))

        record_type = cls(
            uuid=uuid,
            name=name,
            description=description,
            plural_name=plural_name,
            type_reference=type_reference,
            source_type=source_type,
            table_name=table_name,
            data_source_uuid=data_source_uuid,
            schema=schema,
            fields=fields,
            relationships=relationships,
            has_record_events=has_record_events,
            security_rules=security_rules,
            security_expression=security_expression,
            title_expression=title_expression,
            hide_record_header=hide_record_header,
            hide_news_view=hide_news_view,
            hide_related_actions_view=hide_related_actions_view,
            version_id=version_id,
            field_rest=field_rest,
        )

        record_type.additional_properties = d
        return record_type

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
