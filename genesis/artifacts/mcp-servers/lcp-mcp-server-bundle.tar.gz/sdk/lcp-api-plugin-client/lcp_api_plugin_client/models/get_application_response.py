from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.application_default_objects import ApplicationDefaultObjects


T = TypeVar("T", bound="GetApplicationResponse")


@_attrs_define
class GetApplicationResponse:
    """Application details with default scaffolded object UUIDs

    Attributes:
        uuid (str):
        name (str):
        description (None | str | Unset):
        prefix (str | Unset):
        url_identifier (str | Unset):
        default_objects (ApplicationDefaultObjects | Unset): UUIDs of the default objects created with an application
    """

    uuid: str
    name: str
    description: None | str | Unset = UNSET
    prefix: str | Unset = UNSET
    url_identifier: str | Unset = UNSET
    default_objects: ApplicationDefaultObjects | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        prefix = self.prefix

        url_identifier = self.url_identifier

        default_objects: dict[str, Any] | Unset = UNSET
        if not isinstance(self.default_objects, Unset):
            default_objects = self.default_objects.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if prefix is not UNSET:
            field_dict["prefix"] = prefix
        if url_identifier is not UNSET:
            field_dict["urlIdentifier"] = url_identifier
        if default_objects is not UNSET:
            field_dict["defaultObjects"] = default_objects

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.application_default_objects import ApplicationDefaultObjects

        d = dict(src_dict)
        uuid = d.pop("uuid")

        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        prefix = d.pop("prefix", UNSET)

        url_identifier = d.pop("urlIdentifier", UNSET)

        _default_objects = d.pop("defaultObjects", UNSET)
        default_objects: ApplicationDefaultObjects | Unset
        if isinstance(_default_objects, Unset):
            default_objects = UNSET
        else:
            default_objects = ApplicationDefaultObjects.from_dict(_default_objects)

        get_application_response = cls(
            uuid=uuid,
            name=name,
            description=description,
            prefix=prefix,
            url_identifier=url_identifier,
            default_objects=default_objects,
        )

        get_application_response.additional_properties = d
        return get_application_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
