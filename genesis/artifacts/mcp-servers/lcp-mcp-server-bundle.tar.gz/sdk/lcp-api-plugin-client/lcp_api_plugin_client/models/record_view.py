from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.record_view_launch_type import RecordViewLaunchType
from ..types import UNSET, Unset

T = TypeVar("T", bound="RecordView")


@_attrs_define
class RecordView:
    """A view (tab) on a record type's detail screen

    Attributes:
        url_stub (str | Unset): Auto-generated URL identifier for this view (read-only) Example: _iVzdg.
        name_expr (str | Unset): An Appian SAIL expression. Validated on create/update via two-pass validation (parse +
            eval). Invalid expressions are rejected with HTTP 400.
        ui_expr (str | Unset): An Appian SAIL expression. Validated on create/update via two-pass validation (parse +
            eval). Invalid expressions are rejected with HTTP 400.
        visibility_expr (None | str | Unset): SAIL expression (true/false) controlling view tab visibility. Null =
            visible to all.
        related_action_shortcuts (list[str] | Unset): UUIDs of related actions shown as shortcut buttons on this view
        launch_type (RecordViewLaunchType | Unset): How related action shortcuts open from this view Default:
            RecordViewLaunchType.SAME_TAB.
    """

    url_stub: str | Unset = UNSET
    name_expr: str | Unset = UNSET
    ui_expr: str | Unset = UNSET
    visibility_expr: None | str | Unset = UNSET
    related_action_shortcuts: list[str] | Unset = UNSET
    launch_type: RecordViewLaunchType | Unset = RecordViewLaunchType.SAME_TAB
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        url_stub = self.url_stub

        name_expr = self.name_expr

        ui_expr = self.ui_expr

        visibility_expr: None | str | Unset
        if isinstance(self.visibility_expr, Unset):
            visibility_expr = UNSET
        else:
            visibility_expr = self.visibility_expr

        related_action_shortcuts: list[str] | Unset = UNSET
        if not isinstance(self.related_action_shortcuts, Unset):
            related_action_shortcuts = self.related_action_shortcuts

        launch_type: str | Unset = UNSET
        if not isinstance(self.launch_type, Unset):
            launch_type = self.launch_type.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if url_stub is not UNSET:
            field_dict["urlStub"] = url_stub
        if name_expr is not UNSET:
            field_dict["nameExpr"] = name_expr
        if ui_expr is not UNSET:
            field_dict["uiExpr"] = ui_expr
        if visibility_expr is not UNSET:
            field_dict["visibilityExpr"] = visibility_expr
        if related_action_shortcuts is not UNSET:
            field_dict["relatedActionShortcuts"] = related_action_shortcuts
        if launch_type is not UNSET:
            field_dict["launchType"] = launch_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        url_stub = d.pop("urlStub", UNSET)

        name_expr = d.pop("nameExpr", UNSET)

        ui_expr = d.pop("uiExpr", UNSET)

        def _parse_visibility_expr(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        visibility_expr = _parse_visibility_expr(d.pop("visibilityExpr", UNSET))

        related_action_shortcuts = cast(list[str], d.pop("relatedActionShortcuts", UNSET))

        _launch_type = d.pop("launchType", UNSET)
        launch_type: RecordViewLaunchType | Unset
        if isinstance(_launch_type, Unset):
            launch_type = UNSET
        else:
            launch_type = RecordViewLaunchType(_launch_type)

        record_view = cls(
            url_stub=url_stub,
            name_expr=name_expr,
            ui_expr=ui_expr,
            visibility_expr=visibility_expr,
            related_action_shortcuts=related_action_shortcuts,
            launch_type=launch_type,
        )

        record_view.additional_properties = d
        return record_view

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
