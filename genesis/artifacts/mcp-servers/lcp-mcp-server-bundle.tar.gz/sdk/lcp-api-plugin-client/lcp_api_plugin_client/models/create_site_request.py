from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_site_request_layout import CreateSiteRequestLayout
from ..models.create_site_request_style import CreateSiteRequestStyle
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.site_page import SitePage


T = TypeVar("T", bound="CreateSiteRequest")


@_attrs_define
class CreateSiteRequest:
    """Request body for creating a new site

    Attributes:
        name (str): Internal name of the site Example: Customer Portal.
        display_name (str): Display name shown to users Example: Customer Portal.
        web_address_identifier (str): URL stub for the site (becomes part of URL path) Example: customer-portal.
        description (str | Unset): Description of the site (optional) Example: Portal for customer self-service.
        app_uuid (str | Unset): UUID of the application to add this site to (optional). When provided, the site is
            created and automatically added to the application with inherited security. Example: a1b2c3d4-e5f6-7890-abcd-
            ef1234567890.
        layout (CreateSiteRequestLayout | Unset): Navigation bar layout. HEADER_BAR (default) displays pages
            horizontally across the top. SIDEBAR displays pages in a vertically stacked collapsible list on the left.
        style (CreateSiteRequestStyle | Unset): Header bar style (only applies when layout is HEADER_BAR). MERCURY
            (default) shows page names on left with logo on left. HELIUM shows icons above page names with logo on right.
            OXYGEN shows page names on right with logo on left.
        pages (list[SitePage] | Unset): Array of page configurations (optional)
    """

    name: str
    display_name: str
    web_address_identifier: str
    description: str | Unset = UNSET
    app_uuid: str | Unset = UNSET
    layout: CreateSiteRequestLayout | Unset = UNSET
    style: CreateSiteRequestStyle | Unset = UNSET
    pages: list[SitePage] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        display_name = self.display_name

        web_address_identifier = self.web_address_identifier

        description = self.description

        app_uuid = self.app_uuid

        layout: str | Unset = UNSET
        if not isinstance(self.layout, Unset):
            layout = self.layout.value

        style: str | Unset = UNSET
        if not isinstance(self.style, Unset):
            style = self.style.value

        pages: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.pages, Unset):
            pages = []
            for pages_item_data in self.pages:
                pages_item = pages_item_data.to_dict()
                pages.append(pages_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "displayName": display_name,
                "webAddressIdentifier": web_address_identifier,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid
        if layout is not UNSET:
            field_dict["layout"] = layout
        if style is not UNSET:
            field_dict["style"] = style
        if pages is not UNSET:
            field_dict["pages"] = pages

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.site_page import SitePage

        d = dict(src_dict)
        name = d.pop("name")

        display_name = d.pop("displayName")

        web_address_identifier = d.pop("webAddressIdentifier")

        description = d.pop("description", UNSET)

        app_uuid = d.pop("appUuid", UNSET)

        _layout = d.pop("layout", UNSET)
        layout: CreateSiteRequestLayout | Unset
        if isinstance(_layout, Unset):
            layout = UNSET
        else:
            layout = CreateSiteRequestLayout(_layout)

        _style = d.pop("style", UNSET)
        style: CreateSiteRequestStyle | Unset
        if isinstance(_style, Unset):
            style = UNSET
        else:
            style = CreateSiteRequestStyle(_style)

        _pages = d.pop("pages", UNSET)
        pages: list[SitePage] | Unset = UNSET
        if _pages is not UNSET:
            pages = []
            for pages_item_data in _pages:
                pages_item = SitePage.from_dict(pages_item_data)

                pages.append(pages_item)

        create_site_request = cls(
            name=name,
            display_name=display_name,
            web_address_identifier=web_address_identifier,
            description=description,
            app_uuid=app_uuid,
            layout=layout,
            style=style,
            pages=pages,
        )

        create_site_request.additional_properties = d
        return create_site_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
