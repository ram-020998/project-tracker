from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.role_entry import RoleEntry


T = TypeVar("T", bound="SecurityResponse")


@_attrs_define
class SecurityResponse:
    """
    Attributes:
        object_type (str): Resolved object type (e.g. "record_type", "constant", "application")
        uuid (str):
        roles (list[RoleEntry]): All valid roles for this object type with current group assignments. Unassigned roles
            have empty groupNames arrays.
        inherit_security (bool | None | Unset): Whether this object inherits security from its parent folder. True when
            inheritance is enabled, false when disabled. Null for non-content objects (applications, record types, process
            models, sites, groups).
        parent_folder_uuid (None | str | Unset): UUID of the parent folder for content-backed objects. Null for non-
            content objects (applications, record types, process models, sites, groups).
    """

    object_type: str
    uuid: str
    roles: list[RoleEntry]
    inherit_security: bool | None | Unset = UNSET
    parent_folder_uuid: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        object_type = self.object_type

        uuid = self.uuid

        roles = []
        for roles_item_data in self.roles:
            roles_item = roles_item_data.to_dict()
            roles.append(roles_item)

        inherit_security: bool | None | Unset
        if isinstance(self.inherit_security, Unset):
            inherit_security = UNSET
        else:
            inherit_security = self.inherit_security

        parent_folder_uuid: None | str | Unset
        if isinstance(self.parent_folder_uuid, Unset):
            parent_folder_uuid = UNSET
        else:
            parent_folder_uuid = self.parent_folder_uuid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "objectType": object_type,
                "uuid": uuid,
                "roles": roles,
            }
        )
        if inherit_security is not UNSET:
            field_dict["inheritSecurity"] = inherit_security
        if parent_folder_uuid is not UNSET:
            field_dict["parentFolderUuid"] = parent_folder_uuid

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.role_entry import RoleEntry

        d = dict(src_dict)
        object_type = d.pop("objectType")

        uuid = d.pop("uuid")

        roles = []
        _roles = d.pop("roles")
        for roles_item_data in _roles:
            roles_item = RoleEntry.from_dict(roles_item_data)

            roles.append(roles_item)

        def _parse_inherit_security(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        inherit_security = _parse_inherit_security(d.pop("inheritSecurity", UNSET))

        def _parse_parent_folder_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_folder_uuid = _parse_parent_folder_uuid(d.pop("parentFolderUuid", UNSET))

        security_response = cls(
            object_type=object_type,
            uuid=uuid,
            roles=roles,
            inherit_security=inherit_security,
            parent_folder_uuid=parent_folder_uuid,
        )

        security_response.additional_properties = d
        return security_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
