from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.folder_folder_type import FolderFolderType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rest_metadata_type_0 import RestMetadataType0


T = TypeVar("T", bound="Folder")


@_attrs_define
class Folder:
    """Represents a folder in the Appian content management system.

    **Implementation**: Backed by FolderHandler.getFolder()

    **Folder Types**: Appian supports different folder types for organizing different kinds of content:
    - KNOWLEDGE_CENTER: Root container for document folders
    - KNOWLEDGE_FOLDER: Standard folder within a Knowledge Center for documents
    - RULES_FOLDER: Folder for expression rules, interfaces, and constants
    - PROCESS_MODEL_FOLDER: Folder for process models
    - UNKNOWN: Folder type cannot be determined

    **Note**: Path field is currently null due to implementation limitations.

        Attributes:
            uuid (str): Unique identifier in standard UUID format Example: folder-uuid-123.
            name (str): Folder name Example: Reports.
            folder_type (FolderFolderType): Type of folder indicating its purpose and what it contains Example:
                KNOWLEDGE_FOLDER.
            path (None | str | Unset): Full path to the folder (currently null - not yet implemented)
            created_at (datetime.datetime | None | Unset): Creation timestamp (may be null due to API limitations) Example:
                2024-01-15T10:30:00Z.
            modified_at (datetime.datetime | None | Unset): Last modification timestamp (may be null due to API limitations)
                Example: 2024-01-20T14:45:00Z.
            parent_folder_uuid (None | str | Unset): UUID of the parent folder Example: parent-folder-uuid.
            field_rest (None | RestMetadataType0 | Unset): Response metadata including the Designer URL for this object.
                Present on get, create, and update responses for design objects.
    """

    uuid: str
    name: str
    folder_type: FolderFolderType
    path: None | str | Unset = UNSET
    created_at: datetime.datetime | None | Unset = UNSET
    modified_at: datetime.datetime | None | Unset = UNSET
    parent_folder_uuid: None | str | Unset = UNSET
    field_rest: None | RestMetadataType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rest_metadata_type_0 import RestMetadataType0

        uuid = self.uuid

        name = self.name

        folder_type = self.folder_type.value

        path: None | str | Unset
        if isinstance(self.path, Unset):
            path = UNSET
        else:
            path = self.path

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        elif isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        modified_at: None | str | Unset
        if isinstance(self.modified_at, Unset):
            modified_at = UNSET
        elif isinstance(self.modified_at, datetime.datetime):
            modified_at = self.modified_at.isoformat()
        else:
            modified_at = self.modified_at

        parent_folder_uuid: None | str | Unset
        if isinstance(self.parent_folder_uuid, Unset):
            parent_folder_uuid = UNSET
        else:
            parent_folder_uuid = self.parent_folder_uuid

        field_rest: dict[str, Any] | None | Unset
        if isinstance(self.field_rest, Unset):
            field_rest = UNSET
        elif isinstance(self.field_rest, RestMetadataType0):
            field_rest = self.field_rest.to_dict()
        else:
            field_rest = self.field_rest

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "name": name,
                "folderType": folder_type,
            }
        )
        if path is not UNSET:
            field_dict["path"] = path
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if modified_at is not UNSET:
            field_dict["modifiedAt"] = modified_at
        if parent_folder_uuid is not UNSET:
            field_dict["parentFolderUuid"] = parent_folder_uuid
        if field_rest is not UNSET:
            field_dict["_rest"] = field_rest

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rest_metadata_type_0 import RestMetadataType0

        d = dict(src_dict)
        uuid = d.pop("uuid")

        name = d.pop("name")

        folder_type = FolderFolderType(d.pop("folderType"))

        def _parse_path(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        path = _parse_path(d.pop("path", UNSET))

        def _parse_created_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = datetime.datetime.fromisoformat(data)

                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        created_at = _parse_created_at(d.pop("createdAt", UNSET))

        def _parse_modified_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                modified_at_type_0 = datetime.datetime.fromisoformat(data)

                return modified_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        modified_at = _parse_modified_at(d.pop("modifiedAt", UNSET))

        def _parse_parent_folder_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_folder_uuid = _parse_parent_folder_uuid(d.pop("parentFolderUuid", UNSET))

        def _parse_field_rest(data: object) -> None | RestMetadataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_rest_metadata_type_0 = RestMetadataType0.from_dict(data)

                return componentsschemas_rest_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RestMetadataType0 | Unset, data)

        field_rest = _parse_field_rest(d.pop("_rest", UNSET))

        folder = cls(
            uuid=uuid,
            name=name,
            folder_type=folder_type,
            path=path,
            created_at=created_at,
            modified_at=modified_at,
            parent_folder_uuid=parent_folder_uuid,
            field_rest=field_rest,
        )

        folder.additional_properties = d
        return folder

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
