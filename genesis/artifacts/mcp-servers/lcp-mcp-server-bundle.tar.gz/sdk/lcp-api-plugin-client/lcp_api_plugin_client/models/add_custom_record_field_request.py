from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.add_custom_record_field_request_calculation_type import AddCustomRecordFieldRequestCalculationType
from ..models.add_custom_record_field_request_field_type import AddCustomRecordFieldRequestFieldType
from ..models.add_custom_record_field_request_template_type import AddCustomRecordFieldRequestTemplateType
from ..types import UNSET, Unset

T = TypeVar("T", bound="AddCustomRecordFieldRequest")


@_attrs_define
class AddCustomRecordFieldRequest:
    """Request body for adding a custom (calculated/expression-based) field to a record type.

    Attributes:
        field_name (str): The field name
        field_type (AddCustomRecordFieldRequestFieldType): The return type of the expression
        expression (str): SAIL expression that computes the field value.
        calculation_type (AddCustomRecordFieldRequestCalculationType | Unset): When the expression is evaluated.
            Default: AddCustomRecordFieldRequestCalculationType.REAL_TIME.
        template_type (AddCustomRecordFieldRequestTemplateType | Unset): Template type. Only NONE is currently
            supported. Default: AddCustomRecordFieldRequestTemplateType.NONE.
        display_name (str | Unset): Human-readable display name. Defaults to fieldName.
        description (str | Unset): Field description
    """

    field_name: str
    field_type: AddCustomRecordFieldRequestFieldType
    expression: str
    calculation_type: AddCustomRecordFieldRequestCalculationType | Unset = (
        AddCustomRecordFieldRequestCalculationType.REAL_TIME
    )
    template_type: AddCustomRecordFieldRequestTemplateType | Unset = AddCustomRecordFieldRequestTemplateType.NONE
    display_name: str | Unset = UNSET
    description: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        field_name = self.field_name

        field_type = self.field_type.value

        expression = self.expression

        calculation_type: str | Unset = UNSET
        if not isinstance(self.calculation_type, Unset):
            calculation_type = self.calculation_type.value

        template_type: str | Unset = UNSET
        if not isinstance(self.template_type, Unset):
            template_type = self.template_type.value

        display_name = self.display_name

        description = self.description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "fieldName": field_name,
                "fieldType": field_type,
                "expression": expression,
            }
        )
        if calculation_type is not UNSET:
            field_dict["calculationType"] = calculation_type
        if template_type is not UNSET:
            field_dict["templateType"] = template_type
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        field_name = d.pop("fieldName")

        field_type = AddCustomRecordFieldRequestFieldType(d.pop("fieldType"))

        expression = d.pop("expression")

        _calculation_type = d.pop("calculationType", UNSET)
        calculation_type: AddCustomRecordFieldRequestCalculationType | Unset
        if isinstance(_calculation_type, Unset):
            calculation_type = UNSET
        else:
            calculation_type = AddCustomRecordFieldRequestCalculationType(_calculation_type)

        _template_type = d.pop("templateType", UNSET)
        template_type: AddCustomRecordFieldRequestTemplateType | Unset
        if isinstance(_template_type, Unset):
            template_type = UNSET
        else:
            template_type = AddCustomRecordFieldRequestTemplateType(_template_type)

        display_name = d.pop("displayName", UNSET)

        description = d.pop("description", UNSET)

        add_custom_record_field_request = cls(
            field_name=field_name,
            field_type=field_type,
            expression=expression,
            calculation_type=calculation_type,
            template_type=template_type,
            display_name=display_name,
            description=description,
        )

        add_custom_record_field_request.additional_properties = d
        return add_custom_record_field_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
