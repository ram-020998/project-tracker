from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="TestRuleDiagnostics")


@_attrs_define
class TestRuleDiagnostics:
    """Diagnostic information about the rule test execution.

    Attributes:
        duration_ms (int | Unset): Execution duration in milliseconds
        result_type (None | str | Unset): Java type name of the result value
        error (None | str | Unset): Error message if execution failed
        timed_out (bool | Unset): Whether the execution timed out
        truncated (bool | Unset): Whether the result was truncated due to size limits
    """

    duration_ms: int | Unset = UNSET
    result_type: None | str | Unset = UNSET
    error: None | str | Unset = UNSET
    timed_out: bool | Unset = UNSET
    truncated: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        duration_ms = self.duration_ms

        result_type: None | str | Unset
        if isinstance(self.result_type, Unset):
            result_type = UNSET
        else:
            result_type = self.result_type

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        timed_out = self.timed_out

        truncated = self.truncated

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if duration_ms is not UNSET:
            field_dict["durationMs"] = duration_ms
        if result_type is not UNSET:
            field_dict["resultType"] = result_type
        if error is not UNSET:
            field_dict["error"] = error
        if timed_out is not UNSET:
            field_dict["timedOut"] = timed_out
        if truncated is not UNSET:
            field_dict["truncated"] = truncated

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        duration_ms = d.pop("durationMs", UNSET)

        def _parse_result_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        result_type = _parse_result_type(d.pop("resultType", UNSET))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        timed_out = d.pop("timedOut", UNSET)

        truncated = d.pop("truncated", UNSET)

        test_rule_diagnostics = cls(
            duration_ms=duration_ms,
            result_type=result_type,
            error=error,
            timed_out=timed_out,
            truncated=truncated,
        )

        test_rule_diagnostics.additional_properties = d
        return test_rule_diagnostics

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
