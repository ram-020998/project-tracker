from enum import Enum


class DocumentTextMetadataExtractionMethod(str, Enum):
    NATIVE = "NATIVE"
    OCR = "OCR"
    PARSED = "PARSED"

    def __str__(self) -> str:
        return str(self.value)
