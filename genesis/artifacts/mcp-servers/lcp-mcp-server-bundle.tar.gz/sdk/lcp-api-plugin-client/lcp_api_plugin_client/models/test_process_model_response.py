from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.test_process_model_diagnostics import TestProcessModelDiagnostics
    from ..models.test_process_model_result import TestProcessModelResult


T = TypeVar("T", bound="TestProcessModelResponse")


@_attrs_define
class TestProcessModelResponse:
    """Result of a process model test execution.

    Attributes:
        result (TestProcessModelResult | Unset): Process execution result.
        diagnostics (TestProcessModelDiagnostics | Unset): Diagnostic information about the process model test
            execution.
    """

    result: TestProcessModelResult | Unset = UNSET
    diagnostics: TestProcessModelDiagnostics | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] | Unset = UNSET
        if not isinstance(self.result, Unset):
            result = self.result.to_dict()

        diagnostics: dict[str, Any] | Unset = UNSET
        if not isinstance(self.diagnostics, Unset):
            diagnostics = self.diagnostics.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if result is not UNSET:
            field_dict["result"] = result
        if diagnostics is not UNSET:
            field_dict["diagnostics"] = diagnostics

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.test_process_model_diagnostics import TestProcessModelDiagnostics
        from ..models.test_process_model_result import TestProcessModelResult

        d = dict(src_dict)
        _result = d.pop("result", UNSET)
        result: TestProcessModelResult | Unset
        if isinstance(_result, Unset):
            result = UNSET
        else:
            result = TestProcessModelResult.from_dict(_result)

        _diagnostics = d.pop("diagnostics", UNSET)
        diagnostics: TestProcessModelDiagnostics | Unset
        if isinstance(_diagnostics, Unset):
            diagnostics = UNSET
        else:
            diagnostics = TestProcessModelDiagnostics.from_dict(_diagnostics)

        test_process_model_response = cls(
            result=result,
            diagnostics=diagnostics,
        )

        test_process_model_response.additional_properties = d
        return test_process_model_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
