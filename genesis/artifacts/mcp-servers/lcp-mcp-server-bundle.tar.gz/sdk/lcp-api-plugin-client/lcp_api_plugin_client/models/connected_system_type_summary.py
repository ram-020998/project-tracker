from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.operation_summary import OperationSummary


T = TypeVar("T", bound="ConnectedSystemTypeSummary")


@_attrs_define
class ConnectedSystemTypeSummary:
    """Summary of a connected system type with its child operations.

    Attributes:
        type_id (str): Type identifier Example: system.http.
        name (str): Display name Example: HTTP.
        description (None | str | Unset): Type description Example: HTTP connected system for REST API calls.
        operations (list[OperationSummary] | Unset): Child operations (integration templates) for this type
    """

    type_id: str
    name: str
    description: None | str | Unset = UNSET
    operations: list[OperationSummary] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_id = self.type_id

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        operations: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.operations, Unset):
            operations = []
            for operations_item_data in self.operations:
                operations_item = operations_item_data.to_dict()
                operations.append(operations_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "typeId": type_id,
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if operations is not UNSET:
            field_dict["operations"] = operations

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.operation_summary import OperationSummary

        d = dict(src_dict)
        type_id = d.pop("typeId")

        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        _operations = d.pop("operations", UNSET)
        operations: list[OperationSummary] | Unset = UNSET
        if _operations is not UNSET:
            operations = []
            for operations_item_data in _operations:
                operations_item = OperationSummary.from_dict(operations_item_data)

                operations.append(operations_item)

        connected_system_type_summary = cls(
            type_id=type_id,
            name=name,
            description=description,
            operations=operations,
        )

        connected_system_type_summary.additional_properties = d
        return connected_system_type_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
