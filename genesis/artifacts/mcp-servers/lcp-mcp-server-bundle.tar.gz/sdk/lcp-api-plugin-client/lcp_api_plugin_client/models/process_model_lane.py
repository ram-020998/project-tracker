from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.process_model_lane_run_as import ProcessModelLaneRunAs
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.lane_label_style_type_0 import LaneLabelStyleType0


T = TypeVar("T", bound="ProcessModelLane")


@_attrs_define
class ProcessModelLane:
    """A swimlane in an Appian Process Model. Lanes visually organize nodes by role.
    Nodes reference their lane by the lane's index in the process model's lanes array.
    Array order is visual order (top-to-bottom for horizontal, left-to-right for vertical).

        Attributes:
            label (str): Display name of the lane Example: Approvers.
            color (None | str | Unset): Background color (hex) Example: #E3F2FD.
            dimension (int | None | Unset): Lane width (for vertical) or height (for horizontal) in pixels
            is_vertical (bool | None | Unset): true = vertical lane, false/null = horizontal (default)
            is_lane_assignment (bool | None | Unset): Whether this lane defines default task assignment for its nodes
                Default: False.
            attended (bool | None | Unset): true = attended (task), false = unattended (system).
                Only relevant when isLaneAssignment is true.
            assign_to (None | str | Unset): SAIL expression for assignee(s). Only relevant when isLaneAssignment is true
                and attended is true.
                 Example: group(toGroup(cons!APPROVER_GROUP), "user").
            run_as (ProcessModelLaneRunAs | Unset): Who the system runs as. Only relevant when isLaneAssignment is true
                and attended is false. INITIATOR or DESIGNER.
            label_style (LaneLabelStyleType0 | None | Unset): Font styling for the lane's label
    """

    label: str
    color: None | str | Unset = UNSET
    dimension: int | None | Unset = UNSET
    is_vertical: bool | None | Unset = UNSET
    is_lane_assignment: bool | None | Unset = False
    attended: bool | None | Unset = UNSET
    assign_to: None | str | Unset = UNSET
    run_as: ProcessModelLaneRunAs | Unset = UNSET
    label_style: LaneLabelStyleType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.lane_label_style_type_0 import LaneLabelStyleType0

        label = self.label

        color: None | str | Unset
        if isinstance(self.color, Unset):
            color = UNSET
        else:
            color = self.color

        dimension: int | None | Unset
        if isinstance(self.dimension, Unset):
            dimension = UNSET
        else:
            dimension = self.dimension

        is_vertical: bool | None | Unset
        if isinstance(self.is_vertical, Unset):
            is_vertical = UNSET
        else:
            is_vertical = self.is_vertical

        is_lane_assignment: bool | None | Unset
        if isinstance(self.is_lane_assignment, Unset):
            is_lane_assignment = UNSET
        else:
            is_lane_assignment = self.is_lane_assignment

        attended: bool | None | Unset
        if isinstance(self.attended, Unset):
            attended = UNSET
        else:
            attended = self.attended

        assign_to: None | str | Unset
        if isinstance(self.assign_to, Unset):
            assign_to = UNSET
        else:
            assign_to = self.assign_to

        run_as: str | Unset = UNSET
        if not isinstance(self.run_as, Unset):
            run_as = self.run_as.value

        label_style: dict[str, Any] | None | Unset
        if isinstance(self.label_style, Unset):
            label_style = UNSET
        elif isinstance(self.label_style, LaneLabelStyleType0):
            label_style = self.label_style.to_dict()
        else:
            label_style = self.label_style

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "label": label,
            }
        )
        if color is not UNSET:
            field_dict["color"] = color
        if dimension is not UNSET:
            field_dict["dimension"] = dimension
        if is_vertical is not UNSET:
            field_dict["isVertical"] = is_vertical
        if is_lane_assignment is not UNSET:
            field_dict["isLaneAssignment"] = is_lane_assignment
        if attended is not UNSET:
            field_dict["attended"] = attended
        if assign_to is not UNSET:
            field_dict["assignTo"] = assign_to
        if run_as is not UNSET:
            field_dict["runAs"] = run_as
        if label_style is not UNSET:
            field_dict["labelStyle"] = label_style

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.lane_label_style_type_0 import LaneLabelStyleType0

        d = dict(src_dict)
        label = d.pop("label")

        def _parse_color(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        color = _parse_color(d.pop("color", UNSET))

        def _parse_dimension(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        dimension = _parse_dimension(d.pop("dimension", UNSET))

        def _parse_is_vertical(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_vertical = _parse_is_vertical(d.pop("isVertical", UNSET))

        def _parse_is_lane_assignment(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_lane_assignment = _parse_is_lane_assignment(d.pop("isLaneAssignment", UNSET))

        def _parse_attended(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        attended = _parse_attended(d.pop("attended", UNSET))

        def _parse_assign_to(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        assign_to = _parse_assign_to(d.pop("assignTo", UNSET))

        _run_as = d.pop("runAs", UNSET)
        run_as: ProcessModelLaneRunAs | Unset
        if isinstance(_run_as, Unset):
            run_as = UNSET
        else:
            run_as = ProcessModelLaneRunAs(_run_as)

        def _parse_label_style(data: object) -> LaneLabelStyleType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_lane_label_style_type_0 = LaneLabelStyleType0.from_dict(data)

                return componentsschemas_lane_label_style_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LaneLabelStyleType0 | None | Unset, data)

        label_style = _parse_label_style(d.pop("labelStyle", UNSET))

        process_model_lane = cls(
            label=label,
            color=color,
            dimension=dimension,
            is_vertical=is_vertical,
            is_lane_assignment=is_lane_assignment,
            attended=attended,
            assign_to=assign_to,
            run_as=run_as,
            label_style=label_style,
        )

        process_model_lane.additional_properties = d
        return process_model_lane

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
