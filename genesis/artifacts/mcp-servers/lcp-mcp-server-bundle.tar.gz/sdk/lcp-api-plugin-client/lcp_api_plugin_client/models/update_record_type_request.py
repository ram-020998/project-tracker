from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.record_security_rule import RecordSecurityRule


T = TypeVar("T", bound="UpdateRecordTypeRequest")


@_attrs_define
class UpdateRecordTypeRequest:
    """Request body for updating an existing record type (at least one field required)

    Attributes:
        version_id (str | Unset): Version ID for optimistic concurrency control. If provided, validates against current
            version.
        name (str | Unset): The singular name of the record type Example: Updated Customer.
        description (str | Unset): A text description of the record type's purpose Example: Updated customer records.
        plural_name (str | Unset): The plural form of the record type name Example: Updated Customers.
        security_rules (list[RecordSecurityRule] | None | Unset): Full replacement of security rules. List order =
            evaluation order. Empty list clears all rules.
        security_expression (None | str | Unset): SAIL expression string. Set to null to clear.
        title_expression (None | str | Unset): SAIL expression for the record title. Format:
            rv!record['recordType!{uuid}Name.fields.{fieldUuid}fieldName']. Set to null to clear.
        hide_record_header (bool | None | Unset): Whether to hide the default record header on record views. Requires at
            least one record view to be configured.
        hide_news_view (bool | Unset): Whether to hide the News view tab on this record type.
        hide_related_actions_view (bool | Unset): Whether to hide the Related Actions view tab on this record type.
    """

    version_id: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    plural_name: str | Unset = UNSET
    security_rules: list[RecordSecurityRule] | None | Unset = UNSET
    security_expression: None | str | Unset = UNSET
    title_expression: None | str | Unset = UNSET
    hide_record_header: bool | None | Unset = UNSET
    hide_news_view: bool | Unset = UNSET
    hide_related_actions_view: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        version_id = self.version_id

        name = self.name

        description = self.description

        plural_name = self.plural_name

        security_rules: list[dict[str, Any]] | None | Unset
        if isinstance(self.security_rules, Unset):
            security_rules = UNSET
        elif isinstance(self.security_rules, list):
            security_rules = []
            for security_rules_type_0_item_data in self.security_rules:
                security_rules_type_0_item = security_rules_type_0_item_data.to_dict()
                security_rules.append(security_rules_type_0_item)

        else:
            security_rules = self.security_rules

        security_expression: None | str | Unset
        if isinstance(self.security_expression, Unset):
            security_expression = UNSET
        else:
            security_expression = self.security_expression

        title_expression: None | str | Unset
        if isinstance(self.title_expression, Unset):
            title_expression = UNSET
        else:
            title_expression = self.title_expression

        hide_record_header: bool | None | Unset
        if isinstance(self.hide_record_header, Unset):
            hide_record_header = UNSET
        else:
            hide_record_header = self.hide_record_header

        hide_news_view = self.hide_news_view

        hide_related_actions_view = self.hide_related_actions_view

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if plural_name is not UNSET:
            field_dict["pluralName"] = plural_name
        if security_rules is not UNSET:
            field_dict["securityRules"] = security_rules
        if security_expression is not UNSET:
            field_dict["securityExpression"] = security_expression
        if title_expression is not UNSET:
            field_dict["titleExpression"] = title_expression
        if hide_record_header is not UNSET:
            field_dict["hideRecordHeader"] = hide_record_header
        if hide_news_view is not UNSET:
            field_dict["hideNewsView"] = hide_news_view
        if hide_related_actions_view is not UNSET:
            field_dict["hideRelatedActionsView"] = hide_related_actions_view

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.record_security_rule import RecordSecurityRule

        d = dict(src_dict)
        version_id = d.pop("versionId", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        plural_name = d.pop("pluralName", UNSET)

        def _parse_security_rules(data: object) -> list[RecordSecurityRule] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                security_rules_type_0 = []
                _security_rules_type_0 = data
                for security_rules_type_0_item_data in _security_rules_type_0:
                    security_rules_type_0_item = RecordSecurityRule.from_dict(security_rules_type_0_item_data)

                    security_rules_type_0.append(security_rules_type_0_item)

                return security_rules_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[RecordSecurityRule] | None | Unset, data)

        security_rules = _parse_security_rules(d.pop("securityRules", UNSET))

        def _parse_security_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        security_expression = _parse_security_expression(d.pop("securityExpression", UNSET))

        def _parse_title_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title_expression = _parse_title_expression(d.pop("titleExpression", UNSET))

        def _parse_hide_record_header(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        hide_record_header = _parse_hide_record_header(d.pop("hideRecordHeader", UNSET))

        hide_news_view = d.pop("hideNewsView", UNSET)

        hide_related_actions_view = d.pop("hideRelatedActionsView", UNSET)

        update_record_type_request = cls(
            version_id=version_id,
            name=name,
            description=description,
            plural_name=plural_name,
            security_rules=security_rules,
            security_expression=security_expression,
            title_expression=title_expression,
            hide_record_header=hide_record_header,
            hide_news_view=hide_news_view,
            hide_related_actions_view=hide_related_actions_view,
        )

        update_record_type_request.additional_properties = d
        return update_record_type_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
