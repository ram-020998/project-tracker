from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_expression_rule_request_test_inputs_item import CreateExpressionRuleRequestTestInputsItem
    from ..models.typed_input import TypedInput


T = TypeVar("T", bound="CreateExpressionRuleRequest")


@_attrs_define
class CreateExpressionRuleRequest:
    """Request body for creating a new expression rule.

    Either `parentFolderUuid` or `appUuid` must be provided to determine where the expression rule will be created.

        Attributes:
            name (str): Expression rule name (required) Example: calculateTotal.
            description (str | Unset): Expression rule description (optional) Example: Calculates order total with tax.
            parent_folder_uuid (str | Unset): UUID of the parent Rules and Constants folder where the expression rule will
                be created (optional).
                If provided, this takes precedence over `appUuid` for folder selection.
                 Example: _a-0000e0b2-7f2c-8000-cd82-011c48011c48_24303.
            app_uuid (str | Unset): Application UUID (optional). When provided:
                - The expression rule is added to the application and is given the same security role map
                - If `parentFolderUuid` is not provided, the tool automatically selects an appropriate Rules and Constants
                folder from the application (prefers folders named "<prefix> Rules and Constants")

                Either `parentFolderUuid` or `appUuid` must be provided.
                 Example: 2723d382-da1c-4a19-af4f-86498eb7b6eb.
            expression (str | Unset): An Appian SAIL expression. Validated on create/update via two-pass validation (parse +
                eval). Invalid expressions are rejected with HTTP 400.
            inputs (list[TypedInput] | Unset): Input parameter definitions (optional)
            test_inputs (list[CreateExpressionRuleRequestTestInputsItem] | Unset): Test input values to use during
                validation and save as default test values.
                If not provided, validation uses null inputs (current behavior).
                Once saved, these become the default test values used on subsequent updates.
    """

    name: str
    description: str | Unset = UNSET
    parent_folder_uuid: str | Unset = UNSET
    app_uuid: str | Unset = UNSET
    expression: str | Unset = UNSET
    inputs: list[TypedInput] | Unset = UNSET
    test_inputs: list[CreateExpressionRuleRequestTestInputsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        description = self.description

        parent_folder_uuid = self.parent_folder_uuid

        app_uuid = self.app_uuid

        expression = self.expression

        inputs: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.inputs, Unset):
            inputs = []
            for inputs_item_data in self.inputs:
                inputs_item = inputs_item_data.to_dict()
                inputs.append(inputs_item)

        test_inputs: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.test_inputs, Unset):
            test_inputs = []
            for test_inputs_item_data in self.test_inputs:
                test_inputs_item = test_inputs_item_data.to_dict()
                test_inputs.append(test_inputs_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if parent_folder_uuid is not UNSET:
            field_dict["parentFolderUuid"] = parent_folder_uuid
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid
        if expression is not UNSET:
            field_dict["expression"] = expression
        if inputs is not UNSET:
            field_dict["inputs"] = inputs
        if test_inputs is not UNSET:
            field_dict["testInputs"] = test_inputs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_expression_rule_request_test_inputs_item import CreateExpressionRuleRequestTestInputsItem
        from ..models.typed_input import TypedInput

        d = dict(src_dict)
        name = d.pop("name")

        description = d.pop("description", UNSET)

        parent_folder_uuid = d.pop("parentFolderUuid", UNSET)

        app_uuid = d.pop("appUuid", UNSET)

        expression = d.pop("expression", UNSET)

        _inputs = d.pop("inputs", UNSET)
        inputs: list[TypedInput] | Unset = UNSET
        if _inputs is not UNSET:
            inputs = []
            for inputs_item_data in _inputs:
                inputs_item = TypedInput.from_dict(inputs_item_data)

                inputs.append(inputs_item)

        _test_inputs = d.pop("testInputs", UNSET)
        test_inputs: list[CreateExpressionRuleRequestTestInputsItem] | Unset = UNSET
        if _test_inputs is not UNSET:
            test_inputs = []
            for test_inputs_item_data in _test_inputs:
                test_inputs_item = CreateExpressionRuleRequestTestInputsItem.from_dict(test_inputs_item_data)

                test_inputs.append(test_inputs_item)

        create_expression_rule_request = cls(
            name=name,
            description=description,
            parent_folder_uuid=parent_folder_uuid,
            app_uuid=app_uuid,
            expression=expression,
            inputs=inputs,
            test_inputs=test_inputs,
        )

        create_expression_rule_request.additional_properties = d
        return create_expression_rule_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
