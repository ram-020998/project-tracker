from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.add_record_type_relationship_request_relationship_type import (
    AddRecordTypeRelationshipRequestRelationshipType,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="AddRecordTypeRelationshipRequest")


@_attrs_define
class AddRecordTypeRelationshipRequest:
    """Request body for adding a relationship to a record type

    Attributes:
        relationship_name (str): Name of the relationship (used in expressions) Example: orders.
        source_record_type_field_uuid (str): UUID of the field in the source record type Example: customer-id-field-
            uuid.
        target_record_type_field_uuid (str): UUID of the field in the target record type Example: order-customer-id-
            field-uuid.
        target_record_type_uuid (str): UUID of the target record type Example: order-uuid-456.
        relationship_type (AddRecordTypeRelationshipRequestRelationshipType): Type of relationship Example: ONE_TO_MANY.
        version_id (str | Unset): Current version ID for optimistic concurrency control
    """

    relationship_name: str
    source_record_type_field_uuid: str
    target_record_type_field_uuid: str
    target_record_type_uuid: str
    relationship_type: AddRecordTypeRelationshipRequestRelationshipType
    version_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        relationship_name = self.relationship_name

        source_record_type_field_uuid = self.source_record_type_field_uuid

        target_record_type_field_uuid = self.target_record_type_field_uuid

        target_record_type_uuid = self.target_record_type_uuid

        relationship_type = self.relationship_type.value

        version_id = self.version_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "relationshipName": relationship_name,
                "sourceRecordTypeFieldUuid": source_record_type_field_uuid,
                "targetRecordTypeFieldUuid": target_record_type_field_uuid,
                "targetRecordTypeUuid": target_record_type_uuid,
                "relationshipType": relationship_type,
            }
        )
        if version_id is not UNSET:
            field_dict["versionId"] = version_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        relationship_name = d.pop("relationshipName")

        source_record_type_field_uuid = d.pop("sourceRecordTypeFieldUuid")

        target_record_type_field_uuid = d.pop("targetRecordTypeFieldUuid")

        target_record_type_uuid = d.pop("targetRecordTypeUuid")

        relationship_type = AddRecordTypeRelationshipRequestRelationshipType(d.pop("relationshipType"))

        version_id = d.pop("versionId", UNSET)

        add_record_type_relationship_request = cls(
            relationship_name=relationship_name,
            source_record_type_field_uuid=source_record_type_field_uuid,
            target_record_type_field_uuid=target_record_type_field_uuid,
            target_record_type_uuid=target_record_type_uuid,
            relationship_type=relationship_type,
            version_id=version_id,
        )

        add_record_type_relationship_request.additional_properties = d
        return add_record_type_relationship_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
