from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_record_action_request_action_type import CreateRecordActionRequestActionType
from ..models.create_record_action_request_dialog_height import CreateRecordActionRequestDialogHeight
from ..models.create_record_action_request_dialog_width import CreateRecordActionRequestDialogWidth
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateRecordActionRequest")


@_attrs_define
class CreateRecordActionRequest:
    """A record action that triggers a process model from a record list or record view

    Attributes:
        key (str): Unique key for referencing this action in SAIL (e.g., recordType!Case.actions.editCase) Example:
            submitRequest.
        display_name (str): Display name of the action shown to users Example: Submit Request.
        process_model_uuid (str): UUID of the process model this action triggers Example: pm-uuid-1.
        action_type (CreateRecordActionRequestActionType): Type of record action Example: LIST_ACTION.
        version_id (str | Unset): Current version ID for optimistic concurrency control
        uuid (str | Unset): Unique identifier for the action (server-generated, not sent on create) Example:
            a1b2c3d4-e5f6-7890-abcd-ef1234567890.
        description (None | str | Unset): Action description (tooltip for list actions, description text for related
            actions) Example: Submit a new request for this record.
        icon (None | str | Unset): Icon ID for the action button (default "f0e7") Example: f0e7.
        visibility_expr (None | str | Unset): SAIL expression controlling when the action is visible (default "=true()")
            Example: =true().
        dialog_width (CreateRecordActionRequestDialogWidth | Unset): Dialog width when action opens in a dialog box
            (default "MEDIUM_PLUS")
        dialog_height (CreateRecordActionRequestDialogHeight | Unset): Dialog height when action opens in a dialog box
            (default "AUTO")
        context_expr (None | str | Unset): SAIL expression for related actions that passes record context to the process
            model. Only valid for RELATED_ACTION type. Ignored for LIST_ACTION.
             Example: ={id: rv!identifier}.
    """

    key: str
    display_name: str
    process_model_uuid: str
    action_type: CreateRecordActionRequestActionType
    version_id: str | Unset = UNSET
    uuid: str | Unset = UNSET
    description: None | str | Unset = UNSET
    icon: None | str | Unset = UNSET
    visibility_expr: None | str | Unset = UNSET
    dialog_width: CreateRecordActionRequestDialogWidth | Unset = UNSET
    dialog_height: CreateRecordActionRequestDialogHeight | Unset = UNSET
    context_expr: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        key = self.key

        display_name = self.display_name

        process_model_uuid = self.process_model_uuid

        action_type = self.action_type.value

        version_id = self.version_id

        uuid = self.uuid

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        icon: None | str | Unset
        if isinstance(self.icon, Unset):
            icon = UNSET
        else:
            icon = self.icon

        visibility_expr: None | str | Unset
        if isinstance(self.visibility_expr, Unset):
            visibility_expr = UNSET
        else:
            visibility_expr = self.visibility_expr

        dialog_width: str | Unset = UNSET
        if not isinstance(self.dialog_width, Unset):
            dialog_width = self.dialog_width.value

        dialog_height: str | Unset = UNSET
        if not isinstance(self.dialog_height, Unset):
            dialog_height = self.dialog_height.value

        context_expr: None | str | Unset
        if isinstance(self.context_expr, Unset):
            context_expr = UNSET
        else:
            context_expr = self.context_expr

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "key": key,
                "displayName": display_name,
                "processModelUuid": process_model_uuid,
                "actionType": action_type,
            }
        )
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if description is not UNSET:
            field_dict["description"] = description
        if icon is not UNSET:
            field_dict["icon"] = icon
        if visibility_expr is not UNSET:
            field_dict["visibilityExpr"] = visibility_expr
        if dialog_width is not UNSET:
            field_dict["dialogWidth"] = dialog_width
        if dialog_height is not UNSET:
            field_dict["dialogHeight"] = dialog_height
        if context_expr is not UNSET:
            field_dict["contextExpr"] = context_expr

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        key = d.pop("key")

        display_name = d.pop("displayName")

        process_model_uuid = d.pop("processModelUuid")

        action_type = CreateRecordActionRequestActionType(d.pop("actionType"))

        version_id = d.pop("versionId", UNSET)

        uuid = d.pop("uuid", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_icon(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        icon = _parse_icon(d.pop("icon", UNSET))

        def _parse_visibility_expr(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        visibility_expr = _parse_visibility_expr(d.pop("visibilityExpr", UNSET))

        _dialog_width = d.pop("dialogWidth", UNSET)
        dialog_width: CreateRecordActionRequestDialogWidth | Unset
        if isinstance(_dialog_width, Unset):
            dialog_width = UNSET
        else:
            dialog_width = CreateRecordActionRequestDialogWidth(_dialog_width)

        _dialog_height = d.pop("dialogHeight", UNSET)
        dialog_height: CreateRecordActionRequestDialogHeight | Unset
        if isinstance(_dialog_height, Unset):
            dialog_height = UNSET
        else:
            dialog_height = CreateRecordActionRequestDialogHeight(_dialog_height)

        def _parse_context_expr(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        context_expr = _parse_context_expr(d.pop("contextExpr", UNSET))

        create_record_action_request = cls(
            key=key,
            display_name=display_name,
            process_model_uuid=process_model_uuid,
            action_type=action_type,
            version_id=version_id,
            uuid=uuid,
            description=description,
            icon=icon,
            visibility_expr=visibility_expr,
            dialog_width=dialog_width,
            dialog_height=dialog_height,
            context_expr=context_expr,
        )

        create_record_action_request.additional_properties = d
        return create_record_action_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
