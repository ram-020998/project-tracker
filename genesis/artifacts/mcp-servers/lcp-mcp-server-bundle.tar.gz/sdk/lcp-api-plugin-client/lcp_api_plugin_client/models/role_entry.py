from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="RoleEntry")


@_attrs_define
class RoleEntry:
    """
    Attributes:
        role_name (str):
        group_names (list[str]):
        inherited_group_names (list[str] | Unset): Group names inherited from parent objects (read-only). Empty for non-
            content objects or when inheritance is disabled. Not accepted on PUT — only groupNames is used for updates.
    """

    role_name: str
    group_names: list[str]
    inherited_group_names: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        role_name = self.role_name

        group_names = self.group_names

        inherited_group_names: list[str] | Unset = UNSET
        if not isinstance(self.inherited_group_names, Unset):
            inherited_group_names = self.inherited_group_names

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "roleName": role_name,
                "groupNames": group_names,
            }
        )
        if inherited_group_names is not UNSET:
            field_dict["inheritedGroupNames"] = inherited_group_names

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        role_name = d.pop("roleName")

        group_names = cast(list[str], d.pop("groupNames"))

        inherited_group_names = cast(list[str], d.pop("inheritedGroupNames", UNSET))

        role_entry = cls(
            role_name=role_name,
            group_names=group_names,
            inherited_group_names=inherited_group_names,
        )

        role_entry.additional_properties = d
        return role_entry

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
