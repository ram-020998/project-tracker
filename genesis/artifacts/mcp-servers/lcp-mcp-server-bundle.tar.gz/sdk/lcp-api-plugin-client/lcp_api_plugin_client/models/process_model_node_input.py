from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.form_config import FormConfig
    from ..models.node_assignment import NodeAssignment
    from ..models.node_connection import NodeConnection
    from ..models.node_data import NodeData
    from ..models.node_decision import NodeDecision
    from ..models.process_model_node_input_forms_type_1 import ProcessModelNodeInputFormsType1
    from ..models.process_model_node_input_name_type_1 import ProcessModelNodeInputNameType1


T = TypeVar("T", bound="ProcessModelNodeInput")


@_attrs_define
class ProcessModelNodeInput:
    """A node in a process model graph.

    The `type` field is a node type identifier. Use `listProcessModelNodeTypes`
    to discover available types and `getProcessModelNodeTypeSchema` to get the
    input/output schema for a specific type.

    Nodes are connected via an adjacency list: each node's `connections` array
    lists the IDs of nodes it has outgoing edges to.

        Attributes:
            id (int): Node ID, must be unique within the process model Example: 1.
            type_ (str): Activity class schema ID. For new nodes, use one of the supported
                current-version IDs. For round-trip updates, pass the value from GET
                unchanged to preserve the node version.
                 Example: core.0.
            name (ProcessModelNodeInputNameType1 | str): Developer-defined instance label shown on the process modeler
                canvas.
                Can be a simple string (stored in site's primary locale) or a map of locale codes to localized names.
                When viewing nodes (GET), always returns as a locale map showing all configured locales.
            coordinates (list[int]): Canvas position as [x, y] Example: [100, 200].
            type_name (str | Unset): Static display name from the activity schema (e.g., "Send E-Mail",
                "Write Records and Related Records"). Read-only, returned on GET
                responses only. Ignored on create/update.
                 Example: Start Event.
            connections (list[NodeConnection] | Unset): Outgoing edges: the connections from this node to target nodes. Each
                connection
                specifies its `targetNodeId` and its `activityChained` flag (required), plus optional
                `overridesAssignment`, `synchronizeData`, and `label`. Direction is always from this
                node to the target.
                Defaults to empty array if omitted. Use an empty array (or omit) for terminal nodes (e.g., End Event).

                IMPORTANT: All target node IDs must already exist in the process model.
                When creating multiple connected nodes, either:
                1. Create nodes without connections first, then use updateProcessModelNode to wire connections after all nodes
                exist, OR
                2. Create nodes in reverse-dependency order (create target nodes before source nodes)
                 Example: [{'targetNodeId': 2, 'activityChained': False}].
            decision (NodeDecision | None | Unset): Gateway decision config (Decision tab). Present on XOR and OR gateway
                nodes.
                Null for activities, events, and AND gateways.
            data (NodeData | None | Unset): Activity/event node data (Data/Setup tab). Present on activity nodes
                (smart services, script tasks, user input tasks) and configurable event nodes
                (e.g., event.timer). Null for gateways and unconfigured events (Start, End).
                Contains inputs/customInputs/outputs/customOutputs split by schema-defined vs custom ACPs.
                For event.timer: contains synthetic inputs (delayFor, delayUnit, delayUntil).
            forms (FormConfig | None | ProcessModelNodeInputFormsType1 | Unset): Form configuration (Forms tab). Present on
                attended activity nodes
                (e.g., User Input Task). Null for unattended nodes, gateways, and events.

                **INPUT**: Can be a simple FormConfig (stored in site's primary locale) OR a map of locale codes to FormConfig
                objects for multi-locale support.
                **OUTPUT**: Always returns as a map of locale codes to FormConfig objects, showing all configured locales.
            assignment (NodeAssignment | None | Unset): Assignment configuration (Assignment tab). Present on activity
                nodes.
                Null for gateways and events. Controls attended/unattended mode,
                task assignee, reassignment privileges, and run-as identity.
            lane (int | None | Unset): Index into the process model's lanes array.
    """

    id: int
    type_: str
    name: ProcessModelNodeInputNameType1 | str
    coordinates: list[int]
    type_name: str | Unset = UNSET
    connections: list[NodeConnection] | Unset = UNSET
    decision: NodeDecision | None | Unset = UNSET
    data: NodeData | None | Unset = UNSET
    forms: FormConfig | None | ProcessModelNodeInputFormsType1 | Unset = UNSET
    assignment: NodeAssignment | None | Unset = UNSET
    lane: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.form_config import FormConfig
        from ..models.node_assignment import NodeAssignment
        from ..models.node_data import NodeData
        from ..models.node_decision import NodeDecision
        from ..models.process_model_node_input_forms_type_1 import ProcessModelNodeInputFormsType1
        from ..models.process_model_node_input_name_type_1 import ProcessModelNodeInputNameType1

        id = self.id

        type_ = self.type_

        name: dict[str, Any] | str
        if isinstance(self.name, ProcessModelNodeInputNameType1):
            name = self.name.to_dict()
        else:
            name = self.name

        coordinates = self.coordinates

        type_name = self.type_name

        connections: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.connections, Unset):
            connections = []
            for connections_item_data in self.connections:
                connections_item = connections_item_data.to_dict()
                connections.append(connections_item)

        decision: dict[str, Any] | None | Unset
        if isinstance(self.decision, Unset):
            decision = UNSET
        elif isinstance(self.decision, NodeDecision):
            decision = self.decision.to_dict()
        else:
            decision = self.decision

        data: dict[str, Any] | None | Unset
        if isinstance(self.data, Unset):
            data = UNSET
        elif isinstance(self.data, NodeData):
            data = self.data.to_dict()
        else:
            data = self.data

        forms: dict[str, Any] | None | Unset
        if isinstance(self.forms, Unset):
            forms = UNSET
        elif isinstance(self.forms, FormConfig):
            forms = self.forms.to_dict()
        elif isinstance(self.forms, ProcessModelNodeInputFormsType1):
            forms = self.forms.to_dict()
        else:
            forms = self.forms

        assignment: dict[str, Any] | None | Unset
        if isinstance(self.assignment, Unset):
            assignment = UNSET
        elif isinstance(self.assignment, NodeAssignment):
            assignment = self.assignment.to_dict()
        else:
            assignment = self.assignment

        lane: int | None | Unset
        if isinstance(self.lane, Unset):
            lane = UNSET
        else:
            lane = self.lane

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "type": type_,
                "name": name,
                "coordinates": coordinates,
            }
        )
        if type_name is not UNSET:
            field_dict["typeName"] = type_name
        if connections is not UNSET:
            field_dict["connections"] = connections
        if decision is not UNSET:
            field_dict["decision"] = decision
        if data is not UNSET:
            field_dict["data"] = data
        if forms is not UNSET:
            field_dict["forms"] = forms
        if assignment is not UNSET:
            field_dict["assignment"] = assignment
        if lane is not UNSET:
            field_dict["lane"] = lane

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.form_config import FormConfig
        from ..models.node_assignment import NodeAssignment
        from ..models.node_connection import NodeConnection
        from ..models.node_data import NodeData
        from ..models.node_decision import NodeDecision
        from ..models.process_model_node_input_forms_type_1 import ProcessModelNodeInputFormsType1
        from ..models.process_model_node_input_name_type_1 import ProcessModelNodeInputNameType1

        d = dict(src_dict)
        id = d.pop("id")

        type_ = d.pop("type")

        def _parse_name(data: object) -> ProcessModelNodeInputNameType1 | str:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                name_type_1 = ProcessModelNodeInputNameType1.from_dict(data)

                return name_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ProcessModelNodeInputNameType1 | str, data)

        name = _parse_name(d.pop("name"))

        coordinates = cast(list[int], d.pop("coordinates"))

        type_name = d.pop("typeName", UNSET)

        _connections = d.pop("connections", UNSET)
        connections: list[NodeConnection] | Unset = UNSET
        if _connections is not UNSET:
            connections = []
            for connections_item_data in _connections:
                connections_item = NodeConnection.from_dict(connections_item_data)

                connections.append(connections_item)

        def _parse_decision(data: object) -> NodeDecision | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                decision_type_1 = NodeDecision.from_dict(data)

                return decision_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(NodeDecision | None | Unset, data)

        decision = _parse_decision(d.pop("decision", UNSET))

        def _parse_data(data: object) -> NodeData | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                data_type_1 = NodeData.from_dict(data)

                return data_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(NodeData | None | Unset, data)

        data = _parse_data(d.pop("data", UNSET))

        def _parse_forms(data: object) -> FormConfig | None | ProcessModelNodeInputFormsType1 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                forms_type_0 = FormConfig.from_dict(data)

                return forms_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                forms_type_1 = ProcessModelNodeInputFormsType1.from_dict(data)

                return forms_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(FormConfig | None | ProcessModelNodeInputFormsType1 | Unset, data)

        forms = _parse_forms(d.pop("forms", UNSET))

        def _parse_assignment(data: object) -> NodeAssignment | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                assignment_type_1 = NodeAssignment.from_dict(data)

                return assignment_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(NodeAssignment | None | Unset, data)

        assignment = _parse_assignment(d.pop("assignment", UNSET))

        def _parse_lane(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        lane = _parse_lane(d.pop("lane", UNSET))

        process_model_node_input = cls(
            id=id,
            type_=type_,
            name=name,
            coordinates=coordinates,
            type_name=type_name,
            connections=connections,
            decision=decision,
            data=data,
            forms=forms,
            assignment=assignment,
            lane=lane,
        )

        process_model_node_input.additional_properties = d
        return process_model_node_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
