from enum import Enum


class FacetOptionOperator(str, Enum):
    BETWEEN = "BETWEEN"
    EQUALS = "EQUALS"
    NOT_EQUALS = "NOT_EQUALS"

    def __str__(self) -> str:
        return str(self.value)
