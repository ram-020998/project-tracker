from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ValidateExpressionRequestBindingsType0Item")


@_attrs_define
class ValidateExpressionRequestBindingsType0Item:
    """
    Attributes:
        name (str | Unset): Variable name (without domain prefix)
        domain (str | Unset): Variable domain (e.g. "local")
        type_ (str | Unset): Variable type (e.g. "Text")
    """

    name: str | Unset = UNSET
    domain: str | Unset = UNSET
    type_: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        domain = self.domain

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if domain is not UNSET:
            field_dict["domain"] = domain
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        domain = d.pop("domain", UNSET)

        type_ = d.pop("type", UNSET)

        validate_expression_request_bindings_type_0_item = cls(
            name=name,
            domain=domain,
            type_=type_,
        )

        validate_expression_request_bindings_type_0_item.additional_properties = d
        return validate_expression_request_bindings_type_0_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
