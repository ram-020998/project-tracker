from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ConfigureRecordEventsRequest")


@_attrs_define
class ConfigureRecordEventsRequest:
    """Request body for configuring record events on a record type.

    Attributes:
        version_id (str | Unset): Current version ID for optimistic concurrency control
        app_uuid (None | str | Unset): Application UUID (see listApplications). Auto-adds generated record types to the
            app and applies the app's default security.
             Example: app-uuid-456.
        event_types (list[str] | None | Unset): Event types representing key moments in the business lifecycle of this
            record. Use past-tense verb phrases (e.g. "Created Order", "Approved Application", "Shipped Order"). Avoid
            generic recurring operations like "Updated" — focus on meaningful business activities that ideally occur once
            per record in a specific order.
             Example: ['Created Order', 'Approved Application', 'Shipped Order'].
    """

    version_id: str | Unset = UNSET
    app_uuid: None | str | Unset = UNSET
    event_types: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        version_id = self.version_id

        app_uuid: None | str | Unset
        if isinstance(self.app_uuid, Unset):
            app_uuid = UNSET
        else:
            app_uuid = self.app_uuid

        event_types: list[str] | None | Unset
        if isinstance(self.event_types, Unset):
            event_types = UNSET
        elif isinstance(self.event_types, list):
            event_types = self.event_types

        else:
            event_types = self.event_types

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid
        if event_types is not UNSET:
            field_dict["eventTypes"] = event_types

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        version_id = d.pop("versionId", UNSET)

        def _parse_app_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        app_uuid = _parse_app_uuid(d.pop("appUuid", UNSET))

        def _parse_event_types(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                event_types_type_0 = cast(list[str], data)

                return event_types_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        event_types = _parse_event_types(d.pop("eventTypes", UNSET))

        configure_record_events_request = cls(
            version_id=version_id,
            app_uuid=app_uuid,
            event_types=event_types,
        )

        configure_record_events_request.additional_properties = d
        return configure_record_events_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
