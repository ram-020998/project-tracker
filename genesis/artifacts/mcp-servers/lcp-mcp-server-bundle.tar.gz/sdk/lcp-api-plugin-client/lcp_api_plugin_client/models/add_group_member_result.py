from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.add_group_member_result_status import AddGroupMemberResultStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="AddGroupMemberResult")


@_attrs_define
class AddGroupMemberResult:
    """
    Attributes:
        type_ (str | Unset):
        id (str | Unset):
        status (AddGroupMemberResultStatus | Unset):
        message (None | str | Unset):
    """

    type_: str | Unset = UNSET
    id: str | Unset = UNSET
    status: AddGroupMemberResultStatus | Unset = UNSET
    message: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        id = self.id

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        message: None | str | Unset
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if id is not UNSET:
            field_dict["id"] = id
        if status is not UNSET:
            field_dict["status"] = status
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = d.pop("type", UNSET)

        id = d.pop("id", UNSET)

        _status = d.pop("status", UNSET)
        status: AddGroupMemberResultStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = AddGroupMemberResultStatus(_status)

        def _parse_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        message = _parse_message(d.pop("message", UNSET))

        add_group_member_result = cls(
            type_=type_,
            id=id,
            status=status,
            message=message,
        )

        add_group_member_result.additional_properties = d
        return add_group_member_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
