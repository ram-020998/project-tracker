from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.document_text_metadata_extraction_method import DocumentTextMetadataExtractionMethod
from ..types import UNSET, Unset

T = TypeVar("T", bound="DocumentTextMetadata")


@_attrs_define
class DocumentTextMetadata:
    """Metadata about the text extraction

    Attributes:
        extraction_method (DocumentTextMetadataExtractionMethod | Unset): How the text was extracted Example: NATIVE.
        language (None | str | Unset): Detected language code (e.g., "en", "es") Example: en.
    """

    extraction_method: DocumentTextMetadataExtractionMethod | Unset = UNSET
    language: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        extraction_method: str | Unset = UNSET
        if not isinstance(self.extraction_method, Unset):
            extraction_method = self.extraction_method.value

        language: None | str | Unset
        if isinstance(self.language, Unset):
            language = UNSET
        else:
            language = self.language

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if extraction_method is not UNSET:
            field_dict["extractionMethod"] = extraction_method
        if language is not UNSET:
            field_dict["language"] = language

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _extraction_method = d.pop("extractionMethod", UNSET)
        extraction_method: DocumentTextMetadataExtractionMethod | Unset
        if isinstance(_extraction_method, Unset):
            extraction_method = UNSET
        else:
            extraction_method = DocumentTextMetadataExtractionMethod(_extraction_method)

        def _parse_language(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        language = _parse_language(d.pop("language", UNSET))

        document_text_metadata = cls(
            extraction_method=extraction_method,
            language=language,
        )

        document_text_metadata.additional_properties = d
        return document_text_metadata

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
