from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.record_type_relationship_detail_relationship_type import RecordTypeRelationshipDetailRelationshipType
from ..types import UNSET, Unset

T = TypeVar("T", bound="RecordTypeRelationshipDetail")


@_attrs_define
class RecordTypeRelationshipDetail:
    """Relationship metadata returned in record type responses

    Attributes:
        relationship_uuid (str | Unset): The relationship UUID Example: rel-uuid-123.
        relationship_name (str | Unset): The relationship name Example: orders.
        source_record_type_field_uuid (str | Unset): UUID of the source field in this record type Example: field-
            uuid-123.
        target_record_type_field_uuid (str | Unset): UUID of the target field in the related record type Example: field-
            uuid-456.
        target_record_type_uuid (str | Unset): UUID of the related record type Example: rt-uuid-789.
        relationship_type (RecordTypeRelationshipDetailRelationshipType | Unset): The type of relationship Example:
            ONE_TO_MANY.
    """

    relationship_uuid: str | Unset = UNSET
    relationship_name: str | Unset = UNSET
    source_record_type_field_uuid: str | Unset = UNSET
    target_record_type_field_uuid: str | Unset = UNSET
    target_record_type_uuid: str | Unset = UNSET
    relationship_type: RecordTypeRelationshipDetailRelationshipType | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        relationship_uuid = self.relationship_uuid

        relationship_name = self.relationship_name

        source_record_type_field_uuid = self.source_record_type_field_uuid

        target_record_type_field_uuid = self.target_record_type_field_uuid

        target_record_type_uuid = self.target_record_type_uuid

        relationship_type: str | Unset = UNSET
        if not isinstance(self.relationship_type, Unset):
            relationship_type = self.relationship_type.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if relationship_uuid is not UNSET:
            field_dict["relationshipUuid"] = relationship_uuid
        if relationship_name is not UNSET:
            field_dict["relationshipName"] = relationship_name
        if source_record_type_field_uuid is not UNSET:
            field_dict["sourceRecordTypeFieldUuid"] = source_record_type_field_uuid
        if target_record_type_field_uuid is not UNSET:
            field_dict["targetRecordTypeFieldUuid"] = target_record_type_field_uuid
        if target_record_type_uuid is not UNSET:
            field_dict["targetRecordTypeUuid"] = target_record_type_uuid
        if relationship_type is not UNSET:
            field_dict["relationshipType"] = relationship_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        relationship_uuid = d.pop("relationshipUuid", UNSET)

        relationship_name = d.pop("relationshipName", UNSET)

        source_record_type_field_uuid = d.pop("sourceRecordTypeFieldUuid", UNSET)

        target_record_type_field_uuid = d.pop("targetRecordTypeFieldUuid", UNSET)

        target_record_type_uuid = d.pop("targetRecordTypeUuid", UNSET)

        _relationship_type = d.pop("relationshipType", UNSET)
        relationship_type: RecordTypeRelationshipDetailRelationshipType | Unset
        if isinstance(_relationship_type, Unset):
            relationship_type = UNSET
        else:
            relationship_type = RecordTypeRelationshipDetailRelationshipType(_relationship_type)

        record_type_relationship_detail = cls(
            relationship_uuid=relationship_uuid,
            relationship_name=relationship_name,
            source_record_type_field_uuid=source_record_type_field_uuid,
            target_record_type_field_uuid=target_record_type_field_uuid,
            target_record_type_uuid=target_record_type_uuid,
            relationship_type=relationship_type,
        )

        record_type_relationship_detail.additional_properties = d
        return record_type_relationship_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
