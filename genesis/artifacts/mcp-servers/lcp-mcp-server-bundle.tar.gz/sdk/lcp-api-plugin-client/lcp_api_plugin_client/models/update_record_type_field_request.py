from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.update_record_type_field_request_field_type import UpdateRecordTypeFieldRequestFieldType
from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateRecordTypeFieldRequest")


@_attrs_define
class UpdateRecordTypeFieldRequest:
    """Request body for updating a field on a record type. Only provided fields are changed.

    Attributes:
        version_id (str | Unset): Current version ID for optimistic concurrency control
        field_name (str | Unset): The field name Example: emailAddress.
        field_type (UpdateRecordTypeFieldRequestFieldType | Unset): The field data type Example: TEXT.
        source_field_name (str | Unset): Backing store field/column name Example: email_address.
        display_name (str | Unset): Human-readable display name Example: Email Address.
        description (str | Unset): Field description Example: Customer email address.
        is_primary_key (bool | Unset): Whether this field is the primary key
        is_unique (bool | Unset): Whether this field has a unique constraint
        length (int | Unset): Column length for TEXT fields. 0 means default. Example: 255.
        update_table (bool | Unset): When true, Appian ALTERs the database table to update the column (mirrors the
            'Update Table' checkbox in Appian Designer). When false, returns an error — non-CDM operations are not yet
            supported. Default: True. Example: True.
    """

    version_id: str | Unset = UNSET
    field_name: str | Unset = UNSET
    field_type: UpdateRecordTypeFieldRequestFieldType | Unset = UNSET
    source_field_name: str | Unset = UNSET
    display_name: str | Unset = UNSET
    description: str | Unset = UNSET
    is_primary_key: bool | Unset = UNSET
    is_unique: bool | Unset = UNSET
    length: int | Unset = UNSET
    update_table: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        version_id = self.version_id

        field_name = self.field_name

        field_type: str | Unset = UNSET
        if not isinstance(self.field_type, Unset):
            field_type = self.field_type.value

        source_field_name = self.source_field_name

        display_name = self.display_name

        description = self.description

        is_primary_key = self.is_primary_key

        is_unique = self.is_unique

        length = self.length

        update_table = self.update_table

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if field_name is not UNSET:
            field_dict["fieldName"] = field_name
        if field_type is not UNSET:
            field_dict["fieldType"] = field_type
        if source_field_name is not UNSET:
            field_dict["sourceFieldName"] = source_field_name
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if description is not UNSET:
            field_dict["description"] = description
        if is_primary_key is not UNSET:
            field_dict["isPrimaryKey"] = is_primary_key
        if is_unique is not UNSET:
            field_dict["isUnique"] = is_unique
        if length is not UNSET:
            field_dict["length"] = length
        if update_table is not UNSET:
            field_dict["updateTable"] = update_table

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        version_id = d.pop("versionId", UNSET)

        field_name = d.pop("fieldName", UNSET)

        _field_type = d.pop("fieldType", UNSET)
        field_type: UpdateRecordTypeFieldRequestFieldType | Unset
        if isinstance(_field_type, Unset):
            field_type = UNSET
        else:
            field_type = UpdateRecordTypeFieldRequestFieldType(_field_type)

        source_field_name = d.pop("sourceFieldName", UNSET)

        display_name = d.pop("displayName", UNSET)

        description = d.pop("description", UNSET)

        is_primary_key = d.pop("isPrimaryKey", UNSET)

        is_unique = d.pop("isUnique", UNSET)

        length = d.pop("length", UNSET)

        update_table = d.pop("updateTable", UNSET)

        update_record_type_field_request = cls(
            version_id=version_id,
            field_name=field_name,
            field_type=field_type,
            source_field_name=source_field_name,
            display_name=display_name,
            description=description,
            is_primary_key=is_primary_key,
            is_unique=is_unique,
            length=length,
            update_table=update_table,
        )

        update_record_type_field_request.additional_properties = d
        return update_record_type_field_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
