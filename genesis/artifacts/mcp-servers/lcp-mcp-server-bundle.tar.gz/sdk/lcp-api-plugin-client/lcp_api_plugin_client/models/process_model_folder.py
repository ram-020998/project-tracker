from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ProcessModelFolder")


@_attrs_define
class ProcessModelFolder:
    """
    Attributes:
        uuid (str | Unset):
        name (str | Unset):
        description (str | Unset):
        number_of_process_models (int | Unset):
        number_of_child_folders (int | Unset):
    """

    uuid: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    number_of_process_models: int | Unset = UNSET
    number_of_child_folders: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        name = self.name

        description = self.description

        number_of_process_models = self.number_of_process_models

        number_of_child_folders = self.number_of_child_folders

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if number_of_process_models is not UNSET:
            field_dict["numberOfProcessModels"] = number_of_process_models
        if number_of_child_folders is not UNSET:
            field_dict["numberOfChildFolders"] = number_of_child_folders

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        number_of_process_models = d.pop("numberOfProcessModels", UNSET)

        number_of_child_folders = d.pop("numberOfChildFolders", UNSET)

        process_model_folder = cls(
            uuid=uuid,
            name=name,
            description=description,
            number_of_process_models=number_of_process_models,
            number_of_child_folders=number_of_child_folders,
        )

        process_model_folder.additional_properties = d
        return process_model_folder

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
