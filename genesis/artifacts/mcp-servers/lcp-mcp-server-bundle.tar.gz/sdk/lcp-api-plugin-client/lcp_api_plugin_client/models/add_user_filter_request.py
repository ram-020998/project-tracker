from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.add_user_filter_request_facet_type import AddUserFilterRequestFacetType
from ..models.add_user_filter_request_related_record_sort import AddUserFilterRequestRelatedRecordSort
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.facet_option import FacetOption


T = TypeVar("T", bound="AddUserFilterRequest")


@_attrs_define
class AddUserFilterRequest:
    """
    Attributes:
        name (str):
        facet_type (AddUserFilterRequestFacetType):
        version_id (str | Unset): Current version ID for optimistic concurrency control
        expression (None | str | Unset):
        label_expression (None | str | Unset):
        source_ref (None | str | Unset):
        visibility_expression (None | str | Unset):
        default_option_expression (None | str | Unset):
        options (list[FacetOption] | Unset):
        start_date_expression (None | str | Unset):
        end_date_expression (None | str | Unset):
        allow_multiple_selections (bool | Unset):  Default: False.
        use_related_record_values (bool | Unset): Applies when sourceRef is a related record field or a foreign key
            field that references a related record. Automatically use the values from the related record field as the list
            options.
             Default: False.
        related_record_display_field (str | Unset): UUID of a Text field on the related record type to use as filter
            option labels. Required when useRelatedRecordValues is true.
        related_record_sort (AddUserFilterRequestRelatedRecordSort | Unset): Sort order for related record filter
            options. Required when useRelatedRecordValues is true.
    """

    name: str
    facet_type: AddUserFilterRequestFacetType
    version_id: str | Unset = UNSET
    expression: None | str | Unset = UNSET
    label_expression: None | str | Unset = UNSET
    source_ref: None | str | Unset = UNSET
    visibility_expression: None | str | Unset = UNSET
    default_option_expression: None | str | Unset = UNSET
    options: list[FacetOption] | Unset = UNSET
    start_date_expression: None | str | Unset = UNSET
    end_date_expression: None | str | Unset = UNSET
    allow_multiple_selections: bool | Unset = False
    use_related_record_values: bool | Unset = False
    related_record_display_field: str | Unset = UNSET
    related_record_sort: AddUserFilterRequestRelatedRecordSort | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        facet_type = self.facet_type.value

        version_id = self.version_id

        expression: None | str | Unset
        if isinstance(self.expression, Unset):
            expression = UNSET
        else:
            expression = self.expression

        label_expression: None | str | Unset
        if isinstance(self.label_expression, Unset):
            label_expression = UNSET
        else:
            label_expression = self.label_expression

        source_ref: None | str | Unset
        if isinstance(self.source_ref, Unset):
            source_ref = UNSET
        else:
            source_ref = self.source_ref

        visibility_expression: None | str | Unset
        if isinstance(self.visibility_expression, Unset):
            visibility_expression = UNSET
        else:
            visibility_expression = self.visibility_expression

        default_option_expression: None | str | Unset
        if isinstance(self.default_option_expression, Unset):
            default_option_expression = UNSET
        else:
            default_option_expression = self.default_option_expression

        options: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.options, Unset):
            options = []
            for options_item_data in self.options:
                options_item = options_item_data.to_dict()
                options.append(options_item)

        start_date_expression: None | str | Unset
        if isinstance(self.start_date_expression, Unset):
            start_date_expression = UNSET
        else:
            start_date_expression = self.start_date_expression

        end_date_expression: None | str | Unset
        if isinstance(self.end_date_expression, Unset):
            end_date_expression = UNSET
        else:
            end_date_expression = self.end_date_expression

        allow_multiple_selections = self.allow_multiple_selections

        use_related_record_values = self.use_related_record_values

        related_record_display_field = self.related_record_display_field

        related_record_sort: str | Unset = UNSET
        if not isinstance(self.related_record_sort, Unset):
            related_record_sort = self.related_record_sort.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "facetType": facet_type,
            }
        )
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if expression is not UNSET:
            field_dict["expression"] = expression
        if label_expression is not UNSET:
            field_dict["labelExpression"] = label_expression
        if source_ref is not UNSET:
            field_dict["sourceRef"] = source_ref
        if visibility_expression is not UNSET:
            field_dict["visibilityExpression"] = visibility_expression
        if default_option_expression is not UNSET:
            field_dict["defaultOptionExpression"] = default_option_expression
        if options is not UNSET:
            field_dict["options"] = options
        if start_date_expression is not UNSET:
            field_dict["startDateExpression"] = start_date_expression
        if end_date_expression is not UNSET:
            field_dict["endDateExpression"] = end_date_expression
        if allow_multiple_selections is not UNSET:
            field_dict["allowMultipleSelections"] = allow_multiple_selections
        if use_related_record_values is not UNSET:
            field_dict["useRelatedRecordValues"] = use_related_record_values
        if related_record_display_field is not UNSET:
            field_dict["relatedRecordDisplayField"] = related_record_display_field
        if related_record_sort is not UNSET:
            field_dict["relatedRecordSort"] = related_record_sort

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.facet_option import FacetOption

        d = dict(src_dict)
        name = d.pop("name")

        facet_type = AddUserFilterRequestFacetType(d.pop("facetType"))

        version_id = d.pop("versionId", UNSET)

        def _parse_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expression = _parse_expression(d.pop("expression", UNSET))

        def _parse_label_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        label_expression = _parse_label_expression(d.pop("labelExpression", UNSET))

        def _parse_source_ref(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        source_ref = _parse_source_ref(d.pop("sourceRef", UNSET))

        def _parse_visibility_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        visibility_expression = _parse_visibility_expression(d.pop("visibilityExpression", UNSET))

        def _parse_default_option_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        default_option_expression = _parse_default_option_expression(d.pop("defaultOptionExpression", UNSET))

        _options = d.pop("options", UNSET)
        options: list[FacetOption] | Unset = UNSET
        if _options is not UNSET:
            options = []
            for options_item_data in _options:
                options_item = FacetOption.from_dict(options_item_data)

                options.append(options_item)

        def _parse_start_date_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        start_date_expression = _parse_start_date_expression(d.pop("startDateExpression", UNSET))

        def _parse_end_date_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        end_date_expression = _parse_end_date_expression(d.pop("endDateExpression", UNSET))

        allow_multiple_selections = d.pop("allowMultipleSelections", UNSET)

        use_related_record_values = d.pop("useRelatedRecordValues", UNSET)

        related_record_display_field = d.pop("relatedRecordDisplayField", UNSET)

        _related_record_sort = d.pop("relatedRecordSort", UNSET)
        related_record_sort: AddUserFilterRequestRelatedRecordSort | Unset
        if isinstance(_related_record_sort, Unset):
            related_record_sort = UNSET
        else:
            related_record_sort = AddUserFilterRequestRelatedRecordSort(_related_record_sort)

        add_user_filter_request = cls(
            name=name,
            facet_type=facet_type,
            version_id=version_id,
            expression=expression,
            label_expression=label_expression,
            source_ref=source_ref,
            visibility_expression=visibility_expression,
            default_option_expression=default_option_expression,
            options=options,
            start_date_expression=start_date_expression,
            end_date_expression=end_date_expression,
            allow_multiple_selections=allow_multiple_selections,
            use_related_record_values=use_related_record_values,
            related_record_display_field=related_record_display_field,
            related_record_sort=related_record_sort,
        )

        add_user_filter_request.additional_properties = d
        return add_user_filter_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
