from enum import Enum


class UpdateSiteRequestStyle(str, Enum):
    HELIUM = "HELIUM"
    MERCURY = "MERCURY"
    OXYGEN = "OXYGEN"

    def __str__(self) -> str:
        return str(self.value)
