from enum import Enum


class SiteStyle(str, Enum):
    HELIUM = "HELIUM"
    MERCURY = "MERCURY"
    OXYGEN = "OXYGEN"

    def __str__(self) -> str:
        return str(self.value)
