from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.update_constant_request_type import UpdateConstantRequestType
from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateConstantRequest")


@_attrs_define
class UpdateConstantRequest:
    """Request body for updating an existing constant. All fields are optional, but at
    least one field must be provided. Only the fields included in the request will
    be updated; other fields will retain their existing values.

    **Important**: When updating type and value together, the value must be compatible
    with the new type. If only value is updated, it must be compatible with the existing
    type. If only type is updated, the existing value must be compatible with the new type.

        Attributes:
            version_id (str | Unset): Version ID for optimistic concurrency control. If provided, validates against current
                version.
            name (str | Unset): New constant name (cannot be empty if provided) Example: UPDATED_CONSTANT_NAME.
            description (str | Unset): New description (can be empty string to clear description) Example: This is the
                updated description.
            type_ (UpdateConstantRequestType | Unset): New data type for the constant. Must be one of the supported types.
                If provided, ensure the value (existing or new) is compatible with this type.
                 Example: NUMBER.
            value (bool | float | int | list[float | int | str] | str | Unset): New value for the constant. Must be
                compatible with the type (existing or new).
                When multiple=true, value must be a JSON array.
                 Example: 10.
            multiple (bool | Unset): When true, converts to a list-typed constant. When toggling multiple, value must also
                be provided in the compatible format. Boolean type does not support multiple.
    """

    version_id: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    type_: UpdateConstantRequestType | Unset = UNSET
    value: bool | float | int | list[float | int | str] | str | Unset = UNSET
    multiple: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        version_id = self.version_id

        name = self.name

        description = self.description

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        value: bool | float | int | list[float | int | str] | str | Unset
        if isinstance(self.value, Unset):
            value = UNSET
        elif isinstance(self.value, list):
            value = []
            for value_type_4_item_data in self.value:
                value_type_4_item: float | int | str
                value_type_4_item = value_type_4_item_data
                value.append(value_type_4_item)

        else:
            value = self.value

        multiple = self.multiple

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if type_ is not UNSET:
            field_dict["type"] = type_
        if value is not UNSET:
            field_dict["value"] = value
        if multiple is not UNSET:
            field_dict["multiple"] = multiple

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        version_id = d.pop("versionId", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: UpdateConstantRequestType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = UpdateConstantRequestType(_type_)

        def _parse_value(data: object) -> bool | float | int | list[float | int | str] | str | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                value_type_4 = []
                _value_type_4 = data
                for value_type_4_item_data in _value_type_4:

                    def _parse_value_type_4_item(data: object) -> float | int | str:
                        return cast(float | int | str, data)

                    value_type_4_item = _parse_value_type_4_item(value_type_4_item_data)

                    value_type_4.append(value_type_4_item)

                return value_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(bool | float | int | list[float | int | str] | str | Unset, data)

        value = _parse_value(d.pop("value", UNSET))

        multiple = d.pop("multiple", UNSET)

        update_constant_request = cls(
            version_id=version_id,
            name=name,
            description=description,
            type_=type_,
            value=value,
            multiple=multiple,
        )

        update_constant_request.additional_properties = d
        return update_constant_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
