from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="CreateIntegrationRequestPropertiesType0")


@_attrs_define
class CreateIntegrationRequestPropertiesType0:
    """Configuration properties (validated against the operation schema).

    For HTTP integrations with a `multipart/form-data` body, set the body one of
    two ways:
    - `bodyFormParts`: a structured list of `{name, contentType, value}` objects,
      one per form field. Each is compiled into an `a!httpFormPart(...)` call.
      `value` is a raw SAIL expression fragment (e.g. `ri!requirements`, or a
      literal like `true`); `contentType` is the part's MIME type (e.g.
      `"text/plain"`, or `"auto-detect"` for document parts).
    - `bodyContent`: a raw SAIL expression that must evaluate to a list of
      `a!httpFormPart(...)` values. Overrides `bodyFormParts` when set. Use this
      when you need conditional parts, e.g.
      `if(a!isNotNullOrEmpty(ri!file), a!httpFormPart(name: "file", contentType: "auto-detect", value: ri!file), {})`.

    The body is validated before save: unresolved `ri!` references and, for
    multipart, a body that does not evaluate to `a!httpFormPart(...)` values are
    rejected with a 400.

        Example:
            {'httpMethod': 'GET', 'relativePath': '/orders'}

    """

    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        create_integration_request_properties_type_0 = cls()

        create_integration_request_properties_type_0.additional_properties = d
        return create_integration_request_properties_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
