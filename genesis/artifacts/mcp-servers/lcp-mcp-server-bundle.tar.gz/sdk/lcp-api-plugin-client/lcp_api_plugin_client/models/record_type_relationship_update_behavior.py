from enum import Enum


class RecordTypeRelationshipUpdateBehavior(str, Enum):
    CASCADING = "CASCADING"
    NON_CASCADING = "NON_CASCADING"

    def __str__(self) -> str:
        return str(self.value)
