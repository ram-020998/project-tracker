from enum import Enum


class RecordActionActionType(str, Enum):
    LIST_ACTION = "LIST_ACTION"
    RELATED_ACTION = "RELATED_ACTION"

    def __str__(self) -> str:
        return str(self.value)
