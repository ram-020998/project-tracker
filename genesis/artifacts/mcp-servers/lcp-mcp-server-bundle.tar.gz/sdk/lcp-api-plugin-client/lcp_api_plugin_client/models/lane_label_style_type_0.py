from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="LaneLabelStyleType0")


@_attrs_define
class LaneLabelStyleType0:
    """Font styling for the lane's label

    Attributes:
        font_color (None | str | Unset): Font color (hex) Example: #000000.
        font_family (None | str | Unset): Font family Example: Appian Open Sans, Sans-Serif.
        font_size (int | None | Unset): Font size in pixels Example: 12.
        bold (bool | None | Unset): Whether the label text is bold
        italics (bool | None | Unset): Whether the label text is italicized
        underline (bool | None | Unset): Whether the label text is underlined
    """

    font_color: None | str | Unset = UNSET
    font_family: None | str | Unset = UNSET
    font_size: int | None | Unset = UNSET
    bold: bool | None | Unset = UNSET
    italics: bool | None | Unset = UNSET
    underline: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        font_color: None | str | Unset
        if isinstance(self.font_color, Unset):
            font_color = UNSET
        else:
            font_color = self.font_color

        font_family: None | str | Unset
        if isinstance(self.font_family, Unset):
            font_family = UNSET
        else:
            font_family = self.font_family

        font_size: int | None | Unset
        if isinstance(self.font_size, Unset):
            font_size = UNSET
        else:
            font_size = self.font_size

        bold: bool | None | Unset
        if isinstance(self.bold, Unset):
            bold = UNSET
        else:
            bold = self.bold

        italics: bool | None | Unset
        if isinstance(self.italics, Unset):
            italics = UNSET
        else:
            italics = self.italics

        underline: bool | None | Unset
        if isinstance(self.underline, Unset):
            underline = UNSET
        else:
            underline = self.underline

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if font_color is not UNSET:
            field_dict["fontColor"] = font_color
        if font_family is not UNSET:
            field_dict["fontFamily"] = font_family
        if font_size is not UNSET:
            field_dict["fontSize"] = font_size
        if bold is not UNSET:
            field_dict["bold"] = bold
        if italics is not UNSET:
            field_dict["italics"] = italics
        if underline is not UNSET:
            field_dict["underline"] = underline

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_font_color(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        font_color = _parse_font_color(d.pop("fontColor", UNSET))

        def _parse_font_family(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        font_family = _parse_font_family(d.pop("fontFamily", UNSET))

        def _parse_font_size(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        font_size = _parse_font_size(d.pop("fontSize", UNSET))

        def _parse_bold(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        bold = _parse_bold(d.pop("bold", UNSET))

        def _parse_italics(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        italics = _parse_italics(d.pop("italics", UNSET))

        def _parse_underline(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        underline = _parse_underline(d.pop("underline", UNSET))

        lane_label_style_type_0 = cls(
            font_color=font_color,
            font_family=font_family,
            font_size=font_size,
            bold=bold,
            italics=italics,
            underline=underline,
        )

        lane_label_style_type_0.additional_properties = d
        return lane_label_style_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
