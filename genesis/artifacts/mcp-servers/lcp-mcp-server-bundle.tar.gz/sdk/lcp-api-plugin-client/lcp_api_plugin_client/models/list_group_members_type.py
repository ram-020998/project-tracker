from enum import Enum


class ListGroupMembersType(str, Enum):
    ALL = "ALL"
    GROUP = "group"
    USER = "user"

    def __str__(self) -> str:
        return str(self.value)
