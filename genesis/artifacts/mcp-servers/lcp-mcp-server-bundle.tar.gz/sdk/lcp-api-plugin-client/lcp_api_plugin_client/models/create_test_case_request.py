from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_test_case_request_assertion_type import CreateTestCaseRequestAssertionType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_test_case_request_inputs_item import CreateTestCaseRequestInputsItem


T = TypeVar("T", bound="CreateTestCaseRequest")


@_attrs_define
class CreateTestCaseRequest:
    """Request body for creating or updating a test case

    Attributes:
        name (str): Test case name (must be unique within the parent object)
        description (None | str | Unset): Optional description of the test case
        is_default (bool | Unset): Whether this is the default test case Default: False.
        inputs (list[CreateTestCaseRequestInputsItem] | Unset): List of test case input values
        assertion_type (CreateTestCaseRequestAssertionType | Unset): Assertion mode for expression rule test cases.
            Ignored for interfaces. NO_ERRORS: passes if no evaluation error. EXPECTED_OUTPUT: passes if output matches
            expectedOutput. RESULT_ASSERTIONS: passes if all resultAssertions return true. Defaults to NO_ERRORS if not
            specified.
        expected_output (None | str | Unset): SAIL expression string for the expected output value. Only used when
            assertionType is EXPECTED_OUTPUT.
        expected_output_type (None | str | Unset): Type of the expected output value (e.g. "Number (Integer)", "Number
            (Decimal)", "Text", "Boolean"). Required when assertionType is EXPECTED_OUTPUT. Must match the return type of
            the rule.
        result_assertion (None | str | Unset): SAIL assertion expression that must return true. Has access to "result"
            variable containing the rule output. Only used when assertionType is RESULT_ASSERTIONS.
    """

    name: str
    description: None | str | Unset = UNSET
    is_default: bool | Unset = False
    inputs: list[CreateTestCaseRequestInputsItem] | Unset = UNSET
    assertion_type: CreateTestCaseRequestAssertionType | Unset = UNSET
    expected_output: None | str | Unset = UNSET
    expected_output_type: None | str | Unset = UNSET
    result_assertion: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        is_default = self.is_default

        inputs: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.inputs, Unset):
            inputs = []
            for inputs_item_data in self.inputs:
                inputs_item = inputs_item_data.to_dict()
                inputs.append(inputs_item)

        assertion_type: str | Unset = UNSET
        if not isinstance(self.assertion_type, Unset):
            assertion_type = self.assertion_type.value

        expected_output: None | str | Unset
        if isinstance(self.expected_output, Unset):
            expected_output = UNSET
        else:
            expected_output = self.expected_output

        expected_output_type: None | str | Unset
        if isinstance(self.expected_output_type, Unset):
            expected_output_type = UNSET
        else:
            expected_output_type = self.expected_output_type

        result_assertion: None | str | Unset
        if isinstance(self.result_assertion, Unset):
            result_assertion = UNSET
        else:
            result_assertion = self.result_assertion

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if is_default is not UNSET:
            field_dict["isDefault"] = is_default
        if inputs is not UNSET:
            field_dict["inputs"] = inputs
        if assertion_type is not UNSET:
            field_dict["assertionType"] = assertion_type
        if expected_output is not UNSET:
            field_dict["expectedOutput"] = expected_output
        if expected_output_type is not UNSET:
            field_dict["expectedOutputType"] = expected_output_type
        if result_assertion is not UNSET:
            field_dict["resultAssertion"] = result_assertion

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_test_case_request_inputs_item import CreateTestCaseRequestInputsItem

        d = dict(src_dict)
        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        is_default = d.pop("isDefault", UNSET)

        _inputs = d.pop("inputs", UNSET)
        inputs: list[CreateTestCaseRequestInputsItem] | Unset = UNSET
        if _inputs is not UNSET:
            inputs = []
            for inputs_item_data in _inputs:
                inputs_item = CreateTestCaseRequestInputsItem.from_dict(inputs_item_data)

                inputs.append(inputs_item)

        _assertion_type = d.pop("assertionType", UNSET)
        assertion_type: CreateTestCaseRequestAssertionType | Unset
        if isinstance(_assertion_type, Unset):
            assertion_type = UNSET
        else:
            assertion_type = CreateTestCaseRequestAssertionType(_assertion_type)

        def _parse_expected_output(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expected_output = _parse_expected_output(d.pop("expectedOutput", UNSET))

        def _parse_expected_output_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expected_output_type = _parse_expected_output_type(d.pop("expectedOutputType", UNSET))

        def _parse_result_assertion(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        result_assertion = _parse_result_assertion(d.pop("resultAssertion", UNSET))

        create_test_case_request = cls(
            name=name,
            description=description,
            is_default=is_default,
            inputs=inputs,
            assertion_type=assertion_type,
            expected_output=expected_output,
            expected_output_type=expected_output_type,
            result_assertion=result_assertion,
        )

        create_test_case_request.additional_properties = d
        return create_test_case_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
