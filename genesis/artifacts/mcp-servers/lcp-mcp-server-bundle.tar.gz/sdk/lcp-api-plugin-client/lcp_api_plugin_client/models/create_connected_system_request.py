from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_connected_system_request_properties_type_0 import CreateConnectedSystemRequestPropertiesType0


T = TypeVar("T", bound="CreateConnectedSystemRequest")


@_attrs_define
class CreateConnectedSystemRequest:
    """Request body for creating a connected system.

    Attributes:
        name (str): Display name Example: My HTTP Service.
        type_ (str): Connected system type identifier Example: system.http.
        description (None | str | Unset): Description
        properties (CreateConnectedSystemRequestPropertiesType0 | None | Unset): Configuration properties (validated
            against the type schema) Example: {'baseUrl': 'https://api.example.com', 'authType': 'API_KEY', 'apiKeyName':
            'X-API-Key', 'apiKeyValue': 'secret123'}.
        app_uuid (None | str | Unset): Application UUID. When provided, the connected system is added to the
            application.
    """

    name: str
    type_: str
    description: None | str | Unset = UNSET
    properties: CreateConnectedSystemRequestPropertiesType0 | None | Unset = UNSET
    app_uuid: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.create_connected_system_request_properties_type_0 import (
            CreateConnectedSystemRequestPropertiesType0,
        )

        name = self.name

        type_ = self.type_

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        properties: dict[str, Any] | None | Unset
        if isinstance(self.properties, Unset):
            properties = UNSET
        elif isinstance(self.properties, CreateConnectedSystemRequestPropertiesType0):
            properties = self.properties.to_dict()
        else:
            properties = self.properties

        app_uuid: None | str | Unset
        if isinstance(self.app_uuid, Unset):
            app_uuid = UNSET
        else:
            app_uuid = self.app_uuid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type_,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if properties is not UNSET:
            field_dict["properties"] = properties
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_connected_system_request_properties_type_0 import (
            CreateConnectedSystemRequestPropertiesType0,
        )

        d = dict(src_dict)
        name = d.pop("name")

        type_ = d.pop("type")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_properties(data: object) -> CreateConnectedSystemRequestPropertiesType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                properties_type_0 = CreateConnectedSystemRequestPropertiesType0.from_dict(data)

                return properties_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateConnectedSystemRequestPropertiesType0 | None | Unset, data)

        properties = _parse_properties(d.pop("properties", UNSET))

        def _parse_app_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        app_uuid = _parse_app_uuid(d.pop("appUuid", UNSET))

        create_connected_system_request = cls(
            name=name,
            type_=type_,
            description=description,
            properties=properties,
            app_uuid=app_uuid,
        )

        create_connected_system_request.additional_properties = d
        return create_connected_system_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
