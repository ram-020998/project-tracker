from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="GetObjectDependentsResponse200DependentsItem")


@_attrs_define
class GetObjectDependentsResponse200DependentsItem:
    """
    Attributes:
        uuid (str | Unset): UUID of the dependent object
        type_ (str | Unset): Type of the dependent object (e.g. FREEFORM_RULE, INTERFACE, PROCESS_MODEL)
        name (None | str | Unset): Name of the dependent object (first breadcrumb)
        breadcrumb (None | str | Unset): Full breadcrumb path showing where in the dependent object this reference
            occurs (e.g. "My Interface > Local Variables > myConstant")
    """

    uuid: str | Unset = UNSET
    type_: str | Unset = UNSET
    name: None | str | Unset = UNSET
    breadcrumb: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        type_ = self.type_

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        breadcrumb: None | str | Unset
        if isinstance(self.breadcrumb, Unset):
            breadcrumb = UNSET
        else:
            breadcrumb = self.breadcrumb

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if type_ is not UNSET:
            field_dict["type"] = type_
        if name is not UNSET:
            field_dict["name"] = name
        if breadcrumb is not UNSET:
            field_dict["breadcrumb"] = breadcrumb

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid", UNSET)

        type_ = d.pop("type", UNSET)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_breadcrumb(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        breadcrumb = _parse_breadcrumb(d.pop("breadcrumb", UNSET))

        get_object_dependents_response_200_dependents_item = cls(
            uuid=uuid,
            type_=type_,
            name=name,
            breadcrumb=breadcrumb,
        )

        get_object_dependents_response_200_dependents_item.additional_properties = d
        return get_object_dependents_response_200_dependents_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
