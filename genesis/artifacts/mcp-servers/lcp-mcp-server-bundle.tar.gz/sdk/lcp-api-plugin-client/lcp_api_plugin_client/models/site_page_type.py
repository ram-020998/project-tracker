from enum import Enum


class SitePageType(str, Enum):
    ACTION = "ACTION"
    INTERFACE = "INTERFACE"
    RECORD_LIST = "RECORD_LIST"

    def __str__(self) -> str:
        return str(self.value)
