from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ReplaceDocumentContentRequest")


@_attrs_define
class ReplaceDocumentContentRequest:
    """Request body for replacing a document's file content

    Attributes:
        file_content (str): The new file content encoded as base64 string Example:
            JVBERi0xLjQKJeLjz9MKMSAwIG9iago8PC9UeXBlL....
    """

    file_content: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        file_content = self.file_content

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "fileContent": file_content,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        file_content = d.pop("fileContent")

        replace_document_content_request = cls(
            file_content=file_content,
        )

        replace_document_content_request.additional_properties = d
        return replace_document_content_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
