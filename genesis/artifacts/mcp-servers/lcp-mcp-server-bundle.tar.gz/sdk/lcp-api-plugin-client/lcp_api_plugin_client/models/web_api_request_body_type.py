from enum import Enum


class WebApiRequestBodyType(str, Enum):
    BINARY = "BINARY"
    MULTIPART = "MULTIPART"
    NONE = "NONE"

    def __str__(self) -> str:
        return str(self.value)
