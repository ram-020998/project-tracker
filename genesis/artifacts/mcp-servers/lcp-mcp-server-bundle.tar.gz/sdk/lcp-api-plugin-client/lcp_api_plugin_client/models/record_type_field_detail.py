from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.record_type_field_detail_field_type import RecordTypeFieldDetailFieldType
from ..types import UNSET, Unset

T = TypeVar("T", bound="RecordTypeFieldDetail")


@_attrs_define
class RecordTypeFieldDetail:
    """Full field metadata within a record type source configuration

    Attributes:
        uuid (str | Unset): The field UUID (stable across updates when field name is unchanged) Example: field-uuid-123.
        field_name (str | Unset): The internal field name used in expressions Example: customerId.
        field_type (RecordTypeFieldDetailFieldType | Unset): The data type of the field Example: INTEGER.
        display_name (str | Unset): Human-readable display name Example: Customer ID.
        description (None | str | Unset): Field description Example: Primary key for customer records.
        is_primary_key (bool | Unset): Whether this field is the primary key Default: False. Example: True.
        is_unique (bool | Unset): Whether this field has a unique constraint Default: False.
        source_field_name (None | str | Unset): Backing store field/column name Example: customer_id.
        source_field_type (None | str | Unset): Database column type (e.g. VARCHAR(255), TIMESTAMP, INTEGER). Read-only
            — reflects the actual backing store type. Example: INTEGER.
    """

    uuid: str | Unset = UNSET
    field_name: str | Unset = UNSET
    field_type: RecordTypeFieldDetailFieldType | Unset = UNSET
    display_name: str | Unset = UNSET
    description: None | str | Unset = UNSET
    is_primary_key: bool | Unset = False
    is_unique: bool | Unset = False
    source_field_name: None | str | Unset = UNSET
    source_field_type: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        field_name = self.field_name

        field_type: str | Unset = UNSET
        if not isinstance(self.field_type, Unset):
            field_type = self.field_type.value

        display_name = self.display_name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        is_primary_key = self.is_primary_key

        is_unique = self.is_unique

        source_field_name: None | str | Unset
        if isinstance(self.source_field_name, Unset):
            source_field_name = UNSET
        else:
            source_field_name = self.source_field_name

        source_field_type: None | str | Unset
        if isinstance(self.source_field_type, Unset):
            source_field_type = UNSET
        else:
            source_field_type = self.source_field_type

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if field_name is not UNSET:
            field_dict["fieldName"] = field_name
        if field_type is not UNSET:
            field_dict["fieldType"] = field_type
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if description is not UNSET:
            field_dict["description"] = description
        if is_primary_key is not UNSET:
            field_dict["isPrimaryKey"] = is_primary_key
        if is_unique is not UNSET:
            field_dict["isUnique"] = is_unique
        if source_field_name is not UNSET:
            field_dict["sourceFieldName"] = source_field_name
        if source_field_type is not UNSET:
            field_dict["sourceFieldType"] = source_field_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid", UNSET)

        field_name = d.pop("fieldName", UNSET)

        _field_type = d.pop("fieldType", UNSET)
        field_type: RecordTypeFieldDetailFieldType | Unset
        if isinstance(_field_type, Unset):
            field_type = UNSET
        else:
            field_type = RecordTypeFieldDetailFieldType(_field_type)

        display_name = d.pop("displayName", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        is_primary_key = d.pop("isPrimaryKey", UNSET)

        is_unique = d.pop("isUnique", UNSET)

        def _parse_source_field_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        source_field_name = _parse_source_field_name(d.pop("sourceFieldName", UNSET))

        def _parse_source_field_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        source_field_type = _parse_source_field_type(d.pop("sourceFieldType", UNSET))

        record_type_field_detail = cls(
            uuid=uuid,
            field_name=field_name,
            field_type=field_type,
            display_name=display_name,
            description=description,
            is_primary_key=is_primary_key,
            is_unique=is_unique,
            source_field_name=source_field_name,
            source_field_type=source_field_type,
        )

        record_type_field_detail.additional_properties = d
        return record_type_field_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
