from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.form_config_input_map_type_0 import FormConfigInputMapType0


T = TypeVar("T", bound="FormConfig")


@_attrs_define
class FormConfig:
    """Form configuration for attended nodes.

    Attributes:
        interface_uuid (str): UUID of the form interface
        input_map (FormConfigInputMapType0 | None | Unset): Maps interface inputs to their data sources. Keys are
            interface input names (without ri! prefix). Values depend on context:
            For start forms: values are process variable names (without pv! prefix). The form bidirectionally syncs with PVs
            — user input flows back to the PV on submission automatically.
            For task forms: values are typically ACP names defined in customInputs (from the Data tab). Each ACP's
            expression provides data into the form; its saveInto (if set in customInputs) writes user changes back to a PV
            on submission. Without saveInto, data flows one-way in only. Values may also be expressions (e.g. =pv!myVar) in
            existing configurations — these provide read-only form input with no write-back path.
            Required when interfaceUuid is provided.
    """

    interface_uuid: str
    input_map: FormConfigInputMapType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.form_config_input_map_type_0 import FormConfigInputMapType0

        interface_uuid = self.interface_uuid

        input_map: dict[str, Any] | None | Unset
        if isinstance(self.input_map, Unset):
            input_map = UNSET
        elif isinstance(self.input_map, FormConfigInputMapType0):
            input_map = self.input_map.to_dict()
        else:
            input_map = self.input_map

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "interfaceUuid": interface_uuid,
            }
        )
        if input_map is not UNSET:
            field_dict["inputMap"] = input_map

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.form_config_input_map_type_0 import FormConfigInputMapType0

        d = dict(src_dict)
        interface_uuid = d.pop("interfaceUuid")

        def _parse_input_map(data: object) -> FormConfigInputMapType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                input_map_type_0 = FormConfigInputMapType0.from_dict(data)

                return input_map_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(FormConfigInputMapType0 | None | Unset, data)

        input_map = _parse_input_map(d.pop("inputMap", UNSET))

        form_config = cls(
            interface_uuid=interface_uuid,
            input_map=input_map,
        )

        form_config.additional_properties = d
        return form_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
