from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.validate_expression_request_bindings_type_0_item import ValidateExpressionRequestBindingsType0Item


T = TypeVar("T", bound="ValidateExpressionRequest")


@_attrs_define
class ValidateExpressionRequest:
    """
    Attributes:
        expression (str): SAIL expression to validate
        is_interface (bool | Unset): Whether the expression is an interface (SAIL component tree). Set true for
            interface/form expressions (e.g. those using a!formLayout or referencing env!features); these are validated via
            the strict interface eval path that supplies the client-state context. Defaults to false for ordinary
            expressions. Default: False.
        bindings (list[ValidateExpressionRequestBindingsType0Item] | None | Unset): Optional variable bindings for
            navigation linking between screens
    """

    expression: str
    is_interface: bool | Unset = False
    bindings: list[ValidateExpressionRequestBindingsType0Item] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        expression = self.expression

        is_interface = self.is_interface

        bindings: list[dict[str, Any]] | None | Unset
        if isinstance(self.bindings, Unset):
            bindings = UNSET
        elif isinstance(self.bindings, list):
            bindings = []
            for bindings_type_0_item_data in self.bindings:
                bindings_type_0_item = bindings_type_0_item_data.to_dict()
                bindings.append(bindings_type_0_item)

        else:
            bindings = self.bindings

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "expression": expression,
            }
        )
        if is_interface is not UNSET:
            field_dict["isInterface"] = is_interface
        if bindings is not UNSET:
            field_dict["bindings"] = bindings

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.validate_expression_request_bindings_type_0_item import ValidateExpressionRequestBindingsType0Item

        d = dict(src_dict)
        expression = d.pop("expression")

        is_interface = d.pop("isInterface", UNSET)

        def _parse_bindings(data: object) -> list[ValidateExpressionRequestBindingsType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                bindings_type_0 = []
                _bindings_type_0 = data
                for bindings_type_0_item_data in _bindings_type_0:
                    bindings_type_0_item = ValidateExpressionRequestBindingsType0Item.from_dict(
                        bindings_type_0_item_data
                    )

                    bindings_type_0.append(bindings_type_0_item)

                return bindings_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ValidateExpressionRequestBindingsType0Item] | None | Unset, data)

        bindings = _parse_bindings(d.pop("bindings", UNSET))

        validate_expression_request = cls(
            expression=expression,
            is_interface=is_interface,
            bindings=bindings,
        )

        validate_expression_request.additional_properties = d
        return validate_expression_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
