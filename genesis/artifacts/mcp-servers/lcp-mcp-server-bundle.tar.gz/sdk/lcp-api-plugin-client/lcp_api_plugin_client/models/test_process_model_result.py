from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.test_process_model_result_status import TestProcessModelResultStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.test_process_model_result_process_variables_type_0 import TestProcessModelResultProcessVariablesType0


T = TypeVar("T", bound="TestProcessModelResult")


@_attrs_define
class TestProcessModelResult:
    """Process execution result.

    Attributes:
        process_id (int | Unset): Runtime process instance ID
        status (TestProcessModelResultStatus | Unset): Process status: ACTIVE, COMPLETED, PAUSED, CANCELLED, or
            PAUSED_BY_EXCEPTION
        process_variables (None | TestProcessModelResultProcessVariablesType0 | Unset): Map of process variable names to
            their final values
    """

    process_id: int | Unset = UNSET
    status: TestProcessModelResultStatus | Unset = UNSET
    process_variables: None | TestProcessModelResultProcessVariablesType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.test_process_model_result_process_variables_type_0 import (
            TestProcessModelResultProcessVariablesType0,
        )

        process_id = self.process_id

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        process_variables: dict[str, Any] | None | Unset
        if isinstance(self.process_variables, Unset):
            process_variables = UNSET
        elif isinstance(self.process_variables, TestProcessModelResultProcessVariablesType0):
            process_variables = self.process_variables.to_dict()
        else:
            process_variables = self.process_variables

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if process_id is not UNSET:
            field_dict["processId"] = process_id
        if status is not UNSET:
            field_dict["status"] = status
        if process_variables is not UNSET:
            field_dict["processVariables"] = process_variables

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.test_process_model_result_process_variables_type_0 import (
            TestProcessModelResultProcessVariablesType0,
        )

        d = dict(src_dict)
        process_id = d.pop("processId", UNSET)

        _status = d.pop("status", UNSET)
        status: TestProcessModelResultStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = TestProcessModelResultStatus(_status)

        def _parse_process_variables(data: object) -> None | TestProcessModelResultProcessVariablesType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                process_variables_type_0 = TestProcessModelResultProcessVariablesType0.from_dict(data)

                return process_variables_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TestProcessModelResultProcessVariablesType0 | Unset, data)

        process_variables = _parse_process_variables(d.pop("processVariables", UNSET))

        test_process_model_result = cls(
            process_id=process_id,
            status=status,
            process_variables=process_variables,
        )

        test_process_model_result.additional_properties = d
        return test_process_model_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
