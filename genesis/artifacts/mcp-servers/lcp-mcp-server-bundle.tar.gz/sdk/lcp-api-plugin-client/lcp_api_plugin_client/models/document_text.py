from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.document_text_metadata import DocumentTextMetadata


T = TypeVar("T", bound="DocumentText")


@_attrs_define
class DocumentText:
    """Extracted text content from a document with optional metadata.

    **Implementation**: Not yet implemented - ContentService API limitations

        Attributes:
            text (str): Extracted text content Example: This is the extracted text from the document....
            metadata (DocumentTextMetadata | None | Unset): Metadata about the text extraction
    """

    text: str
    metadata: DocumentTextMetadata | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.document_text_metadata import DocumentTextMetadata

        text = self.text

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, DocumentTextMetadata):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "text": text,
            }
        )
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.document_text_metadata import DocumentTextMetadata

        d = dict(src_dict)
        text = d.pop("text")

        def _parse_metadata(data: object) -> DocumentTextMetadata | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_1 = DocumentTextMetadata.from_dict(data)

                return metadata_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DocumentTextMetadata | None | Unset, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        document_text = cls(
            text=text,
            metadata=metadata,
        )

        document_text.additional_properties = d
        return document_text

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
