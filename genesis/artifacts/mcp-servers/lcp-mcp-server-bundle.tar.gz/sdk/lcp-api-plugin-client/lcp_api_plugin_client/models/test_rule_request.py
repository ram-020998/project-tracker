from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.test_rule_request_inputs_type_0 import TestRuleRequestInputsType0


T = TypeVar("T", bound="TestRuleRequest")


@_attrs_define
class TestRuleRequest:
    """Request body for testing a rule-type design object (expression rule, integration, or decision).

    Attributes:
        inputs (None | TestRuleRequestInputsType0 | Unset): Input values to pass to the rule
        timeout_seconds (int | None | Unset): Maximum time to wait for execution. Default 5, max 60. Default: 5.
        max_response_size_bytes (int | None | Unset): Maximum response size to return. Default 5120 (5KB), max 1048576
            (1MB). Truncated at byte boundary if exceeded. Default: 5120.
    """

    inputs: None | TestRuleRequestInputsType0 | Unset = UNSET
    timeout_seconds: int | None | Unset = 5
    max_response_size_bytes: int | None | Unset = 5120
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.test_rule_request_inputs_type_0 import TestRuleRequestInputsType0

        inputs: dict[str, Any] | None | Unset
        if isinstance(self.inputs, Unset):
            inputs = UNSET
        elif isinstance(self.inputs, TestRuleRequestInputsType0):
            inputs = self.inputs.to_dict()
        else:
            inputs = self.inputs

        timeout_seconds: int | None | Unset
        if isinstance(self.timeout_seconds, Unset):
            timeout_seconds = UNSET
        else:
            timeout_seconds = self.timeout_seconds

        max_response_size_bytes: int | None | Unset
        if isinstance(self.max_response_size_bytes, Unset):
            max_response_size_bytes = UNSET
        else:
            max_response_size_bytes = self.max_response_size_bytes

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if inputs is not UNSET:
            field_dict["inputs"] = inputs
        if timeout_seconds is not UNSET:
            field_dict["timeoutSeconds"] = timeout_seconds
        if max_response_size_bytes is not UNSET:
            field_dict["maxResponseSizeBytes"] = max_response_size_bytes

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.test_rule_request_inputs_type_0 import TestRuleRequestInputsType0

        d = dict(src_dict)

        def _parse_inputs(data: object) -> None | TestRuleRequestInputsType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                inputs_type_0 = TestRuleRequestInputsType0.from_dict(data)

                return inputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TestRuleRequestInputsType0 | Unset, data)

        inputs = _parse_inputs(d.pop("inputs", UNSET))

        def _parse_timeout_seconds(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        timeout_seconds = _parse_timeout_seconds(d.pop("timeoutSeconds", UNSET))

        def _parse_max_response_size_bytes(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_response_size_bytes = _parse_max_response_size_bytes(d.pop("maxResponseSizeBytes", UNSET))

        test_rule_request = cls(
            inputs=inputs,
            timeout_seconds=timeout_seconds,
            max_response_size_bytes=max_response_size_bytes,
        )

        test_rule_request.additional_properties = d
        return test_rule_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
