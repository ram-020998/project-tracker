from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="CreateProcessModelRequestDescriptionType1")


@_attrs_define
class CreateProcessModelRequestDescriptionType1:
    """Localized process model description (object). Keys are locale codes (e.g., en_US, de_DE, ja_JP), values are the
    localized descriptions.

        Example:
            {'en_US': 'Handles order approval workflow', 'de_DE': 'Verarbeitet Bestellgenehmigungsworkflow', 'ja_JP':
                '注文承認ワークフローを処理します'}

    """

    additional_properties: dict[str, str] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        create_process_model_request_description_type_1 = cls()

        create_process_model_request_description_type_1.additional_properties = d
        return create_process_model_request_description_type_1

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> str:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: str) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
