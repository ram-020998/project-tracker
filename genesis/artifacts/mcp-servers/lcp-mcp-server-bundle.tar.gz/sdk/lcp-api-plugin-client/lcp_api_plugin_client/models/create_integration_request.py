from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_integration_request_properties_type_0 import CreateIntegrationRequestPropertiesType0
    from ..models.integration_input import IntegrationInput
    from ..models.integration_test_input import IntegrationTestInput


T = TypeVar("T", bound="CreateIntegrationRequest")


@_attrs_define
class CreateIntegrationRequest:
    """Request body for creating an integration.

    Either `parentFolderUuid` or `appUuid` must be provided to determine where the integration will be created.

        Attributes:
            name (str): Display name Example: Get Orders.
            connected_system_uuid (str): UUID of the parent connected system
            description (None | str | Unset): Description
            operation_id (None | str | Unset): Operation identifier from the connected system type's operations list.
                Example: plugin.[GoogleDrive].[GoogleDrive].[QueryIntegration].READ.
            properties (CreateIntegrationRequestPropertiesType0 | None | Unset): Configuration properties (validated against
                the operation schema).

                For HTTP integrations with a `multipart/form-data` body, set the body one of
                two ways:
                - `bodyFormParts`: a structured list of `{name, contentType, value}` objects,
                  one per form field. Each is compiled into an `a!httpFormPart(...)` call.
                  `value` is a raw SAIL expression fragment (e.g. `ri!requirements`, or a
                  literal like `true`); `contentType` is the part's MIME type (e.g.
                  `"text/plain"`, or `"auto-detect"` for document parts).
                - `bodyContent`: a raw SAIL expression that must evaluate to a list of
                  `a!httpFormPart(...)` values. Overrides `bodyFormParts` when set. Use this
                  when you need conditional parts, e.g.
                  `if(a!isNotNullOrEmpty(ri!file), a!httpFormPart(name: "file", contentType: "auto-detect", value: ri!file),
                {})`.

                The body is validated before save: unresolved `ri!` references and, for
                multipart, a body that does not evaluate to `a!httpFormPart(...)` values are
                rejected with a 400.
                 Example: {'httpMethod': 'GET', 'relativePath': '/orders'}.
            inputs (list[IntegrationInput] | None | Unset): Rule input parameters
            test_inputs (list[IntegrationTestInput] | None | Unset): Test input values used during body validation and saved
                as the integration's
                default test case. Supply these when the body is null-unsafe (e.g. an input
                the expression dereferences) so validation runs against real values instead of
                nulls. Integrations support only a default test case (no named cases).
            parent_folder_uuid (str | Unset): UUID of the parent Rules and Constants folder where the integration will be
                created (optional).
                If provided, this takes precedence over `appUuid` for folder selection.
                 Example: _a-0000e0b2-7f2c-8000-cd82-011c48011c48_24303.
            app_uuid (None | str | Unset): Application UUID (optional). When provided:
                - The integration is added to the application and is given the same security role map
                - If `parentFolderUuid` is not provided, the tool automatically selects an appropriate Rules and Constants
                folder from the application (prefers folders named "<prefix> Rules and Constants")

                Either `parentFolderUuid` or `appUuid` must be provided.
    """

    name: str
    connected_system_uuid: str
    description: None | str | Unset = UNSET
    operation_id: None | str | Unset = UNSET
    properties: CreateIntegrationRequestPropertiesType0 | None | Unset = UNSET
    inputs: list[IntegrationInput] | None | Unset = UNSET
    test_inputs: list[IntegrationTestInput] | None | Unset = UNSET
    parent_folder_uuid: str | Unset = UNSET
    app_uuid: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.create_integration_request_properties_type_0 import CreateIntegrationRequestPropertiesType0

        name = self.name

        connected_system_uuid = self.connected_system_uuid

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        operation_id: None | str | Unset
        if isinstance(self.operation_id, Unset):
            operation_id = UNSET
        else:
            operation_id = self.operation_id

        properties: dict[str, Any] | None | Unset
        if isinstance(self.properties, Unset):
            properties = UNSET
        elif isinstance(self.properties, CreateIntegrationRequestPropertiesType0):
            properties = self.properties.to_dict()
        else:
            properties = self.properties

        inputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.inputs, Unset):
            inputs = UNSET
        elif isinstance(self.inputs, list):
            inputs = []
            for inputs_type_0_item_data in self.inputs:
                inputs_type_0_item = inputs_type_0_item_data.to_dict()
                inputs.append(inputs_type_0_item)

        else:
            inputs = self.inputs

        test_inputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.test_inputs, Unset):
            test_inputs = UNSET
        elif isinstance(self.test_inputs, list):
            test_inputs = []
            for test_inputs_type_0_item_data in self.test_inputs:
                test_inputs_type_0_item = test_inputs_type_0_item_data.to_dict()
                test_inputs.append(test_inputs_type_0_item)

        else:
            test_inputs = self.test_inputs

        parent_folder_uuid = self.parent_folder_uuid

        app_uuid: None | str | Unset
        if isinstance(self.app_uuid, Unset):
            app_uuid = UNSET
        else:
            app_uuid = self.app_uuid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "connectedSystemUuid": connected_system_uuid,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if operation_id is not UNSET:
            field_dict["operationId"] = operation_id
        if properties is not UNSET:
            field_dict["properties"] = properties
        if inputs is not UNSET:
            field_dict["inputs"] = inputs
        if test_inputs is not UNSET:
            field_dict["testInputs"] = test_inputs
        if parent_folder_uuid is not UNSET:
            field_dict["parentFolderUuid"] = parent_folder_uuid
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_integration_request_properties_type_0 import CreateIntegrationRequestPropertiesType0
        from ..models.integration_input import IntegrationInput
        from ..models.integration_test_input import IntegrationTestInput

        d = dict(src_dict)
        name = d.pop("name")

        connected_system_uuid = d.pop("connectedSystemUuid")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_operation_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        operation_id = _parse_operation_id(d.pop("operationId", UNSET))

        def _parse_properties(data: object) -> CreateIntegrationRequestPropertiesType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                properties_type_0 = CreateIntegrationRequestPropertiesType0.from_dict(data)

                return properties_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateIntegrationRequestPropertiesType0 | None | Unset, data)

        properties = _parse_properties(d.pop("properties", UNSET))

        def _parse_inputs(data: object) -> list[IntegrationInput] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                inputs_type_0 = []
                _inputs_type_0 = data
                for inputs_type_0_item_data in _inputs_type_0:
                    inputs_type_0_item = IntegrationInput.from_dict(inputs_type_0_item_data)

                    inputs_type_0.append(inputs_type_0_item)

                return inputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[IntegrationInput] | None | Unset, data)

        inputs = _parse_inputs(d.pop("inputs", UNSET))

        def _parse_test_inputs(data: object) -> list[IntegrationTestInput] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                test_inputs_type_0 = []
                _test_inputs_type_0 = data
                for test_inputs_type_0_item_data in _test_inputs_type_0:
                    test_inputs_type_0_item = IntegrationTestInput.from_dict(test_inputs_type_0_item_data)

                    test_inputs_type_0.append(test_inputs_type_0_item)

                return test_inputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[IntegrationTestInput] | None | Unset, data)

        test_inputs = _parse_test_inputs(d.pop("testInputs", UNSET))

        parent_folder_uuid = d.pop("parentFolderUuid", UNSET)

        def _parse_app_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        app_uuid = _parse_app_uuid(d.pop("appUuid", UNSET))

        create_integration_request = cls(
            name=name,
            connected_system_uuid=connected_system_uuid,
            description=description,
            operation_id=operation_id,
            properties=properties,
            inputs=inputs,
            test_inputs=test_inputs,
            parent_folder_uuid=parent_folder_uuid,
            app_uuid=app_uuid,
        )

        create_integration_request.additional_properties = d
        return create_integration_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
