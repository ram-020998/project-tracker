from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.facet_option_operator import FacetOptionOperator
from ..types import UNSET, Unset

T = TypeVar("T", bound="FacetOption")


@_attrs_define
class FacetOption:
    """
    Attributes:
        label_expression (str | Unset): Display label for this bucket.
        operator (FacetOptionOperator | Unset): EQUALS: field value equals the expression (mapped from
            FacetOperator.IN). NOT_EQUALS: field value does not equal the expression (mapped from FacetOperator.NOT_IN).
            BETWEEN: field value is between lower and upper limits.
        value (None | str | Unset): Expression for the filter value. Used by EQUALS and NOT_EQUALS operators.
        lower_limit_expression (None | str | Unset): Lower bound expression for BETWEEN operator.
        upper_limit_expression (None | str | Unset): Upper bound expression for BETWEEN operator.
    """

    label_expression: str | Unset = UNSET
    operator: FacetOptionOperator | Unset = UNSET
    value: None | str | Unset = UNSET
    lower_limit_expression: None | str | Unset = UNSET
    upper_limit_expression: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        label_expression = self.label_expression

        operator: str | Unset = UNSET
        if not isinstance(self.operator, Unset):
            operator = self.operator.value

        value: None | str | Unset
        if isinstance(self.value, Unset):
            value = UNSET
        else:
            value = self.value

        lower_limit_expression: None | str | Unset
        if isinstance(self.lower_limit_expression, Unset):
            lower_limit_expression = UNSET
        else:
            lower_limit_expression = self.lower_limit_expression

        upper_limit_expression: None | str | Unset
        if isinstance(self.upper_limit_expression, Unset):
            upper_limit_expression = UNSET
        else:
            upper_limit_expression = self.upper_limit_expression

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if label_expression is not UNSET:
            field_dict["labelExpression"] = label_expression
        if operator is not UNSET:
            field_dict["operator"] = operator
        if value is not UNSET:
            field_dict["value"] = value
        if lower_limit_expression is not UNSET:
            field_dict["lowerLimitExpression"] = lower_limit_expression
        if upper_limit_expression is not UNSET:
            field_dict["upperLimitExpression"] = upper_limit_expression

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        label_expression = d.pop("labelExpression", UNSET)

        _operator = d.pop("operator", UNSET)
        operator: FacetOptionOperator | Unset
        if isinstance(_operator, Unset):
            operator = UNSET
        else:
            operator = FacetOptionOperator(_operator)

        def _parse_value(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        value = _parse_value(d.pop("value", UNSET))

        def _parse_lower_limit_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        lower_limit_expression = _parse_lower_limit_expression(d.pop("lowerLimitExpression", UNSET))

        def _parse_upper_limit_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        upper_limit_expression = _parse_upper_limit_expression(d.pop("upperLimitExpression", UNSET))

        facet_option = cls(
            label_expression=label_expression,
            operator=operator,
            value=value,
            lower_limit_expression=lower_limit_expression,
            upper_limit_expression=upper_limit_expression,
        )

        facet_option.additional_properties = d
        return facet_option

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
