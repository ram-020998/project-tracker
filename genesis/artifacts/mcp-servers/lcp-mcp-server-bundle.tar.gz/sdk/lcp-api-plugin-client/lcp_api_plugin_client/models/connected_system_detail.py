from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.connected_system_detail_properties_type_0 import ConnectedSystemDetailPropertiesType0
    from ..models.property_descriptor import PropertyDescriptor


T = TypeVar("T", bound="ConnectedSystemDetail")


@_attrs_define
class ConnectedSystemDetail:
    """Full detail for a connected system including non-credential property values and the live-evaluated schema for the
    current configuration state. Use `schema` to discover which properties are valid given the current field values
    (e.g., which auth-specific fields are active). Fields present in `schema` but null in `properties` are available to
    set. Fields absent from `schema` are not valid for the current state.

        Attributes:
            uuid (str): Connected system UUID
            name (str): Display name
            type_ (str): Connected system type identifier Example: system.http.
            description (None | str | Unset): Description
            properties (ConnectedSystemDetailPropertiesType0 | None | Unset): Configuration property values for the current
                schema state. Keys match the `schema` array. Null value means the field is available but not yet set. Credential
                fields are always null. Fields not in the current schema are absent.
            schema (list[PropertyDescriptor] | None | Unset): Live-evaluated flat list of PropertyDescriptors valid for the
                current configuration state. Changes when a discriminator field (e.g., authType) is updated. Use this to know
                what fields to set next.
            version_id (None | str | Unset): Version ID for optimistic concurrency control. Include in PUT/DELETE requests
                to prevent stale writes.
    """

    uuid: str
    name: str
    type_: str
    description: None | str | Unset = UNSET
    properties: ConnectedSystemDetailPropertiesType0 | None | Unset = UNSET
    schema: list[PropertyDescriptor] | None | Unset = UNSET
    version_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.connected_system_detail_properties_type_0 import ConnectedSystemDetailPropertiesType0

        uuid = self.uuid

        name = self.name

        type_ = self.type_

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        properties: dict[str, Any] | None | Unset
        if isinstance(self.properties, Unset):
            properties = UNSET
        elif isinstance(self.properties, ConnectedSystemDetailPropertiesType0):
            properties = self.properties.to_dict()
        else:
            properties = self.properties

        schema: list[dict[str, Any]] | None | Unset
        if isinstance(self.schema, Unset):
            schema = UNSET
        elif isinstance(self.schema, list):
            schema = []
            for schema_type_0_item_data in self.schema:
                schema_type_0_item = schema_type_0_item_data.to_dict()
                schema.append(schema_type_0_item)

        else:
            schema = self.schema

        version_id: None | str | Unset
        if isinstance(self.version_id, Unset):
            version_id = UNSET
        else:
            version_id = self.version_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "name": name,
                "type": type_,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if properties is not UNSET:
            field_dict["properties"] = properties
        if schema is not UNSET:
            field_dict["schema"] = schema
        if version_id is not UNSET:
            field_dict["versionId"] = version_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.connected_system_detail_properties_type_0 import ConnectedSystemDetailPropertiesType0
        from ..models.property_descriptor import PropertyDescriptor

        d = dict(src_dict)
        uuid = d.pop("uuid")

        name = d.pop("name")

        type_ = d.pop("type")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_properties(data: object) -> ConnectedSystemDetailPropertiesType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                properties_type_0 = ConnectedSystemDetailPropertiesType0.from_dict(data)

                return properties_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ConnectedSystemDetailPropertiesType0 | None | Unset, data)

        properties = _parse_properties(d.pop("properties", UNSET))

        def _parse_schema(data: object) -> list[PropertyDescriptor] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                schema_type_0 = []
                _schema_type_0 = data
                for schema_type_0_item_data in _schema_type_0:
                    schema_type_0_item = PropertyDescriptor.from_dict(schema_type_0_item_data)

                    schema_type_0.append(schema_type_0_item)

                return schema_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[PropertyDescriptor] | None | Unset, data)

        schema = _parse_schema(d.pop("schema", UNSET))

        def _parse_version_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version_id = _parse_version_id(d.pop("versionId", UNSET))

        connected_system_detail = cls(
            uuid=uuid,
            name=name,
            type_=type_,
            description=description,
            properties=properties,
            schema=schema,
            version_id=version_id,
        )

        connected_system_detail.additional_properties = d
        return connected_system_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
