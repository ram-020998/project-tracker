from enum import Enum


class NodeAssignmentReassignPrivileges(str, Enum):
    NONE = "NONE"
    REASSIGN_TO_ANY = "REASSIGN_TO_ANY"
    REASSIGN_WITHIN_POOL = "REASSIGN_WITHIN_POOL"
    REJECT_ONLY = "REJECT_ONLY"

    def __str__(self) -> str:
        return str(self.value)
