from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.test_case import TestCase


T = TypeVar("T", bound="TestCaseList")


@_attrs_define
class TestCaseList:
    """List of test cases with total count

    Attributes:
        test_cases (list[TestCase] | Unset):
        total_count (int | Unset): Total number of test cases
    """

    test_cases: list[TestCase] | Unset = UNSET
    total_count: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        test_cases: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.test_cases, Unset):
            test_cases = []
            for test_cases_item_data in self.test_cases:
                test_cases_item = test_cases_item_data.to_dict()
                test_cases.append(test_cases_item)

        total_count = self.total_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if test_cases is not UNSET:
            field_dict["testCases"] = test_cases
        if total_count is not UNSET:
            field_dict["totalCount"] = total_count

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.test_case import TestCase

        d = dict(src_dict)
        _test_cases = d.pop("testCases", UNSET)
        test_cases: list[TestCase] | Unset = UNSET
        if _test_cases is not UNSET:
            test_cases = []
            for test_cases_item_data in _test_cases:
                test_cases_item = TestCase.from_dict(test_cases_item_data)

                test_cases.append(test_cases_item)

        total_count = d.pop("totalCount", UNSET)

        test_case_list = cls(
            test_cases=test_cases,
            total_count=total_count,
        )

        test_case_list.additional_properties = d
        return test_case_list

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
