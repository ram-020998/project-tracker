from enum import Enum


class RecordTypeRelationshipDetailRelationshipType(str, Enum):
    MANY_TO_ONE = "MANY_TO_ONE"
    ONE_TO_MANY = "ONE_TO_MANY"
    ONE_TO_ONE = "ONE_TO_ONE"

    def __str__(self) -> str:
        return str(self.value)
