from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ProcessModelVariable")


@_attrs_define
class ProcessModelVariable:
    """Process variable with string-based types. Built-in types by name (e.g., "Text", "Number (Integer)", "Boolean"). For
    developer-defined types (e.g., record types), use the typeReference from the record type response.

        Attributes:
            name (str): Variable name (required, cannot be empty) Example: orderId.
            type_ (str): Appian type reference. Built-in types by name (e.g., "Text", "Number (Integer)", "Boolean"). For
                developer-defined types, use the typeReference from the record type response.
                 Example: Text.
            is_parameter (bool | Unset): Whether this is a process parameter (input to the process) Default: False. Example:
                True.
            is_required (bool | Unset): Whether this parameter is required (only relevant if isParameter is true) Default:
                False.
            multiple (bool | Unset): Whether this variable holds a list of values. Defaults to false (single value).
                 Default: False.
            value (str | Unset): Optional default-value expression for the variable, evaluated when the process is
                initiated. Provide without a leading "=" (e.g. "now()" or "rule!blankCase()"); the leading "=" is added
                automatically on save and stripped on read.
                 Example: now().
    """

    name: str
    type_: str
    is_parameter: bool | Unset = False
    is_required: bool | Unset = False
    multiple: bool | Unset = False
    value: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        type_ = self.type_

        is_parameter = self.is_parameter

        is_required = self.is_required

        multiple = self.multiple

        value = self.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type_,
            }
        )
        if is_parameter is not UNSET:
            field_dict["isParameter"] = is_parameter
        if is_required is not UNSET:
            field_dict["isRequired"] = is_required
        if multiple is not UNSET:
            field_dict["multiple"] = multiple
        if value is not UNSET:
            field_dict["value"] = value

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        type_ = d.pop("type")

        is_parameter = d.pop("isParameter", UNSET)

        is_required = d.pop("isRequired", UNSET)

        multiple = d.pop("multiple", UNSET)

        value = d.pop("value", UNSET)

        process_model_variable = cls(
            name=name,
            type_=type_,
            is_parameter=is_parameter,
            is_required=is_required,
            multiple=multiple,
            value=value,
        )

        process_model_variable.additional_properties = d
        return process_model_variable

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
