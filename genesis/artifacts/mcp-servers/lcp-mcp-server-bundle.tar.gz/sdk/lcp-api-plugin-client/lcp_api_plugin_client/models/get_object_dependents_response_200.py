from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.get_object_dependents_response_200_dependents_item import GetObjectDependentsResponse200DependentsItem


T = TypeVar("T", bound="GetObjectDependentsResponse200")


@_attrs_define
class GetObjectDependentsResponse200:
    """
    Attributes:
        uuid (str | Unset): UUID of the object that was queried
        dependents (list[GetObjectDependentsResponse200DependentsItem] | Unset): Array of objects that reference this
            object
        total_count (int | Unset): Total number of dependents found
    """

    uuid: str | Unset = UNSET
    dependents: list[GetObjectDependentsResponse200DependentsItem] | Unset = UNSET
    total_count: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        dependents: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.dependents, Unset):
            dependents = []
            for dependents_item_data in self.dependents:
                dependents_item = dependents_item_data.to_dict()
                dependents.append(dependents_item)

        total_count = self.total_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if dependents is not UNSET:
            field_dict["dependents"] = dependents
        if total_count is not UNSET:
            field_dict["totalCount"] = total_count

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_object_dependents_response_200_dependents_item import (
            GetObjectDependentsResponse200DependentsItem,
        )

        d = dict(src_dict)
        uuid = d.pop("uuid", UNSET)

        _dependents = d.pop("dependents", UNSET)
        dependents: list[GetObjectDependentsResponse200DependentsItem] | Unset = UNSET
        if _dependents is not UNSET:
            dependents = []
            for dependents_item_data in _dependents:
                dependents_item = GetObjectDependentsResponse200DependentsItem.from_dict(dependents_item_data)

                dependents.append(dependents_item)

        total_count = d.pop("totalCount", UNSET)

        get_object_dependents_response_200 = cls(
            uuid=uuid,
            dependents=dependents,
            total_count=total_count,
        )

        get_object_dependents_response_200.additional_properties = d
        return get_object_dependents_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
