from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="FormConfigInputMapType0")


@_attrs_define
class FormConfigInputMapType0:
    """Maps interface inputs to their data sources. Keys are interface input names (without ri! prefix). Values depend on
    context:
    For start forms: values are process variable names (without pv! prefix). The form bidirectionally syncs with PVs —
    user input flows back to the PV on submission automatically.
    For task forms: values are typically ACP names defined in customInputs (from the Data tab). Each ACP's expression
    provides data into the form; its saveInto (if set in customInputs) writes user changes back to a PV on submission.
    Without saveInto, data flows one-way in only. Values may also be expressions (e.g. =pv!myVar) in existing
    configurations — these provide read-only form input with no write-back path.
    Required when interfaceUuid is provided.

    """

    additional_properties: dict[str, str] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        form_config_input_map_type_0 = cls()

        form_config_input_map_type_0.additional_properties = d
        return form_config_input_map_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> str:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: str) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
