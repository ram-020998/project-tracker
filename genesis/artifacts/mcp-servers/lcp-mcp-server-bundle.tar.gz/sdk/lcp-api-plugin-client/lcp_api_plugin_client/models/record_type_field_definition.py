from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.record_type_field_definition_field_type import RecordTypeFieldDefinitionFieldType
from ..types import UNSET, Unset

T = TypeVar("T", bound="RecordTypeFieldDefinition")


@_attrs_define
class RecordTypeFieldDefinition:
    """Field definition for a record type's source configuration

    Attributes:
        field_name (str): The field name Example: customerId.
        field_type (RecordTypeFieldDefinitionFieldType): The field type Example: INTEGER.
        display_name (str | Unset): Human-readable display name for the field Example: Customer ID.
        description (str | Unset): Field description Example: Unique customer identifier.
        is_primary_key (bool | Unset): Whether this field is the primary key. Exactly one field must be the primary key
            for DATABASE types. Example: True.
        is_unique (bool | Unset): Whether this field has a unique constraint
        length (int | Unset): Column length (for Text fields). 0 means default. Default: 0. Example: 255.
    """

    field_name: str
    field_type: RecordTypeFieldDefinitionFieldType
    display_name: str | Unset = UNSET
    description: str | Unset = UNSET
    is_primary_key: bool | Unset = UNSET
    is_unique: bool | Unset = UNSET
    length: int | Unset = 0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        field_name = self.field_name

        field_type = self.field_type.value

        display_name = self.display_name

        description = self.description

        is_primary_key = self.is_primary_key

        is_unique = self.is_unique

        length = self.length

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "fieldName": field_name,
                "fieldType": field_type,
            }
        )
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if description is not UNSET:
            field_dict["description"] = description
        if is_primary_key is not UNSET:
            field_dict["isPrimaryKey"] = is_primary_key
        if is_unique is not UNSET:
            field_dict["isUnique"] = is_unique
        if length is not UNSET:
            field_dict["length"] = length

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        field_name = d.pop("fieldName")

        field_type = RecordTypeFieldDefinitionFieldType(d.pop("fieldType"))

        display_name = d.pop("displayName", UNSET)

        description = d.pop("description", UNSET)

        is_primary_key = d.pop("isPrimaryKey", UNSET)

        is_unique = d.pop("isUnique", UNSET)

        length = d.pop("length", UNSET)

        record_type_field_definition = cls(
            field_name=field_name,
            field_type=field_type,
            display_name=display_name,
            description=description,
            is_primary_key=is_primary_key,
            is_unique=is_unique,
            length=length,
        )

        record_type_field_definition.additional_properties = d
        return record_type_field_definition

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
