from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.node_assignment_reassign_privileges import NodeAssignmentReassignPrivileges
from ..models.node_assignment_run_as import NodeAssignmentRunAs
from ..types import UNSET, Unset

T = TypeVar("T", bound="NodeAssignment")


@_attrs_define
class NodeAssignment:
    """Assignment tab configuration for activity nodes.

    Specify exactly one of: assignTo (expression), assignToUsers (direct users), or assignToGroups (direct groups).
    Omit all to leave the node unassigned.

        Attributes:
            attended (bool | Unset): true = attended (task assigned to user), false = unattended (system executes).
                Defaulted for ATTENDED_ONLY/UNATTENDED_ONLY nodes. Required for ATTENDED_OR_UNATTENDED nodes.
            assign_to (None | str | Unset): SAIL expression evaluating to user(s) or group(s). Attended only.
                Use for expressions like pp!initiator, touser("username"), togroup("groupname"), etc.
                Mutually exclusive with assignToUsers and assignToGroups.
                 Example: pp!initiator.
            assign_to_users (list[str] | None | Unset): Direct user assignment by username(s). Attended only.
                Mutually exclusive with assignTo and assignToGroups.
                 Example: ['john.doe'].
            assign_to_groups (list[str] | None | Unset): Direct group assignment by group UUID(s). Attended only.
                Mutually exclusive with assignTo and assignToUsers.
                 Example: ['_e-0000f003-122a-8000-9af5-01075c01075c_58'].
            reassign_privileges (NodeAssignmentReassignPrivileges | Unset): Reassignment privilege for assignees. Attended
                only.
                NONE, REJECT_ONLY, REASSIGN_WITHIN_POOL, REASSIGN_TO_ANY.
                Default: REASSIGN_TO_ANY.
                 Example: REASSIGN_TO_ANY.
            run_as (NodeAssignmentRunAs | Unset): Who the system runs as. Unattended only.
                INITIATOR or DESIGNER. Default: INITIATOR.
                 Example: INITIATOR.
            override_lane (bool | None | Unset): Override swimlane assignment for this node. Default false. Default: False.
    """

    attended: bool | Unset = UNSET
    assign_to: None | str | Unset = UNSET
    assign_to_users: list[str] | None | Unset = UNSET
    assign_to_groups: list[str] | None | Unset = UNSET
    reassign_privileges: NodeAssignmentReassignPrivileges | Unset = UNSET
    run_as: NodeAssignmentRunAs | Unset = UNSET
    override_lane: bool | None | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        attended = self.attended

        assign_to: None | str | Unset
        if isinstance(self.assign_to, Unset):
            assign_to = UNSET
        else:
            assign_to = self.assign_to

        assign_to_users: list[str] | None | Unset
        if isinstance(self.assign_to_users, Unset):
            assign_to_users = UNSET
        elif isinstance(self.assign_to_users, list):
            assign_to_users = self.assign_to_users

        else:
            assign_to_users = self.assign_to_users

        assign_to_groups: list[str] | None | Unset
        if isinstance(self.assign_to_groups, Unset):
            assign_to_groups = UNSET
        elif isinstance(self.assign_to_groups, list):
            assign_to_groups = self.assign_to_groups

        else:
            assign_to_groups = self.assign_to_groups

        reassign_privileges: str | Unset = UNSET
        if not isinstance(self.reassign_privileges, Unset):
            reassign_privileges = self.reassign_privileges.value

        run_as: str | Unset = UNSET
        if not isinstance(self.run_as, Unset):
            run_as = self.run_as.value

        override_lane: bool | None | Unset
        if isinstance(self.override_lane, Unset):
            override_lane = UNSET
        else:
            override_lane = self.override_lane

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if attended is not UNSET:
            field_dict["attended"] = attended
        if assign_to is not UNSET:
            field_dict["assignTo"] = assign_to
        if assign_to_users is not UNSET:
            field_dict["assignToUsers"] = assign_to_users
        if assign_to_groups is not UNSET:
            field_dict["assignToGroups"] = assign_to_groups
        if reassign_privileges is not UNSET:
            field_dict["reassignPrivileges"] = reassign_privileges
        if run_as is not UNSET:
            field_dict["runAs"] = run_as
        if override_lane is not UNSET:
            field_dict["overrideLane"] = override_lane

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        attended = d.pop("attended", UNSET)

        def _parse_assign_to(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        assign_to = _parse_assign_to(d.pop("assignTo", UNSET))

        def _parse_assign_to_users(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                assign_to_users_type_0 = cast(list[str], data)

                return assign_to_users_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        assign_to_users = _parse_assign_to_users(d.pop("assignToUsers", UNSET))

        def _parse_assign_to_groups(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                assign_to_groups_type_0 = cast(list[str], data)

                return assign_to_groups_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        assign_to_groups = _parse_assign_to_groups(d.pop("assignToGroups", UNSET))

        _reassign_privileges = d.pop("reassignPrivileges", UNSET)
        reassign_privileges: NodeAssignmentReassignPrivileges | Unset
        if isinstance(_reassign_privileges, Unset):
            reassign_privileges = UNSET
        else:
            reassign_privileges = NodeAssignmentReassignPrivileges(_reassign_privileges)

        _run_as = d.pop("runAs", UNSET)
        run_as: NodeAssignmentRunAs | Unset
        if isinstance(_run_as, Unset):
            run_as = UNSET
        else:
            run_as = NodeAssignmentRunAs(_run_as)

        def _parse_override_lane(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        override_lane = _parse_override_lane(d.pop("overrideLane", UNSET))

        node_assignment = cls(
            attended=attended,
            assign_to=assign_to,
            assign_to_users=assign_to_users,
            assign_to_groups=assign_to_groups,
            reassign_privileges=reassign_privileges,
            run_as=run_as,
            override_lane=override_lane,
        )

        node_assignment.additional_properties = d
        return node_assignment

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
