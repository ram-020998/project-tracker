from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="UpdateIntegrationRequestPropertiesType0")


@_attrs_define
class UpdateIntegrationRequestPropertiesType0:
    """Configuration properties to update (validated against the operation schema).

    For HTTP integrations with a `multipart/form-data` body, set the body via
    `bodyFormParts` (structured `{name, contentType, value}` list) or `bodyContent`
    (a raw SAIL expression evaluating to `a!httpFormPart(...)` values, which
    overrides `bodyFormParts` and supports conditional parts). See
    CreateIntegrationRequest for details. The body is validated before save.

    """

    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        update_integration_request_properties_type_0 = cls()

        update_integration_request_properties_type_0.additional_properties = d
        return update_integration_request_properties_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
