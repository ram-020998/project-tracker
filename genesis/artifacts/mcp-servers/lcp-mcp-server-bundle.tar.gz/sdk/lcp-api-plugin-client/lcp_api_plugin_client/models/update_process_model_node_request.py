from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.form_config import FormConfig
    from ..models.node_assignment import NodeAssignment
    from ..models.node_connection import NodeConnection
    from ..models.node_data import NodeData
    from ..models.node_decision import NodeDecision
    from ..models.update_process_model_node_request_forms_type_1 import UpdateProcessModelNodeRequestFormsType1
    from ..models.update_process_model_node_request_name_type_1 import UpdateProcessModelNodeRequestNameType1


T = TypeVar("T", bound="UpdateProcessModelNodeRequest")


@_attrs_define
class UpdateProcessModelNodeRequest:
    """Request body for updating a node. Only provided fields are changed;
    omitted fields are preserved. type and id cannot be changed.

        Attributes:
            name (str | Unset | UpdateProcessModelNodeRequestNameType1): Developer-defined instance label shown on the
                process modeler canvas.
                Can be a simple string (stored in site's primary locale) or a map of locale codes to localized names.
            coordinates (list[int] | Unset): Canvas position as [x, y]
            connections (list[NodeConnection] | Unset): Outgoing edges — replaces all existing connections when provided.
                Each connection
                specifies its `targetNodeId` and `activityChained` flag (required), plus optional
                `overridesAssignment`, `synchronizeData`, and `label`.
            decision (NodeDecision | None | Unset):
            data (NodeData | None | Unset):
            forms (FormConfig | None | Unset | UpdateProcessModelNodeRequestFormsType1): Can be a simple FormConfig (stored
                in site's primary locale) OR a map of locale codes to FormConfig objects.
            assignment (NodeAssignment | None | Unset):
    """

    name: str | Unset | UpdateProcessModelNodeRequestNameType1 = UNSET
    coordinates: list[int] | Unset = UNSET
    connections: list[NodeConnection] | Unset = UNSET
    decision: NodeDecision | None | Unset = UNSET
    data: NodeData | None | Unset = UNSET
    forms: FormConfig | None | Unset | UpdateProcessModelNodeRequestFormsType1 = UNSET
    assignment: NodeAssignment | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.form_config import FormConfig
        from ..models.node_assignment import NodeAssignment
        from ..models.node_data import NodeData
        from ..models.node_decision import NodeDecision
        from ..models.update_process_model_node_request_forms_type_1 import UpdateProcessModelNodeRequestFormsType1
        from ..models.update_process_model_node_request_name_type_1 import UpdateProcessModelNodeRequestNameType1

        name: dict[str, Any] | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        elif isinstance(self.name, UpdateProcessModelNodeRequestNameType1):
            name = self.name.to_dict()
        else:
            name = self.name

        coordinates: list[int] | Unset = UNSET
        if not isinstance(self.coordinates, Unset):
            coordinates = self.coordinates

        connections: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.connections, Unset):
            connections = []
            for connections_item_data in self.connections:
                connections_item = connections_item_data.to_dict()
                connections.append(connections_item)

        decision: dict[str, Any] | None | Unset
        if isinstance(self.decision, Unset):
            decision = UNSET
        elif isinstance(self.decision, NodeDecision):
            decision = self.decision.to_dict()
        else:
            decision = self.decision

        data: dict[str, Any] | None | Unset
        if isinstance(self.data, Unset):
            data = UNSET
        elif isinstance(self.data, NodeData):
            data = self.data.to_dict()
        else:
            data = self.data

        forms: dict[str, Any] | None | Unset
        if isinstance(self.forms, Unset):
            forms = UNSET
        elif isinstance(self.forms, FormConfig):
            forms = self.forms.to_dict()
        elif isinstance(self.forms, UpdateProcessModelNodeRequestFormsType1):
            forms = self.forms.to_dict()
        else:
            forms = self.forms

        assignment: dict[str, Any] | None | Unset
        if isinstance(self.assignment, Unset):
            assignment = UNSET
        elif isinstance(self.assignment, NodeAssignment):
            assignment = self.assignment.to_dict()
        else:
            assignment = self.assignment

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if coordinates is not UNSET:
            field_dict["coordinates"] = coordinates
        if connections is not UNSET:
            field_dict["connections"] = connections
        if decision is not UNSET:
            field_dict["decision"] = decision
        if data is not UNSET:
            field_dict["data"] = data
        if forms is not UNSET:
            field_dict["forms"] = forms
        if assignment is not UNSET:
            field_dict["assignment"] = assignment

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.form_config import FormConfig
        from ..models.node_assignment import NodeAssignment
        from ..models.node_connection import NodeConnection
        from ..models.node_data import NodeData
        from ..models.node_decision import NodeDecision
        from ..models.update_process_model_node_request_forms_type_1 import UpdateProcessModelNodeRequestFormsType1
        from ..models.update_process_model_node_request_name_type_1 import UpdateProcessModelNodeRequestNameType1

        d = dict(src_dict)

        def _parse_name(data: object) -> str | Unset | UpdateProcessModelNodeRequestNameType1:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                name_type_1 = UpdateProcessModelNodeRequestNameType1.from_dict(data)

                return name_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(str | Unset | UpdateProcessModelNodeRequestNameType1, data)

        name = _parse_name(d.pop("name", UNSET))

        coordinates = cast(list[int], d.pop("coordinates", UNSET))

        _connections = d.pop("connections", UNSET)
        connections: list[NodeConnection] | Unset = UNSET
        if _connections is not UNSET:
            connections = []
            for connections_item_data in _connections:
                connections_item = NodeConnection.from_dict(connections_item_data)

                connections.append(connections_item)

        def _parse_decision(data: object) -> NodeDecision | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                decision_type_1 = NodeDecision.from_dict(data)

                return decision_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(NodeDecision | None | Unset, data)

        decision = _parse_decision(d.pop("decision", UNSET))

        def _parse_data(data: object) -> NodeData | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                data_type_1 = NodeData.from_dict(data)

                return data_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(NodeData | None | Unset, data)

        data = _parse_data(d.pop("data", UNSET))

        def _parse_forms(data: object) -> FormConfig | None | Unset | UpdateProcessModelNodeRequestFormsType1:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                forms_type_0 = FormConfig.from_dict(data)

                return forms_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                forms_type_1 = UpdateProcessModelNodeRequestFormsType1.from_dict(data)

                return forms_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(FormConfig | None | Unset | UpdateProcessModelNodeRequestFormsType1, data)

        forms = _parse_forms(d.pop("forms", UNSET))

        def _parse_assignment(data: object) -> NodeAssignment | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                assignment_type_1 = NodeAssignment.from_dict(data)

                return assignment_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(NodeAssignment | None | Unset, data)

        assignment = _parse_assignment(d.pop("assignment", UNSET))

        update_process_model_node_request = cls(
            name=name,
            coordinates=coordinates,
            connections=connections,
            decision=decision,
            data=data,
            forms=forms,
            assignment=assignment,
        )

        update_process_model_node_request.additional_properties = d
        return update_process_model_node_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
