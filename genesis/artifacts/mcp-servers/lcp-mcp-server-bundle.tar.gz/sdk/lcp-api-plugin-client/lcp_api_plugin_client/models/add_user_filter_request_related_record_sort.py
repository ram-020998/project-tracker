from enum import Enum


class AddUserFilterRequestRelatedRecordSort(str, Enum):
    ASCENDING = "ASCENDING"
    DESCENDING = "DESCENDING"
    UNSORTED = "UNSORTED"

    def __str__(self) -> str:
        return str(self.value)
