from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.add_record_type_field_request_field_type import AddRecordTypeFieldRequestFieldType
from ..types import UNSET, Unset

T = TypeVar("T", bound="AddRecordTypeFieldRequest")


@_attrs_define
class AddRecordTypeFieldRequest:
    """Request body for adding a field to a record type.

    Attributes:
        field_name (str): The field name Example: email.
        field_type (AddRecordTypeFieldRequestFieldType): The field data type Example: TEXT.
        version_id (str | Unset): Current version ID for optimistic concurrency control
        source_field_name (str | Unset): Backing store field/column name. Defaults to toSnakeCase(fieldName) if not
            provided. Example: email_address.
        display_name (str | Unset): Human-readable display name. Defaults to fieldName if not provided. Example: Email
            Address.
        description (str | Unset): Field description Example: Customer email address.
        is_primary_key (bool | Unset): Whether this field is the primary key Default: False.
        is_unique (bool | Unset): Whether this field has a unique constraint Default: False.
        length (int | Unset): Column length for TEXT fields. 0 means default. Default: 0. Example: 255.
        update_table (bool | Unset): When true, Appian ALTERs the database table to add the column (mirrors the 'Update
            Table' checkbox in Appian Designer). When false, returns an error — non-CDM operations are not yet supported.
            Default: True. Example: True.
    """

    field_name: str
    field_type: AddRecordTypeFieldRequestFieldType
    version_id: str | Unset = UNSET
    source_field_name: str | Unset = UNSET
    display_name: str | Unset = UNSET
    description: str | Unset = UNSET
    is_primary_key: bool | Unset = False
    is_unique: bool | Unset = False
    length: int | Unset = 0
    update_table: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        field_name = self.field_name

        field_type = self.field_type.value

        version_id = self.version_id

        source_field_name = self.source_field_name

        display_name = self.display_name

        description = self.description

        is_primary_key = self.is_primary_key

        is_unique = self.is_unique

        length = self.length

        update_table = self.update_table

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "fieldName": field_name,
                "fieldType": field_type,
            }
        )
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if source_field_name is not UNSET:
            field_dict["sourceFieldName"] = source_field_name
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if description is not UNSET:
            field_dict["description"] = description
        if is_primary_key is not UNSET:
            field_dict["isPrimaryKey"] = is_primary_key
        if is_unique is not UNSET:
            field_dict["isUnique"] = is_unique
        if length is not UNSET:
            field_dict["length"] = length
        if update_table is not UNSET:
            field_dict["updateTable"] = update_table

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        field_name = d.pop("fieldName")

        field_type = AddRecordTypeFieldRequestFieldType(d.pop("fieldType"))

        version_id = d.pop("versionId", UNSET)

        source_field_name = d.pop("sourceFieldName", UNSET)

        display_name = d.pop("displayName", UNSET)

        description = d.pop("description", UNSET)

        is_primary_key = d.pop("isPrimaryKey", UNSET)

        is_unique = d.pop("isUnique", UNSET)

        length = d.pop("length", UNSET)

        update_table = d.pop("updateTable", UNSET)

        add_record_type_field_request = cls(
            field_name=field_name,
            field_type=field_type,
            version_id=version_id,
            source_field_name=source_field_name,
            display_name=display_name,
            description=description,
            is_primary_key=is_primary_key,
            is_unique=is_unique,
            length=length,
            update_table=update_table,
        )

        add_record_type_field_request.additional_properties = d
        return add_record_type_field_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
