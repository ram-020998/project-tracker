from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="RecordEventConfig")


@_attrs_define
class RecordEventConfig:
    """Record event configuration for a record type. Contains the UUIDs of the four generated supporting record types and
    the current event type names. Returned by both configureRecordEvents (POST) and getRecordEventsConfig (GET).

        Attributes:
            base_record_type_uuid (str | Unset): The record type events are configured on Example: abc-123-def-456.
            event_history_record_type_uuid (str | Unset): Event History record type UUID Example: eh-uuid-123.
            event_type_lookup_record_type_uuid (str | Unset): Event Type Lookup record type UUID Example: etl-uuid-123.
            reply_thread_record_type_uuid (None | str | Unset): Reply Thread record type UUID Example: rt-uuid-123.
            subscriber_record_type_uuid (None | str | Unset): Subscriber record type UUID Example: sub-uuid-123.
            event_types (list[str] | Unset): Current event type names (may be empty) Example: ['Created Case', 'Assigned
                Case'].
            event_relationship_uuid (str | Unset): UUID of the relationship from the base RT to Event History (ONE_TO_MANY)
            event_type_relationship_uuid (str | Unset): UUID of the relationship from Event History to Event Type Lookup
                (MANY_TO_ONE)
            event_reply_relationship_uuid (None | str | Unset): UUID of the relationship from Event History to Reply Thread
                (ONE_TO_MANY)
            subscriber_relationship_uuid (None | str | Unset): UUID of the relationship from the base RT to Subscriber
                (ONE_TO_MANY)
            event_type_value_field_uuid (str | Unset): UUID of the eventTypeId field on Event History RT
            event_user_field_uuid (str | Unset): UUID of the user field on Event History RT
            event_timestamp_field_uuid (str | Unset): UUID of the timestamp field on Event History RT
            event_automation_identifier_field_uuid (str | Unset): UUID of the automationTypeId field on Event History RT
            event_comment_field_uuid (str | Unset): UUID of the comment field on Event History RT
            comment_event_type_id (int | None | Unset): ID of the comment event type (null if not configured)
            event_reply_user_field_uuid (None | str | Unset): UUID of the user field on Reply Thread RT
            event_reply_comment_field_uuid (None | str | Unset): UUID of the reply field on Reply Thread RT
            event_reply_timestamp_field_uuid (None | str | Unset): UUID of the timestamp field on Reply Thread RT
            subscriber_user_field_uuid (None | str | Unset): UUID of the user field on Subscriber RT
            generate_common_events (bool | Unset): Whether common events are auto-generated
    """

    base_record_type_uuid: str | Unset = UNSET
    event_history_record_type_uuid: str | Unset = UNSET
    event_type_lookup_record_type_uuid: str | Unset = UNSET
    reply_thread_record_type_uuid: None | str | Unset = UNSET
    subscriber_record_type_uuid: None | str | Unset = UNSET
    event_types: list[str] | Unset = UNSET
    event_relationship_uuid: str | Unset = UNSET
    event_type_relationship_uuid: str | Unset = UNSET
    event_reply_relationship_uuid: None | str | Unset = UNSET
    subscriber_relationship_uuid: None | str | Unset = UNSET
    event_type_value_field_uuid: str | Unset = UNSET
    event_user_field_uuid: str | Unset = UNSET
    event_timestamp_field_uuid: str | Unset = UNSET
    event_automation_identifier_field_uuid: str | Unset = UNSET
    event_comment_field_uuid: str | Unset = UNSET
    comment_event_type_id: int | None | Unset = UNSET
    event_reply_user_field_uuid: None | str | Unset = UNSET
    event_reply_comment_field_uuid: None | str | Unset = UNSET
    event_reply_timestamp_field_uuid: None | str | Unset = UNSET
    subscriber_user_field_uuid: None | str | Unset = UNSET
    generate_common_events: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        base_record_type_uuid = self.base_record_type_uuid

        event_history_record_type_uuid = self.event_history_record_type_uuid

        event_type_lookup_record_type_uuid = self.event_type_lookup_record_type_uuid

        reply_thread_record_type_uuid: None | str | Unset
        if isinstance(self.reply_thread_record_type_uuid, Unset):
            reply_thread_record_type_uuid = UNSET
        else:
            reply_thread_record_type_uuid = self.reply_thread_record_type_uuid

        subscriber_record_type_uuid: None | str | Unset
        if isinstance(self.subscriber_record_type_uuid, Unset):
            subscriber_record_type_uuid = UNSET
        else:
            subscriber_record_type_uuid = self.subscriber_record_type_uuid

        event_types: list[str] | Unset = UNSET
        if not isinstance(self.event_types, Unset):
            event_types = self.event_types

        event_relationship_uuid = self.event_relationship_uuid

        event_type_relationship_uuid = self.event_type_relationship_uuid

        event_reply_relationship_uuid: None | str | Unset
        if isinstance(self.event_reply_relationship_uuid, Unset):
            event_reply_relationship_uuid = UNSET
        else:
            event_reply_relationship_uuid = self.event_reply_relationship_uuid

        subscriber_relationship_uuid: None | str | Unset
        if isinstance(self.subscriber_relationship_uuid, Unset):
            subscriber_relationship_uuid = UNSET
        else:
            subscriber_relationship_uuid = self.subscriber_relationship_uuid

        event_type_value_field_uuid = self.event_type_value_field_uuid

        event_user_field_uuid = self.event_user_field_uuid

        event_timestamp_field_uuid = self.event_timestamp_field_uuid

        event_automation_identifier_field_uuid = self.event_automation_identifier_field_uuid

        event_comment_field_uuid = self.event_comment_field_uuid

        comment_event_type_id: int | None | Unset
        if isinstance(self.comment_event_type_id, Unset):
            comment_event_type_id = UNSET
        else:
            comment_event_type_id = self.comment_event_type_id

        event_reply_user_field_uuid: None | str | Unset
        if isinstance(self.event_reply_user_field_uuid, Unset):
            event_reply_user_field_uuid = UNSET
        else:
            event_reply_user_field_uuid = self.event_reply_user_field_uuid

        event_reply_comment_field_uuid: None | str | Unset
        if isinstance(self.event_reply_comment_field_uuid, Unset):
            event_reply_comment_field_uuid = UNSET
        else:
            event_reply_comment_field_uuid = self.event_reply_comment_field_uuid

        event_reply_timestamp_field_uuid: None | str | Unset
        if isinstance(self.event_reply_timestamp_field_uuid, Unset):
            event_reply_timestamp_field_uuid = UNSET
        else:
            event_reply_timestamp_field_uuid = self.event_reply_timestamp_field_uuid

        subscriber_user_field_uuid: None | str | Unset
        if isinstance(self.subscriber_user_field_uuid, Unset):
            subscriber_user_field_uuid = UNSET
        else:
            subscriber_user_field_uuid = self.subscriber_user_field_uuid

        generate_common_events = self.generate_common_events

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if base_record_type_uuid is not UNSET:
            field_dict["baseRecordTypeUuid"] = base_record_type_uuid
        if event_history_record_type_uuid is not UNSET:
            field_dict["eventHistoryRecordTypeUuid"] = event_history_record_type_uuid
        if event_type_lookup_record_type_uuid is not UNSET:
            field_dict["eventTypeLookupRecordTypeUuid"] = event_type_lookup_record_type_uuid
        if reply_thread_record_type_uuid is not UNSET:
            field_dict["replyThreadRecordTypeUuid"] = reply_thread_record_type_uuid
        if subscriber_record_type_uuid is not UNSET:
            field_dict["subscriberRecordTypeUuid"] = subscriber_record_type_uuid
        if event_types is not UNSET:
            field_dict["eventTypes"] = event_types
        if event_relationship_uuid is not UNSET:
            field_dict["eventRelationshipUuid"] = event_relationship_uuid
        if event_type_relationship_uuid is not UNSET:
            field_dict["eventTypeRelationshipUuid"] = event_type_relationship_uuid
        if event_reply_relationship_uuid is not UNSET:
            field_dict["eventReplyRelationshipUuid"] = event_reply_relationship_uuid
        if subscriber_relationship_uuid is not UNSET:
            field_dict["subscriberRelationshipUuid"] = subscriber_relationship_uuid
        if event_type_value_field_uuid is not UNSET:
            field_dict["eventTypeValueFieldUuid"] = event_type_value_field_uuid
        if event_user_field_uuid is not UNSET:
            field_dict["eventUserFieldUuid"] = event_user_field_uuid
        if event_timestamp_field_uuid is not UNSET:
            field_dict["eventTimestampFieldUuid"] = event_timestamp_field_uuid
        if event_automation_identifier_field_uuid is not UNSET:
            field_dict["eventAutomationIdentifierFieldUuid"] = event_automation_identifier_field_uuid
        if event_comment_field_uuid is not UNSET:
            field_dict["eventCommentFieldUuid"] = event_comment_field_uuid
        if comment_event_type_id is not UNSET:
            field_dict["commentEventTypeId"] = comment_event_type_id
        if event_reply_user_field_uuid is not UNSET:
            field_dict["eventReplyUserFieldUuid"] = event_reply_user_field_uuid
        if event_reply_comment_field_uuid is not UNSET:
            field_dict["eventReplyCommentFieldUuid"] = event_reply_comment_field_uuid
        if event_reply_timestamp_field_uuid is not UNSET:
            field_dict["eventReplyTimestampFieldUuid"] = event_reply_timestamp_field_uuid
        if subscriber_user_field_uuid is not UNSET:
            field_dict["subscriberUserFieldUuid"] = subscriber_user_field_uuid
        if generate_common_events is not UNSET:
            field_dict["generateCommonEvents"] = generate_common_events

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        base_record_type_uuid = d.pop("baseRecordTypeUuid", UNSET)

        event_history_record_type_uuid = d.pop("eventHistoryRecordTypeUuid", UNSET)

        event_type_lookup_record_type_uuid = d.pop("eventTypeLookupRecordTypeUuid", UNSET)

        def _parse_reply_thread_record_type_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reply_thread_record_type_uuid = _parse_reply_thread_record_type_uuid(d.pop("replyThreadRecordTypeUuid", UNSET))

        def _parse_subscriber_record_type_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        subscriber_record_type_uuid = _parse_subscriber_record_type_uuid(d.pop("subscriberRecordTypeUuid", UNSET))

        event_types = cast(list[str], d.pop("eventTypes", UNSET))

        event_relationship_uuid = d.pop("eventRelationshipUuid", UNSET)

        event_type_relationship_uuid = d.pop("eventTypeRelationshipUuid", UNSET)

        def _parse_event_reply_relationship_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        event_reply_relationship_uuid = _parse_event_reply_relationship_uuid(d.pop("eventReplyRelationshipUuid", UNSET))

        def _parse_subscriber_relationship_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        subscriber_relationship_uuid = _parse_subscriber_relationship_uuid(d.pop("subscriberRelationshipUuid", UNSET))

        event_type_value_field_uuid = d.pop("eventTypeValueFieldUuid", UNSET)

        event_user_field_uuid = d.pop("eventUserFieldUuid", UNSET)

        event_timestamp_field_uuid = d.pop("eventTimestampFieldUuid", UNSET)

        event_automation_identifier_field_uuid = d.pop("eventAutomationIdentifierFieldUuid", UNSET)

        event_comment_field_uuid = d.pop("eventCommentFieldUuid", UNSET)

        def _parse_comment_event_type_id(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        comment_event_type_id = _parse_comment_event_type_id(d.pop("commentEventTypeId", UNSET))

        def _parse_event_reply_user_field_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        event_reply_user_field_uuid = _parse_event_reply_user_field_uuid(d.pop("eventReplyUserFieldUuid", UNSET))

        def _parse_event_reply_comment_field_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        event_reply_comment_field_uuid = _parse_event_reply_comment_field_uuid(
            d.pop("eventReplyCommentFieldUuid", UNSET)
        )

        def _parse_event_reply_timestamp_field_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        event_reply_timestamp_field_uuid = _parse_event_reply_timestamp_field_uuid(
            d.pop("eventReplyTimestampFieldUuid", UNSET)
        )

        def _parse_subscriber_user_field_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        subscriber_user_field_uuid = _parse_subscriber_user_field_uuid(d.pop("subscriberUserFieldUuid", UNSET))

        generate_common_events = d.pop("generateCommonEvents", UNSET)

        record_event_config = cls(
            base_record_type_uuid=base_record_type_uuid,
            event_history_record_type_uuid=event_history_record_type_uuid,
            event_type_lookup_record_type_uuid=event_type_lookup_record_type_uuid,
            reply_thread_record_type_uuid=reply_thread_record_type_uuid,
            subscriber_record_type_uuid=subscriber_record_type_uuid,
            event_types=event_types,
            event_relationship_uuid=event_relationship_uuid,
            event_type_relationship_uuid=event_type_relationship_uuid,
            event_reply_relationship_uuid=event_reply_relationship_uuid,
            subscriber_relationship_uuid=subscriber_relationship_uuid,
            event_type_value_field_uuid=event_type_value_field_uuid,
            event_user_field_uuid=event_user_field_uuid,
            event_timestamp_field_uuid=event_timestamp_field_uuid,
            event_automation_identifier_field_uuid=event_automation_identifier_field_uuid,
            event_comment_field_uuid=event_comment_field_uuid,
            comment_event_type_id=comment_event_type_id,
            event_reply_user_field_uuid=event_reply_user_field_uuid,
            event_reply_comment_field_uuid=event_reply_comment_field_uuid,
            event_reply_timestamp_field_uuid=event_reply_timestamp_field_uuid,
            subscriber_user_field_uuid=subscriber_user_field_uuid,
            generate_common_events=generate_common_events,
        )

        record_event_config.additional_properties = d
        return record_event_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
