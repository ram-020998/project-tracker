from enum import Enum


class CreateRecordTypeRequestSourceType(str, Enum):
    DATABASE = "DATABASE"
    PROCESS = "PROCESS"
    SALESFORCE = "SALESFORCE"
    SNOWFLAKE = "SNOWFLAKE"
    WEB_SERVICE = "WEB_SERVICE"

    def __str__(self) -> str:
        return str(self.value)
