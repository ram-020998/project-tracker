from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.record_type_relationship_type import RecordTypeRelationshipType
from ..models.record_type_relationship_update_behavior import RecordTypeRelationshipUpdateBehavior
from ..types import UNSET, Unset

T = TypeVar("T", bound="RecordTypeRelationship")


@_attrs_define
class RecordTypeRelationship:
    """Record type relationship metadata

    Attributes:
        name (str | Unset): The relationship name Example: orders.
        uuid (str | Unset): The relationship UUID Example: rel-uuid-1.
        source_field (None | str | Unset): The source field name Example: customerId.
        target_record_name (None | str | Unset): The target record type name Example: Order.
        target_record_uuid (str | Unset): The target record type UUID Example: order-uuid.
        target_field (None | str | Unset): The target field name Example: customerId.
        type_ (RecordTypeRelationshipType | Unset): The relationship type Example: ONE_TO_MANY.
        update_behavior (RecordTypeRelationshipUpdateBehavior | Unset): The update behavior for this relationship
            Example: CASCADING.
    """

    name: str | Unset = UNSET
    uuid: str | Unset = UNSET
    source_field: None | str | Unset = UNSET
    target_record_name: None | str | Unset = UNSET
    target_record_uuid: str | Unset = UNSET
    target_field: None | str | Unset = UNSET
    type_: RecordTypeRelationshipType | Unset = UNSET
    update_behavior: RecordTypeRelationshipUpdateBehavior | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        uuid = self.uuid

        source_field: None | str | Unset
        if isinstance(self.source_field, Unset):
            source_field = UNSET
        else:
            source_field = self.source_field

        target_record_name: None | str | Unset
        if isinstance(self.target_record_name, Unset):
            target_record_name = UNSET
        else:
            target_record_name = self.target_record_name

        target_record_uuid = self.target_record_uuid

        target_field: None | str | Unset
        if isinstance(self.target_field, Unset):
            target_field = UNSET
        else:
            target_field = self.target_field

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        update_behavior: str | Unset = UNSET
        if not isinstance(self.update_behavior, Unset):
            update_behavior = self.update_behavior.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if source_field is not UNSET:
            field_dict["sourceField"] = source_field
        if target_record_name is not UNSET:
            field_dict["targetRecordName"] = target_record_name
        if target_record_uuid is not UNSET:
            field_dict["targetRecordUuid"] = target_record_uuid
        if target_field is not UNSET:
            field_dict["targetField"] = target_field
        if type_ is not UNSET:
            field_dict["type"] = type_
        if update_behavior is not UNSET:
            field_dict["updateBehavior"] = update_behavior

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        uuid = d.pop("uuid", UNSET)

        def _parse_source_field(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        source_field = _parse_source_field(d.pop("sourceField", UNSET))

        def _parse_target_record_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        target_record_name = _parse_target_record_name(d.pop("targetRecordName", UNSET))

        target_record_uuid = d.pop("targetRecordUuid", UNSET)

        def _parse_target_field(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        target_field = _parse_target_field(d.pop("targetField", UNSET))

        _type_ = d.pop("type", UNSET)
        type_: RecordTypeRelationshipType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = RecordTypeRelationshipType(_type_)

        _update_behavior = d.pop("updateBehavior", UNSET)
        update_behavior: RecordTypeRelationshipUpdateBehavior | Unset
        if isinstance(_update_behavior, Unset):
            update_behavior = UNSET
        else:
            update_behavior = RecordTypeRelationshipUpdateBehavior(_update_behavior)

        record_type_relationship = cls(
            name=name,
            uuid=uuid,
            source_field=source_field,
            target_record_name=target_record_name,
            target_record_uuid=target_record_uuid,
            target_field=target_field,
            type_=type_,
            update_behavior=update_behavior,
        )

        record_type_relationship.additional_properties = d
        return record_type_relationship

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
