from enum import Enum


class SiteLayout(str, Enum):
    HEADER_BAR = "HEADER_BAR"
    SIDEBAR = "SIDEBAR"

    def __str__(self) -> str:
        return str(self.value)
