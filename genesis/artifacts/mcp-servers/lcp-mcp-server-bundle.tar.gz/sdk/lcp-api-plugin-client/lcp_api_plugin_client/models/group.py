from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rest_metadata_type_0 import RestMetadataType0


T = TypeVar("T", bound="Group")


@_attrs_define
class Group:
    """Appian group metadata.

    Attributes:
        group_name (str): The unique name of the group (primary identifier) Example: APP_Administrators.
        uuid (None | str | Unset): The UUID of the group. Most groups have UUIDs assigned at creation time. Some legacy
            groups may have a null UUID. Example: _a-0000ed97-98a4-8000-9bb5-011c48011c48_105467.
        group_id (int | None | Unset): The internal numeric identifier of the group Example: 12345.
        display_name (None | str | Unset): The human-readable display name of the group Example: App Administrators.
        description (None | str | Unset): A text description of the group's purpose Example: Administrator group for the
            application.
        group_type (None | str | Unset): The type of group (STANDARD or DYNAMIC)
        members (list[str] | None | Unset): Array of member usernames
        created_at (datetime.datetime | None | Unset): Creation timestamp in ISO 8601 format
        modified_at (datetime.datetime | None | Unset): Last modification timestamp in ISO 8601 format
        field_rest (None | RestMetadataType0 | Unset): Response metadata including the Designer URL for this object.
            Present on get, create, and update responses for design objects.
    """

    group_name: str
    uuid: None | str | Unset = UNSET
    group_id: int | None | Unset = UNSET
    display_name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    group_type: None | str | Unset = UNSET
    members: list[str] | None | Unset = UNSET
    created_at: datetime.datetime | None | Unset = UNSET
    modified_at: datetime.datetime | None | Unset = UNSET
    field_rest: None | RestMetadataType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rest_metadata_type_0 import RestMetadataType0

        group_name = self.group_name

        uuid: None | str | Unset
        if isinstance(self.uuid, Unset):
            uuid = UNSET
        else:
            uuid = self.uuid

        group_id: int | None | Unset
        if isinstance(self.group_id, Unset):
            group_id = UNSET
        else:
            group_id = self.group_id

        display_name: None | str | Unset
        if isinstance(self.display_name, Unset):
            display_name = UNSET
        else:
            display_name = self.display_name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        group_type: None | str | Unset
        if isinstance(self.group_type, Unset):
            group_type = UNSET
        else:
            group_type = self.group_type

        members: list[str] | None | Unset
        if isinstance(self.members, Unset):
            members = UNSET
        elif isinstance(self.members, list):
            members = self.members

        else:
            members = self.members

        created_at: None | str | Unset
        if isinstance(self.created_at, Unset):
            created_at = UNSET
        elif isinstance(self.created_at, datetime.datetime):
            created_at = self.created_at.isoformat()
        else:
            created_at = self.created_at

        modified_at: None | str | Unset
        if isinstance(self.modified_at, Unset):
            modified_at = UNSET
        elif isinstance(self.modified_at, datetime.datetime):
            modified_at = self.modified_at.isoformat()
        else:
            modified_at = self.modified_at

        field_rest: dict[str, Any] | None | Unset
        if isinstance(self.field_rest, Unset):
            field_rest = UNSET
        elif isinstance(self.field_rest, RestMetadataType0):
            field_rest = self.field_rest.to_dict()
        else:
            field_rest = self.field_rest

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "groupName": group_name,
            }
        )
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if group_id is not UNSET:
            field_dict["groupId"] = group_id
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if description is not UNSET:
            field_dict["description"] = description
        if group_type is not UNSET:
            field_dict["groupType"] = group_type
        if members is not UNSET:
            field_dict["members"] = members
        if created_at is not UNSET:
            field_dict["createdAt"] = created_at
        if modified_at is not UNSET:
            field_dict["modifiedAt"] = modified_at
        if field_rest is not UNSET:
            field_dict["_rest"] = field_rest

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rest_metadata_type_0 import RestMetadataType0

        d = dict(src_dict)
        group_name = d.pop("groupName")

        def _parse_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        uuid = _parse_uuid(d.pop("uuid", UNSET))

        def _parse_group_id(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        group_id = _parse_group_id(d.pop("groupId", UNSET))

        def _parse_display_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        display_name = _parse_display_name(d.pop("displayName", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_group_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        group_type = _parse_group_type(d.pop("groupType", UNSET))

        def _parse_members(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                members_type_0 = cast(list[str], data)

                return members_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        members = _parse_members(d.pop("members", UNSET))

        def _parse_created_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                created_at_type_0 = datetime.datetime.fromisoformat(data)

                return created_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        created_at = _parse_created_at(d.pop("createdAt", UNSET))

        def _parse_modified_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                modified_at_type_0 = datetime.datetime.fromisoformat(data)

                return modified_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        modified_at = _parse_modified_at(d.pop("modifiedAt", UNSET))

        def _parse_field_rest(data: object) -> None | RestMetadataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_rest_metadata_type_0 = RestMetadataType0.from_dict(data)

                return componentsschemas_rest_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RestMetadataType0 | Unset, data)

        field_rest = _parse_field_rest(d.pop("_rest", UNSET))

        group = cls(
            group_name=group_name,
            uuid=uuid,
            group_id=group_id,
            display_name=display_name,
            description=description,
            group_type=group_type,
            members=members,
            created_at=created_at,
            modified_at=modified_at,
            field_rest=field_rest,
        )

        group.additional_properties = d
        return group

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
