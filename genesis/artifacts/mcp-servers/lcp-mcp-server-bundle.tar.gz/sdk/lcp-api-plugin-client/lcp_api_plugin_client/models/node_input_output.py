from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="NodeInputOutput")


@_attrs_define
class NodeInputOutput:
    """An input or output parameter on an activity node. For customOutputs, only expression and saveInto are used (name and
    type are null).

        Attributes:
            name (None | str | Unset): Parameter identifier (null for customOutputs)
            type_ (str | Unset): Type name: primitives (TEXT, BOOLEAN, etc.) or record type QName
            required (bool | Unset): Whether the input must be provided
            expression (None | str | Unset): SAIL expression (e.g., "pv!order")
            value (Any | Unset): Literal value — UUID for reference types (auto-translated)
            save_into (None | str | Unset): Process variable to save into (e.g., "pv!result")
    """

    name: None | str | Unset = UNSET
    type_: str | Unset = UNSET
    required: bool | Unset = UNSET
    expression: None | str | Unset = UNSET
    value: Any | Unset = UNSET
    save_into: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        type_ = self.type_

        required = self.required

        expression: None | str | Unset
        if isinstance(self.expression, Unset):
            expression = UNSET
        else:
            expression = self.expression

        value = self.value

        save_into: None | str | Unset
        if isinstance(self.save_into, Unset):
            save_into = UNSET
        else:
            save_into = self.save_into

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if type_ is not UNSET:
            field_dict["type"] = type_
        if required is not UNSET:
            field_dict["required"] = required
        if expression is not UNSET:
            field_dict["expression"] = expression
        if value is not UNSET:
            field_dict["value"] = value
        if save_into is not UNSET:
            field_dict["saveInto"] = save_into

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        type_ = d.pop("type", UNSET)

        required = d.pop("required", UNSET)

        def _parse_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expression = _parse_expression(d.pop("expression", UNSET))

        value = d.pop("value", UNSET)

        def _parse_save_into(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        save_into = _parse_save_into(d.pop("saveInto", UNSET))

        node_input_output = cls(
            name=name,
            type_=type_,
            required=required,
            expression=expression,
            value=value,
            save_into=save_into,
        )

        node_input_output.additional_properties = d
        return node_input_output

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
