from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.application_default_objects import ApplicationDefaultObjects


T = TypeVar("T", bound="CreateApplicationResponse")


@_attrs_define
class CreateApplicationResponse:
    """Application with UUIDs of all default objects created alongside it

    Attributes:
        uuid (str):
        name (str):
        default_objects (ApplicationDefaultObjects): UUIDs of the default objects created with an application
        description (None | str | Unset):
        prefix (str | Unset):
        url_identifier (str | Unset):
    """

    uuid: str
    name: str
    default_objects: ApplicationDefaultObjects
    description: None | str | Unset = UNSET
    prefix: str | Unset = UNSET
    url_identifier: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        name = self.name

        default_objects = self.default_objects.to_dict()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        prefix = self.prefix

        url_identifier = self.url_identifier

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "name": name,
                "defaultObjects": default_objects,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if prefix is not UNSET:
            field_dict["prefix"] = prefix
        if url_identifier is not UNSET:
            field_dict["urlIdentifier"] = url_identifier

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.application_default_objects import ApplicationDefaultObjects

        d = dict(src_dict)
        uuid = d.pop("uuid")

        name = d.pop("name")

        default_objects = ApplicationDefaultObjects.from_dict(d.pop("defaultObjects"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        prefix = d.pop("prefix", UNSET)

        url_identifier = d.pop("urlIdentifier", UNSET)

        create_application_response = cls(
            uuid=uuid,
            name=name,
            default_objects=default_objects,
            description=description,
            prefix=prefix,
            url_identifier=url_identifier,
        )

        create_application_response.additional_properties = d
        return create_application_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
