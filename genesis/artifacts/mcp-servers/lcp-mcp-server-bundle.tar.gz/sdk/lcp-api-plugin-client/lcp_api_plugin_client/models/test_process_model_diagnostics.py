from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="TestProcessModelDiagnostics")


@_attrs_define
class TestProcessModelDiagnostics:
    """Diagnostic information about the process model test execution.

    Attributes:
        duration_ms (int | Unset): Execution duration in milliseconds
        error (None | str | Unset): Error message if execution failed or timed out
        timed_out (bool | Unset): Whether the process did not complete within the timeout
    """

    duration_ms: int | Unset = UNSET
    error: None | str | Unset = UNSET
    timed_out: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        duration_ms = self.duration_ms

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        timed_out = self.timed_out

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if duration_ms is not UNSET:
            field_dict["durationMs"] = duration_ms
        if error is not UNSET:
            field_dict["error"] = error
        if timed_out is not UNSET:
            field_dict["timedOut"] = timed_out

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        duration_ms = d.pop("durationMs", UNSET)

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        timed_out = d.pop("timedOut", UNSET)

        test_process_model_diagnostics = cls(
            duration_ms=duration_ms,
            error=error,
            timed_out=timed_out,
        )

        test_process_model_diagnostics.additional_properties = d
        return test_process_model_diagnostics

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
