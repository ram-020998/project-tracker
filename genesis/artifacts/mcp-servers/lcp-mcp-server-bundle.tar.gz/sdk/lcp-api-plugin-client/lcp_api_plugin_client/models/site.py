from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.site_layout import SiteLayout
from ..models.site_style import SiteStyle
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rest_metadata_type_0 import RestMetadataType0
    from ..models.site_page import SitePage


T = TypeVar("T", bound="Site")


@_attrs_define
class Site:
    """Site metadata

    Attributes:
        uuid (str | Unset): The universally unique identifier of the site Example: site-123.
        name (str | Unset): The internal name of the site Example: Main Site.
        display_name (str | Unset): The display name shown to users Example: Main Site.
        web_address_identifier (str | Unset): The URL stub used in the site's web address Example: main-site.
        description (None | str | Unset): A text description of the site's purpose Example: Primary application site.
        layout (SiteLayout | Unset): Navigation bar layout. HEADER_BAR displays pages horizontally across the top.
            SIDEBAR displays pages in a vertically stacked collapsible list on the left. Example: HEADER_BAR.
        style (SiteStyle | Unset): Header bar style (only applies when layout is HEADER_BAR). HELIUM shows icons above
            page names with logo on right. MERCURY shows page names on left with logo on left. OXYGEN shows page names on
            right with logo on left. Not present when layout is SIDEBAR. Example: MERCURY.
        pages (list[SitePage] | Unset): The pages configured for this site
        version_id (None | str | Unset): Version ID for optimistic concurrency control. Include in PUT/DELETE requests
            to prevent stale writes.
        field_rest (None | RestMetadataType0 | Unset): Response metadata including the Designer URL for this object.
            Present on get, create, and update responses for design objects.
    """

    uuid: str | Unset = UNSET
    name: str | Unset = UNSET
    display_name: str | Unset = UNSET
    web_address_identifier: str | Unset = UNSET
    description: None | str | Unset = UNSET
    layout: SiteLayout | Unset = UNSET
    style: SiteStyle | Unset = UNSET
    pages: list[SitePage] | Unset = UNSET
    version_id: None | str | Unset = UNSET
    field_rest: None | RestMetadataType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rest_metadata_type_0 import RestMetadataType0

        uuid = self.uuid

        name = self.name

        display_name = self.display_name

        web_address_identifier = self.web_address_identifier

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        layout: str | Unset = UNSET
        if not isinstance(self.layout, Unset):
            layout = self.layout.value

        style: str | Unset = UNSET
        if not isinstance(self.style, Unset):
            style = self.style.value

        pages: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.pages, Unset):
            pages = []
            for pages_item_data in self.pages:
                pages_item = pages_item_data.to_dict()
                pages.append(pages_item)

        version_id: None | str | Unset
        if isinstance(self.version_id, Unset):
            version_id = UNSET
        else:
            version_id = self.version_id

        field_rest: dict[str, Any] | None | Unset
        if isinstance(self.field_rest, Unset):
            field_rest = UNSET
        elif isinstance(self.field_rest, RestMetadataType0):
            field_rest = self.field_rest.to_dict()
        else:
            field_rest = self.field_rest

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if name is not UNSET:
            field_dict["name"] = name
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if web_address_identifier is not UNSET:
            field_dict["webAddressIdentifier"] = web_address_identifier
        if description is not UNSET:
            field_dict["description"] = description
        if layout is not UNSET:
            field_dict["layout"] = layout
        if style is not UNSET:
            field_dict["style"] = style
        if pages is not UNSET:
            field_dict["pages"] = pages
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if field_rest is not UNSET:
            field_dict["_rest"] = field_rest

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rest_metadata_type_0 import RestMetadataType0
        from ..models.site_page import SitePage

        d = dict(src_dict)
        uuid = d.pop("uuid", UNSET)

        name = d.pop("name", UNSET)

        display_name = d.pop("displayName", UNSET)

        web_address_identifier = d.pop("webAddressIdentifier", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        _layout = d.pop("layout", UNSET)
        layout: SiteLayout | Unset
        if isinstance(_layout, Unset):
            layout = UNSET
        else:
            layout = SiteLayout(_layout)

        _style = d.pop("style", UNSET)
        style: SiteStyle | Unset
        if isinstance(_style, Unset):
            style = UNSET
        else:
            style = SiteStyle(_style)

        _pages = d.pop("pages", UNSET)
        pages: list[SitePage] | Unset = UNSET
        if _pages is not UNSET:
            pages = []
            for pages_item_data in _pages:
                pages_item = SitePage.from_dict(pages_item_data)

                pages.append(pages_item)

        def _parse_version_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version_id = _parse_version_id(d.pop("versionId", UNSET))

        def _parse_field_rest(data: object) -> None | RestMetadataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_rest_metadata_type_0 = RestMetadataType0.from_dict(data)

                return componentsschemas_rest_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RestMetadataType0 | Unset, data)

        field_rest = _parse_field_rest(d.pop("_rest", UNSET))

        site = cls(
            uuid=uuid,
            name=name,
            display_name=display_name,
            web_address_identifier=web_address_identifier,
            description=description,
            layout=layout,
            style=style,
            pages=pages,
            version_id=version_id,
            field_rest=field_rest,
        )

        site.additional_properties = d
        return site

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
