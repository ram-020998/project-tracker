from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.add_group_member_result import AddGroupMemberResult


T = TypeVar("T", bound="AddGroupMembersResponse")


@_attrs_define
class AddGroupMembersResponse:
    """
    Attributes:
        has_errors (bool): True if any member addition failed.
        added (list[AddGroupMemberResult]):
    """

    has_errors: bool
    added: list[AddGroupMemberResult]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        has_errors = self.has_errors

        added = []
        for added_item_data in self.added:
            added_item = added_item_data.to_dict()
            added.append(added_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hasErrors": has_errors,
                "added": added,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.add_group_member_result import AddGroupMemberResult

        d = dict(src_dict)
        has_errors = d.pop("hasErrors")

        added = []
        _added = d.pop("added")
        for added_item_data in _added:
            added_item = AddGroupMemberResult.from_dict(added_item_data)

            added.append(added_item)

        add_group_members_response = cls(
            has_errors=has_errors,
            added=added,
        )

        add_group_members_response.additional_properties = d
        return add_group_members_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
