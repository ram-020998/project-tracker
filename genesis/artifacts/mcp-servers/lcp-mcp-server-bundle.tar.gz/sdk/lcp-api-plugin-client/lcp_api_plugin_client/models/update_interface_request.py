from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.typed_input import TypedInput
    from ..models.update_interface_request_test_inputs_item import UpdateInterfaceRequestTestInputsItem


T = TypeVar("T", bound="UpdateInterfaceRequest")


@_attrs_define
class UpdateInterfaceRequest:
    """Request body for updating an existing interface. At least one field must be provided.
    Only the fields provided will be updated; other fields remain unchanged.

        Attributes:
            version_id (str | Unset): Version ID for optimistic concurrency control. If provided, validates against current
                version.
            name (str | Unset): Name of the interface (cannot be empty if provided) Example: Updated Customer Form.
            description (None | str | Unset): Description of what this interface does Example: Updated form for editing
                customer information.
            expression (None | str | Unset): The SAIL expression that renders this interface Example: a!formLayout(
                  label: "Customer Information",
                  contents: {
                    a!textField(
                      label: "Name",
                      value: ri!customerName,
                      saveInto: ri!customerName,
                      required: true
                    )
                  }
                )
                .
            inputs (list[TypedInput] | Unset): Input parameters for the interface. Replaces all existing parameters.
                Each parameter must have a name and type.
                 Example: [{'name': 'customerId', 'type': 'Number (Integer)'}, {'name': 'customerName', 'type': 'Text'},
                {'name': 'email', 'type': 'Text'}].
            test_inputs (list[UpdateInterfaceRequestTestInputsItem] | Unset): Test input values to use during validation and
                save as default test values.
                If not provided, existing test values are reused. If none exist, validation uses null inputs.
    """

    version_id: str | Unset = UNSET
    name: str | Unset = UNSET
    description: None | str | Unset = UNSET
    expression: None | str | Unset = UNSET
    inputs: list[TypedInput] | Unset = UNSET
    test_inputs: list[UpdateInterfaceRequestTestInputsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        version_id = self.version_id

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        expression: None | str | Unset
        if isinstance(self.expression, Unset):
            expression = UNSET
        else:
            expression = self.expression

        inputs: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.inputs, Unset):
            inputs = []
            for inputs_item_data in self.inputs:
                inputs_item = inputs_item_data.to_dict()
                inputs.append(inputs_item)

        test_inputs: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.test_inputs, Unset):
            test_inputs = []
            for test_inputs_item_data in self.test_inputs:
                test_inputs_item = test_inputs_item_data.to_dict()
                test_inputs.append(test_inputs_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if expression is not UNSET:
            field_dict["expression"] = expression
        if inputs is not UNSET:
            field_dict["inputs"] = inputs
        if test_inputs is not UNSET:
            field_dict["testInputs"] = test_inputs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.typed_input import TypedInput
        from ..models.update_interface_request_test_inputs_item import UpdateInterfaceRequestTestInputsItem

        d = dict(src_dict)
        version_id = d.pop("versionId", UNSET)

        name = d.pop("name", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expression = _parse_expression(d.pop("expression", UNSET))

        _inputs = d.pop("inputs", UNSET)
        inputs: list[TypedInput] | Unset = UNSET
        if _inputs is not UNSET:
            inputs = []
            for inputs_item_data in _inputs:
                inputs_item = TypedInput.from_dict(inputs_item_data)

                inputs.append(inputs_item)

        _test_inputs = d.pop("testInputs", UNSET)
        test_inputs: list[UpdateInterfaceRequestTestInputsItem] | Unset = UNSET
        if _test_inputs is not UNSET:
            test_inputs = []
            for test_inputs_item_data in _test_inputs:
                test_inputs_item = UpdateInterfaceRequestTestInputsItem.from_dict(test_inputs_item_data)

                test_inputs.append(test_inputs_item)

        update_interface_request = cls(
            version_id=version_id,
            name=name,
            description=description,
            expression=expression,
            inputs=inputs,
            test_inputs=test_inputs,
        )

        update_interface_request.additional_properties = d
        return update_interface_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
