from enum import Enum


class NodeTypeSummaryAssignment(str, Enum):
    ATTENDED_ONLY = "ATTENDED_ONLY"
    ATTENDED_OR_UNATTENDED = "ATTENDED_OR_UNATTENDED"
    UNATTENDED_ONLY = "UNATTENDED_ONLY"

    def __str__(self) -> str:
        return str(self.value)
