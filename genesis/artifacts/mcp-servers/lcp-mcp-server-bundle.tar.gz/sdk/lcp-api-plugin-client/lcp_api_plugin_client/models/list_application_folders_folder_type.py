from enum import Enum


class ListApplicationFoldersFolderType(str, Enum):
    KNOWLEDGE_CENTER = "KNOWLEDGE_CENTER"
    KNOWLEDGE_FOLDER = "KNOWLEDGE_FOLDER"
    PROCESS_MODEL_FOLDER = "PROCESS_MODEL_FOLDER"
    RULES_FOLDER = "RULES_FOLDER"

    def __str__(self) -> str:
        return str(self.value)
