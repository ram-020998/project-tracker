from enum import Enum


class DesignObjectReferenceType(str, Enum):
    CONSTANT = "CONSTANT"
    DATA_TYPE = "DATA_TYPE"
    EXPRESSION_RULE = "EXPRESSION_RULE"
    GROUP = "GROUP"
    INTERFACE = "INTERFACE"
    PROCESS_MODEL = "PROCESS_MODEL"
    RECORD_TYPE = "RECORD_TYPE"
    SITE = "SITE"

    def __str__(self) -> str:
        return str(self.value)
