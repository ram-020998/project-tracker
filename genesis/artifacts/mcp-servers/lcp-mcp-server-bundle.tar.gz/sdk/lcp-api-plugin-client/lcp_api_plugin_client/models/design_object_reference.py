from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.design_object_reference_type import DesignObjectReferenceType

T = TypeVar("T", bound="DesignObjectReference")


@_attrs_define
class DesignObjectReference:
    """Reference to a design object by UUID and type.
    Used when adding design objects to applications or managing object relationships.

        Attributes:
            uuid (str): UUID of the design object. Can be either standard UUID format or Appian-specific format.
                Examples:
                - Standard UUID: "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
                - Appian UUID: "_a-0000e5bd-0e0e-8000-4d53-01ef9001ef90_6844"
                 Example: a1b2c3d4-e5f6-7890-abcd-ef1234567890.
            type_ (DesignObjectReferenceType): Type of the design object Example: PROCESS_MODEL.
    """

    uuid: str
    type_: DesignObjectReferenceType
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        type_ = self.type_.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "type": type_,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid")

        type_ = DesignObjectReferenceType(d.pop("type"))

        design_object_reference = cls(
            uuid=uuid,
            type_=type_,
        )

        design_object_reference.additional_properties = d
        return design_object_reference

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
