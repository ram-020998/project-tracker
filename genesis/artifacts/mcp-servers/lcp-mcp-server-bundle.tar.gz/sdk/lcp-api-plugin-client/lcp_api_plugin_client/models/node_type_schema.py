from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.node_type_schema_assignment import NodeTypeSchemaAssignment
from ..models.node_type_schema_category import NodeTypeSchemaCategory
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.node_type_schema_param import NodeTypeSchemaParam


T = TypeVar("T", bound="NodeTypeSchema")


@_attrs_define
class NodeTypeSchema:
    """Full parameter schema for a node type.

    Attributes:
        type_ (str | Unset):
        type_name (str | Unset):
        category (NodeTypeSchemaCategory | Unset):
        assignment (NodeTypeSchemaAssignment | Unset):
        deprecated (bool | Unset): True if this node type is deprecated. Prefer the non-deprecated equivalent.
        inputs (list[NodeTypeSchemaParam] | Unset):
        outputs (list[NodeTypeSchemaParam] | Unset):
        reference_uuid (None | str | Unset):
        reference_name (None | str | Unset):
        custom_inputs (list[NodeTypeSchemaParam] | None | Unset): Dynamic custom inputs populated by schema enrichment
            (e.g., integration rule inputs).
        form_interface_uuid (None | str | Unset):
        form_interface_name (None | str | Unset):
        form_inputs (list[str] | None | Unset):
    """

    type_: str | Unset = UNSET
    type_name: str | Unset = UNSET
    category: NodeTypeSchemaCategory | Unset = UNSET
    assignment: NodeTypeSchemaAssignment | Unset = UNSET
    deprecated: bool | Unset = UNSET
    inputs: list[NodeTypeSchemaParam] | Unset = UNSET
    outputs: list[NodeTypeSchemaParam] | Unset = UNSET
    reference_uuid: None | str | Unset = UNSET
    reference_name: None | str | Unset = UNSET
    custom_inputs: list[NodeTypeSchemaParam] | None | Unset = UNSET
    form_interface_uuid: None | str | Unset = UNSET
    form_interface_name: None | str | Unset = UNSET
    form_inputs: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        type_name = self.type_name

        category: str | Unset = UNSET
        if not isinstance(self.category, Unset):
            category = self.category.value

        assignment: str | Unset = UNSET
        if not isinstance(self.assignment, Unset):
            assignment = self.assignment.value

        deprecated = self.deprecated

        inputs: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.inputs, Unset):
            inputs = []
            for inputs_item_data in self.inputs:
                inputs_item = inputs_item_data.to_dict()
                inputs.append(inputs_item)

        outputs: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.outputs, Unset):
            outputs = []
            for outputs_item_data in self.outputs:
                outputs_item = outputs_item_data.to_dict()
                outputs.append(outputs_item)

        reference_uuid: None | str | Unset
        if isinstance(self.reference_uuid, Unset):
            reference_uuid = UNSET
        else:
            reference_uuid = self.reference_uuid

        reference_name: None | str | Unset
        if isinstance(self.reference_name, Unset):
            reference_name = UNSET
        else:
            reference_name = self.reference_name

        custom_inputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.custom_inputs, Unset):
            custom_inputs = UNSET
        elif isinstance(self.custom_inputs, list):
            custom_inputs = []
            for custom_inputs_type_0_item_data in self.custom_inputs:
                custom_inputs_type_0_item = custom_inputs_type_0_item_data.to_dict()
                custom_inputs.append(custom_inputs_type_0_item)

        else:
            custom_inputs = self.custom_inputs

        form_interface_uuid: None | str | Unset
        if isinstance(self.form_interface_uuid, Unset):
            form_interface_uuid = UNSET
        else:
            form_interface_uuid = self.form_interface_uuid

        form_interface_name: None | str | Unset
        if isinstance(self.form_interface_name, Unset):
            form_interface_name = UNSET
        else:
            form_interface_name = self.form_interface_name

        form_inputs: list[str] | None | Unset
        if isinstance(self.form_inputs, Unset):
            form_inputs = UNSET
        elif isinstance(self.form_inputs, list):
            form_inputs = self.form_inputs

        else:
            form_inputs = self.form_inputs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if type_name is not UNSET:
            field_dict["typeName"] = type_name
        if category is not UNSET:
            field_dict["category"] = category
        if assignment is not UNSET:
            field_dict["assignment"] = assignment
        if deprecated is not UNSET:
            field_dict["deprecated"] = deprecated
        if inputs is not UNSET:
            field_dict["inputs"] = inputs
        if outputs is not UNSET:
            field_dict["outputs"] = outputs
        if reference_uuid is not UNSET:
            field_dict["referenceUuid"] = reference_uuid
        if reference_name is not UNSET:
            field_dict["referenceName"] = reference_name
        if custom_inputs is not UNSET:
            field_dict["customInputs"] = custom_inputs
        if form_interface_uuid is not UNSET:
            field_dict["formInterfaceUuid"] = form_interface_uuid
        if form_interface_name is not UNSET:
            field_dict["formInterfaceName"] = form_interface_name
        if form_inputs is not UNSET:
            field_dict["formInputs"] = form_inputs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.node_type_schema_param import NodeTypeSchemaParam

        d = dict(src_dict)
        type_ = d.pop("type", UNSET)

        type_name = d.pop("typeName", UNSET)

        _category = d.pop("category", UNSET)
        category: NodeTypeSchemaCategory | Unset
        if isinstance(_category, Unset):
            category = UNSET
        else:
            category = NodeTypeSchemaCategory(_category)

        _assignment = d.pop("assignment", UNSET)
        assignment: NodeTypeSchemaAssignment | Unset
        if isinstance(_assignment, Unset):
            assignment = UNSET
        else:
            assignment = NodeTypeSchemaAssignment(_assignment)

        deprecated = d.pop("deprecated", UNSET)

        _inputs = d.pop("inputs", UNSET)
        inputs: list[NodeTypeSchemaParam] | Unset = UNSET
        if _inputs is not UNSET:
            inputs = []
            for inputs_item_data in _inputs:
                inputs_item = NodeTypeSchemaParam.from_dict(inputs_item_data)

                inputs.append(inputs_item)

        _outputs = d.pop("outputs", UNSET)
        outputs: list[NodeTypeSchemaParam] | Unset = UNSET
        if _outputs is not UNSET:
            outputs = []
            for outputs_item_data in _outputs:
                outputs_item = NodeTypeSchemaParam.from_dict(outputs_item_data)

                outputs.append(outputs_item)

        def _parse_reference_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reference_uuid = _parse_reference_uuid(d.pop("referenceUuid", UNSET))

        def _parse_reference_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reference_name = _parse_reference_name(d.pop("referenceName", UNSET))

        def _parse_custom_inputs(data: object) -> list[NodeTypeSchemaParam] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                custom_inputs_type_0 = []
                _custom_inputs_type_0 = data
                for custom_inputs_type_0_item_data in _custom_inputs_type_0:
                    custom_inputs_type_0_item = NodeTypeSchemaParam.from_dict(custom_inputs_type_0_item_data)

                    custom_inputs_type_0.append(custom_inputs_type_0_item)

                return custom_inputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[NodeTypeSchemaParam] | None | Unset, data)

        custom_inputs = _parse_custom_inputs(d.pop("customInputs", UNSET))

        def _parse_form_interface_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        form_interface_uuid = _parse_form_interface_uuid(d.pop("formInterfaceUuid", UNSET))

        def _parse_form_interface_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        form_interface_name = _parse_form_interface_name(d.pop("formInterfaceName", UNSET))

        def _parse_form_inputs(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                form_inputs_type_0 = cast(list[str], data)

                return form_inputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        form_inputs = _parse_form_inputs(d.pop("formInputs", UNSET))

        node_type_schema = cls(
            type_=type_,
            type_name=type_name,
            category=category,
            assignment=assignment,
            deprecated=deprecated,
            inputs=inputs,
            outputs=outputs,
            reference_uuid=reference_uuid,
            reference_name=reference_name,
            custom_inputs=custom_inputs,
            form_interface_uuid=form_interface_uuid,
            form_interface_name=form_interface_name,
            form_inputs=form_inputs,
        )

        node_type_schema.additional_properties = d
        return node_type_schema

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
