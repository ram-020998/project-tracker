from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.test_case_run_result_test_errors_type_0_item import TestCaseRunResultTestErrorsType0Item


T = TypeVar("T", bound="TestCaseRunResult")


@_attrs_define
class TestCaseRunResult:
    """Result of executing a test case

    Attributes:
        success (bool): Whether the test case passed
        output (None | str | Unset): String representation of the rule's output value
        duration_ms (int | None | Unset): Execution time in milliseconds
        test_errors (list[TestCaseRunResultTestErrorsType0Item] | None | Unset): List of test assertion failures (empty
            if test passed)
        error (None | str | Unset): Evaluation error message if the rule failed to execute
    """

    success: bool
    output: None | str | Unset = UNSET
    duration_ms: int | None | Unset = UNSET
    test_errors: list[TestCaseRunResultTestErrorsType0Item] | None | Unset = UNSET
    error: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        success = self.success

        output: None | str | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        else:
            output = self.output

        duration_ms: int | None | Unset
        if isinstance(self.duration_ms, Unset):
            duration_ms = UNSET
        else:
            duration_ms = self.duration_ms

        test_errors: list[dict[str, Any]] | None | Unset
        if isinstance(self.test_errors, Unset):
            test_errors = UNSET
        elif isinstance(self.test_errors, list):
            test_errors = []
            for test_errors_type_0_item_data in self.test_errors:
                test_errors_type_0_item = test_errors_type_0_item_data.to_dict()
                test_errors.append(test_errors_type_0_item)

        else:
            test_errors = self.test_errors

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "success": success,
            }
        )
        if output is not UNSET:
            field_dict["output"] = output
        if duration_ms is not UNSET:
            field_dict["durationMs"] = duration_ms
        if test_errors is not UNSET:
            field_dict["testErrors"] = test_errors
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.test_case_run_result_test_errors_type_0_item import TestCaseRunResultTestErrorsType0Item

        d = dict(src_dict)
        success = d.pop("success")

        def _parse_output(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        output = _parse_output(d.pop("output", UNSET))

        def _parse_duration_ms(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        duration_ms = _parse_duration_ms(d.pop("durationMs", UNSET))

        def _parse_test_errors(data: object) -> list[TestCaseRunResultTestErrorsType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                test_errors_type_0 = []
                _test_errors_type_0 = data
                for test_errors_type_0_item_data in _test_errors_type_0:
                    test_errors_type_0_item = TestCaseRunResultTestErrorsType0Item.from_dict(
                        test_errors_type_0_item_data
                    )

                    test_errors_type_0.append(test_errors_type_0_item)

                return test_errors_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[TestCaseRunResultTestErrorsType0Item] | None | Unset, data)

        test_errors = _parse_test_errors(d.pop("testErrors", UNSET))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        test_case_run_result = cls(
            success=success,
            output=output,
            duration_ms=duration_ms,
            test_errors=test_errors,
            error=error,
        )

        test_case_run_result.additional_properties = d
        return test_case_run_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
