from enum import Enum


class UpdateCustomRecordFieldRequestFieldType(str, Enum):
    BOOLEAN = "BOOLEAN"
    DATE = "DATE"
    DATETIME = "DATETIME"
    DECIMAL = "DECIMAL"
    DOCUMENT = "DOCUMENT"
    FOLDER = "FOLDER"
    GROUP = "GROUP"
    INTEGER = "INTEGER"
    NUMBER = "NUMBER"
    TEXT = "TEXT"
    TIME = "TIME"
    USER = "USER"

    def __str__(self) -> str:
        return str(self.value)
