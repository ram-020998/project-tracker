from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.integration_input import IntegrationInput
    from ..models.integration_test_input import IntegrationTestInput
    from ..models.update_integration_request_properties_type_0 import UpdateIntegrationRequestPropertiesType0


T = TypeVar("T", bound="UpdateIntegrationRequest")


@_attrs_define
class UpdateIntegrationRequest:
    """Request body for updating an integration. Only provided fields are changed. Inputs are full-replacement (not
    merged).

        Attributes:
            version_id (str | Unset): Version ID for optimistic concurrency control. If provided, validates against current
                version.
            name (str | Unset): Display name
            description (None | str | Unset): Description
            operation_id (None | str | Unset): Operation identifier. Changing this switches the integration to a different
                operation.
            properties (None | Unset | UpdateIntegrationRequestPropertiesType0): Configuration properties to update
                (validated against the operation schema).

                For HTTP integrations with a `multipart/form-data` body, set the body via
                `bodyFormParts` (structured `{name, contentType, value}` list) or `bodyContent`
                (a raw SAIL expression evaluating to `a!httpFormPart(...)` values, which
                overrides `bodyFormParts` and supports conditional parts). See
                CreateIntegrationRequest for details. The body is validated before save.
            inputs (list[IntegrationInput] | None | Unset): Rule input parameters (full replacement — replaces all existing
                inputs)
            test_inputs (list[IntegrationTestInput] | None | Unset): Test input values used during body validation and saved
                as the integration's
                default test case. If omitted, the previously saved default test case is used
                for validation. Integrations support only a default test case (no named cases).
    """

    version_id: str | Unset = UNSET
    name: str | Unset = UNSET
    description: None | str | Unset = UNSET
    operation_id: None | str | Unset = UNSET
    properties: None | Unset | UpdateIntegrationRequestPropertiesType0 = UNSET
    inputs: list[IntegrationInput] | None | Unset = UNSET
    test_inputs: list[IntegrationTestInput] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.update_integration_request_properties_type_0 import UpdateIntegrationRequestPropertiesType0

        version_id = self.version_id

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        operation_id: None | str | Unset
        if isinstance(self.operation_id, Unset):
            operation_id = UNSET
        else:
            operation_id = self.operation_id

        properties: dict[str, Any] | None | Unset
        if isinstance(self.properties, Unset):
            properties = UNSET
        elif isinstance(self.properties, UpdateIntegrationRequestPropertiesType0):
            properties = self.properties.to_dict()
        else:
            properties = self.properties

        inputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.inputs, Unset):
            inputs = UNSET
        elif isinstance(self.inputs, list):
            inputs = []
            for inputs_type_0_item_data in self.inputs:
                inputs_type_0_item = inputs_type_0_item_data.to_dict()
                inputs.append(inputs_type_0_item)

        else:
            inputs = self.inputs

        test_inputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.test_inputs, Unset):
            test_inputs = UNSET
        elif isinstance(self.test_inputs, list):
            test_inputs = []
            for test_inputs_type_0_item_data in self.test_inputs:
                test_inputs_type_0_item = test_inputs_type_0_item_data.to_dict()
                test_inputs.append(test_inputs_type_0_item)

        else:
            test_inputs = self.test_inputs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if operation_id is not UNSET:
            field_dict["operationId"] = operation_id
        if properties is not UNSET:
            field_dict["properties"] = properties
        if inputs is not UNSET:
            field_dict["inputs"] = inputs
        if test_inputs is not UNSET:
            field_dict["testInputs"] = test_inputs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.integration_input import IntegrationInput
        from ..models.integration_test_input import IntegrationTestInput
        from ..models.update_integration_request_properties_type_0 import UpdateIntegrationRequestPropertiesType0

        d = dict(src_dict)
        version_id = d.pop("versionId", UNSET)

        name = d.pop("name", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_operation_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        operation_id = _parse_operation_id(d.pop("operationId", UNSET))

        def _parse_properties(data: object) -> None | Unset | UpdateIntegrationRequestPropertiesType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                properties_type_0 = UpdateIntegrationRequestPropertiesType0.from_dict(data)

                return properties_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateIntegrationRequestPropertiesType0, data)

        properties = _parse_properties(d.pop("properties", UNSET))

        def _parse_inputs(data: object) -> list[IntegrationInput] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                inputs_type_0 = []
                _inputs_type_0 = data
                for inputs_type_0_item_data in _inputs_type_0:
                    inputs_type_0_item = IntegrationInput.from_dict(inputs_type_0_item_data)

                    inputs_type_0.append(inputs_type_0_item)

                return inputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[IntegrationInput] | None | Unset, data)

        inputs = _parse_inputs(d.pop("inputs", UNSET))

        def _parse_test_inputs(data: object) -> list[IntegrationTestInput] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                test_inputs_type_0 = []
                _test_inputs_type_0 = data
                for test_inputs_type_0_item_data in _test_inputs_type_0:
                    test_inputs_type_0_item = IntegrationTestInput.from_dict(test_inputs_type_0_item_data)

                    test_inputs_type_0.append(test_inputs_type_0_item)

                return test_inputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[IntegrationTestInput] | None | Unset, data)

        test_inputs = _parse_test_inputs(d.pop("testInputs", UNSET))

        update_integration_request = cls(
            version_id=version_id,
            name=name,
            description=description,
            operation_id=operation_id,
            properties=properties,
            inputs=inputs,
            test_inputs=test_inputs,
        )

        update_integration_request.additional_properties = d
        return update_integration_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
