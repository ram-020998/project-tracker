from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.custom_record_field_response_calculation_type import CustomRecordFieldResponseCalculationType
from ..types import UNSET, Unset

T = TypeVar("T", bound="CustomRecordFieldResponse")


@_attrs_define
class CustomRecordFieldResponse:
    """Response body for a created custom field.

    Attributes:
        uuid (str | Unset):
        field_name (str | Unset):
        field_type (str | Unset):
        display_name (str | Unset):
        description (str | Unset):
        is_custom_field (bool | Unset):
        expression (str | Unset):
        calculation_type (CustomRecordFieldResponseCalculationType | Unset):
    """

    uuid: str | Unset = UNSET
    field_name: str | Unset = UNSET
    field_type: str | Unset = UNSET
    display_name: str | Unset = UNSET
    description: str | Unset = UNSET
    is_custom_field: bool | Unset = UNSET
    expression: str | Unset = UNSET
    calculation_type: CustomRecordFieldResponseCalculationType | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        field_name = self.field_name

        field_type = self.field_type

        display_name = self.display_name

        description = self.description

        is_custom_field = self.is_custom_field

        expression = self.expression

        calculation_type: str | Unset = UNSET
        if not isinstance(self.calculation_type, Unset):
            calculation_type = self.calculation_type.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if field_name is not UNSET:
            field_dict["fieldName"] = field_name
        if field_type is not UNSET:
            field_dict["fieldType"] = field_type
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if description is not UNSET:
            field_dict["description"] = description
        if is_custom_field is not UNSET:
            field_dict["isCustomField"] = is_custom_field
        if expression is not UNSET:
            field_dict["expression"] = expression
        if calculation_type is not UNSET:
            field_dict["calculationType"] = calculation_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid", UNSET)

        field_name = d.pop("fieldName", UNSET)

        field_type = d.pop("fieldType", UNSET)

        display_name = d.pop("displayName", UNSET)

        description = d.pop("description", UNSET)

        is_custom_field = d.pop("isCustomField", UNSET)

        expression = d.pop("expression", UNSET)

        _calculation_type = d.pop("calculationType", UNSET)
        calculation_type: CustomRecordFieldResponseCalculationType | Unset
        if isinstance(_calculation_type, Unset):
            calculation_type = UNSET
        else:
            calculation_type = CustomRecordFieldResponseCalculationType(_calculation_type)

        custom_record_field_response = cls(
            uuid=uuid,
            field_name=field_name,
            field_type=field_type,
            display_name=display_name,
            description=description,
            is_custom_field=is_custom_field,
            expression=expression,
            calculation_type=calculation_type,
        )

        custom_record_field_response.additional_properties = d
        return custom_record_field_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
