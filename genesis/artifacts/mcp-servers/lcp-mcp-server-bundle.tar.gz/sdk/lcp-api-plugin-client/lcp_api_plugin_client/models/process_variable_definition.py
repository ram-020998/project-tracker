from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ProcessVariableDefinition")


@_attrs_define
class ProcessVariableDefinition:
    """Process variable definition for process models. Built-in types by name (e.g., "Text", "Number (Integer)",
    "Boolean"). For developer-defined types, use the typeReference from the record type response.

        Attributes:
            name (str): Variable name Example: orderId.
            type_ (str): Appian type reference. Built-in types by name (e.g., "Text", "Number (Integer)", "Boolean"). For
                developer-defined types, use the typeReference from the record type response.
                 Example: Text.
            description (None | str | Unset): Optional variable description Example: The order identifier.
            is_parameter (bool | None | Unset): Whether this is a process parameter (input to the process) Default: False.
                Example: True.
            is_required (bool | None | Unset): Whether this parameter is required Default: False.
            multiple (bool | None | Unset): Whether this variable holds a list of values. Defaults to false (single value).
                 Default: False.
            value (None | str | Unset): Optional default-value expression for the variable, evaluated when the process is
                initiated. Provide without a leading "=" (e.g. "now()" or "rule!blankCase()"); the leading "=" is added
                automatically on save and stripped on read.
                 Example: now().
    """

    name: str
    type_: str
    description: None | str | Unset = UNSET
    is_parameter: bool | None | Unset = False
    is_required: bool | None | Unset = False
    multiple: bool | None | Unset = False
    value: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        type_ = self.type_

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        is_parameter: bool | None | Unset
        if isinstance(self.is_parameter, Unset):
            is_parameter = UNSET
        else:
            is_parameter = self.is_parameter

        is_required: bool | None | Unset
        if isinstance(self.is_required, Unset):
            is_required = UNSET
        else:
            is_required = self.is_required

        multiple: bool | None | Unset
        if isinstance(self.multiple, Unset):
            multiple = UNSET
        else:
            multiple = self.multiple

        value: None | str | Unset
        if isinstance(self.value, Unset):
            value = UNSET
        else:
            value = self.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type_,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if is_parameter is not UNSET:
            field_dict["isParameter"] = is_parameter
        if is_required is not UNSET:
            field_dict["isRequired"] = is_required
        if multiple is not UNSET:
            field_dict["multiple"] = multiple
        if value is not UNSET:
            field_dict["value"] = value

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        type_ = d.pop("type")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_is_parameter(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_parameter = _parse_is_parameter(d.pop("isParameter", UNSET))

        def _parse_is_required(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_required = _parse_is_required(d.pop("isRequired", UNSET))

        def _parse_multiple(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        multiple = _parse_multiple(d.pop("multiple", UNSET))

        def _parse_value(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        value = _parse_value(d.pop("value", UNSET))

        process_variable_definition = cls(
            name=name,
            type_=type_,
            description=description,
            is_parameter=is_parameter,
            is_required=is_required,
            multiple=multiple,
            value=value,
        )

        process_variable_definition.additional_properties = d
        return process_variable_definition

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
