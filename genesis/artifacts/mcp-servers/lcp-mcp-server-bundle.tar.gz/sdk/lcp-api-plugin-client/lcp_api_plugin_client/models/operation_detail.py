from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.conditional_property_group import ConditionalPropertyGroup
    from ..models.property_descriptor import PropertyDescriptor


T = TypeVar("T", bound="OperationDetail")


@_attrs_define
class OperationDetail:
    """Full detail for an operation including its configuration schema.

    Attributes:
        operation_id (str): Operation identifier Example: httpCall.
        name (str): Display name Example: HTTP Call.
        description (None | str | Unset): Operation description
        properties (list[PropertyDescriptor] | Unset): Configuration schema properties
        one_of (list[ConditionalPropertyGroup] | None | Unset): Conditional property branches
    """

    operation_id: str
    name: str
    description: None | str | Unset = UNSET
    properties: list[PropertyDescriptor] | Unset = UNSET
    one_of: list[ConditionalPropertyGroup] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        operation_id = self.operation_id

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        properties: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.properties, Unset):
            properties = []
            for properties_item_data in self.properties:
                properties_item = properties_item_data.to_dict()
                properties.append(properties_item)

        one_of: list[dict[str, Any]] | None | Unset
        if isinstance(self.one_of, Unset):
            one_of = UNSET
        elif isinstance(self.one_of, list):
            one_of = []
            for one_of_type_0_item_data in self.one_of:
                one_of_type_0_item = one_of_type_0_item_data.to_dict()
                one_of.append(one_of_type_0_item)

        else:
            one_of = self.one_of

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "operationId": operation_id,
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if properties is not UNSET:
            field_dict["properties"] = properties
        if one_of is not UNSET:
            field_dict["oneOf"] = one_of

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.conditional_property_group import ConditionalPropertyGroup
        from ..models.property_descriptor import PropertyDescriptor

        d = dict(src_dict)
        operation_id = d.pop("operationId")

        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        _properties = d.pop("properties", UNSET)
        properties: list[PropertyDescriptor] | Unset = UNSET
        if _properties is not UNSET:
            properties = []
            for properties_item_data in _properties:
                properties_item = PropertyDescriptor.from_dict(properties_item_data)

                properties.append(properties_item)

        def _parse_one_of(data: object) -> list[ConditionalPropertyGroup] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                one_of_type_0 = []
                _one_of_type_0 = data
                for one_of_type_0_item_data in _one_of_type_0:
                    one_of_type_0_item = ConditionalPropertyGroup.from_dict(one_of_type_0_item_data)

                    one_of_type_0.append(one_of_type_0_item)

                return one_of_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ConditionalPropertyGroup] | None | Unset, data)

        one_of = _parse_one_of(d.pop("oneOf", UNSET))

        operation_detail = cls(
            operation_id=operation_id,
            name=name,
            description=description,
            properties=properties,
            one_of=one_of,
        )

        operation_detail.additional_properties = d
        return operation_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
