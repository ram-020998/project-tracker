from enum import Enum


class ProcessVariableType(str, Enum):
    BOOLEAN = "BOOLEAN"
    DATE = "DATE"
    DATETIME = "DATETIME"
    DECIMAL = "DECIMAL"
    DOCUMENT = "DOCUMENT"
    FOLDER = "FOLDER"
    GROUP = "GROUP"
    INTEGER = "INTEGER"
    TEXT = "TEXT"
    USERNAME = "USERNAME"

    def __str__(self) -> str:
        return str(self.value)
