from enum import Enum


class UserFilterFacetType(str, Enum):
    DATE_RANGE = "DATE_RANGE"
    EXPRESSION = "EXPRESSION"
    LIST_OF_VALUES = "LIST_OF_VALUES"

    def __str__(self) -> str:
        return str(self.value)
