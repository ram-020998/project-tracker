from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.update_record_type_relationship_request_relationship_type import (
    UpdateRecordTypeRelationshipRequestRelationshipType,
)
from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateRecordTypeRelationshipRequest")


@_attrs_define
class UpdateRecordTypeRelationshipRequest:
    """Request body for updating a relationship on a record type. Only provided fields are changed.

    Attributes:
        version_id (str | Unset): Current version ID for optimistic concurrency control
        relationship_name (str | Unset): Name of the relationship (used in expressions) Example: orders.
        source_record_type_field_uuid (str | Unset): UUID of the field in the source record type Example: customer-id-
            field-uuid.
        target_record_type_field_uuid (str | Unset): UUID of the field in the target record type Example: order-
            customer-id-field-uuid.
        target_record_type_uuid (str | Unset): UUID of the target record type Example: order-uuid-456.
        relationship_type (UpdateRecordTypeRelationshipRequestRelationshipType | Unset): Type of relationship Example:
            ONE_TO_MANY.
    """

    version_id: str | Unset = UNSET
    relationship_name: str | Unset = UNSET
    source_record_type_field_uuid: str | Unset = UNSET
    target_record_type_field_uuid: str | Unset = UNSET
    target_record_type_uuid: str | Unset = UNSET
    relationship_type: UpdateRecordTypeRelationshipRequestRelationshipType | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        version_id = self.version_id

        relationship_name = self.relationship_name

        source_record_type_field_uuid = self.source_record_type_field_uuid

        target_record_type_field_uuid = self.target_record_type_field_uuid

        target_record_type_uuid = self.target_record_type_uuid

        relationship_type: str | Unset = UNSET
        if not isinstance(self.relationship_type, Unset):
            relationship_type = self.relationship_type.value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if relationship_name is not UNSET:
            field_dict["relationshipName"] = relationship_name
        if source_record_type_field_uuid is not UNSET:
            field_dict["sourceRecordTypeFieldUuid"] = source_record_type_field_uuid
        if target_record_type_field_uuid is not UNSET:
            field_dict["targetRecordTypeFieldUuid"] = target_record_type_field_uuid
        if target_record_type_uuid is not UNSET:
            field_dict["targetRecordTypeUuid"] = target_record_type_uuid
        if relationship_type is not UNSET:
            field_dict["relationshipType"] = relationship_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        version_id = d.pop("versionId", UNSET)

        relationship_name = d.pop("relationshipName", UNSET)

        source_record_type_field_uuid = d.pop("sourceRecordTypeFieldUuid", UNSET)

        target_record_type_field_uuid = d.pop("targetRecordTypeFieldUuid", UNSET)

        target_record_type_uuid = d.pop("targetRecordTypeUuid", UNSET)

        _relationship_type = d.pop("relationshipType", UNSET)
        relationship_type: UpdateRecordTypeRelationshipRequestRelationshipType | Unset
        if isinstance(_relationship_type, Unset):
            relationship_type = UNSET
        else:
            relationship_type = UpdateRecordTypeRelationshipRequestRelationshipType(_relationship_type)

        update_record_type_relationship_request = cls(
            version_id=version_id,
            relationship_name=relationship_name,
            source_record_type_field_uuid=source_record_type_field_uuid,
            target_record_type_field_uuid=target_record_type_field_uuid,
            target_record_type_uuid=target_record_type_uuid,
            relationship_type=relationship_type,
        )

        update_record_type_relationship_request.additional_properties = d
        return update_record_type_relationship_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
