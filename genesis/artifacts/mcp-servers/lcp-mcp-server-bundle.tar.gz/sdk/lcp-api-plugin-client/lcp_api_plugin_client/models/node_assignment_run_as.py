from enum import Enum


class NodeAssignmentRunAs(str, Enum):
    DESIGNER = "DESIGNER"
    INITIATOR = "INITIATOR"

    def __str__(self) -> str:
        return str(self.value)
