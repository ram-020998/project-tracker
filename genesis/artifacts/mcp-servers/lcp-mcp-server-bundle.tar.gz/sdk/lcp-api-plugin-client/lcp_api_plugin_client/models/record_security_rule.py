from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.record_security_rule_membership_type import RecordSecurityRuleMembershipType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.security_rule_filter_condition import SecurityRuleFilterCondition


T = TypeVar("T", bound="RecordSecurityRule")


@_attrs_define
class RecordSecurityRule:
    """A record-level security rule with membership type, type-specific config, and optional filter conditions.

    Attributes:
        membership_type (RecordSecurityRuleMembershipType):
        group_uuids (list[str] | None | Unset): Group UUIDs (GROUPS membership only)
        field_uuids (list[str] | None | Unset): User or Group field UUIDs — direct fields or related record fields
            (FIELDS membership only). Handler resolves field type and relationship path.
        relationship_uuid (None | str | Unset): Relationship UUID (RELATED_RECORDS membership only)
        conditions (list[SecurityRuleFilterCondition] | None | Unset): Additional filter conditions to further limit
            rule applicability.
    """

    membership_type: RecordSecurityRuleMembershipType
    group_uuids: list[str] | None | Unset = UNSET
    field_uuids: list[str] | None | Unset = UNSET
    relationship_uuid: None | str | Unset = UNSET
    conditions: list[SecurityRuleFilterCondition] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        membership_type = self.membership_type.value

        group_uuids: list[str] | None | Unset
        if isinstance(self.group_uuids, Unset):
            group_uuids = UNSET
        elif isinstance(self.group_uuids, list):
            group_uuids = self.group_uuids

        else:
            group_uuids = self.group_uuids

        field_uuids: list[str] | None | Unset
        if isinstance(self.field_uuids, Unset):
            field_uuids = UNSET
        elif isinstance(self.field_uuids, list):
            field_uuids = self.field_uuids

        else:
            field_uuids = self.field_uuids

        relationship_uuid: None | str | Unset
        if isinstance(self.relationship_uuid, Unset):
            relationship_uuid = UNSET
        else:
            relationship_uuid = self.relationship_uuid

        conditions: list[dict[str, Any]] | None | Unset
        if isinstance(self.conditions, Unset):
            conditions = UNSET
        elif isinstance(self.conditions, list):
            conditions = []
            for conditions_type_0_item_data in self.conditions:
                conditions_type_0_item = conditions_type_0_item_data.to_dict()
                conditions.append(conditions_type_0_item)

        else:
            conditions = self.conditions

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "membershipType": membership_type,
            }
        )
        if group_uuids is not UNSET:
            field_dict["groupUuids"] = group_uuids
        if field_uuids is not UNSET:
            field_dict["fieldUuids"] = field_uuids
        if relationship_uuid is not UNSET:
            field_dict["relationshipUuid"] = relationship_uuid
        if conditions is not UNSET:
            field_dict["conditions"] = conditions

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.security_rule_filter_condition import SecurityRuleFilterCondition

        d = dict(src_dict)
        membership_type = RecordSecurityRuleMembershipType(d.pop("membershipType"))

        def _parse_group_uuids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                group_uuids_type_0 = cast(list[str], data)

                return group_uuids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        group_uuids = _parse_group_uuids(d.pop("groupUuids", UNSET))

        def _parse_field_uuids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                field_uuids_type_0 = cast(list[str], data)

                return field_uuids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        field_uuids = _parse_field_uuids(d.pop("fieldUuids", UNSET))

        def _parse_relationship_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        relationship_uuid = _parse_relationship_uuid(d.pop("relationshipUuid", UNSET))

        def _parse_conditions(data: object) -> list[SecurityRuleFilterCondition] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                conditions_type_0 = []
                _conditions_type_0 = data
                for conditions_type_0_item_data in _conditions_type_0:
                    conditions_type_0_item = SecurityRuleFilterCondition.from_dict(conditions_type_0_item_data)

                    conditions_type_0.append(conditions_type_0_item)

                return conditions_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[SecurityRuleFilterCondition] | None | Unset, data)

        conditions = _parse_conditions(d.pop("conditions", UNSET))

        record_security_rule = cls(
            membership_type=membership_type,
            group_uuids=group_uuids,
            field_uuids=field_uuids,
            relationship_uuid=relationship_uuid,
            conditions=conditions,
        )

        record_security_rule.additional_properties = d
        return record_security_rule

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
