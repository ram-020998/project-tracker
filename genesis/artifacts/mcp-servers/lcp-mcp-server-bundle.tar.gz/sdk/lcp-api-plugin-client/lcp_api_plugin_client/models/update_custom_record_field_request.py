from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.update_custom_record_field_request_calculation_type import UpdateCustomRecordFieldRequestCalculationType
from ..models.update_custom_record_field_request_field_type import UpdateCustomRecordFieldRequestFieldType
from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateCustomRecordFieldRequest")


@_attrs_define
class UpdateCustomRecordFieldRequest:
    """Request body for updating a custom (expression-based) field. Only provided fields are changed.

    Attributes:
        field_name (str | Unset): The field name
        field_type (UpdateCustomRecordFieldRequestFieldType | Unset): The return type of the expression
        expression (str | Unset): SAIL expression that computes the field value.
        calculation_type (UpdateCustomRecordFieldRequestCalculationType | Unset): When the expression is evaluated.
        display_name (str | Unset): Human-readable display name.
        description (str | Unset): Field description
    """

    field_name: str | Unset = UNSET
    field_type: UpdateCustomRecordFieldRequestFieldType | Unset = UNSET
    expression: str | Unset = UNSET
    calculation_type: UpdateCustomRecordFieldRequestCalculationType | Unset = UNSET
    display_name: str | Unset = UNSET
    description: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        field_name = self.field_name

        field_type: str | Unset = UNSET
        if not isinstance(self.field_type, Unset):
            field_type = self.field_type.value

        expression = self.expression

        calculation_type: str | Unset = UNSET
        if not isinstance(self.calculation_type, Unset):
            calculation_type = self.calculation_type.value

        display_name = self.display_name

        description = self.description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if field_name is not UNSET:
            field_dict["fieldName"] = field_name
        if field_type is not UNSET:
            field_dict["fieldType"] = field_type
        if expression is not UNSET:
            field_dict["expression"] = expression
        if calculation_type is not UNSET:
            field_dict["calculationType"] = calculation_type
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        field_name = d.pop("fieldName", UNSET)

        _field_type = d.pop("fieldType", UNSET)
        field_type: UpdateCustomRecordFieldRequestFieldType | Unset
        if isinstance(_field_type, Unset):
            field_type = UNSET
        else:
            field_type = UpdateCustomRecordFieldRequestFieldType(_field_type)

        expression = d.pop("expression", UNSET)

        _calculation_type = d.pop("calculationType", UNSET)
        calculation_type: UpdateCustomRecordFieldRequestCalculationType | Unset
        if isinstance(_calculation_type, Unset):
            calculation_type = UNSET
        else:
            calculation_type = UpdateCustomRecordFieldRequestCalculationType(_calculation_type)

        display_name = d.pop("displayName", UNSET)

        description = d.pop("description", UNSET)

        update_custom_record_field_request = cls(
            field_name=field_name,
            field_type=field_type,
            expression=expression,
            calculation_type=calculation_type,
            display_name=display_name,
            description=description,
        )

        update_custom_record_field_request.additional_properties = d
        return update_custom_record_field_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
