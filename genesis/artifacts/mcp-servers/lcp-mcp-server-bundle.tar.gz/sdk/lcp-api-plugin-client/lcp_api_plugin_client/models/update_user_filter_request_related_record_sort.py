from enum import Enum


class UpdateUserFilterRequestRelatedRecordSort(str, Enum):
    ASCENDING = "ASCENDING"
    DESCENDING = "DESCENDING"
    UNSORTED = "UNSORTED"

    def __str__(self) -> str:
        return str(self.value)
