from enum import Enum


class TestCaseAssertionType(str, Enum):
    EXPECTED_OUTPUT = "EXPECTED_OUTPUT"
    NO_ERRORS = "NO_ERRORS"
    RESULT_ASSERTIONS = "RESULT_ASSERTIONS"

    def __str__(self) -> str:
        return str(self.value)
