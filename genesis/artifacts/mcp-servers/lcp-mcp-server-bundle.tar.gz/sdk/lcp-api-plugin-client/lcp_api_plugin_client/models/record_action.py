from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.record_action_action_type import RecordActionActionType
from ..models.record_action_dialog_height import RecordActionDialogHeight
from ..models.record_action_dialog_width import RecordActionDialogWidth
from ..types import UNSET, Unset

T = TypeVar("T", bound="RecordAction")


@_attrs_define
class RecordAction:
    """A record action response

    Attributes:
        uuid (str | Unset):
        key (str | Unset):
        display_name (str | Unset):
        process_model_uuid (str | Unset):
        action_type (RecordActionActionType | Unset):
        description (None | str | Unset):
        icon (None | str | Unset):
        visibility_expr (None | str | Unset):
        dialog_width (RecordActionDialogWidth | Unset):
        dialog_height (RecordActionDialogHeight | Unset):
        context_expr (None | str | Unset):
    """

    uuid: str | Unset = UNSET
    key: str | Unset = UNSET
    display_name: str | Unset = UNSET
    process_model_uuid: str | Unset = UNSET
    action_type: RecordActionActionType | Unset = UNSET
    description: None | str | Unset = UNSET
    icon: None | str | Unset = UNSET
    visibility_expr: None | str | Unset = UNSET
    dialog_width: RecordActionDialogWidth | Unset = UNSET
    dialog_height: RecordActionDialogHeight | Unset = UNSET
    context_expr: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        key = self.key

        display_name = self.display_name

        process_model_uuid = self.process_model_uuid

        action_type: str | Unset = UNSET
        if not isinstance(self.action_type, Unset):
            action_type = self.action_type.value

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        icon: None | str | Unset
        if isinstance(self.icon, Unset):
            icon = UNSET
        else:
            icon = self.icon

        visibility_expr: None | str | Unset
        if isinstance(self.visibility_expr, Unset):
            visibility_expr = UNSET
        else:
            visibility_expr = self.visibility_expr

        dialog_width: str | Unset = UNSET
        if not isinstance(self.dialog_width, Unset):
            dialog_width = self.dialog_width.value

        dialog_height: str | Unset = UNSET
        if not isinstance(self.dialog_height, Unset):
            dialog_height = self.dialog_height.value

        context_expr: None | str | Unset
        if isinstance(self.context_expr, Unset):
            context_expr = UNSET
        else:
            context_expr = self.context_expr

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if key is not UNSET:
            field_dict["key"] = key
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if process_model_uuid is not UNSET:
            field_dict["processModelUuid"] = process_model_uuid
        if action_type is not UNSET:
            field_dict["actionType"] = action_type
        if description is not UNSET:
            field_dict["description"] = description
        if icon is not UNSET:
            field_dict["icon"] = icon
        if visibility_expr is not UNSET:
            field_dict["visibilityExpr"] = visibility_expr
        if dialog_width is not UNSET:
            field_dict["dialogWidth"] = dialog_width
        if dialog_height is not UNSET:
            field_dict["dialogHeight"] = dialog_height
        if context_expr is not UNSET:
            field_dict["contextExpr"] = context_expr

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid", UNSET)

        key = d.pop("key", UNSET)

        display_name = d.pop("displayName", UNSET)

        process_model_uuid = d.pop("processModelUuid", UNSET)

        _action_type = d.pop("actionType", UNSET)
        action_type: RecordActionActionType | Unset
        if isinstance(_action_type, Unset):
            action_type = UNSET
        else:
            action_type = RecordActionActionType(_action_type)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_icon(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        icon = _parse_icon(d.pop("icon", UNSET))

        def _parse_visibility_expr(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        visibility_expr = _parse_visibility_expr(d.pop("visibilityExpr", UNSET))

        _dialog_width = d.pop("dialogWidth", UNSET)
        dialog_width: RecordActionDialogWidth | Unset
        if isinstance(_dialog_width, Unset):
            dialog_width = UNSET
        else:
            dialog_width = RecordActionDialogWidth(_dialog_width)

        _dialog_height = d.pop("dialogHeight", UNSET)
        dialog_height: RecordActionDialogHeight | Unset
        if isinstance(_dialog_height, Unset):
            dialog_height = UNSET
        else:
            dialog_height = RecordActionDialogHeight(_dialog_height)

        def _parse_context_expr(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        context_expr = _parse_context_expr(d.pop("contextExpr", UNSET))

        record_action = cls(
            uuid=uuid,
            key=key,
            display_name=display_name,
            process_model_uuid=process_model_uuid,
            action_type=action_type,
            description=description,
            icon=icon,
            visibility_expr=visibility_expr,
            dialog_width=dialog_width,
            dialog_height=dialog_height,
            context_expr=context_expr,
        )

        record_action.additional_properties = d
        return record_action

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
