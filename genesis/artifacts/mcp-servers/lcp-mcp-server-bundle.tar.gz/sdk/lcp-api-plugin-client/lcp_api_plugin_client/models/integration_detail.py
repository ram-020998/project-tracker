from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.integration_detail_properties_type_0 import IntegrationDetailPropertiesType0
    from ..models.integration_input import IntegrationInput
    from ..models.property_descriptor import PropertyDescriptor


T = TypeVar("T", bound="IntegrationDetail")


@_attrs_define
class IntegrationDetail:
    """Full detail for an integration including properties, input parameters, and the live-evaluated schema for the current
    configuration state. Use `schema` to discover which properties are valid. Fields present in `schema` but null in
    `properties` are available to set.

        Attributes:
            uuid (str): Integration UUID
            name (str): Display name
            description (None | str | Unset): Description
            connected_system_uuid (None | str | Unset): UUID of the parent connected system
            operation_id (None | str | Unset): Operation identifier from the connected system type's operations list.
            properties (IntegrationDetailPropertiesType0 | None | Unset): Configuration property values for the current
                schema state. Keys match the `schema` array. Null value means the field is available but not yet set. Fields not
                in the current schema are absent.
            inputs (list[IntegrationInput] | None | Unset): Rule input parameters
            schema (list[PropertyDescriptor] | None | Unset): Live-evaluated flat list of PropertyDescriptors valid for the
                current configuration state. Use this to know what fields to set next.
            version_id (None | str | Unset): Version ID for optimistic concurrency control. Include in PUT/DELETE requests
                to prevent stale writes.
    """

    uuid: str
    name: str
    description: None | str | Unset = UNSET
    connected_system_uuid: None | str | Unset = UNSET
    operation_id: None | str | Unset = UNSET
    properties: IntegrationDetailPropertiesType0 | None | Unset = UNSET
    inputs: list[IntegrationInput] | None | Unset = UNSET
    schema: list[PropertyDescriptor] | None | Unset = UNSET
    version_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.integration_detail_properties_type_0 import IntegrationDetailPropertiesType0

        uuid = self.uuid

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        connected_system_uuid: None | str | Unset
        if isinstance(self.connected_system_uuid, Unset):
            connected_system_uuid = UNSET
        else:
            connected_system_uuid = self.connected_system_uuid

        operation_id: None | str | Unset
        if isinstance(self.operation_id, Unset):
            operation_id = UNSET
        else:
            operation_id = self.operation_id

        properties: dict[str, Any] | None | Unset
        if isinstance(self.properties, Unset):
            properties = UNSET
        elif isinstance(self.properties, IntegrationDetailPropertiesType0):
            properties = self.properties.to_dict()
        else:
            properties = self.properties

        inputs: list[dict[str, Any]] | None | Unset
        if isinstance(self.inputs, Unset):
            inputs = UNSET
        elif isinstance(self.inputs, list):
            inputs = []
            for inputs_type_0_item_data in self.inputs:
                inputs_type_0_item = inputs_type_0_item_data.to_dict()
                inputs.append(inputs_type_0_item)

        else:
            inputs = self.inputs

        schema: list[dict[str, Any]] | None | Unset
        if isinstance(self.schema, Unset):
            schema = UNSET
        elif isinstance(self.schema, list):
            schema = []
            for schema_type_0_item_data in self.schema:
                schema_type_0_item = schema_type_0_item_data.to_dict()
                schema.append(schema_type_0_item)

        else:
            schema = self.schema

        version_id: None | str | Unset
        if isinstance(self.version_id, Unset):
            version_id = UNSET
        else:
            version_id = self.version_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if connected_system_uuid is not UNSET:
            field_dict["connectedSystemUuid"] = connected_system_uuid
        if operation_id is not UNSET:
            field_dict["operationId"] = operation_id
        if properties is not UNSET:
            field_dict["properties"] = properties
        if inputs is not UNSET:
            field_dict["inputs"] = inputs
        if schema is not UNSET:
            field_dict["schema"] = schema
        if version_id is not UNSET:
            field_dict["versionId"] = version_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.integration_detail_properties_type_0 import IntegrationDetailPropertiesType0
        from ..models.integration_input import IntegrationInput
        from ..models.property_descriptor import PropertyDescriptor

        d = dict(src_dict)
        uuid = d.pop("uuid")

        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_connected_system_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        connected_system_uuid = _parse_connected_system_uuid(d.pop("connectedSystemUuid", UNSET))

        def _parse_operation_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        operation_id = _parse_operation_id(d.pop("operationId", UNSET))

        def _parse_properties(data: object) -> IntegrationDetailPropertiesType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                properties_type_0 = IntegrationDetailPropertiesType0.from_dict(data)

                return properties_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(IntegrationDetailPropertiesType0 | None | Unset, data)

        properties = _parse_properties(d.pop("properties", UNSET))

        def _parse_inputs(data: object) -> list[IntegrationInput] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                inputs_type_0 = []
                _inputs_type_0 = data
                for inputs_type_0_item_data in _inputs_type_0:
                    inputs_type_0_item = IntegrationInput.from_dict(inputs_type_0_item_data)

                    inputs_type_0.append(inputs_type_0_item)

                return inputs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[IntegrationInput] | None | Unset, data)

        inputs = _parse_inputs(d.pop("inputs", UNSET))

        def _parse_schema(data: object) -> list[PropertyDescriptor] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                schema_type_0 = []
                _schema_type_0 = data
                for schema_type_0_item_data in _schema_type_0:
                    schema_type_0_item = PropertyDescriptor.from_dict(schema_type_0_item_data)

                    schema_type_0.append(schema_type_0_item)

                return schema_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[PropertyDescriptor] | None | Unset, data)

        schema = _parse_schema(d.pop("schema", UNSET))

        def _parse_version_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version_id = _parse_version_id(d.pop("versionId", UNSET))

        integration_detail = cls(
            uuid=uuid,
            name=name,
            description=description,
            connected_system_uuid=connected_system_uuid,
            operation_id=operation_id,
            properties=properties,
            inputs=inputs,
            schema=schema,
            version_id=version_id,
        )

        integration_detail.additional_properties = d
        return integration_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
