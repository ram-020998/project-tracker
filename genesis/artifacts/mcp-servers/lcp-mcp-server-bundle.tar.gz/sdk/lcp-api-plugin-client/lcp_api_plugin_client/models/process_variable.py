from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.process_variable_type import ProcessVariableType
from ..types import UNSET, Unset

T = TypeVar("T", bound="ProcessVariable")


@_attrs_define
class ProcessVariable:
    """A process variable in an Appian Process Model.

    **Schema Changes (v1.0.64)**:
    - Changed `type` from string to enum with user-friendly display names
    - Removed `dataType` field (now handled internally by type enum)
    - Renamed `parameter` to `isParameter` for consistency
    - Renamed `multiple` to `isMultiple` for consistency
    - Added `isRequired` field for parameter validation

        Attributes:
            name (str): Variable name Example: orderId.
            type_ (ProcessVariableType): Variable data type in SCREAMING_SNAKE_CASE.
                Internally converted to Appian type IDs.
                 Example: INTEGER.
            description (str | Unset): Variable description (defaults to empty string) Example: Order ID to process.
            is_parameter (bool | Unset): Whether this is a process parameter (input to the process) Default: False. Example:
                True.
            is_required (bool | Unset): Whether this parameter is required (only relevant if isParameter is true) Default:
                False.
            is_multiple (bool | Unset): Whether this is an array variable (stores multiple values) Default: False.
    """

    name: str
    type_: ProcessVariableType
    description: str | Unset = UNSET
    is_parameter: bool | Unset = False
    is_required: bool | Unset = False
    is_multiple: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        type_ = self.type_.value

        description = self.description

        is_parameter = self.is_parameter

        is_required = self.is_required

        is_multiple = self.is_multiple

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type_,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if is_parameter is not UNSET:
            field_dict["isParameter"] = is_parameter
        if is_required is not UNSET:
            field_dict["isRequired"] = is_required
        if is_multiple is not UNSET:
            field_dict["isMultiple"] = is_multiple

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        type_ = ProcessVariableType(d.pop("type"))

        description = d.pop("description", UNSET)

        is_parameter = d.pop("isParameter", UNSET)

        is_required = d.pop("isRequired", UNSET)

        is_multiple = d.pop("isMultiple", UNSET)

        process_variable = cls(
            name=name,
            type_=type_,
            description=description,
            is_parameter=is_parameter,
            is_required=is_required,
            is_multiple=is_multiple,
        )

        process_variable.additional_properties = d
        return process_variable

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
