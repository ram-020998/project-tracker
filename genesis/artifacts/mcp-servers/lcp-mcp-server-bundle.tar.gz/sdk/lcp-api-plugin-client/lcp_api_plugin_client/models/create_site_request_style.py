from enum import Enum


class CreateSiteRequestStyle(str, Enum):
    HELIUM = "HELIUM"
    MERCURY = "MERCURY"
    OXYGEN = "OXYGEN"

    def __str__(self) -> str:
        return str(self.value)
