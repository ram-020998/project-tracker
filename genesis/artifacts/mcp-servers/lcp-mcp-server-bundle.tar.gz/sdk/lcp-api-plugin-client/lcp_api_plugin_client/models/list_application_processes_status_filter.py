from enum import Enum


class ListApplicationProcessesStatusFilter(str, Enum):
    CANCELLED = "CANCELLED"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    RUNNING = "RUNNING"

    def __str__(self) -> str:
        return str(self.value)
