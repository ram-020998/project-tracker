from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_process_model_request_description_type_1 import CreateProcessModelRequestDescriptionType1
    from ..models.create_process_model_request_name_type_1 import CreateProcessModelRequestNameType1
    from ..models.create_process_model_request_start_form_type_1 import CreateProcessModelRequestStartFormType1
    from ..models.form_config import FormConfig
    from ..models.process_model_lane import ProcessModelLane
    from ..models.process_model_node_input import ProcessModelNodeInput
    from ..models.process_model_variable import ProcessModelVariable


T = TypeVar("T", bound="CreateProcessModelRequest")


@_attrs_define
class CreateProcessModelRequest:
    """Request body for creating a new process model.

    Nodes use activity class schema IDs (schemaId) as the `type` field.
    See `ProcessModelNodeInput` for the full node schema and supported types.

        Attributes:
            name (CreateProcessModelRequestNameType1 | str): Process model name. Can be either a simple string (uses site
                primary locale) or a locale map for multi-language support.
            description (CreateProcessModelRequestDescriptionType1 | str): Process model description (required, can be empty
                string). Can be either a simple string (uses site primary locale) or a locale map for multi-language support.
            parent_folder_uuid (str): UUID of the process model folder (required for creation) Example:
                _g-0000ef47-88c0-8000-ffb7-7f0000014e7a_703.
            error_alert_group_name (str): Name of the group that receives error alerts for this process model (required for
                creation) Example: APP Administrators.
            nodes (list[ProcessModelNodeInput]): Process model nodes (required, minimum 2 nodes)
            app_uuid (str | Unset): Application UUID (optional). When provided, the process model is automatically added to
                the application.
                 Example: _a-0000ef29-ff98-8000-9bc1-011c48011c48_37560.
            start_form (CreateProcessModelRequestStartFormType1 | FormConfig | None | Unset): Start form configuration. Same
                shape as task form (FormConfig).

                **INPUT**: Can be a simple FormConfig (stored in site's primary locale) OR a map of locale codes to FormConfig
                objects for multi-locale support.
                **OUTPUT**: Always returns as a map of locale codes to FormConfig objects, showing all configured locales.
            process_variables (list[ProcessModelVariable] | Unset): Process variables with simplified string-based types
                (optional)
            lanes (list[ProcessModelLane] | None | Unset): List of swimlanes for visual role-based organization. Array order
                is visual
                order (top-to-bottom for horizontal, left-to-right for vertical). Nodes
                reference their lane by the lane's index in this array. Optional — omit or
                pass empty array for process models without lanes.
    """

    name: CreateProcessModelRequestNameType1 | str
    description: CreateProcessModelRequestDescriptionType1 | str
    parent_folder_uuid: str
    error_alert_group_name: str
    nodes: list[ProcessModelNodeInput]
    app_uuid: str | Unset = UNSET
    start_form: CreateProcessModelRequestStartFormType1 | FormConfig | None | Unset = UNSET
    process_variables: list[ProcessModelVariable] | Unset = UNSET
    lanes: list[ProcessModelLane] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.create_process_model_request_description_type_1 import CreateProcessModelRequestDescriptionType1
        from ..models.create_process_model_request_name_type_1 import CreateProcessModelRequestNameType1
        from ..models.create_process_model_request_start_form_type_1 import CreateProcessModelRequestStartFormType1
        from ..models.form_config import FormConfig

        name: dict[str, Any] | str
        if isinstance(self.name, CreateProcessModelRequestNameType1):
            name = self.name.to_dict()
        else:
            name = self.name

        description: dict[str, Any] | str
        if isinstance(self.description, CreateProcessModelRequestDescriptionType1):
            description = self.description.to_dict()
        else:
            description = self.description

        parent_folder_uuid = self.parent_folder_uuid

        error_alert_group_name = self.error_alert_group_name

        nodes = []
        for nodes_item_data in self.nodes:
            nodes_item = nodes_item_data.to_dict()
            nodes.append(nodes_item)

        app_uuid = self.app_uuid

        start_form: dict[str, Any] | None | Unset
        if isinstance(self.start_form, Unset):
            start_form = UNSET
        elif isinstance(self.start_form, FormConfig):
            start_form = self.start_form.to_dict()
        elif isinstance(self.start_form, CreateProcessModelRequestStartFormType1):
            start_form = self.start_form.to_dict()
        else:
            start_form = self.start_form

        process_variables: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.process_variables, Unset):
            process_variables = []
            for process_variables_item_data in self.process_variables:
                process_variables_item = process_variables_item_data.to_dict()
                process_variables.append(process_variables_item)

        lanes: list[dict[str, Any]] | None | Unset
        if isinstance(self.lanes, Unset):
            lanes = UNSET
        elif isinstance(self.lanes, list):
            lanes = []
            for lanes_type_0_item_data in self.lanes:
                lanes_type_0_item = lanes_type_0_item_data.to_dict()
                lanes.append(lanes_type_0_item)

        else:
            lanes = self.lanes

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "description": description,
                "parentFolderUuid": parent_folder_uuid,
                "errorAlertGroupName": error_alert_group_name,
                "nodes": nodes,
            }
        )
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid
        if start_form is not UNSET:
            field_dict["startForm"] = start_form
        if process_variables is not UNSET:
            field_dict["processVariables"] = process_variables
        if lanes is not UNSET:
            field_dict["lanes"] = lanes

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_process_model_request_description_type_1 import CreateProcessModelRequestDescriptionType1
        from ..models.create_process_model_request_name_type_1 import CreateProcessModelRequestNameType1
        from ..models.create_process_model_request_start_form_type_1 import CreateProcessModelRequestStartFormType1
        from ..models.form_config import FormConfig
        from ..models.process_model_lane import ProcessModelLane
        from ..models.process_model_node_input import ProcessModelNodeInput
        from ..models.process_model_variable import ProcessModelVariable

        d = dict(src_dict)

        def _parse_name(data: object) -> CreateProcessModelRequestNameType1 | str:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                name_type_1 = CreateProcessModelRequestNameType1.from_dict(data)

                return name_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateProcessModelRequestNameType1 | str, data)

        name = _parse_name(d.pop("name"))

        def _parse_description(data: object) -> CreateProcessModelRequestDescriptionType1 | str:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                description_type_1 = CreateProcessModelRequestDescriptionType1.from_dict(data)

                return description_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateProcessModelRequestDescriptionType1 | str, data)

        description = _parse_description(d.pop("description"))

        parent_folder_uuid = d.pop("parentFolderUuid")

        error_alert_group_name = d.pop("errorAlertGroupName")

        nodes = []
        _nodes = d.pop("nodes")
        for nodes_item_data in _nodes:
            nodes_item = ProcessModelNodeInput.from_dict(nodes_item_data)

            nodes.append(nodes_item)

        app_uuid = d.pop("appUuid", UNSET)

        def _parse_start_form(data: object) -> CreateProcessModelRequestStartFormType1 | FormConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                start_form_type_0 = FormConfig.from_dict(data)

                return start_form_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                start_form_type_1 = CreateProcessModelRequestStartFormType1.from_dict(data)

                return start_form_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateProcessModelRequestStartFormType1 | FormConfig | None | Unset, data)

        start_form = _parse_start_form(d.pop("startForm", UNSET))

        _process_variables = d.pop("processVariables", UNSET)
        process_variables: list[ProcessModelVariable] | Unset = UNSET
        if _process_variables is not UNSET:
            process_variables = []
            for process_variables_item_data in _process_variables:
                process_variables_item = ProcessModelVariable.from_dict(process_variables_item_data)

                process_variables.append(process_variables_item)

        def _parse_lanes(data: object) -> list[ProcessModelLane] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                lanes_type_0 = []
                _lanes_type_0 = data
                for lanes_type_0_item_data in _lanes_type_0:
                    lanes_type_0_item = ProcessModelLane.from_dict(lanes_type_0_item_data)

                    lanes_type_0.append(lanes_type_0_item)

                return lanes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ProcessModelLane] | None | Unset, data)

        lanes = _parse_lanes(d.pop("lanes", UNSET))

        create_process_model_request = cls(
            name=name,
            description=description,
            parent_folder_uuid=parent_folder_uuid,
            error_alert_group_name=error_alert_group_name,
            nodes=nodes,
            app_uuid=app_uuid,
            start_form=start_form,
            process_variables=process_variables,
            lanes=lanes,
        )

        create_process_model_request.additional_properties = d
        return create_process_model_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
