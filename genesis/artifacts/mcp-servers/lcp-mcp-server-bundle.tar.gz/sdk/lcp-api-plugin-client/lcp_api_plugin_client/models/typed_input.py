from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="TypedInput")


@_attrs_define
class TypedInput:
    """Input definition for expression rule and interface inputs.

    Attributes:
        name (str): Input name Example: customerId.
        type_ (str): Appian type reference. Built-in types by name (e.g., "Text", "Number (Integer)", "Boolean"). For
            developer-defined types, use the typeReference from the record type response.
             Example: Text.
        multiple (bool | Unset): Whether this input accepts a list of values. Defaults to false. Default: False.
        description (None | str | Unset): Optional description of this input. Example: The customer's unique identifier.
    """

    name: str
    type_: str
    multiple: bool | Unset = False
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        type_ = self.type_

        multiple = self.multiple

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type_,
            }
        )
        if multiple is not UNSET:
            field_dict["multiple"] = multiple
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        type_ = d.pop("type")

        multiple = d.pop("multiple", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        typed_input = cls(
            name=name,
            type_=type_,
            multiple=multiple,
            description=description,
        )

        typed_input.additional_properties = d
        return typed_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
