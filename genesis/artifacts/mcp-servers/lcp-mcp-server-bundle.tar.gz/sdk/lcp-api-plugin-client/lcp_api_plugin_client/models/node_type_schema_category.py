from enum import Enum


class NodeTypeSchemaCategory(str, Enum):
    ACTIVITY = "activity"
    EVENT = "event"
    GATEWAY = "gateway"

    def __str__(self) -> str:
        return str(self.value)
