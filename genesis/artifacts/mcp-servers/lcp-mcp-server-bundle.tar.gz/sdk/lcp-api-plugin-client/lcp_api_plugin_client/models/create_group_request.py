from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateGroupRequest")


@_attrs_define
class CreateGroupRequest:
    """Request body for creating a new group

    Attributes:
        name (str): The name of the group to create Example: APP_Reviewers.
        description (str | Unset): A text description of the group's purpose (optional) Example: Reviewer group for the
            application.
        parent_group_name (str | Unset): Name of an existing parent group to add this group as a member of (optional)
            Example: APP_Users.
        app_uuid (str | Unset): UUID of the application to add this group to (optional). When provided, the group is
            created and automatically added to the application. Example: a1b2c3d4-e5f6-7890-abcd-ef1234567890.
    """

    name: str
    description: str | Unset = UNSET
    parent_group_name: str | Unset = UNSET
    app_uuid: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        description = self.description

        parent_group_name = self.parent_group_name

        app_uuid = self.app_uuid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if parent_group_name is not UNSET:
            field_dict["parentGroupName"] = parent_group_name
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        description = d.pop("description", UNSET)

        parent_group_name = d.pop("parentGroupName", UNSET)

        app_uuid = d.pop("appUuid", UNSET)

        create_group_request = cls(
            name=name,
            description=description,
            parent_group_name=parent_group_name,
            app_uuid=app_uuid,
        )

        create_group_request.additional_properties = d
        return create_group_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
