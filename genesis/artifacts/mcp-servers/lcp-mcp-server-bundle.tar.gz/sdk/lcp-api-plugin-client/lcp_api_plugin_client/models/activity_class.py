from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.activity_parameter import ActivityParameter


T = TypeVar("T", bound="ActivityClass")


@_attrs_define
class ActivityClass:
    """Activity class configuration for a process node

    Attributes:
        local_id (str | Unset): Local ID of the activity class Example: com.appiancorp.ps.node.UserInputTask.
        unattended (bool | Unset): Whether this is an unattended (automated) activity
        parameters (list[ActivityParameter] | Unset): List of activity parameters
        form_expression (None | str | Unset): The SAIL expression for the form (if this is a form node) Example:
            a!formLayout(label: "Review Order", contents: {...}).
    """

    local_id: str | Unset = UNSET
    unattended: bool | Unset = UNSET
    parameters: list[ActivityParameter] | Unset = UNSET
    form_expression: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        local_id = self.local_id

        unattended = self.unattended

        parameters: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.parameters, Unset):
            parameters = []
            for parameters_item_data in self.parameters:
                parameters_item = parameters_item_data.to_dict()
                parameters.append(parameters_item)

        form_expression: None | str | Unset
        if isinstance(self.form_expression, Unset):
            form_expression = UNSET
        else:
            form_expression = self.form_expression

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if local_id is not UNSET:
            field_dict["localId"] = local_id
        if unattended is not UNSET:
            field_dict["unattended"] = unattended
        if parameters is not UNSET:
            field_dict["parameters"] = parameters
        if form_expression is not UNSET:
            field_dict["formExpression"] = form_expression

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.activity_parameter import ActivityParameter

        d = dict(src_dict)
        local_id = d.pop("localId", UNSET)

        unattended = d.pop("unattended", UNSET)

        _parameters = d.pop("parameters", UNSET)
        parameters: list[ActivityParameter] | Unset = UNSET
        if _parameters is not UNSET:
            parameters = []
            for parameters_item_data in _parameters:
                parameters_item = ActivityParameter.from_dict(parameters_item_data)

                parameters.append(parameters_item)

        def _parse_form_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        form_expression = _parse_form_expression(d.pop("formExpression", UNSET))

        activity_class = cls(
            local_id=local_id,
            unattended=unattended,
            parameters=parameters,
            form_expression=form_expression,
        )

        activity_class.additional_properties = d
        return activity_class

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
