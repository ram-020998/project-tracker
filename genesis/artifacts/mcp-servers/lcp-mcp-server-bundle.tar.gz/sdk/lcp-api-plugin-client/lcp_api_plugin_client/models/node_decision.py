from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.gateway_condition import GatewayCondition


T = TypeVar("T", bound="NodeDecision")


@_attrs_define
class NodeDecision:
    """Decision tab configuration for gateway nodes (XOR, OR).

    Attributes:
        conditions (list[GatewayCondition] | Unset): Ordered list of condition rules evaluated top-to-bottom.
        default_path (int | Unset): Target node ID for the default branch (taken when no condition matches). Example: 4.
    """

    conditions: list[GatewayCondition] | Unset = UNSET
    default_path: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        conditions: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.conditions, Unset):
            conditions = []
            for conditions_item_data in self.conditions:
                conditions_item = conditions_item_data.to_dict()
                conditions.append(conditions_item)

        default_path = self.default_path

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if conditions is not UNSET:
            field_dict["conditions"] = conditions
        if default_path is not UNSET:
            field_dict["defaultPath"] = default_path

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.gateway_condition import GatewayCondition

        d = dict(src_dict)
        _conditions = d.pop("conditions", UNSET)
        conditions: list[GatewayCondition] | Unset = UNSET
        if _conditions is not UNSET:
            conditions = []
            for conditions_item_data in _conditions:
                conditions_item = GatewayCondition.from_dict(conditions_item_data)

                conditions.append(conditions_item)

        default_path = d.pop("defaultPath", UNSET)

        node_decision = cls(
            conditions=conditions,
            default_path=default_path,
        )

        node_decision.additional_properties = d
        return node_decision

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
