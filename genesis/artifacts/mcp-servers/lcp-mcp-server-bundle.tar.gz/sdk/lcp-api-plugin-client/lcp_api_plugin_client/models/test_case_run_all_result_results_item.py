from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.test_case_run_all_result_results_item_test_errors_item import (
        TestCaseRunAllResultResultsItemTestErrorsItem,
    )


T = TypeVar("T", bound="TestCaseRunAllResultResultsItem")


@_attrs_define
class TestCaseRunAllResultResultsItem:
    """
    Attributes:
        test_case_uuid (str | Unset):
        name (str | Unset):
        success (bool | Unset):
        output (None | str | Unset):
        duration_ms (float | None | Unset):
        test_errors (list[TestCaseRunAllResultResultsItemTestErrorsItem] | Unset):
        error (None | str | Unset):
    """

    test_case_uuid: str | Unset = UNSET
    name: str | Unset = UNSET
    success: bool | Unset = UNSET
    output: None | str | Unset = UNSET
    duration_ms: float | None | Unset = UNSET
    test_errors: list[TestCaseRunAllResultResultsItemTestErrorsItem] | Unset = UNSET
    error: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        test_case_uuid = self.test_case_uuid

        name = self.name

        success = self.success

        output: None | str | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        else:
            output = self.output

        duration_ms: float | None | Unset
        if isinstance(self.duration_ms, Unset):
            duration_ms = UNSET
        else:
            duration_ms = self.duration_ms

        test_errors: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.test_errors, Unset):
            test_errors = []
            for test_errors_item_data in self.test_errors:
                test_errors_item = test_errors_item_data.to_dict()
                test_errors.append(test_errors_item)

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if test_case_uuid is not UNSET:
            field_dict["testCaseUuid"] = test_case_uuid
        if name is not UNSET:
            field_dict["name"] = name
        if success is not UNSET:
            field_dict["success"] = success
        if output is not UNSET:
            field_dict["output"] = output
        if duration_ms is not UNSET:
            field_dict["durationMs"] = duration_ms
        if test_errors is not UNSET:
            field_dict["testErrors"] = test_errors
        if error is not UNSET:
            field_dict["error"] = error

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.test_case_run_all_result_results_item_test_errors_item import (
            TestCaseRunAllResultResultsItemTestErrorsItem,
        )

        d = dict(src_dict)
        test_case_uuid = d.pop("testCaseUuid", UNSET)

        name = d.pop("name", UNSET)

        success = d.pop("success", UNSET)

        def _parse_output(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        output = _parse_output(d.pop("output", UNSET))

        def _parse_duration_ms(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        duration_ms = _parse_duration_ms(d.pop("durationMs", UNSET))

        _test_errors = d.pop("testErrors", UNSET)
        test_errors: list[TestCaseRunAllResultResultsItemTestErrorsItem] | Unset = UNSET
        if _test_errors is not UNSET:
            test_errors = []
            for test_errors_item_data in _test_errors:
                test_errors_item = TestCaseRunAllResultResultsItemTestErrorsItem.from_dict(test_errors_item_data)

                test_errors.append(test_errors_item)

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        test_case_run_all_result_results_item = cls(
            test_case_uuid=test_case_uuid,
            name=name,
            success=success,
            output=output,
            duration_ms=duration_ms,
            test_errors=test_errors,
            error=error,
        )

        test_case_run_all_result_results_item.additional_properties = d
        return test_case_run_all_result_results_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
