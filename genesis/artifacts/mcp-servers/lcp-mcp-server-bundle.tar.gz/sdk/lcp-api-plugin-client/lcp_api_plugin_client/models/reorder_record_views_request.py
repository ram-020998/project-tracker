from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ReorderRecordViewsRequest")


@_attrs_define
class ReorderRecordViewsRequest:
    """
    Attributes:
        url_stubs (list[str]): Ordered list of all view urlStubs
        version_id (str | Unset): Current version ID for optimistic concurrency control
    """

    url_stubs: list[str]
    version_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        url_stubs = self.url_stubs

        version_id = self.version_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "urlStubs": url_stubs,
            }
        )
        if version_id is not UNSET:
            field_dict["versionId"] = version_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        url_stubs = cast(list[str], d.pop("urlStubs"))

        version_id = d.pop("versionId", UNSET)

        reorder_record_views_request = cls(
            url_stubs=url_stubs,
            version_id=version_id,
        )

        reorder_record_views_request.additional_properties = d
        return reorder_record_views_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
