from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.web_api_request_body_type import WebApiRequestBodyType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.rest_metadata_type_0 import RestMetadataType0


T = TypeVar("T", bound="WebAPIDesignObject")


@_attrs_define
class WebAPIDesignObject:
    """A Web API is an HTTP endpoint definition that developers create to expose
    application logic as RESTful services.

        Attributes:
            uuid (str | Unset): Appian UUID
            name (str | Unset):
            description (None | str | Unset):
            expression (None | str | Unset): SAIL expression (included when expanded)
            url_alias (str | Unset): URL path segment for the Web API
            http_method (str | Unset): HTTP method (GET, POST, PUT, DELETE, etc.)
            request_body_type (WebApiRequestBodyType | Unset): How the Web API handles request body content
            is_public (bool | Unset):
            logging_enabled (bool | Unset):
            field_rest (None | RestMetadataType0 | Unset): Response metadata including the Designer URL for this object.
                Present on get, create, and update responses for design objects.
    """

    uuid: str | Unset = UNSET
    name: str | Unset = UNSET
    description: None | str | Unset = UNSET
    expression: None | str | Unset = UNSET
    url_alias: str | Unset = UNSET
    http_method: str | Unset = UNSET
    request_body_type: WebApiRequestBodyType | Unset = UNSET
    is_public: bool | Unset = UNSET
    logging_enabled: bool | Unset = UNSET
    field_rest: None | RestMetadataType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.rest_metadata_type_0 import RestMetadataType0

        uuid = self.uuid

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        expression: None | str | Unset
        if isinstance(self.expression, Unset):
            expression = UNSET
        else:
            expression = self.expression

        url_alias = self.url_alias

        http_method = self.http_method

        request_body_type: str | Unset = UNSET
        if not isinstance(self.request_body_type, Unset):
            request_body_type = self.request_body_type.value

        is_public = self.is_public

        logging_enabled = self.logging_enabled

        field_rest: dict[str, Any] | None | Unset
        if isinstance(self.field_rest, Unset):
            field_rest = UNSET
        elif isinstance(self.field_rest, RestMetadataType0):
            field_rest = self.field_rest.to_dict()
        else:
            field_rest = self.field_rest

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if expression is not UNSET:
            field_dict["expression"] = expression
        if url_alias is not UNSET:
            field_dict["urlAlias"] = url_alias
        if http_method is not UNSET:
            field_dict["httpMethod"] = http_method
        if request_body_type is not UNSET:
            field_dict["requestBodyType"] = request_body_type
        if is_public is not UNSET:
            field_dict["isPublic"] = is_public
        if logging_enabled is not UNSET:
            field_dict["loggingEnabled"] = logging_enabled
        if field_rest is not UNSET:
            field_dict["_rest"] = field_rest

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rest_metadata_type_0 import RestMetadataType0

        d = dict(src_dict)
        uuid = d.pop("uuid", UNSET)

        name = d.pop("name", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expression = _parse_expression(d.pop("expression", UNSET))

        url_alias = d.pop("urlAlias", UNSET)

        http_method = d.pop("httpMethod", UNSET)

        _request_body_type = d.pop("requestBodyType", UNSET)
        request_body_type: WebApiRequestBodyType | Unset
        if isinstance(_request_body_type, Unset):
            request_body_type = UNSET
        else:
            request_body_type = WebApiRequestBodyType(_request_body_type)

        is_public = d.pop("isPublic", UNSET)

        logging_enabled = d.pop("loggingEnabled", UNSET)

        def _parse_field_rest(data: object) -> None | RestMetadataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_rest_metadata_type_0 = RestMetadataType0.from_dict(data)

                return componentsschemas_rest_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RestMetadataType0 | Unset, data)

        field_rest = _parse_field_rest(d.pop("_rest", UNSET))

        web_api_design_object = cls(
            uuid=uuid,
            name=name,
            description=description,
            expression=expression,
            url_alias=url_alias,
            http_method=http_method,
            request_body_type=request_body_type,
            is_public=is_public,
            logging_enabled=logging_enabled,
            field_rest=field_rest,
        )

        web_api_design_object.additional_properties = d
        return web_api_design_object

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
