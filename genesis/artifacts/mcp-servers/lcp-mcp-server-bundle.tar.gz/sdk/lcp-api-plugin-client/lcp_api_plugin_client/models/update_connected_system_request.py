from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.update_connected_system_request_properties_type_0 import UpdateConnectedSystemRequestPropertiesType0


T = TypeVar("T", bound="UpdateConnectedSystemRequest")


@_attrs_define
class UpdateConnectedSystemRequest:
    """Request body for updating a connected system. Only provided fields are changed.

    Attributes:
        version_id (str | Unset): Version ID for optimistic concurrency control. If provided, validates against current
            version.
        name (str | Unset): Display name
        description (None | str | Unset): Description
        properties (None | Unset | UpdateConnectedSystemRequestPropertiesType0): Configuration properties to update
            (validated against the type schema)
    """

    version_id: str | Unset = UNSET
    name: str | Unset = UNSET
    description: None | str | Unset = UNSET
    properties: None | Unset | UpdateConnectedSystemRequestPropertiesType0 = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.update_connected_system_request_properties_type_0 import (
            UpdateConnectedSystemRequestPropertiesType0,
        )

        version_id = self.version_id

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        properties: dict[str, Any] | None | Unset
        if isinstance(self.properties, Unset):
            properties = UNSET
        elif isinstance(self.properties, UpdateConnectedSystemRequestPropertiesType0):
            properties = self.properties.to_dict()
        else:
            properties = self.properties

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if properties is not UNSET:
            field_dict["properties"] = properties

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.update_connected_system_request_properties_type_0 import (
            UpdateConnectedSystemRequestPropertiesType0,
        )

        d = dict(src_dict)
        version_id = d.pop("versionId", UNSET)

        name = d.pop("name", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_properties(data: object) -> None | Unset | UpdateConnectedSystemRequestPropertiesType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                properties_type_0 = UpdateConnectedSystemRequestPropertiesType0.from_dict(data)

                return properties_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UpdateConnectedSystemRequestPropertiesType0, data)

        properties = _parse_properties(d.pop("properties", UNSET))

        update_connected_system_request = cls(
            version_id=version_id,
            name=name,
            description=description,
            properties=properties,
        )

        update_connected_system_request.additional_properties = d
        return update_connected_system_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
