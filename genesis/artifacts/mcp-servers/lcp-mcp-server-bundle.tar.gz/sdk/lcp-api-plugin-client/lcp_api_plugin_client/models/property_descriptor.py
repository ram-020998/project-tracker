from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="PropertyDescriptor")


@_attrs_define
class PropertyDescriptor:
    """Schema property descriptor for connected system or integration configuration.

    Attributes:
        key (str): Property key used in the properties map Example: baseUrl.
        label (str): Human-readable label Example: Base URL.
        type_ (str): Property data type (TEXT, NUMBER, BOOLEAN, ENCRYPTED_TEXT, etc.) Example: TEXT.
        required (bool | Unset): Whether this property is required Default: False. Example: True.
        is_credential (bool | Unset): Whether this property holds a credential value (values are masked on read)
            Default: False.
        allowed_values (list[str] | None | Unset): Allowed values for this property (null if unconstrained)
        is_expressionable (bool | Unset): Whether this property accepts SAIL expressions
        description (None | str | Unset): Detailed description of the property's purpose and usage Example: The base URL
            for all requests made by integrations using this connected system..
        instruction_text (None | str | Unset): Instructional text shown to the user when configuring this property
        placeholder (None | str | Unset): Placeholder text shown in the input field when empty Example:
            https://api.example.com.
    """

    key: str
    label: str
    type_: str
    required: bool | Unset = False
    is_credential: bool | Unset = False
    allowed_values: list[str] | None | Unset = UNSET
    is_expressionable: bool | Unset = UNSET
    description: None | str | Unset = UNSET
    instruction_text: None | str | Unset = UNSET
    placeholder: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        key = self.key

        label = self.label

        type_ = self.type_

        required = self.required

        is_credential = self.is_credential

        allowed_values: list[str] | None | Unset
        if isinstance(self.allowed_values, Unset):
            allowed_values = UNSET
        elif isinstance(self.allowed_values, list):
            allowed_values = self.allowed_values

        else:
            allowed_values = self.allowed_values

        is_expressionable = self.is_expressionable

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        instruction_text: None | str | Unset
        if isinstance(self.instruction_text, Unset):
            instruction_text = UNSET
        else:
            instruction_text = self.instruction_text

        placeholder: None | str | Unset
        if isinstance(self.placeholder, Unset):
            placeholder = UNSET
        else:
            placeholder = self.placeholder

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "key": key,
                "label": label,
                "type": type_,
            }
        )
        if required is not UNSET:
            field_dict["required"] = required
        if is_credential is not UNSET:
            field_dict["isCredential"] = is_credential
        if allowed_values is not UNSET:
            field_dict["allowedValues"] = allowed_values
        if is_expressionable is not UNSET:
            field_dict["isExpressionable"] = is_expressionable
        if description is not UNSET:
            field_dict["description"] = description
        if instruction_text is not UNSET:
            field_dict["instructionText"] = instruction_text
        if placeholder is not UNSET:
            field_dict["placeholder"] = placeholder

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        key = d.pop("key")

        label = d.pop("label")

        type_ = d.pop("type")

        required = d.pop("required", UNSET)

        is_credential = d.pop("isCredential", UNSET)

        def _parse_allowed_values(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                allowed_values_type_0 = cast(list[str], data)

                return allowed_values_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        allowed_values = _parse_allowed_values(d.pop("allowedValues", UNSET))

        is_expressionable = d.pop("isExpressionable", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_instruction_text(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        instruction_text = _parse_instruction_text(d.pop("instructionText", UNSET))

        def _parse_placeholder(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        placeholder = _parse_placeholder(d.pop("placeholder", UNSET))

        property_descriptor = cls(
            key=key,
            label=label,
            type_=type_,
            required=required,
            is_credential=is_credential,
            allowed_values=allowed_values,
            is_expressionable=is_expressionable,
            description=description,
            instruction_text=instruction_text,
            placeholder=placeholder,
        )

        property_descriptor.additional_properties = d
        return property_descriptor

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
