from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.form_config import FormConfig
    from ..models.process_model_lane import ProcessModelLane
    from ..models.process_model_node_input import ProcessModelNodeInput
    from ..models.process_model_variable import ProcessModelVariable
    from ..models.rest_metadata_type_0 import RestMetadataType0


T = TypeVar("T", bound="ProcessModel")


@_attrs_define
class ProcessModel:
    """An Appian Process Model design object.

    Process model responses include three fields:
    - uuid: The Appian UUID of the process model
    - name: The process model name
    - description: The process model description

        Attributes:
            uuid (str): Appian UUID for the process model in Appian's custom format.
                This is NOT a standard UUID and cannot be parsed by standard UUID libraries.
                 Example: _a-0000ef01-4394-8000-fc94-7f0000014e7a_12345.
            name (str): Process model name Example: Order Approval Process.
            description (str): Process model description (empty string if not provided) Example: Handles order approval
                workflow.
            parent_folder_uuid (None | str | Unset): Parent folder UUID. Required for creation requests (POST). Returned in
                GET and PUT responses when the folder is accessible.
            error_alert_group_name (None | str | Unset): Error alert group name. Required for creation requests (POST), null
                in GET responses.
            start_form (FormConfig | None | Unset): Start form configuration. Null if no start form is configured.
            process_variables (list[ProcessModelVariable] | None | Unset): List of process variables defined in the process
                model. Each variable includes name, type (SCREAMING_SNAKE_CASE enum: TEXT, INTEGER, DECIMAL, DATE, DATETIME,
                BOOLEAN, USERNAME, GROUP, DOCUMENT, RECORD_TYPE), and flags for isParameter and isRequired.
            nodes (list[ProcessModelNodeInput] | None | Unset): List of process nodes (activities, gateways, events) in the
                process model.
                Each node includes a `typeName` field (read-only) with the static display name.
            lanes (list[ProcessModelLane] | None | Unset): List of swimlanes for visual role-based organization. Array order
                is visual
                order (top-to-bottom for horizontal, left-to-right for vertical). Nodes
                reference their lane by the lane's index in this array. Optional — omit or
                pass empty array for process models without lanes.
            version_id (None | str | Unset): Version ID for optimistic concurrency control. Include in PUT/DELETE requests
                to prevent stale writes.
            field_rest (None | RestMetadataType0 | Unset): Response metadata including the Designer URL for this object.
                Present on get, create, and update responses for design objects.
    """

    uuid: str
    name: str
    description: str
    parent_folder_uuid: None | str | Unset = UNSET
    error_alert_group_name: None | str | Unset = UNSET
    start_form: FormConfig | None | Unset = UNSET
    process_variables: list[ProcessModelVariable] | None | Unset = UNSET
    nodes: list[ProcessModelNodeInput] | None | Unset = UNSET
    lanes: list[ProcessModelLane] | None | Unset = UNSET
    version_id: None | str | Unset = UNSET
    field_rest: None | RestMetadataType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.form_config import FormConfig
        from ..models.rest_metadata_type_0 import RestMetadataType0

        uuid = self.uuid

        name = self.name

        description = self.description

        parent_folder_uuid: None | str | Unset
        if isinstance(self.parent_folder_uuid, Unset):
            parent_folder_uuid = UNSET
        else:
            parent_folder_uuid = self.parent_folder_uuid

        error_alert_group_name: None | str | Unset
        if isinstance(self.error_alert_group_name, Unset):
            error_alert_group_name = UNSET
        else:
            error_alert_group_name = self.error_alert_group_name

        start_form: dict[str, Any] | None | Unset
        if isinstance(self.start_form, Unset):
            start_form = UNSET
        elif isinstance(self.start_form, FormConfig):
            start_form = self.start_form.to_dict()
        else:
            start_form = self.start_form

        process_variables: list[dict[str, Any]] | None | Unset
        if isinstance(self.process_variables, Unset):
            process_variables = UNSET
        elif isinstance(self.process_variables, list):
            process_variables = []
            for process_variables_type_0_item_data in self.process_variables:
                process_variables_type_0_item = process_variables_type_0_item_data.to_dict()
                process_variables.append(process_variables_type_0_item)

        else:
            process_variables = self.process_variables

        nodes: list[dict[str, Any]] | None | Unset
        if isinstance(self.nodes, Unset):
            nodes = UNSET
        elif isinstance(self.nodes, list):
            nodes = []
            for nodes_type_0_item_data in self.nodes:
                nodes_type_0_item = nodes_type_0_item_data.to_dict()
                nodes.append(nodes_type_0_item)

        else:
            nodes = self.nodes

        lanes: list[dict[str, Any]] | None | Unset
        if isinstance(self.lanes, Unset):
            lanes = UNSET
        elif isinstance(self.lanes, list):
            lanes = []
            for lanes_type_0_item_data in self.lanes:
                lanes_type_0_item = lanes_type_0_item_data.to_dict()
                lanes.append(lanes_type_0_item)

        else:
            lanes = self.lanes

        version_id: None | str | Unset
        if isinstance(self.version_id, Unset):
            version_id = UNSET
        else:
            version_id = self.version_id

        field_rest: dict[str, Any] | None | Unset
        if isinstance(self.field_rest, Unset):
            field_rest = UNSET
        elif isinstance(self.field_rest, RestMetadataType0):
            field_rest = self.field_rest.to_dict()
        else:
            field_rest = self.field_rest

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "name": name,
                "description": description,
            }
        )
        if parent_folder_uuid is not UNSET:
            field_dict["parentFolderUuid"] = parent_folder_uuid
        if error_alert_group_name is not UNSET:
            field_dict["errorAlertGroupName"] = error_alert_group_name
        if start_form is not UNSET:
            field_dict["startForm"] = start_form
        if process_variables is not UNSET:
            field_dict["processVariables"] = process_variables
        if nodes is not UNSET:
            field_dict["nodes"] = nodes
        if lanes is not UNSET:
            field_dict["lanes"] = lanes
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if field_rest is not UNSET:
            field_dict["_rest"] = field_rest

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.form_config import FormConfig
        from ..models.process_model_lane import ProcessModelLane
        from ..models.process_model_node_input import ProcessModelNodeInput
        from ..models.process_model_variable import ProcessModelVariable
        from ..models.rest_metadata_type_0 import RestMetadataType0

        d = dict(src_dict)
        uuid = d.pop("uuid")

        name = d.pop("name")

        description = d.pop("description")

        def _parse_parent_folder_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_folder_uuid = _parse_parent_folder_uuid(d.pop("parentFolderUuid", UNSET))

        def _parse_error_alert_group_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_alert_group_name = _parse_error_alert_group_name(d.pop("errorAlertGroupName", UNSET))

        def _parse_start_form(data: object) -> FormConfig | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                start_form_type_1 = FormConfig.from_dict(data)

                return start_form_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(FormConfig | None | Unset, data)

        start_form = _parse_start_form(d.pop("startForm", UNSET))

        def _parse_process_variables(data: object) -> list[ProcessModelVariable] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                process_variables_type_0 = []
                _process_variables_type_0 = data
                for process_variables_type_0_item_data in _process_variables_type_0:
                    process_variables_type_0_item = ProcessModelVariable.from_dict(process_variables_type_0_item_data)

                    process_variables_type_0.append(process_variables_type_0_item)

                return process_variables_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ProcessModelVariable] | None | Unset, data)

        process_variables = _parse_process_variables(d.pop("processVariables", UNSET))

        def _parse_nodes(data: object) -> list[ProcessModelNodeInput] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                nodes_type_0 = []
                _nodes_type_0 = data
                for nodes_type_0_item_data in _nodes_type_0:
                    nodes_type_0_item = ProcessModelNodeInput.from_dict(nodes_type_0_item_data)

                    nodes_type_0.append(nodes_type_0_item)

                return nodes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ProcessModelNodeInput] | None | Unset, data)

        nodes = _parse_nodes(d.pop("nodes", UNSET))

        def _parse_lanes(data: object) -> list[ProcessModelLane] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                lanes_type_0 = []
                _lanes_type_0 = data
                for lanes_type_0_item_data in _lanes_type_0:
                    lanes_type_0_item = ProcessModelLane.from_dict(lanes_type_0_item_data)

                    lanes_type_0.append(lanes_type_0_item)

                return lanes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ProcessModelLane] | None | Unset, data)

        lanes = _parse_lanes(d.pop("lanes", UNSET))

        def _parse_version_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version_id = _parse_version_id(d.pop("versionId", UNSET))

        def _parse_field_rest(data: object) -> None | RestMetadataType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                componentsschemas_rest_metadata_type_0 = RestMetadataType0.from_dict(data)

                return componentsschemas_rest_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RestMetadataType0 | Unset, data)

        field_rest = _parse_field_rest(d.pop("_rest", UNSET))

        process_model = cls(
            uuid=uuid,
            name=name,
            description=description,
            parent_folder_uuid=parent_folder_uuid,
            error_alert_group_name=error_alert_group_name,
            start_form=start_form,
            process_variables=process_variables,
            nodes=nodes,
            lanes=lanes,
            version_id=version_id,
            field_rest=field_rest,
        )

        process_model.additional_properties = d
        return process_model

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
