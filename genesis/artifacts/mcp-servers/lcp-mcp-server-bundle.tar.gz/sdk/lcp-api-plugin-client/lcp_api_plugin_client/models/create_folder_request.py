from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateFolderRequest")


@_attrs_define
class CreateFolderRequest:
    """Request body for creating a new folder

    Attributes:
        name (str): The folder name (max 255 characters) Example: 2024 Reports.
        parent_folder_uuid (str): The UUID of the parent folder Example: 550e8400-e29b-41d4-a716-446655440000.
        description (str | Unset): The folder description (max 4000 characters, optional) Example: Annual reports for
            2024.
        app_uuid (str | Unset): UUID of the application to add this folder to (optional). When provided, the folder is
            created and automatically added to the application with inherited security. Example: a1b2c3d4-e5f6-7890-abcd-
            ef1234567890.
    """

    name: str
    parent_folder_uuid: str
    description: str | Unset = UNSET
    app_uuid: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        parent_folder_uuid = self.parent_folder_uuid

        description = self.description

        app_uuid = self.app_uuid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "parentFolderUuid": parent_folder_uuid,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        parent_folder_uuid = d.pop("parentFolderUuid")

        description = d.pop("description", UNSET)

        app_uuid = d.pop("appUuid", UNSET)

        create_folder_request = cls(
            name=name,
            parent_folder_uuid=parent_folder_uuid,
            description=description,
            app_uuid=app_uuid,
        )

        create_folder_request.additional_properties = d
        return create_folder_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
