from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.process_model_node_input import ProcessModelNodeInput


T = TypeVar("T", bound="ListProcessModelNodesResponse200")


@_attrs_define
class ListProcessModelNodesResponse200:
    """
    Attributes:
        total_count (int | Unset):
        nodes (list[ProcessModelNodeInput] | Unset):
    """

    total_count: int | Unset = UNSET
    nodes: list[ProcessModelNodeInput] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total_count = self.total_count

        nodes: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.nodes, Unset):
            nodes = []
            for nodes_item_data in self.nodes:
                nodes_item = nodes_item_data.to_dict()
                nodes.append(nodes_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if total_count is not UNSET:
            field_dict["totalCount"] = total_count
        if nodes is not UNSET:
            field_dict["nodes"] = nodes

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.process_model_node_input import ProcessModelNodeInput

        d = dict(src_dict)
        total_count = d.pop("totalCount", UNSET)

        _nodes = d.pop("nodes", UNSET)
        nodes: list[ProcessModelNodeInput] | Unset = UNSET
        if _nodes is not UNSET:
            nodes = []
            for nodes_item_data in _nodes:
                nodes_item = ProcessModelNodeInput.from_dict(nodes_item_data)

                nodes.append(nodes_item)

        list_process_model_nodes_response_200 = cls(
            total_count=total_count,
            nodes=nodes,
        )

        list_process_model_nodes_response_200.additional_properties = d
        return list_process_model_nodes_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
