from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.error_item import ErrorItem


T = TypeVar("T", bound="ValidationResponse")


@_attrs_define
class ValidationResponse:
    """Result of validating expressions on a design object.

    Attributes:
        has_errors (bool): Whether any expression validation errors were found
        errors (list[ErrorItem]): List of validation errors (empty if hasErrors is false)
    """

    has_errors: bool
    errors: list[ErrorItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        has_errors = self.has_errors

        errors = []
        for errors_item_data in self.errors:
            errors_item = errors_item_data.to_dict()
            errors.append(errors_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "hasErrors": has_errors,
                "errors": errors,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.error_item import ErrorItem

        d = dict(src_dict)
        has_errors = d.pop("hasErrors")

        errors = []
        _errors = d.pop("errors")
        for errors_item_data in _errors:
            errors_item = ErrorItem.from_dict(errors_item_data)

            errors.append(errors_item)

        validation_response = cls(
            has_errors=has_errors,
            errors=errors,
        )

        validation_response.additional_properties = d
        return validation_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
