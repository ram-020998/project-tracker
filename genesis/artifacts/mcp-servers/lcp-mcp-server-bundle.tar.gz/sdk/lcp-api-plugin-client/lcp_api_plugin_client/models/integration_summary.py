from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="IntegrationSummary")


@_attrs_define
class IntegrationSummary:
    """Summary of an integration instance.

    Attributes:
        uuid (str): Integration UUID
        name (str): Display name
        description (None | str | Unset): Description
        connected_system_uuid (None | str | Unset): UUID of the parent connected system
    """

    uuid: str
    name: str
    description: None | str | Unset = UNSET
    connected_system_uuid: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        connected_system_uuid: None | str | Unset
        if isinstance(self.connected_system_uuid, Unset):
            connected_system_uuid = UNSET
        else:
            connected_system_uuid = self.connected_system_uuid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if connected_system_uuid is not UNSET:
            field_dict["connectedSystemUuid"] = connected_system_uuid

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid")

        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_connected_system_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        connected_system_uuid = _parse_connected_system_uuid(d.pop("connectedSystemUuid", UNSET))

        integration_summary = cls(
            uuid=uuid,
            name=name,
            description=description,
            connected_system_uuid=connected_system_uuid,
        )

        integration_summary.additional_properties = d
        return integration_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
