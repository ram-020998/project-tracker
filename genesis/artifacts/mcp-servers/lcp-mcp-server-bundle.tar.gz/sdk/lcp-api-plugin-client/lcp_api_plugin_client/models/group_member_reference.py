from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.group_member_reference_type import GroupMemberReferenceType

T = TypeVar("T", bound="GroupMemberReference")


@_attrs_define
class GroupMemberReference:
    """
    Attributes:
        type_ (GroupMemberReferenceType): Member type
        id (str): Username for users, group name for groups
    """

    type_: GroupMemberReferenceType
    id: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_.value

        id = self.id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type_,
                "id": id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = GroupMemberReferenceType(d.pop("type"))

        id = d.pop("id")

        group_member_reference = cls(
            type_=type_,
            id=id,
        )

        group_member_reference.additional_properties = d
        return group_member_reference

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
