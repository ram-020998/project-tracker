from enum import Enum


class CreateRecordActionRequestDialogWidth(str, Enum):
    EXTRA_WIDE = "EXTRA_WIDE"
    FIT = "FIT"
    MEDIUM = "MEDIUM"
    MEDIUM_PLUS = "MEDIUM_PLUS"
    NARROW = "NARROW"
    WIDE = "WIDE"

    def __str__(self) -> str:
        return str(self.value)
