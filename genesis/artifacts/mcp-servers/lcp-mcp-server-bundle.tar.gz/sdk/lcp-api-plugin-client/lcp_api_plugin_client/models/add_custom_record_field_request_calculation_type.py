from enum import Enum


class AddCustomRecordFieldRequestCalculationType(str, Enum):
    REAL_TIME = "REAL_TIME"
    SYNC_TIME = "SYNC_TIME"

    def __str__(self) -> str:
        return str(self.value)
