from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.test_rule_diagnostics import TestRuleDiagnostics


T = TypeVar("T", bound="TestRuleResponse")


@_attrs_define
class TestRuleResponse:
    """Result of a rule test execution.

    Attributes:
        result (Any | Unset): The evaluated return value. Shape depends on the object type.
        diagnostics (TestRuleDiagnostics | Unset): Diagnostic information about the rule test execution.
    """

    result: Any | Unset = UNSET
    diagnostics: TestRuleDiagnostics | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        result = self.result

        diagnostics: dict[str, Any] | Unset = UNSET
        if not isinstance(self.diagnostics, Unset):
            diagnostics = self.diagnostics.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if result is not UNSET:
            field_dict["result"] = result
        if diagnostics is not UNSET:
            field_dict["diagnostics"] = diagnostics

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.test_rule_diagnostics import TestRuleDiagnostics

        d = dict(src_dict)
        result = d.pop("result", UNSET)

        _diagnostics = d.pop("diagnostics", UNSET)
        diagnostics: TestRuleDiagnostics | Unset
        if isinstance(_diagnostics, Unset):
            diagnostics = UNSET
        else:
            diagnostics = TestRuleDiagnostics.from_dict(_diagnostics)

        test_rule_response = cls(
            result=result,
            diagnostics=diagnostics,
        )

        test_rule_response.additional_properties = d
        return test_rule_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
