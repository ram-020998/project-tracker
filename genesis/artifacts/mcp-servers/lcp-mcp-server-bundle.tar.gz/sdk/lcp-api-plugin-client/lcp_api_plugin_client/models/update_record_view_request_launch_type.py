from enum import Enum


class UpdateRecordViewRequestLaunchType(str, Enum):
    DIALOG = "DIALOG"
    NEW_TAB = "NEW_TAB"
    SAME_TAB = "SAME_TAB"

    def __str__(self) -> str:
        return str(self.value)
