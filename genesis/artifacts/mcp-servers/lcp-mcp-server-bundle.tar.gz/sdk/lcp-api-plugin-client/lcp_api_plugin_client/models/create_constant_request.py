from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_constant_request_type import CreateConstantRequestType
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateConstantRequest")


@_attrs_define
class CreateConstantRequest:
    """Request body for creating a new constant. All fields except description, parentFolderUuid, and appUuid are required.

    The value must be compatible with the specified type.

    Either `parentFolderUuid` or `appUuid` must be provided to determine where the constant will be created.

        Attributes:
            name (str): Constant name (typically uppercase with underscores) Example: MAX_RETRY_COUNT.
            type_ (CreateConstantRequestType): The data type of the constant value. Must be one of the supported types.
                 Example: INTEGER.
            value (bool | float | int | list[float | int | str] | str): The value to store in the constant. Must be
                compatible with the specified type:
                - TEXT: string value
                - NUMBER: decimal number
                - INTEGER: whole number
                - BOOLEAN: true or false
                - DATE: ISO date string (e.g., "2024-01-15")
                - DATETIME: ISO datetime string (e.g., "2024-01-15T14:30:00")
                - TIME: ISO time string (e.g., "14:30:00")
                - USER: username string (e.g., "john.doe")
                - GROUP: group ID number
                - FOLDER: folder ID number
                - DOCUMENT: document ID number
                - PROCESS_MODEL: process model UUID string (e.g., "2723d382-da1c-4a19-af4f-86498eb7b6eb")
                 Example: 3.
            description (str | Unset): Human-readable description (optional) Example: Maximum number of retry attempts.
            parent_folder_uuid (str | Unset): UUID of the parent Rules and Constants folder where the constant will be
                created (optional).
                If provided, this takes precedence over `appUuid` for folder selection.
                 Example: _a-0000e0b2-7f2c-8000-cd82-011c48011c48_24303.
            app_uuid (str | Unset): Application UUID (optional). When provided:
                - The constant is added to the application and is given the same security role map
                - If `parentFolderUuid` is not provided, the tool automatically selects an appropriate Rules and Constants
                folder from the application (prefers folders named "<prefix> Rules and Constants")

                Either `parentFolderUuid` or `appUuid` must be provided.
                 Example: 2723d382-da1c-4a19-af4f-86498eb7b6eb.
            multiple (bool | Unset): When true, creates a list-typed constant (e.g., List of Text). Value must be a JSON
                array. Boolean type does not support multiple. Default: False.
    """

    name: str
    type_: CreateConstantRequestType
    value: bool | float | int | list[float | int | str] | str
    description: str | Unset = UNSET
    parent_folder_uuid: str | Unset = UNSET
    app_uuid: str | Unset = UNSET
    multiple: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        type_ = self.type_.value

        value: bool | float | int | list[float | int | str] | str
        if isinstance(self.value, list):
            value = []
            for value_type_4_item_data in self.value:
                value_type_4_item: float | int | str
                value_type_4_item = value_type_4_item_data
                value.append(value_type_4_item)

        else:
            value = self.value

        description = self.description

        parent_folder_uuid = self.parent_folder_uuid

        app_uuid = self.app_uuid

        multiple = self.multiple

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type_,
                "value": value,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if parent_folder_uuid is not UNSET:
            field_dict["parentFolderUuid"] = parent_folder_uuid
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid
        if multiple is not UNSET:
            field_dict["multiple"] = multiple

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        type_ = CreateConstantRequestType(d.pop("type"))

        def _parse_value(data: object) -> bool | float | int | list[float | int | str] | str:
            try:
                if not isinstance(data, list):
                    raise TypeError()
                value_type_4 = []
                _value_type_4 = data
                for value_type_4_item_data in _value_type_4:

                    def _parse_value_type_4_item(data: object) -> float | int | str:
                        return cast(float | int | str, data)

                    value_type_4_item = _parse_value_type_4_item(value_type_4_item_data)

                    value_type_4.append(value_type_4_item)

                return value_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(bool | float | int | list[float | int | str] | str, data)

        value = _parse_value(d.pop("value"))

        description = d.pop("description", UNSET)

        parent_folder_uuid = d.pop("parentFolderUuid", UNSET)

        app_uuid = d.pop("appUuid", UNSET)

        multiple = d.pop("multiple", UNSET)

        create_constant_request = cls(
            name=name,
            type_=type_,
            value=value,
            description=description,
            parent_folder_uuid=parent_folder_uuid,
            app_uuid=app_uuid,
            multiple=multiple,
        )

        create_constant_request.additional_properties = d
        return create_constant_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
