from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ApplicationDefaultObjects")


@_attrs_define
class ApplicationDefaultObjects:
    """UUIDs of the default objects created with an application

    Attributes:
        administrators_group_uuid (str | Unset):
        users_group_uuid (str | Unset):
        rules_and_constants_folder_uuid (str | Unset):
        knowledge_center_uuid (str | Unset):
        artifacts_folder_uuid (str | Unset):
        artifacts_folder_constant_uuid (str | Unset):
        documentation_folder_uuid (str | Unset):
        process_model_folder_uuid (str | Unset):
    """

    administrators_group_uuid: str | Unset = UNSET
    users_group_uuid: str | Unset = UNSET
    rules_and_constants_folder_uuid: str | Unset = UNSET
    knowledge_center_uuid: str | Unset = UNSET
    artifacts_folder_uuid: str | Unset = UNSET
    artifacts_folder_constant_uuid: str | Unset = UNSET
    documentation_folder_uuid: str | Unset = UNSET
    process_model_folder_uuid: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        administrators_group_uuid = self.administrators_group_uuid

        users_group_uuid = self.users_group_uuid

        rules_and_constants_folder_uuid = self.rules_and_constants_folder_uuid

        knowledge_center_uuid = self.knowledge_center_uuid

        artifacts_folder_uuid = self.artifacts_folder_uuid

        artifacts_folder_constant_uuid = self.artifacts_folder_constant_uuid

        documentation_folder_uuid = self.documentation_folder_uuid

        process_model_folder_uuid = self.process_model_folder_uuid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if administrators_group_uuid is not UNSET:
            field_dict["administratorsGroupUuid"] = administrators_group_uuid
        if users_group_uuid is not UNSET:
            field_dict["usersGroupUuid"] = users_group_uuid
        if rules_and_constants_folder_uuid is not UNSET:
            field_dict["rulesAndConstantsFolderUuid"] = rules_and_constants_folder_uuid
        if knowledge_center_uuid is not UNSET:
            field_dict["knowledgeCenterUuid"] = knowledge_center_uuid
        if artifacts_folder_uuid is not UNSET:
            field_dict["artifactsFolderUuid"] = artifacts_folder_uuid
        if artifacts_folder_constant_uuid is not UNSET:
            field_dict["artifactsFolderConstantUuid"] = artifacts_folder_constant_uuid
        if documentation_folder_uuid is not UNSET:
            field_dict["documentationFolderUuid"] = documentation_folder_uuid
        if process_model_folder_uuid is not UNSET:
            field_dict["processModelFolderUuid"] = process_model_folder_uuid

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        administrators_group_uuid = d.pop("administratorsGroupUuid", UNSET)

        users_group_uuid = d.pop("usersGroupUuid", UNSET)

        rules_and_constants_folder_uuid = d.pop("rulesAndConstantsFolderUuid", UNSET)

        knowledge_center_uuid = d.pop("knowledgeCenterUuid", UNSET)

        artifacts_folder_uuid = d.pop("artifactsFolderUuid", UNSET)

        artifacts_folder_constant_uuid = d.pop("artifactsFolderConstantUuid", UNSET)

        documentation_folder_uuid = d.pop("documentationFolderUuid", UNSET)

        process_model_folder_uuid = d.pop("processModelFolderUuid", UNSET)

        application_default_objects = cls(
            administrators_group_uuid=administrators_group_uuid,
            users_group_uuid=users_group_uuid,
            rules_and_constants_folder_uuid=rules_and_constants_folder_uuid,
            knowledge_center_uuid=knowledge_center_uuid,
            artifacts_folder_uuid=artifacts_folder_uuid,
            artifacts_folder_constant_uuid=artifacts_folder_constant_uuid,
            documentation_folder_uuid=documentation_folder_uuid,
            process_model_folder_uuid=process_model_folder_uuid,
        )

        application_default_objects.additional_properties = d
        return application_default_objects

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
