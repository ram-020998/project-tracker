from enum import Enum


class ProcessModelLaneRunAs(str, Enum):
    DESIGNER = "DESIGNER"
    INITIATOR = "INITIATOR"

    def __str__(self) -> str:
        return str(self.value)
