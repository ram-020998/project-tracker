from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.update_site_request_layout import UpdateSiteRequestLayout
from ..models.update_site_request_style import UpdateSiteRequestStyle
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.site_page import SitePage


T = TypeVar("T", bound="UpdateSiteRequest")


@_attrs_define
class UpdateSiteRequest:
    """Request body for updating an existing site. Only provided fields are changed.

    Attributes:
        version_id (str | Unset): Version ID for optimistic concurrency control. If provided, validates against current
            version.
        name (str | Unset): Internal name of the site Example: Customer Portal Updated.
        display_name (str | Unset): Display name shown to users Example: Customer Portal - Updated.
        web_address_identifier (str | Unset): URL stub for the site (becomes part of URL path) Example: customer-portal.
        description (str | Unset): Description of the site (optional) Example: Updated portal description.
        layout (UpdateSiteRequestLayout | Unset): Navigation bar layout. HEADER_BAR displays pages horizontally across
            the top. SIDEBAR displays pages in a vertically stacked collapsible list on the left.
        style (UpdateSiteRequestStyle | Unset): Header bar style (only applies when layout is HEADER_BAR). MERCURY shows
            page names on left with logo on left. HELIUM shows icons above page names with logo on right. OXYGEN shows page
            names on right with logo on left.
        pages (list[SitePage] | Unset): Array of page configurations (optional, replaces all existing pages)
    """

    version_id: str | Unset = UNSET
    name: str | Unset = UNSET
    display_name: str | Unset = UNSET
    web_address_identifier: str | Unset = UNSET
    description: str | Unset = UNSET
    layout: UpdateSiteRequestLayout | Unset = UNSET
    style: UpdateSiteRequestStyle | Unset = UNSET
    pages: list[SitePage] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        version_id = self.version_id

        name = self.name

        display_name = self.display_name

        web_address_identifier = self.web_address_identifier

        description = self.description

        layout: str | Unset = UNSET
        if not isinstance(self.layout, Unset):
            layout = self.layout.value

        style: str | Unset = UNSET
        if not isinstance(self.style, Unset):
            style = self.style.value

        pages: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.pages, Unset):
            pages = []
            for pages_item_data in self.pages:
                pages_item = pages_item_data.to_dict()
                pages.append(pages_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version_id is not UNSET:
            field_dict["versionId"] = version_id
        if name is not UNSET:
            field_dict["name"] = name
        if display_name is not UNSET:
            field_dict["displayName"] = display_name
        if web_address_identifier is not UNSET:
            field_dict["webAddressIdentifier"] = web_address_identifier
        if description is not UNSET:
            field_dict["description"] = description
        if layout is not UNSET:
            field_dict["layout"] = layout
        if style is not UNSET:
            field_dict["style"] = style
        if pages is not UNSET:
            field_dict["pages"] = pages

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.site_page import SitePage

        d = dict(src_dict)
        version_id = d.pop("versionId", UNSET)

        name = d.pop("name", UNSET)

        display_name = d.pop("displayName", UNSET)

        web_address_identifier = d.pop("webAddressIdentifier", UNSET)

        description = d.pop("description", UNSET)

        _layout = d.pop("layout", UNSET)
        layout: UpdateSiteRequestLayout | Unset
        if isinstance(_layout, Unset):
            layout = UNSET
        else:
            layout = UpdateSiteRequestLayout(_layout)

        _style = d.pop("style", UNSET)
        style: UpdateSiteRequestStyle | Unset
        if isinstance(_style, Unset):
            style = UNSET
        else:
            style = UpdateSiteRequestStyle(_style)

        _pages = d.pop("pages", UNSET)
        pages: list[SitePage] | Unset = UNSET
        if _pages is not UNSET:
            pages = []
            for pages_item_data in _pages:
                pages_item = SitePage.from_dict(pages_item_data)

                pages.append(pages_item)

        update_site_request = cls(
            version_id=version_id,
            name=name,
            display_name=display_name,
            web_address_identifier=web_address_identifier,
            description=description,
            layout=layout,
            style=style,
            pages=pages,
        )

        update_site_request.additional_properties = d
        return update_site_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
