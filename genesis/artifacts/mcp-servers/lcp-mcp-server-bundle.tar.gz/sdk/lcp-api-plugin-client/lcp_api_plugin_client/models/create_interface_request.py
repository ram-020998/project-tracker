from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_interface_request_test_inputs_item import CreateInterfaceRequestTestInputsItem
    from ..models.typed_input import TypedInput


T = TypeVar("T", bound="CreateInterfaceRequest")


@_attrs_define
class CreateInterfaceRequest:
    """Request body for creating a new interface.

    Either `parentFolderUuid` or `appUuid` must be provided to determine where the interface will be created.

        Attributes:
            name (str): Name of the interface (required) Example: Customer Form.
            description (None | str | Unset): Description of what this interface does Example: Form for editing customer
                information.
            parent_folder_uuid (str | Unset): UUID of the parent Rules and Constants folder where the interface will be
                created (optional).
                If provided, this takes precedence over `appUuid` for folder selection.
                 Example: _a-0000e0b2-7f2c-8000-cd82-011c48011c48_24303.
            app_uuid (str | Unset): Application UUID (optional). When provided:
                - The interface is added to the application and is given the same security role map
                - If `parentFolderUuid` is not provided, the tool automatically selects an appropriate Rules and Constants
                folder from the application (prefers folders named "<prefix> Rules and Constants")

                Either `parentFolderUuid` or `appUuid` must be provided.
                 Example: 2723d382-da1c-4a19-af4f-86498eb7b6eb.
            expression (None | str | Unset): The SAIL expression that renders this interface. Can be null or empty
                for initial creation and updated later.
                 Example: a!localVariables(
                  local!data: {},
                  {
                    a!textField(
                      label: "Customer Name",
                      value: local!data.name,
                      saveInto: local!data.name
                    )
                  }
                )
                .
            inputs (list[TypedInput] | Unset): Input parameters for the interface. Each parameter must have a name and type.
                Supported types use QName format (e.g., '{http://www.appian.com/ae/types/2009}Text')
                or display names: Text, Number (Integer), Number (Decimal), Boolean, Date,
                Date and Time, Time, User, Group, Document, Folder, and their list variants
                (e.g., "Text (List)").
                 Example: [{'name': 'customerId', 'type': 'Number (Integer)'}, {'name': 'customerName', 'type': 'Text'}].
            test_inputs (list[CreateInterfaceRequestTestInputsItem] | Unset): Test input values to use during validation and
                save as default test values.
                If not provided, validation uses null inputs (current behavior).
                Once saved, these become the default test values used on subsequent updates.
    """

    name: str
    description: None | str | Unset = UNSET
    parent_folder_uuid: str | Unset = UNSET
    app_uuid: str | Unset = UNSET
    expression: None | str | Unset = UNSET
    inputs: list[TypedInput] | Unset = UNSET
    test_inputs: list[CreateInterfaceRequestTestInputsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        parent_folder_uuid = self.parent_folder_uuid

        app_uuid = self.app_uuid

        expression: None | str | Unset
        if isinstance(self.expression, Unset):
            expression = UNSET
        else:
            expression = self.expression

        inputs: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.inputs, Unset):
            inputs = []
            for inputs_item_data in self.inputs:
                inputs_item = inputs_item_data.to_dict()
                inputs.append(inputs_item)

        test_inputs: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.test_inputs, Unset):
            test_inputs = []
            for test_inputs_item_data in self.test_inputs:
                test_inputs_item = test_inputs_item_data.to_dict()
                test_inputs.append(test_inputs_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if parent_folder_uuid is not UNSET:
            field_dict["parentFolderUuid"] = parent_folder_uuid
        if app_uuid is not UNSET:
            field_dict["appUuid"] = app_uuid
        if expression is not UNSET:
            field_dict["expression"] = expression
        if inputs is not UNSET:
            field_dict["inputs"] = inputs
        if test_inputs is not UNSET:
            field_dict["testInputs"] = test_inputs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_interface_request_test_inputs_item import CreateInterfaceRequestTestInputsItem
        from ..models.typed_input import TypedInput

        d = dict(src_dict)
        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        parent_folder_uuid = d.pop("parentFolderUuid", UNSET)

        app_uuid = d.pop("appUuid", UNSET)

        def _parse_expression(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        expression = _parse_expression(d.pop("expression", UNSET))

        _inputs = d.pop("inputs", UNSET)
        inputs: list[TypedInput] | Unset = UNSET
        if _inputs is not UNSET:
            inputs = []
            for inputs_item_data in _inputs:
                inputs_item = TypedInput.from_dict(inputs_item_data)

                inputs.append(inputs_item)

        _test_inputs = d.pop("testInputs", UNSET)
        test_inputs: list[CreateInterfaceRequestTestInputsItem] | Unset = UNSET
        if _test_inputs is not UNSET:
            test_inputs = []
            for test_inputs_item_data in _test_inputs:
                test_inputs_item = CreateInterfaceRequestTestInputsItem.from_dict(test_inputs_item_data)

                test_inputs.append(test_inputs_item)

        create_interface_request = cls(
            name=name,
            description=description,
            parent_folder_uuid=parent_folder_uuid,
            app_uuid=app_uuid,
            expression=expression,
            inputs=inputs,
            test_inputs=test_inputs,
        )

        create_interface_request.additional_properties = d
        return create_interface_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
