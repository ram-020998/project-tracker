from enum import Enum


class TestProcessModelResultStatus(str, Enum):
    ACTIVE = "ACTIVE"
    CANCELLED = "CANCELLED"
    COMPLETED = "COMPLETED"
    ERROR = "ERROR"
    PAUSED = "PAUSED"
    PAUSED_BY_EXCEPTION = "PAUSED_BY_EXCEPTION"

    def __str__(self) -> str:
        return str(self.value)
