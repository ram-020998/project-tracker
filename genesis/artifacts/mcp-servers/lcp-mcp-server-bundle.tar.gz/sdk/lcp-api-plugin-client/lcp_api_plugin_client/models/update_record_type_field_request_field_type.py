from enum import Enum


class UpdateRecordTypeFieldRequestFieldType(str, Enum):
    BOOLEAN = "BOOLEAN"
    DATE = "DATE"
    DATETIME = "DATETIME"
    DECIMAL = "DECIMAL"
    DOCUMENT = "DOCUMENT"
    EXTRA_LONG_TEXT = "EXTRA_LONG_TEXT"
    FOLDER = "FOLDER"
    GROUP = "GROUP"
    INTEGER = "INTEGER"
    NUMBER = "NUMBER"
    TEXT = "TEXT"
    TIME = "TIME"
    USER = "USER"

    def __str__(self) -> str:
        return str(self.value)
