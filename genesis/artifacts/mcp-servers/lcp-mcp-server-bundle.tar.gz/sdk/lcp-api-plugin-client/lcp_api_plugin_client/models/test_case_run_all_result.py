from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.test_case_run_all_result_results_item import TestCaseRunAllResultResultsItem


T = TypeVar("T", bound="TestCaseRunAllResult")


@_attrs_define
class TestCaseRunAllResult:
    """Results of running all test cases for an object

    Attributes:
        results (list[TestCaseRunAllResultResultsItem] | Unset):
        total_count (int | Unset):
        pass_count (int | Unset):
        fail_count (int | Unset):
    """

    results: list[TestCaseRunAllResultResultsItem] | Unset = UNSET
    total_count: int | Unset = UNSET
    pass_count: int | Unset = UNSET
    fail_count: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        results: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.results, Unset):
            results = []
            for results_item_data in self.results:
                results_item = results_item_data.to_dict()
                results.append(results_item)

        total_count = self.total_count

        pass_count = self.pass_count

        fail_count = self.fail_count

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if results is not UNSET:
            field_dict["results"] = results
        if total_count is not UNSET:
            field_dict["totalCount"] = total_count
        if pass_count is not UNSET:
            field_dict["passCount"] = pass_count
        if fail_count is not UNSET:
            field_dict["failCount"] = fail_count

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.test_case_run_all_result_results_item import TestCaseRunAllResultResultsItem

        d = dict(src_dict)
        _results = d.pop("results", UNSET)
        results: list[TestCaseRunAllResultResultsItem] | Unset = UNSET
        if _results is not UNSET:
            results = []
            for results_item_data in _results:
                results_item = TestCaseRunAllResultResultsItem.from_dict(results_item_data)

                results.append(results_item)

        total_count = d.pop("totalCount", UNSET)

        pass_count = d.pop("passCount", UNSET)

        fail_count = d.pop("failCount", UNSET)

        test_case_run_all_result = cls(
            results=results,
            total_count=total_count,
            pass_count=pass_count,
            fail_count=fail_count,
        )

        test_case_run_all_result.additional_properties = d
        return test_case_run_all_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
