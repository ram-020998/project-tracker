from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.site_page_type import SitePageType
from ..types import UNSET, Unset

T = TypeVar("T", bound="SitePage")


@_attrs_define
class SitePage:
    """A page configuration within a site

    Attributes:
        name (str): Display name of the page Example: Home.
        target_uuid (str): UUID of the target design object for this page. For INTERFACE pages, pass an interface UUID.
            For RECORD_LIST pages, pass a record type UUID. For ACTION pages, pass a process model UUID. Example:
            _a-0000ed97-98a4-8000-9bb5-011c48011c48_105467.
        uuid (str | Unset): The page's unique identifier. On update, pass the existing UUID to preserve page identity;
            omit for new pages (a UUID will be generated).
        type_ (SitePageType | Unset): Page type. INTERFACE (default) displays an interface object. RECORD_LIST displays
            a record type's configured record list. ACTION displays a process model's start form. Default:
            SitePageType.INTERFACE. Example: INTERFACE.
        description (str | Unset): Description of the page Example: Home page for customer portal.
        icon_id (str | Unset): Font Awesome icon ID (default "f004") Example: f015.
        visibility_expr (str | Unset): An Appian SAIL expression. Validated on create/update via two-pass validation
            (parse + eval). Invalid expressions are rejected with HTTP 400.
    """

    name: str
    target_uuid: str
    uuid: str | Unset = UNSET
    type_: SitePageType | Unset = SitePageType.INTERFACE
    description: str | Unset = UNSET
    icon_id: str | Unset = UNSET
    visibility_expr: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        target_uuid = self.target_uuid

        uuid = self.uuid

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        description = self.description

        icon_id = self.icon_id

        visibility_expr = self.visibility_expr

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "targetUuid": target_uuid,
            }
        )
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if type_ is not UNSET:
            field_dict["type"] = type_
        if description is not UNSET:
            field_dict["description"] = description
        if icon_id is not UNSET:
            field_dict["iconId"] = icon_id
        if visibility_expr is not UNSET:
            field_dict["visibilityExpr"] = visibility_expr

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        target_uuid = d.pop("targetUuid")

        uuid = d.pop("uuid", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: SitePageType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = SitePageType(_type_)

        description = d.pop("description", UNSET)

        icon_id = d.pop("iconId", UNSET)

        visibility_expr = d.pop("visibilityExpr", UNSET)

        site_page = cls(
            name=name,
            target_uuid=target_uuid,
            uuid=uuid,
            type_=type_,
            description=description,
            icon_id=icon_id,
            visibility_expr=visibility_expr,
        )

        site_page.additional_properties = d
        return site_page

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
