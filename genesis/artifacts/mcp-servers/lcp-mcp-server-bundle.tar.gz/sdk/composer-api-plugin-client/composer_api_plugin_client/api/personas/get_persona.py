from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.persona import Persona
from ...models.problem_details import ProblemDetails
from ...types import Response


def _get_kwargs(
    app_uuid: str,
    uuid: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/applications/{app_uuid}/plan/personas/{uuid}".format(
            app_uuid=quote(str(app_uuid), safe=""),
            uuid=quote(str(uuid), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Persona | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = Persona.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ProblemDetails.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Persona | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient,
) -> Response[Persona | ProblemDetails]:
    """Get a persona by UUID

    Args:
        app_uuid (str):
        uuid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Persona | ProblemDetails]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        uuid=uuid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient,
) -> Persona | ProblemDetails | None:
    """Get a persona by UUID

    Args:
        app_uuid (str):
        uuid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Persona | ProblemDetails
    """

    return sync_detailed(
        app_uuid=app_uuid,
        uuid=uuid,
        client=client,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient,
) -> Response[Persona | ProblemDetails]:
    """Get a persona by UUID

    Args:
        app_uuid (str):
        uuid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Persona | ProblemDetails]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        uuid=uuid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient,
) -> Persona | ProblemDetails | None:
    """Get a persona by UUID

    Args:
        app_uuid (str):
        uuid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Persona | ProblemDetails
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            uuid=uuid,
            client=client,
        )
    ).parsed
