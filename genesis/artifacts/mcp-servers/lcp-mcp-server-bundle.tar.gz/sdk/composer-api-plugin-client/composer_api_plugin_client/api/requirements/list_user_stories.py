from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.problem_details import ProblemDetails
from ...models.user_story_detail import UserStoryDetail
from ...models.user_story_list_response import UserStoryListResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    app_uuid: str,
    *,
    ids: str | Unset = UNSET,
    parent_id: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["ids"] = ids

    params["parentId"] = parent_id

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/applications/{app_uuid}/plan/user-stories".format(
            app_uuid=quote(str(app_uuid), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | list[UserStoryDetail] | UserStoryListResponse | None:
    if response.status_code == 200:

        def _parse_response_200(data: object) -> list[UserStoryDetail] | UserStoryListResponse:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_0 = UserStoryListResponse.from_dict(data)

                return response_200_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, list):
                raise TypeError()
            response_200_type_1 = []
            _response_200_type_1 = data
            for response_200_type_1_item_data in _response_200_type_1:
                response_200_type_1_item = UserStoryDetail.from_dict(response_200_type_1_item_data)

                response_200_type_1.append(response_200_type_1_item)

            return response_200_type_1

        response_200 = _parse_response_200(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = ProblemDetails.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | list[UserStoryDetail] | UserStoryListResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    ids: str | Unset = UNSET,
    parent_id: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[ProblemDetails | list[UserStoryDetail] | UserStoryListResponse]:
    """List or retrieve user stories in an application

     Returns user stories (actions) in the application's requirements plan.
    Use `ids` query parameter to fetch details for specific stories.
    Use `parentId` to filter by epic (activity ID).

    Args:
        app_uuid (str):
        ids (str | Unset):
        parent_id (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[UserStoryDetail] | UserStoryListResponse]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        ids=ids,
        parent_id=parent_id,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    ids: str | Unset = UNSET,
    parent_id: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> ProblemDetails | list[UserStoryDetail] | UserStoryListResponse | None:
    """List or retrieve user stories in an application

     Returns user stories (actions) in the application's requirements plan.
    Use `ids` query parameter to fetch details for specific stories.
    Use `parentId` to filter by epic (activity ID).

    Args:
        app_uuid (str):
        ids (str | Unset):
        parent_id (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[UserStoryDetail] | UserStoryListResponse
    """

    return sync_detailed(
        app_uuid=app_uuid,
        client=client,
        ids=ids,
        parent_id=parent_id,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    ids: str | Unset = UNSET,
    parent_id: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> Response[ProblemDetails | list[UserStoryDetail] | UserStoryListResponse]:
    """List or retrieve user stories in an application

     Returns user stories (actions) in the application's requirements plan.
    Use `ids` query parameter to fetch details for specific stories.
    Use `parentId` to filter by epic (activity ID).

    Args:
        app_uuid (str):
        ids (str | Unset):
        parent_id (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[UserStoryDetail] | UserStoryListResponse]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        ids=ids,
        parent_id=parent_id,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    ids: str | Unset = UNSET,
    parent_id: str | Unset = UNSET,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
) -> ProblemDetails | list[UserStoryDetail] | UserStoryListResponse | None:
    """List or retrieve user stories in an application

     Returns user stories (actions) in the application's requirements plan.
    Use `ids` query parameter to fetch details for specific stories.
    Use `parentId` to filter by epic (activity ID).

    Args:
        app_uuid (str):
        ids (str | Unset):
        parent_id (str | Unset):
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[UserStoryDetail] | UserStoryListResponse
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            client=client,
            ids=ids,
            parent_id=parent_id,
            limit=limit,
            offset=offset,
        )
    ).parsed
