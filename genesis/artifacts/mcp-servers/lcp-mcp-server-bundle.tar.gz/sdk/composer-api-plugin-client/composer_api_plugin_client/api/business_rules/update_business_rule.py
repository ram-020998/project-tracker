from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.business_rule import BusinessRule
from ...models.problem_details import ProblemDetails
from ...models.update_business_rule_request import UpdateBusinessRuleRequest
from ...types import Response


def _get_kwargs(
    app_uuid: str,
    uuid: str,
    *,
    body: UpdateBusinessRuleRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/applications/{app_uuid}/plan/business-rules/{uuid}".format(
            app_uuid=quote(str(app_uuid), safe=""),
            uuid=quote(str(uuid), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BusinessRule | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = BusinessRule.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = ProblemDetails.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[BusinessRule | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateBusinessRuleRequest,
) -> Response[BusinessRule | ProblemDetails]:
    """Update a business rule

    Args:
        app_uuid (str):
        uuid (str):
        body (UpdateBusinessRuleRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BusinessRule | ProblemDetails]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        uuid=uuid,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateBusinessRuleRequest,
) -> BusinessRule | ProblemDetails | None:
    """Update a business rule

    Args:
        app_uuid (str):
        uuid (str):
        body (UpdateBusinessRuleRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BusinessRule | ProblemDetails
    """

    return sync_detailed(
        app_uuid=app_uuid,
        uuid=uuid,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateBusinessRuleRequest,
) -> Response[BusinessRule | ProblemDetails]:
    """Update a business rule

    Args:
        app_uuid (str):
        uuid (str):
        body (UpdateBusinessRuleRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BusinessRule | ProblemDetails]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        uuid=uuid,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateBusinessRuleRequest,
) -> BusinessRule | ProblemDetails | None:
    """Update a business rule

    Args:
        app_uuid (str):
        uuid (str):
        body (UpdateBusinessRuleRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BusinessRule | ProblemDetails
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            uuid=uuid,
            client=client,
            body=body,
        )
    ).parsed
