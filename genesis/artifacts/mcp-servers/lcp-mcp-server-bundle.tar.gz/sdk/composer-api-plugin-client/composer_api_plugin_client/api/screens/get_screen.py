from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.problem_details import ProblemDetails
from ...models.screen import Screen
from ...types import Response


def _get_kwargs(
    app_uuid: str,
    id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/applications/{app_uuid}/plan/screens/{id}".format(
            app_uuid=quote(str(app_uuid), safe=""),
            id=quote(str(id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | Screen | None:
    if response.status_code == 200:
        response_200 = Screen.from_dict(response.json())

        return response_200

    if response.status_code == 403:
        response_403 = ProblemDetails.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | Screen]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ProblemDetails | Screen]:
    """Get a screen by ID

    Args:
        app_uuid (str):
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | Screen]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        id=id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
) -> ProblemDetails | Screen | None:
    """Get a screen by ID

    Args:
        app_uuid (str):
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | Screen
    """

    return sync_detailed(
        app_uuid=app_uuid,
        id=id,
        client=client,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ProblemDetails | Screen]:
    """Get a screen by ID

    Args:
        app_uuid (str):
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | Screen]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        id=id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
) -> ProblemDetails | Screen | None:
    """Get a screen by ID

    Args:
        app_uuid (str):
        id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | Screen
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            id=id,
            client=client,
        )
    ).parsed
