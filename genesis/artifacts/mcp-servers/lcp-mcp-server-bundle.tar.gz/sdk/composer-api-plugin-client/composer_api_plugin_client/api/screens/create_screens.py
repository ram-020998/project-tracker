from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_screen_request import CreateScreenRequest
from ...models.create_screens_response_201_type_1 import CreateScreensResponse201Type1
from ...models.problem_details import ProblemDetails
from ...models.screen import Screen
from ...types import Response


def _get_kwargs(
    app_uuid: str,
    *,
    body: CreateScreenRequest | list[CreateScreenRequest],
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/applications/{app_uuid}/plan/screens".format(
            app_uuid=quote(str(app_uuid), safe=""),
        ),
    }

    if isinstance(body, CreateScreenRequest):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = []
        for body_type_1_item_data in body:
            body_type_1_item = body_type_1_item_data.to_dict()
            _kwargs["json"].append(body_type_1_item)

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreateScreensResponse201Type1 | Screen | ProblemDetails | None:
    if response.status_code == 201:

        def _parse_response_201(data: object) -> CreateScreensResponse201Type1 | Screen:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_201_type_0 = Screen.from_dict(data)

                return response_201_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_201_type_1 = CreateScreensResponse201Type1.from_dict(data)

            return response_201_type_1

        response_201 = _parse_response_201(response.json())

        return response_201

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = ProblemDetails.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreateScreensResponse201Type1 | Screen | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateScreenRequest | list[CreateScreenRequest],
) -> Response[CreateScreensResponse201Type1 | Screen | ProblemDetails]:
    """Create screen(s)

     Accepts a single screen object or an array for batch creation.

    Args:
        app_uuid (str):
        body (CreateScreenRequest | list[CreateScreenRequest]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateScreensResponse201Type1 | Screen | ProblemDetails]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateScreenRequest | list[CreateScreenRequest],
) -> CreateScreensResponse201Type1 | Screen | ProblemDetails | None:
    """Create screen(s)

     Accepts a single screen object or an array for batch creation.

    Args:
        app_uuid (str):
        body (CreateScreenRequest | list[CreateScreenRequest]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateScreensResponse201Type1 | Screen | ProblemDetails
    """

    return sync_detailed(
        app_uuid=app_uuid,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateScreenRequest | list[CreateScreenRequest],
) -> Response[CreateScreensResponse201Type1 | Screen | ProblemDetails]:
    """Create screen(s)

     Accepts a single screen object or an array for batch creation.

    Args:
        app_uuid (str):
        body (CreateScreenRequest | list[CreateScreenRequest]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateScreensResponse201Type1 | Screen | ProblemDetails]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    *,
    client: AuthenticatedClient | Client,
    body: CreateScreenRequest | list[CreateScreenRequest],
) -> CreateScreensResponse201Type1 | Screen | ProblemDetails | None:
    """Create screen(s)

     Accepts a single screen object or an array for batch creation.

    Args:
        app_uuid (str):
        body (CreateScreenRequest | list[CreateScreenRequest]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CreateScreensResponse201Type1 | Screen | ProblemDetails
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            client=client,
            body=body,
        )
    ).parsed
