from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.data_model_entity import DataModelEntity
from ...models.problem_details import ProblemDetails
from ...models.update_data_model_entity_request import UpdateDataModelEntityRequest
from ...types import Response


def _get_kwargs(
    app_uuid: str,
    uuid: str,
    *,
    body: UpdateDataModelEntityRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/applications/{app_uuid}/plan/data-model/entities/{uuid}".format(
            app_uuid=quote(str(app_uuid), safe=""),
            uuid=quote(str(uuid), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DataModelEntity | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = DataModelEntity.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 403:
        response_403 = ProblemDetails.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DataModelEntity | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient,
    body: UpdateDataModelEntityRequest,
) -> Response[DataModelEntity | ProblemDetails]:
    """Update an entity

    Args:
        app_uuid (str):
        uuid (str):
        body (UpdateDataModelEntityRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DataModelEntity | ProblemDetails]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        uuid=uuid,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient,
    body: UpdateDataModelEntityRequest,
) -> DataModelEntity | ProblemDetails | None:
    """Update an entity

    Args:
        app_uuid (str):
        uuid (str):
        body (UpdateDataModelEntityRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DataModelEntity | ProblemDetails
    """

    return sync_detailed(
        app_uuid=app_uuid,
        uuid=uuid,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient,
    body: UpdateDataModelEntityRequest,
) -> Response[DataModelEntity | ProblemDetails]:
    """Update an entity

    Args:
        app_uuid (str):
        uuid (str):
        body (UpdateDataModelEntityRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DataModelEntity | ProblemDetails]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        uuid=uuid,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    uuid: str,
    *,
    client: AuthenticatedClient,
    body: UpdateDataModelEntityRequest,
) -> DataModelEntity | ProblemDetails | None:
    """Update an entity

    Args:
        app_uuid (str):
        uuid (str):
        body (UpdateDataModelEntityRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DataModelEntity | ProblemDetails
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            uuid=uuid,
            client=client,
            body=body,
        )
    ).parsed
