from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.patch_screen_request import PatchScreenRequest
from ...models.problem_details import ProblemDetails
from ...models.screen import Screen
from ...types import Response


def _get_kwargs(
    app_uuid: str,
    id: str,
    *,
    body: PatchScreenRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/applications/{app_uuid}/plan/screens/{id}".format(
            app_uuid=quote(str(app_uuid), safe=""),
            id=quote(str(id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | Screen | None:
    if response.status_code == 200:
        response_200 = Screen.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 403:
        response_403 = ProblemDetails.from_dict(response.json())

        return response_403

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | Screen]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app_uuid: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: PatchScreenRequest,
) -> Response[ProblemDetails | Screen]:
    """Partially update a screen

     Update specific fields of a screen without replacing the entire resource.

    Args:
        app_uuid (str):
        id (str):
        body (PatchScreenRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | Screen]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app_uuid: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: PatchScreenRequest,
) -> ProblemDetails | Screen | None:
    """Partially update a screen

     Update specific fields of a screen without replacing the entire resource.

    Args:
        app_uuid (str):
        id (str):
        body (PatchScreenRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | Screen
    """

    return sync_detailed(
        app_uuid=app_uuid,
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    app_uuid: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: PatchScreenRequest,
) -> Response[ProblemDetails | Screen]:
    """Partially update a screen

     Update specific fields of a screen without replacing the entire resource.

    Args:
        app_uuid (str):
        id (str):
        body (PatchScreenRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | Screen]
    """

    kwargs = _get_kwargs(
        app_uuid=app_uuid,
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app_uuid: str,
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: PatchScreenRequest,
) -> ProblemDetails | Screen | None:
    """Partially update a screen

     Update specific fields of a screen without replacing the entire resource.

    Args:
        app_uuid (str):
        id (str):
        body (PatchScreenRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | Screen
    """

    return (
        await asyncio_detailed(
            app_uuid=app_uuid,
            id=id,
            client=client,
            body=body,
        )
    ).parsed
