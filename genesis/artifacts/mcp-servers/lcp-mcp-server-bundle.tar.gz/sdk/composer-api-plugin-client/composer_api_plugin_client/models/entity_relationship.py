from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.entity_relationship_type import EntityRelationshipType
from ..types import UNSET, Unset

T = TypeVar("T", bound="EntityRelationship")


@_attrs_define
class EntityRelationship:
    """
    Attributes:
        uuid (str):
        type_ (EntityRelationshipType):
        source_attribute_uuid (None | str | Unset):
        target_attribute_uuid (None | str | Unset):
    """

    uuid: str
    type_: EntityRelationshipType
    source_attribute_uuid: None | str | Unset = UNSET
    target_attribute_uuid: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        type_ = self.type_.value

        source_attribute_uuid: None | str | Unset
        if isinstance(self.source_attribute_uuid, Unset):
            source_attribute_uuid = UNSET
        else:
            source_attribute_uuid = self.source_attribute_uuid

        target_attribute_uuid: None | str | Unset
        if isinstance(self.target_attribute_uuid, Unset):
            target_attribute_uuid = UNSET
        else:
            target_attribute_uuid = self.target_attribute_uuid

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "type": type_,
            }
        )
        if source_attribute_uuid is not UNSET:
            field_dict["sourceAttributeUuid"] = source_attribute_uuid
        if target_attribute_uuid is not UNSET:
            field_dict["targetAttributeUuid"] = target_attribute_uuid

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uuid = d.pop("uuid")

        type_ = EntityRelationshipType(d.pop("type"))

        def _parse_source_attribute_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        source_attribute_uuid = _parse_source_attribute_uuid(d.pop("sourceAttributeUuid", UNSET))

        def _parse_target_attribute_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        target_attribute_uuid = _parse_target_attribute_uuid(d.pop("targetAttributeUuid", UNSET))

        entity_relationship = cls(
            uuid=uuid,
            type_=type_,
            source_attribute_uuid=source_attribute_uuid,
            target_attribute_uuid=target_attribute_uuid,
        )

        entity_relationship.additional_properties = d
        return entity_relationship

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
