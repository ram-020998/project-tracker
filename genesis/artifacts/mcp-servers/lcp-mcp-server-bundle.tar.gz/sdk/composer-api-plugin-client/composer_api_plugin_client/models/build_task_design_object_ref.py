from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="BuildTaskDesignObjectRef")


@_attrs_define
class BuildTaskDesignObjectRef:
    """
    Attributes:
        design_object_uuid (str):
        design_object_q_name (str):
    """

    design_object_uuid: str
    design_object_q_name: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        design_object_uuid = self.design_object_uuid

        design_object_q_name = self.design_object_q_name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "designObjectUuid": design_object_uuid,
                "designObjectQName": design_object_q_name,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        design_object_uuid = d.pop("designObjectUuid")

        design_object_q_name = d.pop("designObjectQName")

        build_task_design_object_ref = cls(
            design_object_uuid=design_object_uuid,
            design_object_q_name=design_object_q_name,
        )

        build_task_design_object_ref.additional_properties = d
        return build_task_design_object_ref

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
