from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="PatchScreenRequest")


@_attrs_define
class PatchScreenRequest:
    """
    Attributes:
        name (str | Unset):
        is_site_page (bool | Unset):
        site_order (int | None | Unset):
        job_id (None | Unset | UUID):
        sail_code (None | str | Unset): SAIL code for the screen
    """

    name: str | Unset = UNSET
    is_site_page: bool | Unset = UNSET
    site_order: int | None | Unset = UNSET
    job_id: None | Unset | UUID = UNSET
    sail_code: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        is_site_page = self.is_site_page

        site_order: int | None | Unset
        if isinstance(self.site_order, Unset):
            site_order = UNSET
        else:
            site_order = self.site_order

        job_id: None | str | Unset
        if isinstance(self.job_id, Unset):
            job_id = UNSET
        elif isinstance(self.job_id, UUID):
            job_id = str(self.job_id)
        else:
            job_id = self.job_id

        sail_code: None | str | Unset
        if isinstance(self.sail_code, Unset):
            sail_code = UNSET
        else:
            sail_code = self.sail_code

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if is_site_page is not UNSET:
            field_dict["isSitePage"] = is_site_page
        if site_order is not UNSET:
            field_dict["siteOrder"] = site_order
        if job_id is not UNSET:
            field_dict["jobId"] = job_id
        if sail_code is not UNSET:
            field_dict["sailCode"] = sail_code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        is_site_page = d.pop("isSitePage", UNSET)

        def _parse_site_order(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        site_order = _parse_site_order(d.pop("siteOrder", UNSET))

        def _parse_job_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                job_id_type_0 = UUID(data)

                return job_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        job_id = _parse_job_id(d.pop("jobId", UNSET))

        def _parse_sail_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sail_code = _parse_sail_code(d.pop("sailCode", UNSET))

        patch_screen_request = cls(
            name=name,
            is_site_page=is_site_page,
            site_order=site_order,
            job_id=job_id,
            sail_code=sail_code,
        )

        patch_screen_request.additional_properties = d
        return patch_screen_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
