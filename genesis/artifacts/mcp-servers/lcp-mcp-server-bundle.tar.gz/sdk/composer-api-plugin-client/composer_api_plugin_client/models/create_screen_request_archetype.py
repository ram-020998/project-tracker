from enum import Enum


class CreateScreenRequestArchetype(str, Enum):
    CUSTOM = "custom"
    DASHBOARD = "dashboard"
    FORM = "form"
    LIST = "list"
    SUMMARY = "summary"

    def __str__(self) -> str:
        return str(self.value)
