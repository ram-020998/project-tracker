from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.requirements_status import RequirementsStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.requirement_activity import RequirementActivity


T = TypeVar("T", bound="Requirements")


@_attrs_define
class Requirements:
    """
    Attributes:
        application_uuid (UUID):
        status (RequirementsStatus):
        last_modified_at (datetime.datetime):
        data_model_last_modified_at (datetime.datetime):
        activities (list[RequirementActivity] | None | Unset):
    """

    application_uuid: UUID
    status: RequirementsStatus
    last_modified_at: datetime.datetime
    data_model_last_modified_at: datetime.datetime
    activities: list[RequirementActivity] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        application_uuid = str(self.application_uuid)

        status = self.status.value

        last_modified_at = self.last_modified_at.isoformat()

        data_model_last_modified_at = self.data_model_last_modified_at.isoformat()

        activities: list[dict[str, Any]] | None | Unset
        if isinstance(self.activities, Unset):
            activities = UNSET
        elif isinstance(self.activities, list):
            activities = []
            for activities_type_0_item_data in self.activities:
                activities_type_0_item = activities_type_0_item_data.to_dict()
                activities.append(activities_type_0_item)

        else:
            activities = self.activities

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "applicationUuid": application_uuid,
                "status": status,
                "lastModifiedAt": last_modified_at,
                "dataModelLastModifiedAt": data_model_last_modified_at,
            }
        )
        if activities is not UNSET:
            field_dict["activities"] = activities

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.requirement_activity import RequirementActivity

        d = dict(src_dict)
        application_uuid = UUID(d.pop("applicationUuid"))

        status = RequirementsStatus(d.pop("status"))

        last_modified_at = datetime.datetime.fromisoformat(d.pop("lastModifiedAt"))

        data_model_last_modified_at = datetime.datetime.fromisoformat(d.pop("dataModelLastModifiedAt"))

        def _parse_activities(data: object) -> list[RequirementActivity] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                activities_type_0 = []
                _activities_type_0 = data
                for activities_type_0_item_data in _activities_type_0:
                    activities_type_0_item = RequirementActivity.from_dict(activities_type_0_item_data)

                    activities_type_0.append(activities_type_0_item)

                return activities_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[RequirementActivity] | None | Unset, data)

        activities = _parse_activities(d.pop("activities", UNSET))

        requirements = cls(
            application_uuid=application_uuid,
            status=status,
            last_modified_at=last_modified_at,
            data_model_last_modified_at=data_model_last_modified_at,
            activities=activities,
        )

        requirements.additional_properties = d
        return requirements

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
