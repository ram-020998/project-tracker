from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.automation_item_status import AutomationItemStatus
from ..models.automation_item_type import AutomationItemType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.design_object_ref import DesignObjectRef


T = TypeVar("T", bound="AutomationItem")


@_attrs_define
class AutomationItem:
    """
    Attributes:
        id (UUID):
        name (str):
        item_type (AutomationItemType):
        status (AutomationItemStatus):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        description (None | str | Unset):
        source_action_id (None | str | Unset):
        recommendation_json (None | str | Unset):
        related_stories (None | str | Unset):
        job_id (None | Unset | UUID):
        design_object_refs (list[DesignObjectRef] | None | Unset):
    """

    id: UUID
    name: str
    item_type: AutomationItemType
    status: AutomationItemStatus
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    source_action_id: None | str | Unset = UNSET
    recommendation_json: None | str | Unset = UNSET
    related_stories: None | str | Unset = UNSET
    job_id: None | Unset | UUID = UNSET
    design_object_refs: list[DesignObjectRef] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        name = self.name

        item_type = self.item_type.value

        status = self.status.value

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        source_action_id: None | str | Unset
        if isinstance(self.source_action_id, Unset):
            source_action_id = UNSET
        else:
            source_action_id = self.source_action_id

        recommendation_json: None | str | Unset
        if isinstance(self.recommendation_json, Unset):
            recommendation_json = UNSET
        else:
            recommendation_json = self.recommendation_json

        related_stories: None | str | Unset
        if isinstance(self.related_stories, Unset):
            related_stories = UNSET
        else:
            related_stories = self.related_stories

        job_id: None | str | Unset
        if isinstance(self.job_id, Unset):
            job_id = UNSET
        elif isinstance(self.job_id, UUID):
            job_id = str(self.job_id)
        else:
            job_id = self.job_id

        design_object_refs: list[dict[str, Any]] | None | Unset
        if isinstance(self.design_object_refs, Unset):
            design_object_refs = UNSET
        elif isinstance(self.design_object_refs, list):
            design_object_refs = []
            for design_object_refs_type_0_item_data in self.design_object_refs:
                design_object_refs_type_0_item = design_object_refs_type_0_item_data.to_dict()
                design_object_refs.append(design_object_refs_type_0_item)

        else:
            design_object_refs = self.design_object_refs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "itemType": item_type,
                "status": status,
                "createdAt": created_at,
                "updatedAt": updated_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if source_action_id is not UNSET:
            field_dict["sourceActionId"] = source_action_id
        if recommendation_json is not UNSET:
            field_dict["recommendationJson"] = recommendation_json
        if related_stories is not UNSET:
            field_dict["relatedStories"] = related_stories
        if job_id is not UNSET:
            field_dict["jobId"] = job_id
        if design_object_refs is not UNSET:
            field_dict["designObjectRefs"] = design_object_refs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.design_object_ref import DesignObjectRef

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        name = d.pop("name")

        item_type = AutomationItemType(d.pop("itemType"))

        status = AutomationItemStatus(d.pop("status"))

        created_at = datetime.datetime.fromisoformat(d.pop("createdAt"))

        updated_at = datetime.datetime.fromisoformat(d.pop("updatedAt"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_source_action_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        source_action_id = _parse_source_action_id(d.pop("sourceActionId", UNSET))

        def _parse_recommendation_json(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        recommendation_json = _parse_recommendation_json(d.pop("recommendationJson", UNSET))

        def _parse_related_stories(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        related_stories = _parse_related_stories(d.pop("relatedStories", UNSET))

        def _parse_job_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                job_id_type_0 = UUID(data)

                return job_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        job_id = _parse_job_id(d.pop("jobId", UNSET))

        def _parse_design_object_refs(data: object) -> list[DesignObjectRef] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                design_object_refs_type_0 = []
                _design_object_refs_type_0 = data
                for design_object_refs_type_0_item_data in _design_object_refs_type_0:
                    design_object_refs_type_0_item = DesignObjectRef.from_dict(design_object_refs_type_0_item_data)

                    design_object_refs_type_0.append(design_object_refs_type_0_item)

                return design_object_refs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DesignObjectRef] | None | Unset, data)

        design_object_refs = _parse_design_object_refs(d.pop("designObjectRefs", UNSET))

        automation_item = cls(
            id=id,
            name=name,
            item_type=item_type,
            status=status,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            source_action_id=source_action_id,
            recommendation_json=recommendation_json,
            related_stories=related_stories,
            job_id=job_id,
            design_object_refs=design_object_refs,
        )

        automation_item.additional_properties = d
        return automation_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
