from enum import Enum


class RequirementActionBuildPath(str, Enum):
    DEV_AGENT = "DEV_AGENT"
    GENERATE_OBJECTS = "GENERATE_OBJECTS"

    def __str__(self) -> str:
        return str(self.value)
