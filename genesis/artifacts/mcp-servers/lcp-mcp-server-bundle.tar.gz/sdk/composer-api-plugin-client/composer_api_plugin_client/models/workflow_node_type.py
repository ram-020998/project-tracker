from enum import Enum


class WorkflowNodeType(str, Enum):
    AUTOMATEDACTIVITY = "automatedActivity"
    END = "end"
    EXCLUSIVEGATEWAY = "exclusiveGateway"
    PARALLELGATEWAY = "parallelGateway"
    START = "start"
    USERACTIVITY = "userActivity"

    def __str__(self) -> str:
        return str(self.value)
