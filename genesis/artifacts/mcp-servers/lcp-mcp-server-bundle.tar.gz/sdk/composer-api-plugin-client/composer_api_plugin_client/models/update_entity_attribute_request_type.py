from enum import Enum


class UpdateEntityAttributeRequestType(str, Enum):
    BOOLEAN = "BOOLEAN"
    DATE = "DATE"
    DATE_TIME = "DATE_TIME"
    DECIMAL = "DECIMAL"
    DOCUMENT = "DOCUMENT"
    GROUP = "GROUP"
    INTEGER = "INTEGER"
    LONG_TEXT = "LONG_TEXT"
    TEXT = "TEXT"
    TRANSLATION_STRING = "TRANSLATION_STRING"
    USERNAME = "USERNAME"
    XL_TEXT = "XL_TEXT"

    def __str__(self) -> str:
        return str(self.value)
