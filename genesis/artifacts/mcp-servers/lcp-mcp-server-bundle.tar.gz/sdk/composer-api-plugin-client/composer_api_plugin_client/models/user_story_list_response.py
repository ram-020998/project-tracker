from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.user_story_summary import UserStorySummary


T = TypeVar("T", bound="UserStoryListResponse")


@_attrs_define
class UserStoryListResponse:
    """
    Attributes:
        items (list[UserStorySummary] | Unset):
        total (int | Unset):
        limit (int | Unset):
        offset (int | Unset):
    """

    items: list[UserStorySummary] | Unset = UNSET
    total: int | Unset = UNSET
    limit: int | Unset = UNSET
    offset: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        items: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.items, Unset):
            items = []
            for items_item_data in self.items:
                items_item = items_item_data.to_dict()
                items.append(items_item)

        total = self.total

        limit = self.limit

        offset = self.offset

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if items is not UNSET:
            field_dict["items"] = items
        if total is not UNSET:
            field_dict["total"] = total
        if limit is not UNSET:
            field_dict["limit"] = limit
        if offset is not UNSET:
            field_dict["offset"] = offset

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_story_summary import UserStorySummary

        d = dict(src_dict)
        _items = d.pop("items", UNSET)
        items: list[UserStorySummary] | Unset = UNSET
        if _items is not UNSET:
            items = []
            for items_item_data in _items:
                items_item = UserStorySummary.from_dict(items_item_data)

                items.append(items_item)

        total = d.pop("total", UNSET)

        limit = d.pop("limit", UNSET)

        offset = d.pop("offset", UNSET)

        user_story_list_response = cls(
            items=items,
            total=total,
            limit=limit,
            offset=offset,
        )

        user_story_list_response.additional_properties = d
        return user_story_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
