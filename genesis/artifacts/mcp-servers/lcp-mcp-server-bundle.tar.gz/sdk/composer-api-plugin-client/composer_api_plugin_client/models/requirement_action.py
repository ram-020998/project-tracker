from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.requirement_action_action_type import RequirementActionActionType
from ..models.requirement_action_build_path import RequirementActionBuildPath
from ..models.requirement_action_priority import RequirementActionPriority
from ..models.requirement_action_status import RequirementActionStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.design_object_ref import DesignObjectRef


T = TypeVar("T", bound="RequirementAction")


@_attrs_define
class RequirementAction:
    """A specific action performed by a persona within an activity. Actions represent concrete user interactions or system
    behaviors.

        Attributes:
            name (str):
            uuid (UUID | Unset):
            description (None | str | Unset):
            persona (None | str | Unset):
            action_type (RequirementActionActionType | Unset):
            status (RequirementActionStatus | Unset):  Default: RequirementActionStatus.NOT_STARTED.
            build_path (RequirementActionBuildPath | Unset):
            priority (RequirementActionPriority | Unset):
            assignee (None | str | Unset): Assignee's uuid
            story_points (None | str | Unset):
            build_sequence_number (None | str | Unset):
            story_id (None | str | Unset):
            acceptance_criteria (None | str | Unset):
            design_objects (list[DesignObjectRef] | Unset):
    """

    name: str
    uuid: UUID | Unset = UNSET
    description: None | str | Unset = UNSET
    persona: None | str | Unset = UNSET
    action_type: RequirementActionActionType | Unset = UNSET
    status: RequirementActionStatus | Unset = RequirementActionStatus.NOT_STARTED
    build_path: RequirementActionBuildPath | Unset = UNSET
    priority: RequirementActionPriority | Unset = UNSET
    assignee: None | str | Unset = UNSET
    story_points: None | str | Unset = UNSET
    build_sequence_number: None | str | Unset = UNSET
    story_id: None | str | Unset = UNSET
    acceptance_criteria: None | str | Unset = UNSET
    design_objects: list[DesignObjectRef] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        uuid: str | Unset = UNSET
        if not isinstance(self.uuid, Unset):
            uuid = str(self.uuid)

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        persona: None | str | Unset
        if isinstance(self.persona, Unset):
            persona = UNSET
        else:
            persona = self.persona

        action_type: str | Unset = UNSET
        if not isinstance(self.action_type, Unset):
            action_type = self.action_type.value

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        build_path: str | Unset = UNSET
        if not isinstance(self.build_path, Unset):
            build_path = self.build_path.value

        priority: str | Unset = UNSET
        if not isinstance(self.priority, Unset):
            priority = self.priority.value

        assignee: None | str | Unset
        if isinstance(self.assignee, Unset):
            assignee = UNSET
        else:
            assignee = self.assignee

        story_points: None | str | Unset
        if isinstance(self.story_points, Unset):
            story_points = UNSET
        else:
            story_points = self.story_points

        build_sequence_number: None | str | Unset
        if isinstance(self.build_sequence_number, Unset):
            build_sequence_number = UNSET
        else:
            build_sequence_number = self.build_sequence_number

        story_id: None | str | Unset
        if isinstance(self.story_id, Unset):
            story_id = UNSET
        else:
            story_id = self.story_id

        acceptance_criteria: None | str | Unset
        if isinstance(self.acceptance_criteria, Unset):
            acceptance_criteria = UNSET
        else:
            acceptance_criteria = self.acceptance_criteria

        design_objects: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.design_objects, Unset):
            design_objects = []
            for design_objects_item_data in self.design_objects:
                design_objects_item = design_objects_item_data.to_dict()
                design_objects.append(design_objects_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if description is not UNSET:
            field_dict["description"] = description
        if persona is not UNSET:
            field_dict["persona"] = persona
        if action_type is not UNSET:
            field_dict["actionType"] = action_type
        if status is not UNSET:
            field_dict["status"] = status
        if build_path is not UNSET:
            field_dict["buildPath"] = build_path
        if priority is not UNSET:
            field_dict["priority"] = priority
        if assignee is not UNSET:
            field_dict["assignee"] = assignee
        if story_points is not UNSET:
            field_dict["storyPoints"] = story_points
        if build_sequence_number is not UNSET:
            field_dict["buildSequenceNumber"] = build_sequence_number
        if story_id is not UNSET:
            field_dict["storyId"] = story_id
        if acceptance_criteria is not UNSET:
            field_dict["acceptanceCriteria"] = acceptance_criteria
        if design_objects is not UNSET:
            field_dict["designObjects"] = design_objects

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.design_object_ref import DesignObjectRef

        d = dict(src_dict)
        name = d.pop("name")

        _uuid = d.pop("uuid", UNSET)
        uuid: UUID | Unset
        if isinstance(_uuid, Unset):
            uuid = UNSET
        else:
            uuid = UUID(_uuid)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_persona(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        persona = _parse_persona(d.pop("persona", UNSET))

        _action_type = d.pop("actionType", UNSET)
        action_type: RequirementActionActionType | Unset
        if isinstance(_action_type, Unset):
            action_type = UNSET
        else:
            action_type = RequirementActionActionType(_action_type)

        _status = d.pop("status", UNSET)
        status: RequirementActionStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = RequirementActionStatus(_status)

        _build_path = d.pop("buildPath", UNSET)
        build_path: RequirementActionBuildPath | Unset
        if isinstance(_build_path, Unset):
            build_path = UNSET
        else:
            build_path = RequirementActionBuildPath(_build_path)

        _priority = d.pop("priority", UNSET)
        priority: RequirementActionPriority | Unset
        if isinstance(_priority, Unset):
            priority = UNSET
        else:
            priority = RequirementActionPriority(_priority)

        def _parse_assignee(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        assignee = _parse_assignee(d.pop("assignee", UNSET))

        def _parse_story_points(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        story_points = _parse_story_points(d.pop("storyPoints", UNSET))

        def _parse_build_sequence_number(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        build_sequence_number = _parse_build_sequence_number(d.pop("buildSequenceNumber", UNSET))

        def _parse_story_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        story_id = _parse_story_id(d.pop("storyId", UNSET))

        def _parse_acceptance_criteria(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        acceptance_criteria = _parse_acceptance_criteria(d.pop("acceptanceCriteria", UNSET))

        _design_objects = d.pop("designObjects", UNSET)
        design_objects: list[DesignObjectRef] | Unset = UNSET
        if _design_objects is not UNSET:
            design_objects = []
            for design_objects_item_data in _design_objects:
                design_objects_item = DesignObjectRef.from_dict(design_objects_item_data)

                design_objects.append(design_objects_item)

        requirement_action = cls(
            name=name,
            uuid=uuid,
            description=description,
            persona=persona,
            action_type=action_type,
            status=status,
            build_path=build_path,
            priority=priority,
            assignee=assignee,
            story_points=story_points,
            build_sequence_number=build_sequence_number,
            story_id=story_id,
            acceptance_criteria=acceptance_criteria,
            design_objects=design_objects,
        )

        requirement_action.additional_properties = d
        return requirement_action

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
