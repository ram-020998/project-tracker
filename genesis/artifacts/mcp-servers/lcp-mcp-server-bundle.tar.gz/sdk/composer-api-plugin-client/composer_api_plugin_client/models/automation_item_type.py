from enum import Enum


class AutomationItemType(str, Enum):
    AGENT = "AGENT"
    AI_SKILL = "AI_SKILL"
    RPA = "RPA"

    def __str__(self) -> str:
        return str(self.value)
