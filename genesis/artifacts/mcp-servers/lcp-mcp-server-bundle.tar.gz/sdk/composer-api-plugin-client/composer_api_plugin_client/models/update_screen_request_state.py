from enum import Enum


class UpdateScreenRequestState(str, Enum):
    COMPLETED = "completed"
    FAILED = "failed"
    GENERATING = "generating"
    PENDING = "pending"
    VALIDATING = "validating"

    def __str__(self) -> str:
        return str(self.value)
