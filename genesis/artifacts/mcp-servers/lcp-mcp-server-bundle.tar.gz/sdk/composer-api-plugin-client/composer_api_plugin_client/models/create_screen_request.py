from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_screen_request_archetype import CreateScreenRequestArchetype
from ..models.create_screen_request_state import CreateScreenRequestState
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.design_object_ref import DesignObjectRef


T = TypeVar("T", bound="CreateScreenRequest")


@_attrs_define
class CreateScreenRequest:
    """
    Attributes:
        name (str):
        is_site_page (bool):
        uuid (None | Unset | UUID): Optional screen UUID. If not provided, one will be auto-generated.
        description (None | str | Unset):
        state (CreateScreenRequestState | Unset):
        site_order (int | None | Unset):
        archetype (CreateScreenRequestArchetype | Unset):
        job_id (None | Unset | UUID):
        design_object_refs (list[DesignObjectRef] | None | Unset):
        sail_code (None | str | Unset): SAIL code for the screen
    """

    name: str
    is_site_page: bool
    uuid: None | Unset | UUID = UNSET
    description: None | str | Unset = UNSET
    state: CreateScreenRequestState | Unset = UNSET
    site_order: int | None | Unset = UNSET
    archetype: CreateScreenRequestArchetype | Unset = UNSET
    job_id: None | Unset | UUID = UNSET
    design_object_refs: list[DesignObjectRef] | None | Unset = UNSET
    sail_code: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        is_site_page = self.is_site_page

        uuid: None | str | Unset
        if isinstance(self.uuid, Unset):
            uuid = UNSET
        elif isinstance(self.uuid, UUID):
            uuid = str(self.uuid)
        else:
            uuid = self.uuid

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        state: str | Unset = UNSET
        if not isinstance(self.state, Unset):
            state = self.state.value

        site_order: int | None | Unset
        if isinstance(self.site_order, Unset):
            site_order = UNSET
        else:
            site_order = self.site_order

        archetype: str | Unset = UNSET
        if not isinstance(self.archetype, Unset):
            archetype = self.archetype.value

        job_id: None | str | Unset
        if isinstance(self.job_id, Unset):
            job_id = UNSET
        elif isinstance(self.job_id, UUID):
            job_id = str(self.job_id)
        else:
            job_id = self.job_id

        design_object_refs: list[dict[str, Any]] | None | Unset
        if isinstance(self.design_object_refs, Unset):
            design_object_refs = UNSET
        elif isinstance(self.design_object_refs, list):
            design_object_refs = []
            for design_object_refs_type_0_item_data in self.design_object_refs:
                design_object_refs_type_0_item = design_object_refs_type_0_item_data.to_dict()
                design_object_refs.append(design_object_refs_type_0_item)

        else:
            design_object_refs = self.design_object_refs

        sail_code: None | str | Unset
        if isinstance(self.sail_code, Unset):
            sail_code = UNSET
        else:
            sail_code = self.sail_code

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "isSitePage": is_site_page,
            }
        )
        if uuid is not UNSET:
            field_dict["uuid"] = uuid
        if description is not UNSET:
            field_dict["description"] = description
        if state is not UNSET:
            field_dict["state"] = state
        if site_order is not UNSET:
            field_dict["siteOrder"] = site_order
        if archetype is not UNSET:
            field_dict["archetype"] = archetype
        if job_id is not UNSET:
            field_dict["jobId"] = job_id
        if design_object_refs is not UNSET:
            field_dict["designObjectRefs"] = design_object_refs
        if sail_code is not UNSET:
            field_dict["sailCode"] = sail_code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.design_object_ref import DesignObjectRef

        d = dict(src_dict)
        name = d.pop("name")

        is_site_page = d.pop("isSitePage")

        def _parse_uuid(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                uuid_type_0 = UUID(data)

                return uuid_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        uuid = _parse_uuid(d.pop("uuid", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        _state = d.pop("state", UNSET)
        state: CreateScreenRequestState | Unset
        if isinstance(_state, Unset):
            state = UNSET
        else:
            state = CreateScreenRequestState(_state)

        def _parse_site_order(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        site_order = _parse_site_order(d.pop("siteOrder", UNSET))

        _archetype = d.pop("archetype", UNSET)
        archetype: CreateScreenRequestArchetype | Unset
        if isinstance(_archetype, Unset):
            archetype = UNSET
        else:
            archetype = CreateScreenRequestArchetype(_archetype)

        def _parse_job_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                job_id_type_0 = UUID(data)

                return job_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        job_id = _parse_job_id(d.pop("jobId", UNSET))

        def _parse_design_object_refs(data: object) -> list[DesignObjectRef] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                design_object_refs_type_0 = []
                _design_object_refs_type_0 = data
                for design_object_refs_type_0_item_data in _design_object_refs_type_0:
                    design_object_refs_type_0_item = DesignObjectRef.from_dict(design_object_refs_type_0_item_data)

                    design_object_refs_type_0.append(design_object_refs_type_0_item)

                return design_object_refs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DesignObjectRef] | None | Unset, data)

        design_object_refs = _parse_design_object_refs(d.pop("designObjectRefs", UNSET))

        def _parse_sail_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sail_code = _parse_sail_code(d.pop("sailCode", UNSET))

        create_screen_request = cls(
            name=name,
            is_site_page=is_site_page,
            uuid=uuid,
            description=description,
            state=state,
            site_order=site_order,
            archetype=archetype,
            job_id=job_id,
            design_object_refs=design_object_refs,
            sail_code=sail_code,
        )

        create_screen_request.additional_properties = d
        return create_screen_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
