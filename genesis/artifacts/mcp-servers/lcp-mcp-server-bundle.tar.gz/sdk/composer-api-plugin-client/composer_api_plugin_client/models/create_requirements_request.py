from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_requirements_request_status import CreateRequirementsRequestStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.requirement_activity import RequirementActivity


T = TypeVar("T", bound="CreateRequirementsRequest")


@_attrs_define
class CreateRequirementsRequest:
    """
    Attributes:
        status (CreateRequirementsRequestStatus):
        activities (list[RequirementActivity] | None | Unset):
    """

    status: CreateRequirementsRequestStatus
    activities: list[RequirementActivity] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        status = self.status.value

        activities: list[dict[str, Any]] | None | Unset
        if isinstance(self.activities, Unset):
            activities = UNSET
        elif isinstance(self.activities, list):
            activities = []
            for activities_type_0_item_data in self.activities:
                activities_type_0_item = activities_type_0_item_data.to_dict()
                activities.append(activities_type_0_item)

        else:
            activities = self.activities

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
            }
        )
        if activities is not UNSET:
            field_dict["activities"] = activities

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.requirement_activity import RequirementActivity

        d = dict(src_dict)
        status = CreateRequirementsRequestStatus(d.pop("status"))

        def _parse_activities(data: object) -> list[RequirementActivity] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                activities_type_0 = []
                _activities_type_0 = data
                for activities_type_0_item_data in _activities_type_0:
                    activities_type_0_item = RequirementActivity.from_dict(activities_type_0_item_data)

                    activities_type_0.append(activities_type_0_item)

                return activities_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[RequirementActivity] | None | Unset, data)

        activities = _parse_activities(d.pop("activities", UNSET))

        create_requirements_request = cls(
            status=status,
            activities=activities,
        )

        create_requirements_request.additional_properties = d
        return create_requirements_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
