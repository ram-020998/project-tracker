from enum import Enum


class CreateAutomationRequestStatus(str, Enum):
    COMPLETED = "completed"
    DRAFT = "draft"

    def __str__(self) -> str:
        return str(self.value)
