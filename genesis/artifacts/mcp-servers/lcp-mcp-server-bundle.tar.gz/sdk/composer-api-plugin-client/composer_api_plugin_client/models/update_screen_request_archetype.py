from enum import Enum


class UpdateScreenRequestArchetype(str, Enum):
    CUSTOM = "custom"
    DASHBOARD = "dashboard"
    FORM = "form"
    LIST = "list"
    SUMMARY = "summary"

    def __str__(self) -> str:
        return str(self.value)
