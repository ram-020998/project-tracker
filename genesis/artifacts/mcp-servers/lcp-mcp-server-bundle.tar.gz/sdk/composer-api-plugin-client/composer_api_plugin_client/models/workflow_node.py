from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.workflow_node_activity_type import WorkflowNodeActivityType
from ..models.workflow_node_type import WorkflowNodeType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.edge_label import EdgeLabel


T = TypeVar("T", bound="WorkflowNode")


@_attrs_define
class WorkflowNode:
    """
    Attributes:
        id (str):
        label (str):
        type_ (WorkflowNodeType):
        index (int):
        activity_type (WorkflowNodeActivityType | Unset):
        description (None | str | Unset):
        swimlane_id (None | str | Unset):
        edge_labels (list[EdgeLabel] | None | Unset):
    """

    id: str
    label: str
    type_: WorkflowNodeType
    index: int
    activity_type: WorkflowNodeActivityType | Unset = UNSET
    description: None | str | Unset = UNSET
    swimlane_id: None | str | Unset = UNSET
    edge_labels: list[EdgeLabel] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        label = self.label

        type_ = self.type_.value

        index = self.index

        activity_type: str | Unset = UNSET
        if not isinstance(self.activity_type, Unset):
            activity_type = self.activity_type.value

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        swimlane_id: None | str | Unset
        if isinstance(self.swimlane_id, Unset):
            swimlane_id = UNSET
        else:
            swimlane_id = self.swimlane_id

        edge_labels: list[dict[str, Any]] | None | Unset
        if isinstance(self.edge_labels, Unset):
            edge_labels = UNSET
        elif isinstance(self.edge_labels, list):
            edge_labels = []
            for edge_labels_type_0_item_data in self.edge_labels:
                edge_labels_type_0_item = edge_labels_type_0_item_data.to_dict()
                edge_labels.append(edge_labels_type_0_item)

        else:
            edge_labels = self.edge_labels

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "label": label,
                "type": type_,
                "index": index,
            }
        )
        if activity_type is not UNSET:
            field_dict["activityType"] = activity_type
        if description is not UNSET:
            field_dict["description"] = description
        if swimlane_id is not UNSET:
            field_dict["swimlaneId"] = swimlane_id
        if edge_labels is not UNSET:
            field_dict["edgeLabels"] = edge_labels

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.edge_label import EdgeLabel

        d = dict(src_dict)
        id = d.pop("id")

        label = d.pop("label")

        type_ = WorkflowNodeType(d.pop("type"))

        index = d.pop("index")

        _activity_type = d.pop("activityType", UNSET)
        activity_type: WorkflowNodeActivityType | Unset
        if isinstance(_activity_type, Unset):
            activity_type = UNSET
        else:
            activity_type = WorkflowNodeActivityType(_activity_type)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_swimlane_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        swimlane_id = _parse_swimlane_id(d.pop("swimlaneId", UNSET))

        def _parse_edge_labels(data: object) -> list[EdgeLabel] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                edge_labels_type_0 = []
                _edge_labels_type_0 = data
                for edge_labels_type_0_item_data in _edge_labels_type_0:
                    edge_labels_type_0_item = EdgeLabel.from_dict(edge_labels_type_0_item_data)

                    edge_labels_type_0.append(edge_labels_type_0_item)

                return edge_labels_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[EdgeLabel] | None | Unset, data)

        edge_labels = _parse_edge_labels(d.pop("edgeLabels", UNSET))

        workflow_node = cls(
            id=id,
            label=label,
            type_=type_,
            index=index,
            activity_type=activity_type,
            description=description,
            swimlane_id=swimlane_id,
            edge_labels=edge_labels,
        )

        workflow_node.additional_properties = d
        return workflow_node

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
