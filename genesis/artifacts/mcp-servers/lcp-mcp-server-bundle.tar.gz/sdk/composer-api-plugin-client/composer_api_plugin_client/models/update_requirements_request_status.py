from enum import Enum


class UpdateRequirementsRequestStatus(str, Enum):
    EDITING = "EDITING"
    INIT_FROM_TEMPLATE = "INIT_FROM_TEMPLATE"
    NEW = "NEW"

    def __str__(self) -> str:
        return str(self.value)
