from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.user_story_detail_status import UserStoryDetailStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="UserStoryDetail")


@_attrs_define
class UserStoryDetail:
    """
    Attributes:
        id (str | Unset):
        name (str | Unset):
        description (None | str | Unset):
        acceptance_criteria (None | str | Unset):
        status (UserStoryDetailStatus | Unset):
        story_id (None | str | Unset): External issue key (e.g. Jira)
        parent_id (str | Unset): Parent activity (epic) ID
    """

    id: str | Unset = UNSET
    name: str | Unset = UNSET
    description: None | str | Unset = UNSET
    acceptance_criteria: None | str | Unset = UNSET
    status: UserStoryDetailStatus | Unset = UNSET
    story_id: None | str | Unset = UNSET
    parent_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        acceptance_criteria: None | str | Unset
        if isinstance(self.acceptance_criteria, Unset):
            acceptance_criteria = UNSET
        else:
            acceptance_criteria = self.acceptance_criteria

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        story_id: None | str | Unset
        if isinstance(self.story_id, Unset):
            story_id = UNSET
        else:
            story_id = self.story_id

        parent_id = self.parent_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if acceptance_criteria is not UNSET:
            field_dict["acceptanceCriteria"] = acceptance_criteria
        if status is not UNSET:
            field_dict["status"] = status
        if story_id is not UNSET:
            field_dict["storyId"] = story_id
        if parent_id is not UNSET:
            field_dict["parentId"] = parent_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        name = d.pop("name", UNSET)

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_acceptance_criteria(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        acceptance_criteria = _parse_acceptance_criteria(d.pop("acceptanceCriteria", UNSET))

        _status = d.pop("status", UNSET)
        status: UserStoryDetailStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = UserStoryDetailStatus(_status)

        def _parse_story_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        story_id = _parse_story_id(d.pop("storyId", UNSET))

        parent_id = d.pop("parentId", UNSET)

        user_story_detail = cls(
            id=id,
            name=name,
            description=description,
            acceptance_criteria=acceptance_criteria,
            status=status,
            story_id=story_id,
            parent_id=parent_id,
        )

        user_story_detail.additional_properties = d
        return user_story_detail

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
