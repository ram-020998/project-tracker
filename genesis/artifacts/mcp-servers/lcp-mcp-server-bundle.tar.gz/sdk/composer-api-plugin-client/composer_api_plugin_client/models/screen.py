from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.screen_archetype import ScreenArchetype
from ..models.screen_state import ScreenState
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.design_object_ref import DesignObjectRef


T = TypeVar("T", bound="Screen")


@_attrs_define
class Screen:
    """
    Attributes:
        id (UUID):
        name (str):
        state (ScreenState):
        is_site_page (bool):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        description (None | str | Unset):
        sail_code (None | str | Unset):
        error_message (None | str | Unset):
        site_order (int | None | Unset):
        archetype (ScreenArchetype | Unset):
        thumbnail_url (None | str | Unset):
        job_id (None | Unset | UUID):
        design_object_refs (list[DesignObjectRef] | None | Unset):
    """

    id: UUID
    name: str
    state: ScreenState
    is_site_page: bool
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    sail_code: None | str | Unset = UNSET
    error_message: None | str | Unset = UNSET
    site_order: int | None | Unset = UNSET
    archetype: ScreenArchetype | Unset = UNSET
    thumbnail_url: None | str | Unset = UNSET
    job_id: None | Unset | UUID = UNSET
    design_object_refs: list[DesignObjectRef] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        name = self.name

        state = self.state.value

        is_site_page = self.is_site_page

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        sail_code: None | str | Unset
        if isinstance(self.sail_code, Unset):
            sail_code = UNSET
        else:
            sail_code = self.sail_code

        error_message: None | str | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        site_order: int | None | Unset
        if isinstance(self.site_order, Unset):
            site_order = UNSET
        else:
            site_order = self.site_order

        archetype: str | Unset = UNSET
        if not isinstance(self.archetype, Unset):
            archetype = self.archetype.value

        thumbnail_url: None | str | Unset
        if isinstance(self.thumbnail_url, Unset):
            thumbnail_url = UNSET
        else:
            thumbnail_url = self.thumbnail_url

        job_id: None | str | Unset
        if isinstance(self.job_id, Unset):
            job_id = UNSET
        elif isinstance(self.job_id, UUID):
            job_id = str(self.job_id)
        else:
            job_id = self.job_id

        design_object_refs: list[dict[str, Any]] | None | Unset
        if isinstance(self.design_object_refs, Unset):
            design_object_refs = UNSET
        elif isinstance(self.design_object_refs, list):
            design_object_refs = []
            for design_object_refs_type_0_item_data in self.design_object_refs:
                design_object_refs_type_0_item = design_object_refs_type_0_item_data.to_dict()
                design_object_refs.append(design_object_refs_type_0_item)

        else:
            design_object_refs = self.design_object_refs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "state": state,
                "isSitePage": is_site_page,
                "createdAt": created_at,
                "updatedAt": updated_at,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if sail_code is not UNSET:
            field_dict["sailCode"] = sail_code
        if error_message is not UNSET:
            field_dict["errorMessage"] = error_message
        if site_order is not UNSET:
            field_dict["siteOrder"] = site_order
        if archetype is not UNSET:
            field_dict["archetype"] = archetype
        if thumbnail_url is not UNSET:
            field_dict["thumbnailUrl"] = thumbnail_url
        if job_id is not UNSET:
            field_dict["jobId"] = job_id
        if design_object_refs is not UNSET:
            field_dict["designObjectRefs"] = design_object_refs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.design_object_ref import DesignObjectRef

        d = dict(src_dict)
        id = UUID(d.pop("id"))

        name = d.pop("name")

        state = ScreenState(d.pop("state"))

        is_site_page = d.pop("isSitePage")

        created_at = datetime.datetime.fromisoformat(d.pop("createdAt"))

        updated_at = datetime.datetime.fromisoformat(d.pop("updatedAt"))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_sail_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sail_code = _parse_sail_code(d.pop("sailCode", UNSET))

        def _parse_error_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_message = _parse_error_message(d.pop("errorMessage", UNSET))

        def _parse_site_order(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        site_order = _parse_site_order(d.pop("siteOrder", UNSET))

        _archetype = d.pop("archetype", UNSET)
        archetype: ScreenArchetype | Unset
        if isinstance(_archetype, Unset):
            archetype = UNSET
        else:
            archetype = ScreenArchetype(_archetype)

        def _parse_thumbnail_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        thumbnail_url = _parse_thumbnail_url(d.pop("thumbnailUrl", UNSET))

        def _parse_job_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                job_id_type_0 = UUID(data)

                return job_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        job_id = _parse_job_id(d.pop("jobId", UNSET))

        def _parse_design_object_refs(data: object) -> list[DesignObjectRef] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                design_object_refs_type_0 = []
                _design_object_refs_type_0 = data
                for design_object_refs_type_0_item_data in _design_object_refs_type_0:
                    design_object_refs_type_0_item = DesignObjectRef.from_dict(design_object_refs_type_0_item_data)

                    design_object_refs_type_0.append(design_object_refs_type_0_item)

                return design_object_refs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DesignObjectRef] | None | Unset, data)

        design_object_refs = _parse_design_object_refs(d.pop("designObjectRefs", UNSET))

        screen = cls(
            id=id,
            name=name,
            state=state,
            is_site_page=is_site_page,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            sail_code=sail_code,
            error_message=error_message,
            site_order=site_order,
            archetype=archetype,
            thumbnail_url=thumbnail_url,
            job_id=job_id,
            design_object_refs=design_object_refs,
        )

        screen.additional_properties = d
        return screen

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
