from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_entity_attribute_request_type import CreateEntityAttributeRequestType
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateEntityAttributeRequest")


@_attrs_define
class CreateEntityAttributeRequest:
    """
    Attributes:
        name (str):
        type_ (CreateEntityAttributeRequestType):
        is_primary_key (bool | Unset):  Default: False.
        is_unique (bool | Unset):  Default: False.
        sort_order (int | None | Unset):
    """

    name: str
    type_: CreateEntityAttributeRequestType
    is_primary_key: bool | Unset = False
    is_unique: bool | Unset = False
    sort_order: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        type_ = self.type_.value

        is_primary_key = self.is_primary_key

        is_unique = self.is_unique

        sort_order: int | None | Unset
        if isinstance(self.sort_order, Unset):
            sort_order = UNSET
        else:
            sort_order = self.sort_order

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "type": type_,
            }
        )
        if is_primary_key is not UNSET:
            field_dict["isPrimaryKey"] = is_primary_key
        if is_unique is not UNSET:
            field_dict["isUnique"] = is_unique
        if sort_order is not UNSET:
            field_dict["sortOrder"] = sort_order

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        type_ = CreateEntityAttributeRequestType(d.pop("type"))

        is_primary_key = d.pop("isPrimaryKey", UNSET)

        is_unique = d.pop("isUnique", UNSET)

        def _parse_sort_order(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        sort_order = _parse_sort_order(d.pop("sortOrder", UNSET))

        create_entity_attribute_request = cls(
            name=name,
            type_=type_,
            is_primary_key=is_primary_key,
            is_unique=is_unique,
            sort_order=sort_order,
        )

        create_entity_attribute_request.additional_properties = d
        return create_entity_attribute_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
