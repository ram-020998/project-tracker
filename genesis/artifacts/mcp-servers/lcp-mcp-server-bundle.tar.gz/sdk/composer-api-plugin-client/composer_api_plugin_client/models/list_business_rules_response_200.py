from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.business_rule import BusinessRule


T = TypeVar("T", bound="ListBusinessRulesResponse200")


@_attrs_define
class ListBusinessRulesResponse200:
    """
    Attributes:
        business_rules (list[BusinessRule] | Unset):
    """

    business_rules: list[BusinessRule] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        business_rules: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.business_rules, Unset):
            business_rules = []
            for business_rules_item_data in self.business_rules:
                business_rules_item = business_rules_item_data.to_dict()
                business_rules.append(business_rules_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if business_rules is not UNSET:
            field_dict["businessRules"] = business_rules

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.business_rule import BusinessRule

        d = dict(src_dict)
        _business_rules = d.pop("businessRules", UNSET)
        business_rules: list[BusinessRule] | Unset = UNSET
        if _business_rules is not UNSET:
            business_rules = []
            for business_rules_item_data in _business_rules:
                business_rules_item = BusinessRule.from_dict(business_rules_item_data)

                business_rules.append(business_rules_item)

        list_business_rules_response_200 = cls(
            business_rules=business_rules,
        )

        list_business_rules_response_200.additional_properties = d
        return list_business_rules_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
