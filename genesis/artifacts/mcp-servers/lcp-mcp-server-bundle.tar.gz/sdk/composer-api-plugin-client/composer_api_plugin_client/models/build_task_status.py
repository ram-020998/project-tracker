from enum import Enum


class BuildTaskStatus(str, Enum):
    COMPLETED = "COMPLETED"
    IN_PROGRESS = "IN_PROGRESS"
    PENDING = "PENDING"

    def __str__(self) -> str:
        return str(self.value)
