from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.build_task_status import BuildTaskStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.build_task_design_object_ref import BuildTaskDesignObjectRef


T = TypeVar("T", bound="BuildTask")


@_attrs_define
class BuildTask:
    """
    Attributes:
        uuid (UUID):
        story_id (str):
        task_index (int):
        description (str):
        modifies_object (bool):
        status (BuildTaskStatus):
        created_at (int):
        updated_at (int):
        object_type (None | str | Unset):
        object_name (None | str | Unset):
        object_uuid (None | str | Unset):
        implementation_notes (None | str | Unset):
        execution_source (None | str | Unset):
        depends_on_json (None | str | Unset):
        result_json (None | str | Unset):
        discovered_context_json (None | str | Unset):
        tool (None | str | Unset):
        design_object_refs (list[BuildTaskDesignObjectRef] | None | Unset):
    """

    uuid: UUID
    story_id: str
    task_index: int
    description: str
    modifies_object: bool
    status: BuildTaskStatus
    created_at: int
    updated_at: int
    object_type: None | str | Unset = UNSET
    object_name: None | str | Unset = UNSET
    object_uuid: None | str | Unset = UNSET
    implementation_notes: None | str | Unset = UNSET
    execution_source: None | str | Unset = UNSET
    depends_on_json: None | str | Unset = UNSET
    result_json: None | str | Unset = UNSET
    discovered_context_json: None | str | Unset = UNSET
    tool: None | str | Unset = UNSET
    design_object_refs: list[BuildTaskDesignObjectRef] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = str(self.uuid)

        story_id = self.story_id

        task_index = self.task_index

        description = self.description

        modifies_object = self.modifies_object

        status = self.status.value

        created_at = self.created_at

        updated_at = self.updated_at

        object_type: None | str | Unset
        if isinstance(self.object_type, Unset):
            object_type = UNSET
        else:
            object_type = self.object_type

        object_name: None | str | Unset
        if isinstance(self.object_name, Unset):
            object_name = UNSET
        else:
            object_name = self.object_name

        object_uuid: None | str | Unset
        if isinstance(self.object_uuid, Unset):
            object_uuid = UNSET
        else:
            object_uuid = self.object_uuid

        implementation_notes: None | str | Unset
        if isinstance(self.implementation_notes, Unset):
            implementation_notes = UNSET
        else:
            implementation_notes = self.implementation_notes

        execution_source: None | str | Unset
        if isinstance(self.execution_source, Unset):
            execution_source = UNSET
        else:
            execution_source = self.execution_source

        depends_on_json: None | str | Unset
        if isinstance(self.depends_on_json, Unset):
            depends_on_json = UNSET
        else:
            depends_on_json = self.depends_on_json

        result_json: None | str | Unset
        if isinstance(self.result_json, Unset):
            result_json = UNSET
        else:
            result_json = self.result_json

        discovered_context_json: None | str | Unset
        if isinstance(self.discovered_context_json, Unset):
            discovered_context_json = UNSET
        else:
            discovered_context_json = self.discovered_context_json

        tool: None | str | Unset
        if isinstance(self.tool, Unset):
            tool = UNSET
        else:
            tool = self.tool

        design_object_refs: list[dict[str, Any]] | None | Unset
        if isinstance(self.design_object_refs, Unset):
            design_object_refs = UNSET
        elif isinstance(self.design_object_refs, list):
            design_object_refs = []
            for design_object_refs_type_0_item_data in self.design_object_refs:
                design_object_refs_type_0_item = design_object_refs_type_0_item_data.to_dict()
                design_object_refs.append(design_object_refs_type_0_item)

        else:
            design_object_refs = self.design_object_refs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "storyId": story_id,
                "taskIndex": task_index,
                "description": description,
                "modifiesObject": modifies_object,
                "status": status,
                "createdAt": created_at,
                "updatedAt": updated_at,
            }
        )
        if object_type is not UNSET:
            field_dict["objectType"] = object_type
        if object_name is not UNSET:
            field_dict["objectName"] = object_name
        if object_uuid is not UNSET:
            field_dict["objectUuid"] = object_uuid
        if implementation_notes is not UNSET:
            field_dict["implementationNotes"] = implementation_notes
        if execution_source is not UNSET:
            field_dict["executionSource"] = execution_source
        if depends_on_json is not UNSET:
            field_dict["dependsOnJson"] = depends_on_json
        if result_json is not UNSET:
            field_dict["resultJson"] = result_json
        if discovered_context_json is not UNSET:
            field_dict["discoveredContextJson"] = discovered_context_json
        if tool is not UNSET:
            field_dict["tool"] = tool
        if design_object_refs is not UNSET:
            field_dict["designObjectRefs"] = design_object_refs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.build_task_design_object_ref import BuildTaskDesignObjectRef

        d = dict(src_dict)
        uuid = UUID(d.pop("uuid"))

        story_id = d.pop("storyId")

        task_index = d.pop("taskIndex")

        description = d.pop("description")

        modifies_object = d.pop("modifiesObject")

        status = BuildTaskStatus(d.pop("status"))

        created_at = d.pop("createdAt")

        updated_at = d.pop("updatedAt")

        def _parse_object_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        object_type = _parse_object_type(d.pop("objectType", UNSET))

        def _parse_object_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        object_name = _parse_object_name(d.pop("objectName", UNSET))

        def _parse_object_uuid(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        object_uuid = _parse_object_uuid(d.pop("objectUuid", UNSET))

        def _parse_implementation_notes(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        implementation_notes = _parse_implementation_notes(d.pop("implementationNotes", UNSET))

        def _parse_execution_source(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        execution_source = _parse_execution_source(d.pop("executionSource", UNSET))

        def _parse_depends_on_json(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        depends_on_json = _parse_depends_on_json(d.pop("dependsOnJson", UNSET))

        def _parse_result_json(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        result_json = _parse_result_json(d.pop("resultJson", UNSET))

        def _parse_discovered_context_json(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        discovered_context_json = _parse_discovered_context_json(d.pop("discoveredContextJson", UNSET))

        def _parse_tool(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tool = _parse_tool(d.pop("tool", UNSET))

        def _parse_design_object_refs(data: object) -> list[BuildTaskDesignObjectRef] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                design_object_refs_type_0 = []
                _design_object_refs_type_0 = data
                for design_object_refs_type_0_item_data in _design_object_refs_type_0:
                    design_object_refs_type_0_item = BuildTaskDesignObjectRef.from_dict(
                        design_object_refs_type_0_item_data
                    )

                    design_object_refs_type_0.append(design_object_refs_type_0_item)

                return design_object_refs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[BuildTaskDesignObjectRef] | None | Unset, data)

        design_object_refs = _parse_design_object_refs(d.pop("designObjectRefs", UNSET))

        build_task = cls(
            uuid=uuid,
            story_id=story_id,
            task_index=task_index,
            description=description,
            modifies_object=modifies_object,
            status=status,
            created_at=created_at,
            updated_at=updated_at,
            object_type=object_type,
            object_name=object_name,
            object_uuid=object_uuid,
            implementation_notes=implementation_notes,
            execution_source=execution_source,
            depends_on_json=depends_on_json,
            result_json=result_json,
            discovered_context_json=discovered_context_json,
            tool=tool,
            design_object_refs=design_object_refs,
        )

        build_task.additional_properties = d
        return build_task

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
