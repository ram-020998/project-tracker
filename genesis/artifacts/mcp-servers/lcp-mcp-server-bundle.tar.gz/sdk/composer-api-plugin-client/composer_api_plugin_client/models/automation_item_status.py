from enum import Enum


class AutomationItemStatus(str, Enum):
    COMPLETED = "completed"
    DRAFT = "draft"

    def __str__(self) -> str:
        return str(self.value)
