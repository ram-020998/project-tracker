from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.create_entity_attribute_request import CreateEntityAttributeRequest
    from ..models.design_object_ref import DesignObjectRef


T = TypeVar("T", bound="CreateDataModelEntityRequest")


@_attrs_define
class CreateDataModelEntityRequest:
    """
    Attributes:
        name (str):
        attributes (list[CreateEntityAttributeRequest] | None | Unset):
        design_object_refs (list[DesignObjectRef] | None | Unset):
    """

    name: str
    attributes: list[CreateEntityAttributeRequest] | None | Unset = UNSET
    design_object_refs: list[DesignObjectRef] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        attributes: list[dict[str, Any]] | None | Unset
        if isinstance(self.attributes, Unset):
            attributes = UNSET
        elif isinstance(self.attributes, list):
            attributes = []
            for attributes_type_0_item_data in self.attributes:
                attributes_type_0_item = attributes_type_0_item_data.to_dict()
                attributes.append(attributes_type_0_item)

        else:
            attributes = self.attributes

        design_object_refs: list[dict[str, Any]] | None | Unset
        if isinstance(self.design_object_refs, Unset):
            design_object_refs = UNSET
        elif isinstance(self.design_object_refs, list):
            design_object_refs = []
            for design_object_refs_type_0_item_data in self.design_object_refs:
                design_object_refs_type_0_item = design_object_refs_type_0_item_data.to_dict()
                design_object_refs.append(design_object_refs_type_0_item)

        else:
            design_object_refs = self.design_object_refs

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if attributes is not UNSET:
            field_dict["attributes"] = attributes
        if design_object_refs is not UNSET:
            field_dict["designObjectRefs"] = design_object_refs

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_entity_attribute_request import CreateEntityAttributeRequest
        from ..models.design_object_ref import DesignObjectRef

        d = dict(src_dict)
        name = d.pop("name")

        def _parse_attributes(data: object) -> list[CreateEntityAttributeRequest] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                attributes_type_0 = []
                _attributes_type_0 = data
                for attributes_type_0_item_data in _attributes_type_0:
                    attributes_type_0_item = CreateEntityAttributeRequest.from_dict(attributes_type_0_item_data)

                    attributes_type_0.append(attributes_type_0_item)

                return attributes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[CreateEntityAttributeRequest] | None | Unset, data)

        attributes = _parse_attributes(d.pop("attributes", UNSET))

        def _parse_design_object_refs(data: object) -> list[DesignObjectRef] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                design_object_refs_type_0 = []
                _design_object_refs_type_0 = data
                for design_object_refs_type_0_item_data in _design_object_refs_type_0:
                    design_object_refs_type_0_item = DesignObjectRef.from_dict(design_object_refs_type_0_item_data)

                    design_object_refs_type_0.append(design_object_refs_type_0_item)

                return design_object_refs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DesignObjectRef] | None | Unset, data)

        design_object_refs = _parse_design_object_refs(d.pop("designObjectRefs", UNSET))

        create_data_model_entity_request = cls(
            name=name,
            attributes=attributes,
            design_object_refs=design_object_refs,
        )

        create_data_model_entity_request.additional_properties = d
        return create_data_model_entity_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
