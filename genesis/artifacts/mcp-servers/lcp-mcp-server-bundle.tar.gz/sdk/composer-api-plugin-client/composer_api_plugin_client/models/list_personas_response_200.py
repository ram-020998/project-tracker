from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.persona import Persona


T = TypeVar("T", bound="ListPersonasResponse200")


@_attrs_define
class ListPersonasResponse200:
    """
    Attributes:
        personas (list[Persona] | Unset):
    """

    personas: list[Persona] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        personas: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.personas, Unset):
            personas = []
            for personas_item_data in self.personas:
                personas_item = personas_item_data.to_dict()
                personas.append(personas_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if personas is not UNSET:
            field_dict["personas"] = personas

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.persona import Persona

        d = dict(src_dict)
        _personas = d.pop("personas", UNSET)
        personas: list[Persona] | Unset = UNSET
        if _personas is not UNSET:
            personas = []
            for personas_item_data in _personas:
                personas_item = Persona.from_dict(personas_item_data)

                personas.append(personas_item)

        list_personas_response_200 = cls(
            personas=personas,
        )

        list_personas_response_200.additional_properties = d
        return list_personas_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
