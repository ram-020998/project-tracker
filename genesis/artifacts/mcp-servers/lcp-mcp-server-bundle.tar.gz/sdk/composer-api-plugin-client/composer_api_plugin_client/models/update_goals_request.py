from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.goal import Goal


T = TypeVar("T", bound="UpdateGoalsRequest")


@_attrs_define
class UpdateGoalsRequest:
    """
    Attributes:
        goals (list[Goal]):
    """

    goals: list[Goal]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        goals = []
        for goals_item_data in self.goals:
            goals_item = goals_item_data.to_dict()
            goals.append(goals_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "goals": goals,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.goal import Goal

        d = dict(src_dict)
        goals = []
        _goals = d.pop("goals")
        for goals_item_data in _goals:
            goals_item = Goal.from_dict(goals_item_data)

            goals.append(goals_item)

        update_goals_request = cls(
            goals=goals,
        )

        update_goals_request.additional_properties = d
        return update_goals_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
