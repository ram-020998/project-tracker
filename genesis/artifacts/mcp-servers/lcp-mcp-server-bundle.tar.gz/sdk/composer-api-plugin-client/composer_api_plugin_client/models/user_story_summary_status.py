from enum import Enum


class UserStorySummaryStatus(str, Enum):
    COMPLETED = "COMPLETED"
    IN_PROGRESS = "IN_PROGRESS"
    NOT_STARTED = "NOT_STARTED"
    REVIEW = "REVIEW"

    def __str__(self) -> str:
        return str(self.value)
