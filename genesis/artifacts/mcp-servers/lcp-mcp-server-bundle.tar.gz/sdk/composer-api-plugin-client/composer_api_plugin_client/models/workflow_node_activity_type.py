from enum import Enum


class WorkflowNodeActivityType(str, Enum):
    AI = "ai"
    AI_AGENT = "ai_agent"
    GENERAL = "general"
    INTEGRATION = "integration"
    RPA = "rpa"
    USERTASK = "userTask"

    def __str__(self) -> str:
        return str(self.value)
