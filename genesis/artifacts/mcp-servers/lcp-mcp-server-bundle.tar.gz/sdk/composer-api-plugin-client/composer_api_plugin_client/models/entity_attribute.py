from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.entity_attribute_type import EntityAttributeType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.entity_relationship import EntityRelationship


T = TypeVar("T", bound="EntityAttribute")


@_attrs_define
class EntityAttribute:
    """
    Attributes:
        uuid (str):
        name (str):
        type_ (EntityAttributeType):
        is_primary_key (bool | Unset):  Default: False.
        is_unique (bool | Unset):  Default: False.
        sort_order (int | None | Unset):
        outbound_relationships (list[EntityRelationship] | None | Unset):
        inbound_relationships (list[EntityRelationship] | None | Unset):
    """

    uuid: str
    name: str
    type_: EntityAttributeType
    is_primary_key: bool | Unset = False
    is_unique: bool | Unset = False
    sort_order: int | None | Unset = UNSET
    outbound_relationships: list[EntityRelationship] | None | Unset = UNSET
    inbound_relationships: list[EntityRelationship] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uuid = self.uuid

        name = self.name

        type_ = self.type_.value

        is_primary_key = self.is_primary_key

        is_unique = self.is_unique

        sort_order: int | None | Unset
        if isinstance(self.sort_order, Unset):
            sort_order = UNSET
        else:
            sort_order = self.sort_order

        outbound_relationships: list[dict[str, Any]] | None | Unset
        if isinstance(self.outbound_relationships, Unset):
            outbound_relationships = UNSET
        elif isinstance(self.outbound_relationships, list):
            outbound_relationships = []
            for outbound_relationships_type_0_item_data in self.outbound_relationships:
                outbound_relationships_type_0_item = outbound_relationships_type_0_item_data.to_dict()
                outbound_relationships.append(outbound_relationships_type_0_item)

        else:
            outbound_relationships = self.outbound_relationships

        inbound_relationships: list[dict[str, Any]] | None | Unset
        if isinstance(self.inbound_relationships, Unset):
            inbound_relationships = UNSET
        elif isinstance(self.inbound_relationships, list):
            inbound_relationships = []
            for inbound_relationships_type_0_item_data in self.inbound_relationships:
                inbound_relationships_type_0_item = inbound_relationships_type_0_item_data.to_dict()
                inbound_relationships.append(inbound_relationships_type_0_item)

        else:
            inbound_relationships = self.inbound_relationships

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "uuid": uuid,
                "name": name,
                "type": type_,
            }
        )
        if is_primary_key is not UNSET:
            field_dict["isPrimaryKey"] = is_primary_key
        if is_unique is not UNSET:
            field_dict["isUnique"] = is_unique
        if sort_order is not UNSET:
            field_dict["sortOrder"] = sort_order
        if outbound_relationships is not UNSET:
            field_dict["outboundRelationships"] = outbound_relationships
        if inbound_relationships is not UNSET:
            field_dict["inboundRelationships"] = inbound_relationships

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.entity_relationship import EntityRelationship

        d = dict(src_dict)
        uuid = d.pop("uuid")

        name = d.pop("name")

        type_ = EntityAttributeType(d.pop("type"))

        is_primary_key = d.pop("isPrimaryKey", UNSET)

        is_unique = d.pop("isUnique", UNSET)

        def _parse_sort_order(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        sort_order = _parse_sort_order(d.pop("sortOrder", UNSET))

        def _parse_outbound_relationships(data: object) -> list[EntityRelationship] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                outbound_relationships_type_0 = []
                _outbound_relationships_type_0 = data
                for outbound_relationships_type_0_item_data in _outbound_relationships_type_0:
                    outbound_relationships_type_0_item = EntityRelationship.from_dict(
                        outbound_relationships_type_0_item_data
                    )

                    outbound_relationships_type_0.append(outbound_relationships_type_0_item)

                return outbound_relationships_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[EntityRelationship] | None | Unset, data)

        outbound_relationships = _parse_outbound_relationships(d.pop("outboundRelationships", UNSET))

        def _parse_inbound_relationships(data: object) -> list[EntityRelationship] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                inbound_relationships_type_0 = []
                _inbound_relationships_type_0 = data
                for inbound_relationships_type_0_item_data in _inbound_relationships_type_0:
                    inbound_relationships_type_0_item = EntityRelationship.from_dict(
                        inbound_relationships_type_0_item_data
                    )

                    inbound_relationships_type_0.append(inbound_relationships_type_0_item)

                return inbound_relationships_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[EntityRelationship] | None | Unset, data)

        inbound_relationships = _parse_inbound_relationships(d.pop("inboundRelationships", UNSET))

        entity_attribute = cls(
            uuid=uuid,
            name=name,
            type_=type_,
            is_primary_key=is_primary_key,
            is_unique=is_unique,
            sort_order=sort_order,
            outbound_relationships=outbound_relationships,
            inbound_relationships=inbound_relationships,
        )

        entity_attribute.additional_properties = d
        return entity_attribute

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
