"""LCP MCP Server - Explicit MCP tools for Appian LCP design objects."""

__version__ = "0.1.0"
