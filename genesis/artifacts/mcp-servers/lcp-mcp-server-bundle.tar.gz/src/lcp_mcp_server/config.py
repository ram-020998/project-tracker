"""Configuration management for LCP MCP Server."""

import os

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class LCPConfig(BaseSettings):
    """LCP API configuration."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # LCP API URL
    lcp_url: str = ""

    @field_validator("lcp_url")
    @classmethod
    def validate_api_url(cls, v: str) -> str:
        """Strip whitespace from LCP API URL."""
        return v.strip()

    @property
    def base_url(self) -> str:
        """Return full LCP API URL from LCP_URL + LCP_API_PATH."""
        url = self.lcp_url.rstrip("/")
        path = (
            os.environ.get("LCP_API_PATH", "/suite/rest/a/lcp-api/latest")
            .strip()
            .rstrip("/")
        )
        return f"{url}{path}"

    @property
    def beta_base_url(self) -> str:
        """Return full LCP beta API URL."""
        url = self.lcp_url.rstrip("/")
        return f"{url}/suite/lcp/api"

    @property
    def auth_method(self) -> str:
        """Plugin-client auth method: 'basic' (default) or 'browser' (SSO session capture)."""
        return os.environ.get("LCP_AUTH_METHOD", "basic").strip().lower()

    @property
    def signin_path(self) -> str:
        """Sign-in path opened for browser SSO (e.g. '/suite/?signin=my-saml')."""
        return os.environ.get("LCP_SIGNIN_PATH", "/suite/").strip()

    @property
    def cookie_path(self) -> str:
        """Override path for the persisted session-cookie file (browser auth)."""
        return os.environ.get("LCP_COOKIE_PATH", "").strip()

    @property
    def browser_profile_path(self) -> str:
        """Override path for the persistent Chromium profile (browser auth)."""
        return os.environ.get("LCP_BROWSER_PROFILE_PATH", "").strip()

    @property
    def auth_landing_path(self) -> str:
        """Custom post-login landing page path for browser auth.

        Only needed when the Appian instance has a custom default landing page
        that differs from the standard /suite/tempo or /suite/design. The value
        should be the URL path the browser lands on after a successful login,
        e.g. '/suite/sites/my-portal'.
        """
        return os.environ.get("LCP_AUTH_LANDING_PATH", "").strip()
