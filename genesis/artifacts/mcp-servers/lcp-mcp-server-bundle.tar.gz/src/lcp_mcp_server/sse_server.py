#!/usr/bin/env python3
"""SSE server wrapper for LCP MCP server.

Runs the LCP MCP server as an SSE endpoint that can be accessed over HTTP.
External server on /sse.
Internal server on /internal/sse — for sub-agents only.
JSON-RPC proxy on /jsonrpc — for AIP Agents API tool execution.
"""

import logging
import os

import uvicorn
from composer_logging import get_logger
from fastapi import APIRouter, FastAPI
from fastapi.responses import JSONResponse
from opentelemetry import trace
from shared_mcp_utils.jsonrpc import build_jsonrpc_handler
from shared_mcp_utils.middleware import auth_enforcing_asgi_middleware
from shared_mcp_utils.telemetry import (
    ComposerRoute,
    TracingASGIWrapper,
    configure_telemetry,
)

from lcp_mcp_server.config import LCPConfig
from lcp_mcp_server.server import create_lcp_internal_server, create_lcp_mcp_server

logger = get_logger(__name__)

# Ensure shared_mcp_utils logs are visible (uses stdlib logging, not composer_logging)
logging.getLogger("shared_mcp_utils").setLevel(logging.INFO)
logging.getLogger("shared_mcp_utils").addHandler(logging.StreamHandler())


def create_app() -> FastAPI:
    """Create the FastAPI app. Exposed at module level for uvicorn --reload.

    The external SSE app is mounted at both "/" (for internal cluster access) and
    at MOUNT_PREFIX (for ingress access where the path prefix is not stripped).
    """
    configure_telemetry()
    config = LCPConfig()
    external = create_lcp_mcp_server(config)
    internal = create_lcp_internal_server(config)
    mount_prefix = os.getenv("MOUNT_PREFIX", "")

    from contextlib import asynccontextmanager

    from shared_auth_events import LoggingAuthObserver, set_auth_event_observer

    try:
        from shared_kas import cleanup_kas_client, initialize_kas_client

        _has_kas = True
    except ImportError:
        _has_kas = False

    @asynccontextmanager
    async def lifespan(app):
        if _has_kas:
            await initialize_kas_client()
            logger.info("KAS client initialized")
        set_auth_event_observer(LoggingAuthObserver(service_name="lcp-mcp-server"))
        yield
        if _has_kas:
            await cleanup_kas_client()
        # Flush pending trace spans before pod terminates
        provider = trace.get_tracer_provider()
        if hasattr(provider, "force_flush"):
            provider.force_flush(timeout_millis=5000)
        if hasattr(provider, "shutdown"):
            provider.shutdown()

    application = FastAPI(title="lcp-mcp-server", lifespan=lifespan)
    router = APIRouter(route_class=ComposerRoute)

    @router.get("/health")
    async def health():
        return JSONResponse({"status": "healthy", "service": "lcp-mcp-server"})

    router.add_api_route(
        "/jsonrpc", build_jsonrpc_handler(external, server_name="lcp"), methods=["POST"]
    )

    application.include_router(router)
    application.mount(
        "/internal",
        app=TracingASGIWrapper(
            internal.http_app(transport="sse"), service_name="lcp-internal"
        ),
    )
    if mount_prefix:
        application.mount(
            mount_prefix,
            app=TracingASGIWrapper(
                auth_enforcing_asgi_middleware(external.http_app(transport="sse")),
                service_name="lcp",
            ),
        )
    application.mount(
        "/",
        app=TracingASGIWrapper(
            auth_enforcing_asgi_middleware(external.http_app(transport="sse")),
            service_name="lcp",
        ),
    )

    return application


app = create_app()


def main():
    """Run the server directly (for local development)."""
    port = int(os.getenv("LCP_MCP_PORT", "8003"))
    logger.info("Starting LCP MCP SSE server on port %d", port)
    uvicorn.run(
        "lcp_mcp_server.sse_server:app",
        host="0.0.0.0",
        port=port,
        log_level="info",
        timeout_graceful_shutdown=300,
    )


if __name__ == "__main__":
    main()
