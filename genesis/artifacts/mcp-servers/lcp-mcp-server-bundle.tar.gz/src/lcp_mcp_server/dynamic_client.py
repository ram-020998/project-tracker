"""Per-request LCP client that resolves base_url from the ContextVar callback URL."""

import logging
import os

import httpx
from lcp_api_beta_client.client import AuthenticatedClient as LCPAuthenticatedClient
from lcp_api_plugin_client.client import Client as LCPPluginClient
from opentelemetry import trace
from opentelemetry.propagate import inject
from opentelemetry.trace import SpanKind, StatusCode
from shared_mcp_utils.jsonrpc import get_agent_type, get_auth_token, get_callback_url

logger = logging.getLogger(__name__)

_tracer = trace.get_tracer(__name__)
_REQUIRE_CALLBACK_URL = os.environ.get("LCP_REQUIRE_CALLBACK_URL", "").lower() == "true"


def _resolve_base_url(config_base_url: str) -> str:
    """Return the LCP API base URL, preferring the per-request ContextVar.

    Checks two sources:
    1. ContextVar (set by jsonrpc handler for AIP tool calls)
    2. FastMCP HTTP headers (set by SSE transport for internal MCP calls)
    """
    cb_url = get_callback_url()
    if not cb_url:
        try:
            from fastmcp.server.dependencies import get_http_headers

            headers = get_http_headers()
            cb_url = headers.get("x-callback-api-url")
        except (RuntimeError, ImportError):
            pass
    if cb_url:
        path = (
            os.environ.get("LCP_API_PATH", "/suite/rest/a/lcp-api/latest")
            .strip()
            .rstrip("/")
        )
        return f"{cb_url.rstrip('/')}{path}"
    if _REQUIRE_CALLBACK_URL:
        raise RuntimeError(
            "LCP_REQUIRE_CALLBACK_URL is set but no callback_url in request context"
        )
    logger.warning("[LCP] callback_url not set — falling back to config base_url")
    return config_base_url


class DynamicLCPClient:
    """Wraps an LCPPluginClient, overriding base_url per-request from ContextVar.

    All 133 tool call sites use `client=client` — this wrapper is passed as
    `client` so they all transparently get per-request URL resolution.
    """

    def __init__(self, fallback_client: LCPPluginClient):
        self._fallback = fallback_client

    def _make_client(self) -> LCPPluginClient:
        base_url = _resolve_base_url(self._fallback._base_url)
        token = get_auth_token()
        # When the resolved URL matches the configured fallback, use the
        # fallback client as-is (preserves Basic Auth from LCP_USERNAME/PASSWORD).
        # Bearer auth only applies when the callback URL points to a different
        # site than the configured one.
        if base_url == self._fallback._base_url:
            return self._fallback
        use_bearer = token and "/webapi/" not in base_url
        httpx_args = dict(self._fallback._httpx_args)
        headers = dict(self._fallback._headers)
        if use_bearer:
            httpx_args.pop("auth", None)
            headers["Authorization"] = f"Bearer {token}"
        return LCPPluginClient(
            base_url=base_url,
            headers=headers,
            timeout=self._fallback._timeout,
            httpx_args=httpx_args,
        )

    def get_httpx_client(self):
        return _TracingSyncClient(self._make_client().get_httpx_client())

    def get_async_httpx_client(self):
        return _TracingAsyncClient(self._make_client().get_async_httpx_client())

    def __getattr__(self, name):
        return getattr(self._fallback, name)


class DynamicBetaClient:
    """Wraps an AuthenticatedClient, using per-request JWT and callback URL when available."""

    def __init__(self, fallback_client: LCPAuthenticatedClient):
        self._fallback = fallback_client

    def _make_client(self) -> LCPAuthenticatedClient:
        token = get_auth_token() or self._fallback.token
        cb_url = get_callback_url()
        base_url = (
            f"{cb_url.rstrip('/')}/suite/lcp/api"
            if cb_url
            else self._fallback._base_url
        )
        if token == self._fallback.token and base_url == self._fallback._base_url:
            return self._fallback
        return LCPAuthenticatedClient(
            base_url=base_url,
            token=token,
            timeout=self._fallback._timeout,
        )

    def get_httpx_client(self):
        return _TracingSyncClient(self._make_client().get_httpx_client())

    def get_async_httpx_client(self):
        return _TracingAsyncClient(self._make_client().get_async_httpx_client())

    def __getattr__(self, name):
        return getattr(self._fallback, name)


class _TracingAsyncClient:
    """Wraps httpx.AsyncClient.request() with an OTel CLIENT span."""

    def __init__(self, client: httpx.AsyncClient):
        self._client = client

    async def request(self, method: str, url: str, **kwargs) -> httpx.Response:
        path_tail = url.split("?")[0].rsplit("/", 1)[-1]
        span_name = f"LCP {method} {path_tail}" if path_tail else f"LCP {method}"
        with _tracer.start_as_current_span(span_name, kind=SpanKind.CLIENT) as span:
            span.set_attribute("http.request.method", method)
            full_url = str(self._client.build_request(method, url).url)
            span.set_attribute("url.full", full_url)
            # Inject trace context and agent type header
            headers = kwargs.pop("headers", None) or {}
            inject(headers)
            agent_type = get_agent_type()
            if agent_type:
                headers["X-Agent-Type"] = agent_type
            resp = await self._client.request(method, url, headers=headers, **kwargs)
            span.set_attribute("http.response.status_code", resp.status_code)
            if resp.status_code >= 400:
                span.set_status(StatusCode.ERROR, f"HTTP {resp.status_code}")
            return resp

    def __getattr__(self, name):
        return getattr(self._client, name)


class _TracingSyncClient:
    """Wraps httpx.Client.request() with an OTel CLIENT span."""

    def __init__(self, client: httpx.Client):
        self._client = client

    def request(self, method: str, url: str, **kwargs) -> httpx.Response:
        path_tail = url.split("?")[0].rsplit("/", 1)[-1]
        span_name = f"LCP {method} {path_tail}" if path_tail else f"LCP {method}"
        with _tracer.start_as_current_span(span_name, kind=SpanKind.CLIENT) as span:
            span.set_attribute("http.request.method", method)
            full_url = str(self._client.build_request(method, url).url)
            span.set_attribute("url.full", full_url)
            # Inject trace context and agent type header
            headers = kwargs.pop("headers", None) or {}
            inject(headers)
            agent_type = get_agent_type()
            if agent_type:
                headers["X-Agent-Type"] = agent_type
            resp = self._client.request(method, url, headers=headers, **kwargs)
            span.set_attribute("http.response.status_code", resp.status_code)
            if resp.status_code >= 400:
                span.set_status(StatusCode.ERROR, f"HTTP {resp.status_code}")
            return resp

    def __getattr__(self, name):
        return getattr(self._client, name)
