"""Main entry point for LCP MCP Server."""

import logging
import sys

from .config import LCPConfig
from .server import create_lcp_mcp_server

logger = logging.getLogger(__name__)


def main() -> None:
    """Run LCP MCP Server."""
    try:
        logging.basicConfig(level=logging.INFO)

        logger.info("Starting LCP MCP Server")
        config = LCPConfig()
        mcp = create_lcp_mcp_server(config)
        mcp.run(transport="stdio")

    except ValueError as e:
        logger.error(f"Configuration error: {e}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Server error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
