"""AI Agents domain MCP tools."""

from typing import Annotated

from lcp_api_beta_client.api.design_objects_agents import (
    get_agent,
    list_agents,
)
from lcp_api_beta_client.types import UNSET
from lcp_api_plugin_client.api.applications import list_application_agents
from lcp_api_plugin_client.types import UNSET as PLUGIN_UNSET
from pydantic import Field

from . import _safe_to_dict, tool_error, unwrap_response
from .ai_skills import _unwrap_beta_response

# The AI Agents endpoint requires X-Appian-Api-Version: beta
_API_VERSION = "beta"


def register_tools(mcp, client, plugin_client):
    @mcp.tool(meta={"object_type": "AI Agent", "action_type": "GET"})
    async def listAgents(
        name: str | None = None,
        appUuid: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian AI agents with optional name filtering."""
        try:
            if appUuid is not None:
                resp = await list_application_agents.asyncio_detailed(
                    app_uuid=appUuid,
                    query=name or PLUGIN_UNSET,
                    limit=limit,
                    offset=offset,
                    client=plugin_client,
                )
                return unwrap_response(resp)
            resp = await list_agents.asyncio_detailed(
                client=client,
                name=name or UNSET,
                limit=limit,
                offset=offset,
                x_appian_api_version=_API_VERSION,
            )
            return _safe_to_dict(_unwrap_beta_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "AI Agent", "action_type": "GET"})
    async def getAgent(
        uuid: str,
        expand: Annotated[
            str | None,
            Field(
                description="Comma-separated sub-resources to expand: variables, tools, testCases"
            ),
        ] = None,
    ) -> dict:
        """Get a single Appian AI agent by UUID."""
        try:
            resp = await get_agent.asyncio_detailed(
                uuid=uuid,
                client=client,
                expand=expand or UNSET,
                x_appian_api_version=_API_VERSION,
            )
            return _safe_to_dict(_unwrap_beta_response(resp))
        except Exception as e:
            raise tool_error(e) from e
