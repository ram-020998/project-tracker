"""AI Skills domain MCP tools."""

from lcp_api_beta_client.api.design_objects_ai_skills import (
    get_ai_skill,
    list_ai_skills,
)
from lcp_api_beta_client.models.error_response import ErrorResponse
from lcp_api_beta_client.types import UNSET
from lcp_api_plugin_client.api.applications import list_application_ai_skills
from lcp_api_plugin_client.types import UNSET as PLUGIN_UNSET

from . import LCPResponseError, _safe_to_dict, tool_error, unwrap_response

# The AI Skills endpoint requires X-Appian-Api-Version: beta
_API_VERSION = "beta"


def _unwrap_beta_response(response):
    """Extract parsed result from a beta client response, raising on errors."""
    if response.parsed is not None:
        if isinstance(response.parsed, ErrorResponse):
            detail = (
                response.parsed.detail
                if not isinstance(response.parsed.detail, type(UNSET))
                else ""
            )
            msg = (
                f"{response.parsed.title}: {detail}"
                if detail
                else response.parsed.title
            )
            raise LCPResponseError(
                response.parsed.status, "application/problem+json", msg
            )
        return response.parsed
    from http import HTTPStatus

    status_code = (
        response.status_code.value
        if isinstance(response.status_code, HTTPStatus)
        else int(response.status_code)
    )

    if 200 <= status_code < 300 and not response.content:
        return None

    content_type = response.headers.get("content-type", "unknown")
    body_preview = response.content.decode(errors="replace")[:200]
    raise LCPResponseError(status_code, content_type, body_preview)


def register_tools(mcp, client, plugin_client):
    @mcp.tool(meta={"object_type": "AI Skill", "action_type": "GET"})
    async def listAiSkills(
        name: str | None = None,
        appUuid: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian AI skills with optional name filtering. When appUuid is provided, results are scoped to that application."""
        try:
            if appUuid is not None:
                resp = await list_application_ai_skills.asyncio_detailed(
                    app_uuid=appUuid,
                    query=name or PLUGIN_UNSET,
                    limit=limit,
                    offset=offset,
                    client=plugin_client,
                )
                return unwrap_response(resp)
            resp = await list_ai_skills.asyncio_detailed(
                client=client,
                name=name or UNSET,
                limit=limit,
                offset=offset,
                x_appian_api_version=_API_VERSION,
            )
            return _safe_to_dict(_unwrap_beta_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "AI Skill", "action_type": "GET"})
    async def getAiSkill(uuid: str) -> dict:
        """Get a single Appian AI skill by UUID."""
        try:
            resp = await get_ai_skill.asyncio_detailed(
                uuid=uuid,
                client=client,
                x_appian_api_version=_API_VERSION,
            )
            return _safe_to_dict(_unwrap_beta_response(resp))
        except Exception as e:
            raise tool_error(e) from e
