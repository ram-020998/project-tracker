"""Groups domain MCP tools."""

from http import HTTPStatus
from typing import Annotated

from lcp_api_plugin_client.api.applications import list_application_groups
from lcp_api_plugin_client.api.groups import (
    add_group_members,
    create_group,
    delete_group,
    get_group_by_name,
    list_group_members,
    list_groups,
    remove_group_member,
)
from lcp_api_plugin_client.models.add_group_members_request import (
    AddGroupMembersRequest,
)
from lcp_api_plugin_client.models.create_group_request import CreateGroupRequest
from lcp_api_plugin_client.models.group_member_reference import (
    GroupMemberReference as SDKGroupMemberReference,
)
from lcp_api_plugin_client.models.group_member_reference_type import (
    GroupMemberReferenceType,
)
from lcp_api_plugin_client.models.list_group_members_type import ListGroupMembersType
from lcp_api_plugin_client.models.remove_group_member_type import RemoveGroupMemberType
from lcp_api_plugin_client.types import UNSET
from pydantic import Field

from . import _safe_to_dict, tool_error, unwrap_response
from .models import GroupMemberReference


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Group", "action_type": "GET"})
    async def listGroups(
        appUuid: str,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian groups with optional filtering. Use appUuid to scope to an application."""
        try:
            if appUuid:
                resp = await list_application_groups.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    limit=limit,
                    offset=offset,
                )
            else:
                resp = await list_groups.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Group", "action_type": "GET"})
    async def getGroup(groupName: str) -> dict:
        """Get a single Appian group by name."""
        try:
            resp = await get_group_by_name.asyncio_detailed(
                group_name=groupName, client=client
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Group", "action_type": "CREATE"})
    async def createGroup(
        name: str,
        appUuid: Annotated[
            str,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object to the app and applies the app's default security."
            ),
        ],
        description: str | None = None,
        parentGroupName: str | None = None,
    ) -> dict:
        """Create a new Appian group."""
        try:
            body = CreateGroupRequest(
                name=name,
                app_uuid=appUuid,
                description=description or UNSET,
                parent_group_name=parentGroupName or UNSET,
            )
            resp = await create_group.asyncio_detailed(body=body, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Group", "action_type": "GET"})
    async def listGroupMembers(
        groupName: str,
        directOnly: Annotated[
            bool,
            Field(
                description="When true, returns only direct (explicitly added) members. Default false returns all members including inherited."
            ),
        ] = False,
        memberType: Annotated[
            str,
            Field(
                description="Filter by member type: 'group', 'user', or omit for both. Maps to 'type' query param in the SDK."
            ),
        ] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List members of an Appian group. Returns groups first, then users, with cascading pagination."""
        try:
            type_ = ListGroupMembersType(memberType) if memberType else UNSET
            resp = await list_group_members.asyncio_detailed(
                group_name=groupName,
                client=client,
                direct_only=directOnly,
                type_=type_,
                limit=limit,
                offset=offset,
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Group", "action_type": "UPDATE"})
    async def addGroupMembers(
        groupName: str,
        members: list[GroupMemberReference],
    ) -> dict:
        """Add members to an Appian group. Accepts a batch of users and/or groups."""
        try:
            sdk_members = [
                SDKGroupMemberReference(
                    type_=GroupMemberReferenceType(m.type),
                    id=m.id,
                )
                for m in members
            ]
            body = AddGroupMembersRequest(members=sdk_members)
            resp = await add_group_members.asyncio_detailed(
                group_name=groupName,
                client=client,
                body=body,
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Group", "action_type": "UPDATE"})
    async def removeGroupMember(
        groupName: str,
        memberType: Annotated[
            str,
            Field(description="Type of member to remove: 'user' or 'group'."),
        ],
        memberId: Annotated[
            str,
            Field(description="Username for users, group name for groups."),
        ],
    ) -> str:
        """Remove a direct member from an Appian group. Only direct members can be removed."""
        try:
            type_ = RemoveGroupMemberType(memberType)
            resp = await remove_group_member.asyncio_detailed(
                group_name=groupName,
                type_=type_,
                id=memberId,
                client=client,
            )
            if resp.status_code == HTTPStatus.NO_CONTENT:
                return f"Removed {memberType} '{memberId}' from group '{groupName}'"
            unwrap_response(resp)
            return f"Removed {memberType} '{memberId}' from group '{groupName}'"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Group", "action_type": "UPDATE"})
    async def updateGroup(
        groupName: Annotated[
            str,
            Field(description="The current name of the group to update."),
        ],
        name: str | None = None,
        description: str | None = None,
    ) -> dict:
        """Update an Appian group's name and/or description. At least one field must be provided."""
        try:
            from lcp_api_plugin_client.api.groups import update_group
            from lcp_api_plugin_client.models.update_group_body import UpdateGroupBody

            body = UpdateGroupBody(
                name=name or UNSET,
                description=description if description is not None else UNSET,
            )
            resp = await update_group.asyncio_detailed(
                group_name=groupName, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Group", "action_type": "DELETE"})
    async def deleteGroup(groupName: str) -> str:
        """Permanently delete an Appian group by name. This operation cannot be undone."""
        try:
            resp = await delete_group.asyncio_detailed(
                group_name=groupName, client=client
            )
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e
