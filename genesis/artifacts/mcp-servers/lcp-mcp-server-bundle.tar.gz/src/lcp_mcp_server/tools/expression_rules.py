"""Expression Rules domain MCP tools."""

from typing import Annotated

from lcp_api_plugin_client.api.applications import list_application_expression_rules
from lcp_api_plugin_client.api.expression_rules import (
    create_expression_rule,
    create_expression_rule_test_case,
    delete_expression_rule,
    delete_expression_rule_test_case,
    get_expression_rule_by_uuid,
    get_expression_rule_test_case,
    list_expression_rule_test_cases,
    list_expression_rules,
    run_all_expression_rule_test_cases,
    run_expression_rule_test_case,
    update_expression_rule,
    update_expression_rule_test_case,
)
from lcp_api_plugin_client.models.create_expression_rule_request import (
    CreateExpressionRuleRequest,
)
from lcp_api_plugin_client.models.create_expression_rule_request_test_inputs_item import (
    CreateExpressionRuleRequestTestInputsItem,
)
from lcp_api_plugin_client.models.create_test_case_request import (
    CreateTestCaseRequest,
)
from lcp_api_plugin_client.models.typed_input import TypedInput as SdkTypedInput
from lcp_api_plugin_client.models.update_expression_rule_request import (
    UpdateExpressionRuleRequest,
)
from lcp_api_plugin_client.models.update_expression_rule_request_test_inputs_item import (
    UpdateExpressionRuleRequestTestInputsItem,
)
from fastmcp.exceptions import ToolError
from lcp_api_plugin_client.types import UNSET
from pydantic import BeforeValidator, Field

from . import (
    _coerce_json_str_to_list,
    _safe_to_dict,
    resolve_expression,
    tool_error,
    unwrap_response,
    write_expression_to_path,
)
from .models import TypedInput, TestInput


async def _get_version_id(uuid: str, client) -> str | None:
    resp = await get_expression_rule_by_uuid.asyncio_detailed(uuid=uuid, client=client)
    return _safe_to_dict(unwrap_response(resp)).get("versionId")


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "GET"})
    async def listExpressionRules(
        appUuid: str,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian expression rules with optional filtering. Use appUuid to scope to an application."""
        try:
            if appUuid:
                resp = await list_application_expression_rules.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            else:
                resp = await list_expression_rules.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "GET"})
    async def getExpressionRule(
        uuid: str,
        expressionFilePath: Annotated[
            str | None,
            Field(
                description="Absolute path where the expression body will be written. "
                "When provided, the expression is saved to this file and stripped from the response. "
                "Omit to include the expression inline in the response."
            ),
        ] = None,
    ) -> dict:
        """Get a single Appian expression rule by UUID.

        Writes the expression body to expressionFilePath and strips it from the
        response. Edit the file directly, then pass the path to updateExpressionRule.
        """
        try:
            resp = await get_expression_rule_by_uuid.asyncio_detailed(
                uuid=uuid, client=client
            )
            result = _safe_to_dict(unwrap_response(resp))
            if expressionFilePath:
                expression = result.get("expression")
                if expression:
                    write_expression_to_path(expressionFilePath, expression)
                    result["expressionFilePath"] = expressionFilePath
                result.pop("expression", None)
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "CREATE"})
    async def createExpressionRule(
        name: str,
        appUuid: Annotated[
            str | None,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object to the app and applies the app's default security, selecting an appropriate Rules and Constants folder. Either appUuid or parentFolderUuid must be provided."
            ),
        ] = None,
        parentFolderUuid: Annotated[
            str | None,
            Field(
                description="UUID of the parent Rules and Constants folder. Takes precedence over appUuid for folder selection. Either appUuid or parentFolderUuid must be provided."
            ),
        ] = None,
        expressionFilePath: Annotated[
            str | None,
            Field(
                description="Absolute path to the local file containing the SAIL expression. "
                "Write the expression to this file before calling createExpressionRule. "
                "The file content is submitted as the expression."
            ),
        ] = None,
        expression: Annotated[
            str | None,
            Field(
                description="Inline SAIL expression string. Use expressionFilePath instead for "
                "non-trivial expressions — it enables efficient editing on validation failure."
            ),
        ] = None,
        description: str | None = None,
        inputs: Annotated[
            list[TypedInput] | None, BeforeValidator(_coerce_json_str_to_list)
        ] = None,
        testInputs: Annotated[
            list[TestInput] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description="Test input values for validation and as default test values. If not provided, validation uses null inputs. Once saved, these become the default test values used on subsequent updates."
            ),
        ] = None,
    ) -> dict:
        """Create a new Appian expression rule.

        Provide either appUuid (to auto-select the app's Rules and Constants folder) or
        parentFolderUuid (to target a specific folder). If both are given, parentFolderUuid wins.

        Write the SAIL expression to a local file first, then pass its path as
        expressionFilePath. The file content is submitted as the expression.

        Input types can be built-in (e.g. "Text", "Number (Integer)", "Boolean") or
        developer-defined — use the typeReference string from getRecordType for record types.

        Provide testInputs to validate with real values instead of nulls, useful for expressions
        that require non-null inputs. These values are saved as default test values.

        On validation failure, fix the file and call updateExpressionRule with the same path.
        """
        if not appUuid and not parentFolderUuid:
            raise ToolError("Either appUuid or parentFolderUuid must be provided.")
        try:
            resolved_expression = resolve_expression(expression, expressionFilePath)

            body = CreateExpressionRuleRequest(
                name=name,
                app_uuid=appUuid or UNSET,
                parent_folder_uuid=parentFolderUuid or UNSET,
                description=description or UNSET,
                expression=resolved_expression or UNSET,
                inputs=[
                    SdkTypedInput.from_dict(i.model_dump(exclude_none=True))
                    for i in inputs
                ]
                if inputs is not None
                else UNSET,
                test_inputs=[
                    CreateExpressionRuleRequestTestInputsItem.from_dict(
                        {k: v for k, v in {
                            "name": ti.name,
                            "value": ti.value,
                            "type": ti.type
                        }.items() if v is not None}
                    )
                    for ti in testInputs
                ]
                if testInputs is not None
                else UNSET,
            )
            resp = await create_expression_rule.asyncio_detailed(
                client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            if expressionFilePath:
                result["expressionFilePath"] = expressionFilePath
                result.pop("expression", None)
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "UPDATE"})
    async def updateExpressionRule(
        uuid: str,
        expressionFilePath: Annotated[
            str | None,
            Field(
                description="Absolute path to the local file containing the SAIL expression. "
                "Edit the file from getExpressionRule or createExpressionRule, then pass the same path here. "
                "The file content is read and submitted as the expression."
            ),
        ] = None,
        expression: Annotated[
            str | None,
            Field(
                description="Inline SAIL expression string. Use expressionFilePath instead for "
                "non-trivial expressions — it enables efficient editing on validation failure."
            ),
        ] = None,
        name: str | None = None,
        description: str | None = None,
        inputs: Annotated[
            list[TypedInput] | None, BeforeValidator(_coerce_json_str_to_list)
        ] = None,
        testInputs: Annotated[
            list[TestInput] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description="Test input values for validation. If not provided, existing test values are reused. If none exist, validation uses null inputs."
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Update an existing Appian expression rule. Only provided fields are changed.

        Input types can be built-in (e.g. "Text", "Number (Integer)", "Boolean") or
        developer-defined — use the typeReference string from getRecordType for record types.

        Edit the SAIL file, then pass the same expressionFilePath to submit changes.

        testInputs: If provided, updates the stored test values. If omitted, existing test values
        are preserved and used for validation.
        """
        try:
            resolved_expression = resolve_expression(expression, expressionFilePath)

            body = UpdateExpressionRuleRequest(
                name=name or UNSET,
                description=description or UNSET,
                expression=resolved_expression or UNSET,
                inputs=[
                    SdkTypedInput.from_dict(i.model_dump(exclude_none=True))
                    for i in inputs
                ]
                if inputs is not None
                else UNSET,
                test_inputs=[
                    UpdateExpressionRuleRequestTestInputsItem.from_dict(
                        {k: v for k, v in {
                            "name": ti.name,
                            "value": ti.value,
                            "type": ti.type
                        }.items() if v is not None}
                    )
                    for ti in testInputs
                ]
                if testInputs is not None
                else UNSET,
                version_id=versionId or UNSET,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_expression_rule.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "DELETE"})
    async def deleteExpressionRule(uuid: str) -> str:
        """Permanently delete an Appian expression rule."""
        try:
            resp = await delete_expression_rule.asyncio_detailed(uuid=uuid, client=client)
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    # ── Expression Rule Test Case Tools ──────────────────────────────────────

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "GET"})
    async def listExpressionRuleTestCases(uuid: str) -> dict:
        """List all saved test cases for an expression rule."""
        try:
            resp = await list_expression_rule_test_cases.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "GET"})
    async def getExpressionRuleTestCase(uuid: str, testCaseUuid: str) -> dict:
        """Get a specific test case by UUID for an expression rule."""
        try:
            resp = await get_expression_rule_test_case.asyncio_detailed(
                uuid=uuid, test_case_uuid=testCaseUuid, client=client
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "CREATE"})
    async def createExpressionRuleTestCase(
        uuid: str,
        name: Annotated[str, Field(description="Human-readable test case name")],
        inputs: Annotated[
            list[dict] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description='List of input objects. Each has "name" (parameter name), "value" (SAIL expression string), and optional "type" (e.g. "Text", "Number (Integer)"). Example: [{"name": "tier", "value": "\\"Gold\\""}, {"name": "amount", "value": "100.0"}]'
            ),
        ] = None,
        description: Annotated[str | None, Field(description="Optional description")] = None,
        isDefault: Annotated[bool | None, Field(description="Whether this is the default test case")] = None,
        assertionType: Annotated[str | None, Field(description="Assertion mode. Values: NO_ERRORS (default), EXPECTED_OUTPUT, RESULT_ASSERTIONS.")] = None,
        expectedOutput: Annotated[str | None, Field(description="SAIL expression for expected output value. Used when assertionType=EXPECTED_OUTPUT.")] = None,
        expectedOutputType: Annotated[str | None, Field(description='Type of the expected output value (e.g. "Number (Integer)", "Text", "Boolean"). Required when assertionType is EXPECTED_OUTPUT.')] = None,
        resultAssertion: Annotated[str | None, Field(description="SAIL assertion expression with access to `result` variable. Used when assertionType=RESULT_ASSERTIONS.")] = None,
    ) -> dict:
        """Create a saved test case for an expression rule.

        Stores inputs for the rule. When run via runExpressionRuleTestCase, the platform
        evaluates the rule with these inputs. Duplicate names are rejected with 409.
        """
        try:
            payload = {"name": name}
            if inputs is not None:
                payload["inputs"] = inputs
            if description is not None:
                payload["description"] = description
            if isDefault is not None:
                payload["isDefault"] = isDefault
            if assertionType is not None:
                payload["assertionType"] = assertionType
            if expectedOutput is not None:
                payload["expectedOutput"] = expectedOutput
            if expectedOutputType is not None:
                payload["expectedOutputType"] = expectedOutputType
            if resultAssertion is not None:
                payload["resultAssertion"] = resultAssertion
            body = CreateTestCaseRequest.from_dict(payload)
            resp = await create_expression_rule_test_case.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "CREATE"})
    async def createExpressionRuleTestCases(
        uuid: str,
        testCases: Annotated[
            list[dict],
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description='Array of test cases to create in a single batch. '
                'Each item has: "name" (required), "inputs" (array of {name, value, type?}), '
                '"description", "isDefault", "assertionType", "expectedOutput", "expectedOutputType", "resultAssertion".'
            ),
        ],
    ) -> dict:
        """Create multiple test cases for an expression rule in a single call.

        Accepts an array of test case objects. Returns {"created": [...], "errors": [...]}.
        Partial failures are captured in "errors" rather than aborting the batch.
        Duplicate names within the batch or against existing test cases are rejected with 409.
        """
        results = []
        errors = []
        for i, tc in enumerate(testCases):
            try:
                body = CreateTestCaseRequest.from_dict(tc)
                resp = await create_expression_rule_test_case.asyncio_detailed(
                    uuid=uuid, client=client, body=body
                )
                results.append(_safe_to_dict(unwrap_response(resp)))
            except Exception as item_err:
                errors.append({"index": i, "name": tc.get("name", ""), "error": str(item_err)})
        if errors and not results:
            raise tool_error(Exception(f"All test cases failed: {errors}"))
        return {"created": results, "errors": errors}

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "UPDATE"})
    async def updateExpressionRuleTestCase(
        uuid: str,
        testCaseUuid: Annotated[str, Field(description="Test case UUID (from listExpressionRuleTestCases)")],
        name: Annotated[str, Field(description="Updated test case name")],
        inputs: Annotated[
            list[dict] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description='List of input objects. Each has "name" (parameter name), "value" (SAIL expression string), and optional "type" (e.g. "Text", "Number (Integer)"). Example: [{"name": "tier", "value": "\\"Gold\\""}, {"name": "amount", "value": "100.0"}]'
            ),
        ] = None,
        description: Annotated[str | None, Field(description="Optional description")] = None,
        isDefault: Annotated[bool | None, Field(description="Whether this is the default test case")] = None,
        assertionType: Annotated[str | None, Field(description="Assertion mode. Values: NO_ERRORS (default), EXPECTED_OUTPUT, RESULT_ASSERTIONS.")] = None,
        expectedOutput: Annotated[str | None, Field(description="SAIL expression for expected output value. Used when assertionType=EXPECTED_OUTPUT.")] = None,
        expectedOutputType: Annotated[str | None, Field(description='Type of the expected output value (e.g. "Number (Integer)", "Text", "Boolean"). Required when assertionType is EXPECTED_OUTPUT.')] = None,
        resultAssertion: Annotated[str | None, Field(description="SAIL assertion expression with access to `result` variable. Used when assertionType=RESULT_ASSERTIONS.")] = None,
    ) -> dict:
        """Update an existing expression rule test case. Duplicate names are rejected with 409."""
        try:
            payload = {"name": name}
            if inputs is not None:
                payload["inputs"] = inputs
            if description is not None:
                payload["description"] = description
            if isDefault is not None:
                payload["isDefault"] = isDefault
            if assertionType is not None:
                payload["assertionType"] = assertionType
            if expectedOutput is not None:
                payload["expectedOutput"] = expectedOutput
            if expectedOutputType is not None:
                payload["expectedOutputType"] = expectedOutputType
            if resultAssertion is not None:
                payload["resultAssertion"] = resultAssertion
            body = CreateTestCaseRequest.from_dict(payload)
            resp = await update_expression_rule_test_case.asyncio_detailed(
                uuid=uuid, test_case_uuid=testCaseUuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "DELETE"})
    async def deleteExpressionRuleTestCase(
        uuid: str,
        testCaseUuid: Annotated[str, Field(description="Test case UUID (from listExpressionRuleTestCases)")],
    ) -> str:
        """Delete a saved test case from an expression rule."""
        try:
            resp = await delete_expression_rule_test_case.asyncio_detailed(
                uuid=uuid, test_case_uuid=testCaseUuid, client=client
            )
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "GET"})
    async def runExpressionRuleTestCase(
        uuid: str,
        testCaseUuid: Annotated[str, Field(description="Test case UUID (from listExpressionRuleTestCases)")],
    ) -> dict:
        """Run a single saved test case for an expression rule.

        Returns success/failure, output, duration, and any test errors.
        """
        try:
            resp = await run_expression_rule_test_case.asyncio_detailed(
                uuid=uuid, test_case_uuid=testCaseUuid, client=client
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Expression Rule", "action_type": "GET"})
    async def runAllExpressionRuleTestCases(uuid: str) -> dict:
        """Run all saved test cases for an expression rule.

        Returns pass/fail results for each test case with totalCount, passCount, failCount.
        """
        try:
            resp = await run_all_expression_rule_test_cases.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e
