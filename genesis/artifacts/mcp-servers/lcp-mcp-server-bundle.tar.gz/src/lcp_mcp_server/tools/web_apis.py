"""Web APIs domain MCP tools."""

import re
from typing import Annotated

from lcp_api_plugin_client.api.web_ap_is import (
    create_web_api,
    delete_web_api,
    get_web_api_by_uuid,
    list_application_web_apis,
    list_web_apis,
    update_web_api,
)
from lcp_api_plugin_client.models.create_web_api_request import CreateWebAPIRequest
from lcp_api_plugin_client.models.update_web_api_request import UpdateWebAPIRequest
from lcp_api_plugin_client.types import UNSET
from pydantic import Field

from . import (
    _safe_to_dict,
    resolve_expression,
    tool_error,
    unwrap_response,
    write_expression_to_path,
)
from fastmcp.exceptions import ToolError

_URL_ALIAS_PATTERN = re.compile(r"^[a-zA-Z][a-zA-Z0-9_]*$")


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Web API", "action_type": "GET"})
    async def listWebApis(
        appUuid: str,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian Web APIs with optional filtering. Use appUuid to scope to an application."""
        try:
            if appUuid:
                resp = await list_application_web_apis.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            else:
                resp = await list_web_apis.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Web API", "action_type": "GET"})
    async def getWebApi(
        uuid: str,
        expressionFilePath: Annotated[
            str | None,
            Field(
                description="Absolute path where the expression body will be written. "
                "When provided, the expression is saved to this file and stripped from the response. "
                "Omit to include the expression inline in the response."
            ),
        ] = None,
    ) -> dict:
        """Get a single Appian Web API by UUID.

        Writes the expression body to expressionFilePath and strips it from the
        response. Edit the file directly, then pass the path to updateWebApi.
        """
        try:
            resp = await get_web_api_by_uuid.asyncio_detailed(uuid=uuid, client=client)
            result = _safe_to_dict(unwrap_response(resp))
            if expressionFilePath:
                expression = result.get("expression")
                if expression:
                    write_expression_to_path(expressionFilePath, expression)
                    result["expressionFilePath"] = expressionFilePath
                result.pop("expression", None)
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Web API", "action_type": "CREATE"})
    async def createWebApi(
        name: str,
        urlAlias: Annotated[
            str,
            Field(
                description=(
                    "URL path segment for the endpoint. Must start with a letter and contain "
                    "only letters, numbers, and underscores. No slashes, hyphens, or spaces. Max 255 chars."
                )
            ),
        ],
        httpMethod: str,
        appUuid: Annotated[
            str,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object to the app and applies the app's default security."
            ),
        ],
        expressionFilePath: Annotated[
            str | None,
            Field(
                description="Absolute path to the local file containing the SAIL expression (a!httpResponse). "
                "Write the expression to this file before calling createWebApi. "
                "The file content is submitted as the Web API expression."
            ),
        ] = None,
        expression: Annotated[
            str | None,
            Field(
                description="Inline SAIL expression string (a!httpResponse). Use expressionFilePath "
                "instead for non-trivial expressions — it enables efficient editing on validation failure."
            ),
        ] = None,
        description: str | None = None,
    ) -> dict:
        """Create a new Appian Web API.

        Write the SAIL expression (a!httpResponse) to a local file first, then pass its
        path as expressionFilePath. The file content is submitted as the Web API expression.
        If omitted, the Web API is created as a non-functional shell.

        On validation failure, fix the file and call updateWebApi with the same path.
        """
        if not _URL_ALIAS_PATTERN.match(urlAlias):
            raise ToolError(
                f"Invalid urlAlias '{urlAlias}'. Must start with a letter and contain "
                "only letters, numbers, and underscores (no slashes, hyphens, or spaces)."
            )
        try:
            resolved_expression = resolve_expression(expression, expressionFilePath)

            body = CreateWebAPIRequest(
                name=name,
                url_alias=urlAlias,
                http_method=httpMethod,
                app_uuid=appUuid,
                description=description or UNSET,
                expression=resolved_expression or UNSET,
            )
            resp = await create_web_api.asyncio_detailed(client=client, body=body)
            result = _safe_to_dict(unwrap_response(resp))
            if expressionFilePath:
                result["expressionFilePath"] = expressionFilePath
                result.pop("expression", None)
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Web API", "action_type": "UPDATE"})
    async def updateWebApi(
        uuid: str,
        expressionFilePath: Annotated[
            str | None,
            Field(
                description="Absolute path to the local file containing the SAIL expression (a!httpResponse). "
                "Edit the file from getWebApi or createWebApi, then pass the same path here. "
                "The file content is read and submitted as the expression."
            ),
        ] = None,
        expression: Annotated[
            str | None,
            Field(
                description="Inline SAIL expression string (a!httpResponse). Use expressionFilePath "
                "instead for non-trivial expressions — it enables efficient editing on validation failure."
            ),
        ] = None,
        name: str | None = None,
        description: str | None = None,
    ) -> dict:
        """Update an existing Appian Web API. Only provided fields are changed.

        Edit the SAIL file, then pass the same expressionFilePath to submit changes.
        """
        try:
            resolved_expression = resolve_expression(expression, expressionFilePath)

            body = UpdateWebAPIRequest(
                name=name or UNSET,
                description=description or UNSET,
                expression=resolved_expression or UNSET,
            )
            resp = await update_web_api.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            if expressionFilePath:
                result["expressionFilePath"] = expressionFilePath
                result.pop("expression", None)
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Web API", "action_type": "DELETE"})
    async def deleteWebApi(uuid: str) -> str:
        """Permanently delete an Appian Web API."""
        try:
            resp = await delete_web_api.asyncio_detailed(uuid=uuid, client=client)
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e
