"""Shared Pydantic models for MCP tool parameter schemas.

These models replace the generic ``JsonListOfDicts`` type annotations on tool
parameters that accept typed inputs or process model variables.  Each field
carries a ``Field(description=...)`` so the JSON schema exposed to agents
documents every attribute individually.
"""

from typing import Annotated, Literal

from pydantic import BaseModel, BeforeValidator, Field

from . import _coerce_json_str_to_dict

_TYPE_DESCRIPTION = (
    "Appian type. Built-in types by name: Text, Number (Integer), Number (Decimal), "
    "Boolean, Date, Time, Date and Time, User, Group, Document, Folder, Encrypted Text, "
    "Map, Password, SafeURI. For developer-defined types (e.g. record types): use the "
    "typeReference string from getRecordType. Other Appian types are also supported."
)


class ProcessModelVariableInput(BaseModel):
    """Schema for a process model variable supplied by the agent."""

    name: str = Field(description="Variable name")
    type: str = Field(description=_TYPE_DESCRIPTION)
    isParameter: bool | None = Field(
        default=None,
        description="Expose as a process parameter (visible to callers like record actions, subprocesses, and start forms)",
    )
    isRequired: bool | None = Field(
        default=None, description="Whether this parameter is required"
    )
    multiple: bool | None = Field(
        default=None,
        description="Whether this variable holds a list of values. Defaults to false.",
    )
    value: str | None = Field(
        default=None,
        description=(
            "Optional default-value expression, evaluated when the process is initiated. "
            'Provide without a leading "=" (e.g. "now()" or "rule!blankCase()").'
        ),
    )


class TypedInput(BaseModel):
    """Schema for an expression rule or interface input supplied by the agent."""

    name: str = Field(description="Input name")
    type: str = Field(description=_TYPE_DESCRIPTION)
    multiple: bool | None = Field(
        default=None,
        description="Whether this input accepts a list. Defaults to false.",
    )
    description: str | None = Field(
        default=None, description="Optional description of this input"
    )


class TestInput(BaseModel):
    """Schema for test input values used during validation."""

    name: str = Field(
        description="Input parameter name (must match an input in the 'inputs' array)"
    )
    value: str = Field(
        description="SAIL expression representing the test value, e.g. '\"text\"', '123', 'true()'"
    )
    type: str | None = Field(
        default=None,
        description="Appian type name (optional, inferred from inputs if not provided)",
    )


class GroupMemberReference(BaseModel):
    """Reference to a group member for add/remove operations."""

    type: str = Field(description="Member type: 'user' or 'group'")
    id: str = Field(description="Username for users, group name for groups")


class RoleAssignment(BaseModel):
    """Role-to-groups mapping for object security."""

    roleName: Annotated[
        str,
        Field(
            description="Use getObjectSecurity to see valid roles for the object type."
        ),
    ]
    groupNames: list[str] = []


class FacetOptionInput(BaseModel):
    """Bucket option for LIST_OF_VALUES user filters."""

    labelExpression: str = Field(
        description="Display label for this option. Bare text is auto-quoted as a SAIL string literal."
    )
    operator: str = Field(description="EQUALS (=), NOT_EQUALS (<>), or BETWEEN")
    value: str | None = Field(
        default=None,
        description="Expression for the filter value. Used by EQUALS and NOT_EQUALS operators.",
    )
    lowerLimitExpression: str | None = Field(
        default=None, description="Lower bound expression for BETWEEN operator"
    )
    upperLimitExpression: str | None = Field(
        default=None, description="Upper bound expression for BETWEEN operator"
    )


class RecordFieldInput(BaseModel):
    """Field definition for a record type."""

    fieldName: str
    fieldType: str = Field(
        description=(
            "The field data type. Valid values: TEXT, NUMBER, INTEGER, DECIMAL, "
            "DATE, DATETIME, TIME, BOOLEAN, USER, GROUP, DOCUMENT, FOLDER, EXTRA_LONG_TEXT."
        )
    )
    sourceFieldName: str | None = Field(
        default=None,
        description="Backing store field/column name (defaults to snake_case of fieldName)",
    )
    displayName: str | None = None
    description: str | None = None
    isPrimaryKey: bool | None = None
    isUnique: bool | None = None
    length: int | None = Field(
        default=None, description="Column length for TEXT fields (0 = default)"
    )


class RelationshipInput(BaseModel):
    """Relationship definition using field names as placeholders for UUIDs."""

    relationshipName: str = Field(description="Display name for the relationship")
    sourceFieldName: str = Field(
        description="Field name on THIS record type (resolved to UUID from creation response)"
    )
    targetRecordTypeUuid: str = Field(
        description="UUID of the target record type (must already exist)"
    )
    targetFieldName: str = Field(
        default="id",
        description="Field name on the TARGET record type to join to (default: 'id')",
    )
    relationshipType: str = Field(
        default="MANY_TO_ONE",
        description="ONE_TO_MANY | MANY_TO_ONE | ONE_TO_ONE",
    )


class SitePageInput(BaseModel):
    """Page definition for a site."""

    name: str
    targetUuid: str = Field(
        description=(
            "UUID of the target design object for this page. "
            "For INTERFACE pages, pass an interface UUID. "
            "For RECORD_LIST pages, pass a record type UUID. "
            "For ACTION pages, pass a process model UUID."
        )
    )
    type: Literal["INTERFACE", "RECORD_LIST", "ACTION"] | None = Field(
        default=None,
        description=(
            "Page type. INTERFACE (default) displays an interface object. "
            "RECORD_LIST displays a record type's configured record list. "
            "ACTION displays a process model's start form. "
            "The target process model must have a SAIL start form configured."
        ),
    )
    description: str | None = None
    iconId: (
        Literal[
            "f015",
            "f03a",
            "f080",
            "f013",
            "f0c0",
            "f073",
            "f07b",
            "f002",
            "f01c",
            "f05a",
            "f0f3",
            "f041",
            "f155",
            "f1da",
        ]
        | None
    ) = Field(
        default=None,
        description=(
            "Icon for the page tab. Valid values: f015 (home), f03a (list), f080 (analytics), "
            "f013 (settings), f0c0 (users), f073 (calendar), f07b (files), f002 (search), "
            "f01c (inbox), f05a (info), f0f3 (notifications), f041 (map), f155 (finance), "
            "f1da (history). Omit if none fit."
        ),
    )
    visibilityExpr: str | None = Field(
        default=None,
        description=(
            "SAIL expression controlling page visibility, "
            "e.g. 'if(isUserMemberOfGroup(...), true, false)'"
        ),
    )


class DesignObjectInput(BaseModel):
    """Reference to a design object for application association."""

    uuid: str
    type: str = Field(
        description=(
            "Design object type, e.g. CONSTANT, INTERFACE, PROCESS_MODEL, "
            "EXPRESSION_RULE, RECORD_TYPE, SITE, GROUP, DATA_TYPE"
        )
    )


class RuleInputItem(BaseModel):
    """Maps an interface input to a process variable."""

    name: str
    typeQName: str = Field(
        description=(
            "Type qualified name in Appian format, "
            "e.g. '{urn:com:appian:recordtype:datatype}UUID'"
        )
    )
    value: str = Field(
        description="Mapping expression, typically a process variable reference, e.g. 'pv!order'"
    )


class InterfaceInfoInput(BaseModel):
    """Start form interface details for automatic form expression generation."""

    name: str
    uuid: str
    ruleInputs: list[RuleInputItem] | None = None


# ── Process model node models ────────────────────────────────────────────


class FormConfigInput(BaseModel):
    """Form configuration for attended nodes (Forms tab) or process start forms."""

    interfaceUuid: str = Field(description="Interface UUID")
    inputMap: dict[str, str] | None = Field(
        default=None,
        description=(
            "Maps interface inputs to their data sources. Keys are interface input"
            " names (without ri! prefix). Values are PV names (without pv! prefix)"
            " for start forms, or ACP names (without ac! prefix) from customInputs"
            " for task forms. Existing configurations may use expressions (prefixed"
            " with =) as values — preserve these when editing, but prefer ACPs when"
            " creating new nodes."
        ),
    )


class NodeInputParam(BaseModel):
    """An input parameter on a node (schema-defined or custom)."""

    name: str = Field(description="Input name from getProcessModelNodeTypeSchema")
    type: str | None = Field(
        default=None,
        description=(
            "Type name for custom inputs: primitives (e.g. TEXT, BOOLEAN, INTEGER,"
            " DECIMAL, DATE, DATETIME) or a record type QName. Only applies to"
            " customInputs; schema-defined inputs already have a fixed type. If omitted,"
            " the custom input has no declared type."
        ),
    )
    expression: str | None = Field(default=None, description="SAIL expression")
    value: str | int | float | bool | None = Field(
        default=None, description="Literal value"
    )
    saveInto: str | None = Field(
        default=None,
        description=(
            "PV to save into, e.g. pv!result. For record-typed PVs, target a specific"
            " field with the UUID-qualified reference:"
            " myVar['recordType!{uuid}Name.fields.{fieldUuid}fieldName']"
        ),
    )


class NodeOutputParam(BaseModel):
    """An output parameter on a node."""

    name: str | None = Field(
        default=None, description="Output name from schema (null for customOutputs)"
    )
    expression: str | None = Field(
        default=None, description="Expression to evaluate (for customOutputs)"
    )
    saveInto: str | None = Field(
        default=None,
        description=(
            "PV to save into, e.g. pv!result. For record-typed PVs, target a specific"
            " field with the UUID-qualified reference:"
            " myVar['recordType!{uuid}Name.fields.{fieldUuid}fieldName']"
        ),
    )


class NodeDataInput(BaseModel):
    """Data/Setup tab configuration for activity and event nodes.
    Do NOT use ac! references in downstream nodes — ac! is scoped to the node it belongs to."""

    inputs: list[NodeInputParam] | None = Field(
        default=None,
        description="Schema-defined inputs from getProcessModelNodeTypeSchema",
    )
    outputs: list[NodeOutputParam] | None = Field(
        default=None,
        description="Schema-defined outputs. Set saveInto to wire to a PV.",
    )
    customInputs: list[NodeInputParam] | None = Field(
        default=None, description="User-defined input parameters"
    )
    customOutputs: list[NodeOutputParam] | None = Field(
        default=None, description="User-defined output expressions"
    )


class GatewayConditionInput(BaseModel):
    """A condition rule on an XOR or OR gateway."""

    expression: str = Field(description="SAIL boolean expression")
    targetNodeId: int = Field(description="Target node ID when condition is true")
    label: str | None = None


class NodeDecisionInput(BaseModel):
    """Decision tab configuration for XOR and OR gateways."""

    conditions: list[GatewayConditionInput] = Field(
        description="Ordered conditions evaluated top-to-bottom, first match wins"
    )
    defaultPath: int = Field(description="Target node ID when no condition matches")


class NodeAssignmentInput(BaseModel):
    """Assignment tab configuration for activity nodes.

    Specify exactly one of: assignTo (expression), assignToUsers (direct users), or assignToGroups (direct groups).
    Omit all to leave the node unassigned.
    """

    attended: bool | None = Field(
        default=None,
        description="true=user task, false=system executes. Required for ATTENDED_OR_UNATTENDED node types.",
    )
    assignTo: str | None = Field(
        default=None,
        description="SAIL expression for assignee(s), e.g. pp!initiator. Mutually exclusive with assignToUsers/assignToGroups.",
    )
    assignToUsers: list[str] | None = Field(
        default=None,
        description="Direct user assignment by username(s). Mutually exclusive with assignTo/assignToGroups.",
    )
    assignToGroups: list[str] | None = Field(
        default=None,
        description="Direct group assignment by group UUID(s). Mutually exclusive with assignTo/assignToUsers.",
    )
    reassignPrivileges: str | None = Field(
        default=None,
        description="NONE, REJECT_ONLY, REASSIGN_WITHIN_POOL, or REASSIGN_TO_ANY (default)",
    )
    runAs: str | None = Field(
        default=None,
        description="INITIATOR (default) or DESIGNER, for unattended nodes",
    )
    overrideLane: bool | None = Field(
        default=None, description="Override swimlane assignment"
    )


class ProcessModelConnectionInput(BaseModel):
    """An outgoing connection (flow/arrow) from a node to a target node."""

    targetNodeId: int = Field(
        description="ID of the node this connection points to. Must already exist in the process model."
    )
    activityChained: bool = Field(
        description=(
            "Whether the flow is activity-chained. When true, on form submit the engine follows this "
            "connection and runs the next node synchronously while the user waits (as if part of a wizard) "
            "until the process ends, a non-chained connection is reached, or another attended node is "
            "encountered. If that node is assigned to the same user, they are taken there from the form "
            "they submitted. Required: decide explicitly for every connection (most flows are false)."
        )
    )
    overridesAssignment: bool = Field(
        default=False,
        description=(
            "When chained, whether to override the next attended activity's assignment so it is shown to "
            "the current user. Only meaningful when activityChained is true."
        ),
    )
    synchronizeData: bool = Field(
        default=False,
        description="Whether to synchronize process variables across this flow.",
    )
    label: str | None = Field(
        default=None, description="Optional flow label shown on the connection."
    )


class ProcessModelNodeInput(BaseModel):
    """A node in a process model flow."""

    id: int = Field(description="Node ID, unique within the process model")
    type: str = Field(
        description="Node type ID from listProcessModelNodeTypes, e.g. core.0, internal3.integration, event.timer"
    )
    name: Annotated[
        str | dict[str, str],
        BeforeValidator(_coerce_json_str_to_dict),
    ] = Field(
        description="Label shown on the process modeler canvas. Can be a simple string (stored in site's primary locale) or a dict mapping locale codes to localized names."
    )
    coordinates: list[int] = Field(description="Canvas position [x, y]")
    connections: list[ProcessModelConnectionInput] = Field(
        default=[],
        description=(
            "Outgoing connections. Each specifies targetNodeId and activityChained (required), plus "
            "optional overridesAssignment, synchronizeData, and label. Empty for End Event."
        ),
    )
    data: NodeDataInput | None = Field(
        default=None,
        description="Data/Setup tab. Use getProcessModelNodeTypeSchema to discover inputs/outputs for the node type.",
    )
    decision: NodeDecisionInput | None = Field(
        default=None, description="Decision tab for gateways."
    )
    assignment: NodeAssignmentInput | None = Field(
        default=None, description="Assignment tab for activity nodes."
    )
    forms: Annotated[
        FormConfigInput | dict[str, FormConfigInput] | None,
        BeforeValidator(_coerce_json_str_to_dict),
    ] = Field(
        default=None,
        description="Forms tab for attended activity nodes. Can be a single FormConfig (stored in site's primary locale) or a dict mapping locale codes to FormConfig objects.",
    )
    lane: int | None = Field(
        default=None,
        description="Index into the process model's lanes array. Assigns this node to a swimlane.",
    )


# ── Lane model ───────────────────────────────────────────────────────────


class LaneLabelStyleInput(BaseModel):
    """Font styling for a swimlane's label."""

    fontColor: str | None = Field(default=None, description="Font color (hex)")
    fontFamily: str | None = Field(default=None, description="Font family name")
    fontSize: int | None = Field(default=None, description="Font size in pixels")
    bold: bool | None = Field(default=None)
    italics: bool | None = Field(default=None)
    underline: bool | None = Field(default=None)


class ProcessModelLaneInput(BaseModel):
    """A swimlane in a process model for visual role-based organization."""

    label: str = Field(description="Display name of the lane")
    color: str | None = Field(
        default=None, description="Background color (hex, e.g. '#E3F2FD')"
    )
    dimension: int | None = Field(
        default=None, description="Lane width/height in pixels"
    )
    isVertical: bool | None = Field(
        default=None, description="true for vertical orientation"
    )
    isLaneAssignment: bool | None = Field(
        default=None,
        description="Whether this lane defines default task assignment for its nodes",
    )
    attended: bool | None = Field(
        default=None,
        description="true=attended (task), false=unattended (system); only if isLaneAssignment=true",
    )
    assignTo: str | None = Field(
        default=None,
        description="SAIL expression for assignee(s); only if isLaneAssignment=true and attended=true",
    )
    runAs: str | None = Field(
        default=None,
        description="INITIATOR or DESIGNER; only if isLaneAssignment=true and attended=false",
    )
    labelStyle: LaneLabelStyleInput | None = Field(
        default=None, description="Font styling for the lane's label"
    )


# ── Record-level security models ─────────────────────────────────────────


class FilterConditionInput(BaseModel):
    """Filter condition for record-level security rules."""

    field: str = Field(description="Record field UUID")
    operator: str = Field(description="Comparison operator (=, <>, <, >, <=, >=)")
    value: str | int | float | bool = Field(description="Comparison value")


class SecurityRuleInput(BaseModel):
    """Record-level security rule defining who can see which records."""

    membershipType: str = Field(description="GROUPS, FIELDS, or RELATED_RECORDS")
    groupUuids: list[str] | None = Field(
        default=None,
        description="Group UUIDs. GROUPS membership only. Rule applies to members of the specified groups.",
    )
    fieldUuids: list[str] | None = Field(
        default=None,
        description="User or Group field UUIDs — direct fields or related record fields. FIELDS membership only. Rule applies to any users found in the specified fields.",
    )
    relationshipUuid: str | None = Field(
        default=None,
        description="Relationship UUID. RELATED_RECORDS membership only. Rule applies to any users who have access to the related record.",
    )
    conditions: list[FilterConditionInput] | None = Field(
        default=None,
        description="Additional filter conditions to further limit rule applicability.",
    )
