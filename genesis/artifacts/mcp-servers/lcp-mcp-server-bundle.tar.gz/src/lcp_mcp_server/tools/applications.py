"""Applications domain MCP tools."""

from typing import Annotated

from lcp_api_plugin_client.api.applications import (
    add_objects_to_application,
    create_application,
    delete_application,
    get_application,
    search_applications,
    update_application,
)
from lcp_api_plugin_client.models.create_application_request import (
    CreateApplicationRequest,
)
from lcp_api_plugin_client.models.update_application_request import (
    UpdateApplicationRequest,
)
from lcp_api_plugin_client.models.design_object_reference import DesignObjectReference
from lcp_api_plugin_client.types import UNSET
from pydantic import BeforeValidator, Field

from . import (
    _coerce_json_str_to_list,
    _safe_to_dict,
    tool_error,
    unwrap_response,
)
from fastmcp.exceptions import ToolError
from .models import DesignObjectInput


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Application", "action_type": "GET"})
    async def listApplications(
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian applications with optional filtering."""
        try:
            resp = await search_applications.asyncio_detailed(
                client=client,
                query=query or UNSET,
                limit=limit,
                offset=offset,
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Application", "action_type": "GET"})
    async def getApplication(appUuid: str) -> dict:
        """Get a single Appian application by UUID, including default object UUIDs (administrator and user security groups)."""
        try:
            resp = await get_application.asyncio_detailed(
                app_uuid=appUuid, client=client
            )
            result = _safe_to_dict(unwrap_response(resp))
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Application", "action_type": "CREATE"})
    async def createApplication(
        name: str,
        prefix: Annotated[
            str | None,
            Field(
                description='Application prefix for object naming conventions (e.g. "CUST"). Auto-generated from the name if not provided.'
            ),
        ] = None,
        description: str | None = None,
    ) -> dict:
        """Create a new Appian application. The API automatically generates default objects (groups, folders, etc.) and associates them with the application."""
        try:
            body = CreateApplicationRequest(
                name=name, prefix=prefix or UNSET, description=description or UNSET
            )
            resp = await create_application.asyncio_detailed(client=client, body=body)
            result = _safe_to_dict(unwrap_response(resp))
            # API may return 200 with error in body
            if "Duplicate" in str(result.get("error", "")):
                raise ToolError(result["error"])
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Application", "action_type": "UPDATE"})
    async def addObjectsToApplication(
        appUuid: str,
        objects: Annotated[
            list[DesignObjectInput],
            BeforeValidator(_coerce_json_str_to_list),
        ],
    ) -> dict:
        """Add design objects to an Appian application. Most create tools now accept appUuid directly — use this tool mainly for associating pre-existing objects with an application."""
        try:
            obj_dicts = [o.model_dump() for o in objects]
            for o in obj_dicts:
                if "type" in o:
                    o["type"] = o["type"].upper().replace(" ", "_")
            body = [DesignObjectReference.from_dict(o) for o in obj_dicts]
            resp = await add_objects_to_application.asyncio_detailed(
                app_uuid=appUuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Application", "action_type": "UPDATE"})
    async def updateApplication(
        appUuid: str,
        name: str | None = None,
        description: str | None = None,
        prefix: Annotated[
            str | None,
            Field(
                description='New application prefix for object naming conventions (e.g. "BDC"). Does NOT automatically rename existing objects that use the old prefix.'
            ),
        ] = None,
    ) -> dict:
        """Update an existing Appian application's metadata. Only provided fields are changed. Note: changing the prefix does NOT automatically rename objects using the old prefix — those must be renamed individually."""
        try:
            body = UpdateApplicationRequest(
                name=name or UNSET,
                description=description or UNSET,
                prefix=prefix or UNSET,
            )
            resp = await update_application.asyncio_detailed(
                app_uuid=appUuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Application", "action_type": "DELETE"})
    async def deleteApplication(appUuid: str) -> str:
        """Permanently delete an Appian application. This removes the application container only — all design objects (records, interfaces, process models, etc.) that were part of the application are preserved and become unassociated."""
        try:
            resp = await delete_application.asyncio_detailed(
                app_uuid=appUuid, client=client
            )
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e
