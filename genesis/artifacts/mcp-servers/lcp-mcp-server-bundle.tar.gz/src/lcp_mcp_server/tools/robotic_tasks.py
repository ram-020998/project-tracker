"""Robotic Tasks domain MCP tools."""

from lcp_api_beta_client.api.design_objects_robotic_tasks import (
    get_robotic_task,
    list_robotic_tasks,
)
from lcp_api_beta_client.types import UNSET
from lcp_api_plugin_client.api.applications import list_application_robotic_tasks
from lcp_api_plugin_client.types import UNSET as PLUGIN_UNSET

from . import _safe_to_dict, tool_error, unwrap_response
from .ai_skills import _unwrap_beta_response

# The Robotic Tasks endpoint requires X-Appian-Api-Version: beta
_API_VERSION = "beta"


def register_tools(mcp, client, plugin_client):
    @mcp.tool(meta={"object_type": "Robotic Task", "action_type": "GET"})
    async def listRoboticTasks(
        name: str | None = None,
        appUuid: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian robotic tasks with optional name filtering."""
        try:
            if appUuid is not None:
                resp = await list_application_robotic_tasks.asyncio_detailed(
                    app_uuid=appUuid,
                    query=name or PLUGIN_UNSET,
                    limit=limit,
                    offset=offset,
                    client=plugin_client,
                )
                return unwrap_response(resp)
            resp = await list_robotic_tasks.asyncio_detailed(
                client=client,
                name=name or UNSET,
                limit=limit,
                offset=offset,
                x_appian_api_version=_API_VERSION,
            )
            return _safe_to_dict(_unwrap_beta_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Robotic Task", "action_type": "GET"})
    async def getRoboticTask(uuid: str) -> dict:
        """Get a single Appian robotic task by UUID."""
        try:
            resp = await get_robotic_task.asyncio_detailed(
                uuid=uuid,
                client=client,
                x_appian_api_version=_API_VERSION,
            )
            return _safe_to_dict(_unwrap_beta_response(resp))
        except Exception as e:
            raise tool_error(e) from e
