"""Sites domain MCP tools."""

from typing import Annotated

from lcp_api_plugin_client.api.applications import list_application_sites
from lcp_api_plugin_client.api.sites import (
    create_site,
    delete_site,
    get_site_by_uuid,
    list_sites,
    update_site,
)
from lcp_api_plugin_client.models.create_site_request import CreateSiteRequest
from lcp_api_plugin_client.models.create_site_request_layout import (
    CreateSiteRequestLayout,
)
from lcp_api_plugin_client.models.create_site_request_style import (
    CreateSiteRequestStyle,
)
from lcp_api_plugin_client.models.site_page import SitePage
from lcp_api_plugin_client.models.update_site_request import UpdateSiteRequest
from lcp_api_plugin_client.models.update_site_request_layout import (
    UpdateSiteRequestLayout,
)
from lcp_api_plugin_client.models.update_site_request_style import (
    UpdateSiteRequestStyle,
)
from lcp_api_plugin_client.types import UNSET
from pydantic import BeforeValidator, Field

from . import (
    _coerce_json_str_to_list,
    _safe_to_dict,
    tool_error,
    unwrap_response,
)
from .models import SitePageInput


async def _get_version_id(uuid: str, client) -> str | None:
    resp = await get_site_by_uuid.asyncio_detailed(uuid=uuid, client=client)
    return _safe_to_dict(unwrap_response(resp)).get("versionId")


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Site", "action_type": "GET"})
    async def listSites(
        appUuid: str,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian sites with optional filtering. Use appUuid to scope to an application."""
        try:
            if appUuid:
                resp = await list_application_sites.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    limit=limit,
                    offset=offset,
                )
            else:
                resp = await list_sites.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Site", "action_type": "GET"})
    async def getSite(uuid: str) -> dict:
        """Get a single Appian site by UUID."""
        try:
            resp = await get_site_by_uuid.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Site", "action_type": "CREATE"})
    async def createSite(
        name: str,
        displayName: str,
        webAddressIdentifier: str,
        pages: Annotated[
            list[SitePageInput],
            BeforeValidator(_coerce_json_str_to_list),
        ],
        appUuid: Annotated[
            str,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object to the app and applies the app's default security."
            ),
        ],
        description: str | None = None,
        layout: Annotated[
            str,
            Field(
                description="Navigation bar layout: HEADER_BAR (top nav, default) or SIDEBAR (left nav)."
            ),
        ] = None,
        style: Annotated[
            str,
            Field(
                description="Header bar style (only when layout=HEADER_BAR): MERCURY (default), HELIUM, or OXYGEN."
            ),
        ] = None,
    ) -> dict:
        """Create a new Appian site. Requires at least one page.

        Pages support three types: INTERFACE (default, displays an interface object),
        RECORD_LIST (displays a record type's record list), and ACTION (displays a
        process model's start form). Set the page 'type' field accordingly and pass
        the appropriate UUID as 'targetUuid'."""
        try:
            body = CreateSiteRequest(
                name=name,
                display_name=displayName,
                web_address_identifier=webAddressIdentifier,
                app_uuid=appUuid,
                description=description or UNSET,
                layout=CreateSiteRequestLayout(layout) if layout else UNSET,
                style=CreateSiteRequestStyle(style) if style else UNSET,
                pages=[
                    SitePage.from_dict(p.model_dump(exclude_none=True)) for p in pages
                ],
            )
            resp = await create_site.asyncio_detailed(client=client, body=body)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Site", "action_type": "UPDATE"})
    async def updateSite(
        uuid: str,
        name: str | None = None,
        displayName: str | None = None,
        webAddressIdentifier: str | None = None,
        pages: Annotated[
            list[SitePageInput] | None,
            BeforeValidator(_coerce_json_str_to_list),
        ] = None,
        description: str | None = None,
        layout: Annotated[
            str,
            Field(
                description="Navigation bar layout: HEADER_BAR (top nav) or SIDEBAR (left nav)."
            ),
        ] = None,
        style: Annotated[
            str,
            Field(
                description="Header bar style (only when layout=HEADER_BAR): MERCURY, HELIUM, or OXYGEN."
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Update an existing Appian site. Only provided fields are changed.

        Pages support three types: INTERFACE (default, displays an interface object),
        RECORD_LIST (displays a record type's record list), and ACTION (displays a
        process model's start form). Set the page 'type' field accordingly and pass
        the appropriate UUID as 'targetUuid'."""
        try:
            body = UpdateSiteRequest(
                name=name or UNSET,
                display_name=displayName or UNSET,
                web_address_identifier=webAddressIdentifier or UNSET,
                description=description or UNSET,
                layout=UpdateSiteRequestLayout(layout) if layout else UNSET,
                style=UpdateSiteRequestStyle(style) if style else UNSET,
                pages=[
                    SitePage.from_dict(p.model_dump(exclude_none=True)) for p in pages
                ]
                if pages is not None
                else UNSET,
                version_id=versionId or UNSET,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_site.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Site", "action_type": "DELETE"})
    async def deleteSite(uuid: str) -> str:
        """Permanently delete an Appian site."""
        try:
            resp = await delete_site.asyncio_detailed(uuid=uuid, client=client)
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e
