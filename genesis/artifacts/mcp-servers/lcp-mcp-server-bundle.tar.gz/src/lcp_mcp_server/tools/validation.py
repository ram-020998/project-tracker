"""Validation domain MCP tools."""

from http import HTTPStatus

from lcp_api_plugin_client.api.objects import validate_design_object
from lcp_api_plugin_client.api.validation import validate_expression
from lcp_api_plugin_client.models.validate_expression_request import (
    ValidateExpressionRequest,
)
from lcp_api_plugin_client.models.validate_expression_request_bindings_type_0_item import (
    ValidateExpressionRequestBindingsType0Item,
)

from . import _safe_to_dict, tool_error, unwrap_response
from fastmcp.exceptions import ToolError


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Validation", "action_type": "GET"})
    async def validateDesignObject(uuid: str) -> dict:
        """Validate all expressions on a design object by UUID.

        Returns validation results including any expression errors found.
        Use this to check for expression errors without performing a save.
        """
        try:
            resp = await validate_design_object.asyncio_detailed(
                uuid=uuid, client=client
            )
            status = (
                resp.status_code.value
                if isinstance(resp.status_code, HTTPStatus)
                else int(resp.status_code)
            )
            if status == 403:
                raise ToolError(
                    f"Design object not found or not accessible: {uuid}"
                )
            if status >= 500:
                body_preview = resp.content.decode(errors="replace")[:200]
                raise ToolError(f"Server error (HTTP {status}): {body_preview}")
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Validation", "action_type": "GET"})
    async def validateExpression(
        expression: str,
        bindings: list[dict] | None = None,
        isInterface: bool = False,
    ) -> dict:
        """Validate a raw SAIL expression without saving it.

        Runs parse, discovery, and eval passes. No rule inputs or record
        references are stubbed — use for standalone expressions like freeform mockups.

        Args:
            expression: SAIL expression to validate.
            bindings: Optional list of variable bindings for navigation linking.
                      Each binding has name, domain, and type fields.
            isInterface: Set True when validating an interface/form expression (a SAIL
                      component tree, e.g. one using a!formLayout or referencing
                      env!features). This routes through the strict interface eval path
                      that supplies the client-state context. Leave False for ordinary
                      expressions; passing an interface expression with False fails with
                      "Could not find variable 'env!features'".
        """
        try:
            binding_items = None
            if bindings:
                binding_items = [
                    ValidateExpressionRequestBindingsType0Item(
                        name=b.get("name"),
                        type_=b.get("type"),
                        domain=b.get("domain"),
                    )
                    for b in bindings
                ]
            body = ValidateExpressionRequest(
                expression=expression,
                bindings=binding_items,
                is_interface=isInterface,
            )
            resp = await validate_expression.asyncio_detailed(
                body=body, client=client
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e
