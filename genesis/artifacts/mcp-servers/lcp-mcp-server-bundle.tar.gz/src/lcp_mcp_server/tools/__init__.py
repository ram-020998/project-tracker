"""Tools package — helper utilities and per-domain tool modules."""

import json
import logging
from http import HTTPStatus
from pathlib import Path
from typing import Annotated, Any, Dict

import attrs
import httpx
from fastmcp.exceptions import ToolError
from lcp_api_plugin_client.types import UNSET, Unset
from pydantic import BeforeValidator


def _safe_to_dict(result):
    """Serialize API result, falling back to attrs.asdict when to_dict() fails."""
    if not result:
        return {}
    try:
        return result.to_dict()
    except AttributeError:
        from lcp_api_plugin_client.types import UNSET

        def _filter(_attr, value):
            return not isinstance(value, type(UNSET))

        return attrs.asdict(result, filter=_filter)


def _coerce_json_str_to_list(v):
    """Coerce a JSON string to a list. MCP tool calls may deliver list args as strings."""
    if isinstance(v, str):
        try:
            parsed = json.loads(v)
            if isinstance(parsed, list):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
    return v


def _coerce_json_str_to_dict(v):
    """Coerce a JSON string to a dict. MCP tool calls may deliver dict/object args as strings.

    Used for locale map fields that can be either a plain string or a dict of locale->string mappings.
    """
    if isinstance(v, str):
        try:
            parsed = json.loads(v)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
    return v


JsonListOfDicts = Annotated[list[dict], BeforeValidator(_coerce_json_str_to_list)]


# ── Expression file helpers ───────────────────────────────────────────────────
# Expressions can be exchanged as local files so AI agents can edit them with
# efficient line-based patches rather than regenerating entire expressions.
#
# The agent controls the file location by passing expressionFilePath to
# get* (write target) and create*/update* (read source).


def write_expression_to_path(file_path: str, expression: str | None) -> None:
    """Write expression content to an agent-specified path."""
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(expression or "", encoding="utf-8")


def read_expression_from_file(file_path: str) -> str:
    """Read expression content from a file path.

    Raises ToolError if the file is missing or empty.
    """
    path = Path(file_path)
    if not path.is_file():
        raise ToolError(f"expressionFilePath not found: {file_path}")
    text = path.read_text(encoding="utf-8")
    if not text.strip():
        raise ToolError(f"expressionFilePath is empty: {file_path}")
    return text


def resolve_expression(
    expression: str | None, expressionFilePath: str | None
) -> str | None:
    """Resolve expression from either inline string or file path.

    expressionFilePath takes precedence if both are provided.
    Returns None if neither is provided (caller decides whether that's an error).
    """
    if expressionFilePath:
        return read_expression_from_file(expressionFilePath)
    if expression:
        return expression
    return None


logger = logging.getLogger(__name__)


class LCPResponseError(Exception):
    """Raised when the LCP API returns an unparseable or error response."""

    def __init__(self, status_code: int, content_type: str, body_preview: str):
        self.status_code = status_code
        self.content_type = content_type
        self.body_preview = body_preview
        super().__init__(
            f"LCP API error: HTTP {status_code} ({content_type}). "
            f"Response: {body_preview}"
        )


def unwrap_response(response) -> Any:
    """Extract the parsed result from an SDK detailed response.

    Raises LCPResponseError when the response is an error (4xx/5xx parsed as an
    SDK Error object) or when the response cannot be parsed at all.
    """
    from lcp_api_plugin_client.models.error import Error as SDKError

    if response.parsed is not None:
        # SDK parses 400/403/500 into Error attrs objects — raise, don't return.
        if isinstance(response.parsed, SDKError):
            status_code = (
                response.status_code.value
                if isinstance(response.status_code, HTTPStatus)
                else int(response.status_code)
            )
            # Include validation details if present (e.g., discovery errors)
            body_preview = response.parsed.error
            if response.parsed.details and not isinstance(
                response.parsed.details, Unset
            ):
                detail_msgs = [
                    f"{d.source}: {d.message}"
                    if getattr(d, "source", None)
                    else d.message
                    for d in response.parsed.details
                ]
                body_preview = f"{body_preview} — {'; '.join(detail_msgs)}"
            raise LCPResponseError(
                status_code,
                response.headers.get("content-type", "unknown"),
                body_preview,
            )
        return response.parsed

    # parsed is None — check if this is a successful no-content response (e.g., 204)
    status_code = (
        response.status_code.value
        if isinstance(response.status_code, HTTPStatus)
        else int(response.status_code)
    )

    if 200 <= status_code < 300 and not response.content:
        # 2xx with empty body (e.g., 204 No Content from deletes) is success
        return None

    content_type = response.headers.get("content-type", "unknown")
    body_preview = response.content.decode(errors="replace")[:200]
    raise LCPResponseError(status_code, content_type, body_preview)


def handle_tool_error(e: Exception, tool_name: str) -> Dict[str, Any]:
    """Handle tool execution errors with structured responses.

    .. deprecated::
        Use ``raise tool_error(e)`` instead for MCP protocol-compliant error signaling.
    """
    if isinstance(e, LCPResponseError):
        logger.error(f"[{tool_name}] LCP response error: {e}", exc_info=True)
        return {
            "success": False,
            "error": str(e),
            "error_type": "api_error",
            "status_code": e.status_code,
        }
    elif isinstance(e, httpx.HTTPStatusError):
        status_code = e.response.status_code
        logger.error(f"[{tool_name}] HTTP error {status_code}: {e}", exc_info=True)
        try:
            error_detail = e.response.json().get("error", str(e))
        except Exception:
            error_detail = str(e)
        return {
            "success": False,
            "error": f"HTTP {status_code}: {error_detail}",
            "error_type": "http_error",
            "status_code": status_code,
        }
    elif isinstance(
        e, (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError)
    ):
        logger.error(f"[{tool_name}] Network error: {e}", exc_info=True)
        return {
            "success": False,
            "error": f"Network error: {str(e)}",
            "error_type": "network_error",
        }
    else:
        logger.error(f"[{tool_name}] Unexpected error: {e}", exc_info=True)
        return {"success": False, "error": str(e), "error_type": "api_error"}


def tool_error(e: Exception) -> ToolError:
    """Build a ToolError with a classified, LLM-friendly message.

    Raises via the MCP protocol's isError flag so hosts can distinguish
    tool failures from successful results.
    """
    if isinstance(e, LCPResponseError):
        msg = f"API error (HTTP {e.status_code}): {e.body_preview}"
    elif isinstance(e, httpx.HTTPStatusError):
        status_code = e.response.status_code
        try:
            error_detail = e.response.json().get("error", str(e))
        except Exception:
            error_detail = e.response.text[:200]
        msg = f"HTTP {status_code}: {error_detail}"
    elif isinstance(
        e, (httpx.ConnectError, httpx.TimeoutException, httpx.NetworkError)
    ):
        msg = f"Network error: {e}"
    else:
        msg = f"Unexpected error: {e}"
    return ToolError(msg)
