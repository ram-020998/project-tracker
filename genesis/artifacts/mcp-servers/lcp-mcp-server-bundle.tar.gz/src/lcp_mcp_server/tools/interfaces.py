"""Interfaces domain MCP tools."""

from typing import Annotated

from lcp_api_plugin_client.api.applications import list_application_interfaces
from lcp_api_plugin_client.api.interfaces import (
    create_interface,
    create_interface_test_case,
    delete_interface,
    delete_interface_test_case,
    get_interface,
    get_interface_test_case,
    list_interface_test_cases,
    list_interfaces,
    run_all_interface_test_cases,
    run_interface_test_case,
    test_interface,
    update_interface,
    update_interface_test_case,
)
from lcp_api_plugin_client.models.create_interface_request import CreateInterfaceRequest
from lcp_api_plugin_client.models.create_interface_request_test_inputs_item import (
    CreateInterfaceRequestTestInputsItem,
)
from lcp_api_plugin_client.models.create_test_case_request import CreateTestCaseRequest
from lcp_api_plugin_client.models.test_rule_request import TestRuleRequest
from lcp_api_plugin_client.models.typed_input import TypedInput as SdkTypedInput
from lcp_api_plugin_client.models.update_interface_request import UpdateInterfaceRequest
from lcp_api_plugin_client.models.update_interface_request_test_inputs_item import (
    UpdateInterfaceRequestTestInputsItem,
)
from fastmcp.exceptions import ToolError
from lcp_api_plugin_client.types import UNSET
from pydantic import BeforeValidator, Field

from . import (
    _coerce_json_str_to_list,
    _safe_to_dict,
    resolve_expression,
    tool_error,
    unwrap_response,
    write_expression_to_path,
)
from .models import TypedInput, TestInput


async def _get_version_id(uuid: str, client) -> str | None:
    resp = await get_interface.asyncio_detailed(uuid=uuid, client=client)
    return _safe_to_dict(unwrap_response(resp)).get("versionId")


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Interface", "action_type": "GET"})
    async def listInterfaces(
        appUuid: str,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian interfaces with optional filtering. Use appUuid to scope to an application."""
        try:
            if appUuid:
                resp = await list_application_interfaces.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            else:
                resp = await list_interfaces.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Interface", "action_type": "GET"})
    async def getInterface(
        uuid: str,
        expressionFilePath: Annotated[
            str | None,
            Field(
                description="Absolute path where the expression body will be written. "
                "When provided, the expression is saved to this file and stripped from the response. "
                "Omit to include the expression inline in the response."
            ),
        ] = None,
    ) -> dict:
        """Get a single Appian interface by UUID.

        Writes the expression body to expressionFilePath and strips it from the
        response. Edit the file directly, then pass the path to updateInterface.
        """
        try:
            resp = await get_interface.asyncio_detailed(uuid=uuid, client=client)
            result = _safe_to_dict(unwrap_response(resp))
            if expressionFilePath:
                expression = result.get("expression")
                if expression:
                    write_expression_to_path(expressionFilePath, expression)
                    result["expressionFilePath"] = expressionFilePath
                result.pop("expression", None)
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Interface", "action_type": "CREATE"})
    async def createInterface(
        name: str,
        appUuid: Annotated[
            str | None,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object to the app and applies the app's default security, selecting an appropriate Rules and Constants folder. Either appUuid or parentFolderUuid must be provided."
            ),
        ] = None,
        parentFolderUuid: Annotated[
            str | None,
            Field(
                description="UUID of the parent Rules and Constants folder. Takes precedence over appUuid for folder selection. Either appUuid or parentFolderUuid must be provided."
            ),
        ] = None,
        expressionFilePath: Annotated[
            str | None,
            Field(
                description="Absolute path to the local file containing the SAIL expression. "
                "Write the SAIL expression to this file before calling createInterface. "
                "The file content is submitted as the interface expression."
            ),
        ] = None,
        expression: Annotated[
            str | None,
            Field(
                description="Inline SAIL expression string. Use expressionFilePath instead for "
                "non-trivial expressions — it enables efficient editing on validation failure."
            ),
        ] = None,
        description: str | None = None,
        inputs: Annotated[
            list[TypedInput] | None, BeforeValidator(_coerce_json_str_to_list)
        ] = None,
        testInputs: Annotated[
            list[TestInput] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description="Test input values for validation and as default test values. If not provided, validation uses null inputs. Once saved, these become the default test values used on subsequent updates."
            ),
        ] = None,
    ) -> dict:
        """Create a new Appian interface.

        Provide either appUuid (to auto-select the app's Rules and Constants folder) or
        parentFolderUuid (to target a specific folder). If both are given, parentFolderUuid wins.

        Write the SAIL expression to a local file first, then pass its path as
        expressionFilePath. The file content is submitted as the interface expression.

        Input types can be built-in (e.g. "Text", "Number (Integer)", "Boolean") or
        developer-defined — use the typeReference string from getRecordType for record types.
        Provide inputs alongside expression so that ri! references validate correctly.

        Provide testInputs to validate with real values instead of nulls, useful for interfaces
        that require non-null inputs. These values are saved as default test values.

        On validation failure, fix the file and call updateInterface with the same path.
        """
        if not appUuid and not parentFolderUuid:
            raise ToolError("Either appUuid or parentFolderUuid must be provided.")
        try:
            resolved_expression = resolve_expression(expression, expressionFilePath)

            body = CreateInterfaceRequest(
                name=name,
                app_uuid=appUuid or UNSET,
                parent_folder_uuid=parentFolderUuid or UNSET,
                description=description or UNSET,
                expression=resolved_expression or UNSET,
                inputs=[
                    SdkTypedInput.from_dict(i.model_dump(exclude_none=True))
                    for i in inputs
                ]
                if inputs is not None
                else UNSET,
                test_inputs=[
                    CreateInterfaceRequestTestInputsItem.from_dict(
                        {k: v for k, v in {
                            "name": ti.name,
                            "value": ti.value,
                            "type": ti.type
                        }.items() if v is not None}
                    )
                    for ti in testInputs
                ]
                if testInputs is not None
                else UNSET,
            )
            resp = await create_interface.asyncio_detailed(client=client, body=body)
            result = _safe_to_dict(unwrap_response(resp))
            if expressionFilePath:
                result["expressionFilePath"] = expressionFilePath
                result.pop("expression", None)
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Interface", "action_type": "UPDATE"})
    async def updateInterface(
        uuid: str,
        expressionFilePath: Annotated[
            str | None,
            Field(
                description="Absolute path to the local file containing the SAIL expression. "
                "Edit the file from getInterface or createInterface, then pass the same path here. "
                "The file content is read and submitted as the expression."
            ),
        ] = None,
        expression: Annotated[
            str | None,
            Field(
                description="Inline SAIL expression string. Use expressionFilePath instead for "
                "non-trivial expressions — it enables efficient editing on validation failure."
            ),
        ] = None,
        name: str | None = None,
        description: str | None = None,
        inputs: Annotated[
            list[TypedInput] | None, BeforeValidator(_coerce_json_str_to_list)
        ] = None,
        testInputs: Annotated[
            list[TestInput] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description="Test input values for validation. If not provided, existing test values are reused. If none exist, validation uses null inputs."
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Update an existing Appian interface. Only provided fields are changed.

        Input types can be built-in (e.g. "Text", "Number (Integer)", "Boolean") or
        developer-defined — use the typeReference string from getRecordType for record types.
        Provide inputs alongside expression so that ri! references validate correctly.

        testInputs: If provided, updates the stored test values. If omitted, existing test values
        are preserved and used for validation.

        Edit the SAIL file, then pass the same expressionFilePath to submit changes.
        """
        try:
            resolved_expression = resolve_expression(expression, expressionFilePath)
            body = UpdateInterfaceRequest(
                name=name or UNSET,
                description=description or UNSET,
                expression=resolved_expression or UNSET,
                inputs=[
                    SdkTypedInput.from_dict(i.model_dump(exclude_none=True))
                    for i in inputs
                ]
                if inputs is not None
                else UNSET,
                test_inputs=[
                    UpdateInterfaceRequestTestInputsItem.from_dict(
                        {k: v for k, v in {
                            "name": ti.name,
                            "value": ti.value,
                            "type": ti.type
                        }.items() if v is not None}
                    )
                    for ti in testInputs
                ]
                if testInputs is not None
                else UNSET,
                version_id=versionId or UNSET,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_interface.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Interface", "action_type": "DELETE"})
    async def deleteInterface(uuid: str) -> str:
        """Permanently delete an Appian interface."""
        try:
            resp = await delete_interface.asyncio_detailed(uuid=uuid, client=client)
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Interface", "action_type": "GET"})
    async def testInterface(
        uuid: str,
        inputs: Annotated[
            dict | None,
            Field(description="Key/value map of input parameters."),
        ] = None,
        timeoutSeconds: Annotated[
            int | None,
            Field(
                description="Maximum time to wait for execution. Default: 5. Max: 60."
            ),
        ] = None,
        maxResponseSizeBytes: Annotated[
            int | None,
            Field(
                description="Maximum response size to return. Default: 5120 (5KB). Max: 1048576 (1MB)."
            ),
        ] = None,
    ) -> dict:
        """Evaluate an Appian interface with test inputs and check for runtime errors. Use diagnostics.error to detect rendering failures that syntax validation misses (bad record references, type mismatches, missing inputs). The result contains the rendered SAIL component tree."""
        try:
            body = TestRuleRequest(
                inputs=inputs or UNSET,
                timeout_seconds=timeoutSeconds if timeoutSeconds is not None else UNSET,
                max_response_size_bytes=maxResponseSizeBytes
                if maxResponseSizeBytes is not None
                else UNSET,
            )
            resp = await test_interface.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    # ── Interface Test Case Tools ────────────────────────────────────────────

    @mcp.tool(meta={"object_type": "Interface", "action_type": "GET"})
    async def listInterfaceTestCases(uuid: str) -> dict:
        """List all saved test cases for an interface."""
        try:
            resp = await list_interface_test_cases.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Interface", "action_type": "GET"})
    async def getInterfaceTestCase(uuid: str, testCaseUuid: str) -> dict:
        """Get a specific test case by UUID for an interface."""
        try:
            resp = await get_interface_test_case.asyncio_detailed(
                uuid=uuid, test_case_uuid=testCaseUuid, client=client
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Interface", "action_type": "CREATE"})
    async def createInterfaceTestCase(
        uuid: str,
        name: Annotated[str, Field(description="Human-readable test case name")],
        inputs: Annotated[
            list[dict] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description='List of input objects. Each has "name" (parameter name), "value" (SAIL expression string), and optional "type" (e.g. "Text", "Number (Integer)"). Example: [{"name": "tier", "value": "\\"Gold\\""}, {"name": "amount", "value": "100.0"}]'
            ),
        ] = None,
        description: Annotated[str | None, Field(description="Optional description")] = None,
        isDefault: Annotated[bool | None, Field(description="Whether this is the default test case")] = None,
    ) -> dict:
        """Create a saved test case for an interface.

        Stores input values for the interface. Duplicate names are rejected with 409.
        """
        try:
            payload = {"name": name}
            if inputs is not None:
                payload["inputs"] = inputs
            if description is not None:
                payload["description"] = description
            if isDefault is not None:
                payload["isDefault"] = isDefault
            body = CreateTestCaseRequest.from_dict(payload)
            resp = await create_interface_test_case.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Interface", "action_type": "CREATE"})
    async def createInterfaceTestCases(
        uuid: str,
        testCases: Annotated[
            list[dict],
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description='Array of test cases to create in a single batch. '
                'Each item has: "name" (required), "inputs" (array of {name, value, type?}), '
                '"description", "isDefault".'
            ),
        ],
    ) -> dict:
        """Create multiple test cases for an interface in a single call.

        Accepts an array of test case objects. Returns {"created": [...], "errors": [...]}.
        Partial failures are captured in "errors" rather than aborting the batch.
        Duplicate names within the batch or against existing test cases are rejected with 409.
        """
        results = []
        errors = []
        for i, tc in enumerate(testCases):
            try:
                body = CreateTestCaseRequest.from_dict(tc)
                resp = await create_interface_test_case.asyncio_detailed(
                    uuid=uuid, client=client, body=body
                )
                results.append(_safe_to_dict(unwrap_response(resp)))
            except Exception as item_err:
                errors.append({"index": i, "name": tc.get("name", ""), "error": str(item_err)})
        if errors and not results:
            raise tool_error(Exception(f"All test cases failed: {errors}"))
        return {"created": results, "errors": errors}

    @mcp.tool(meta={"object_type": "Interface", "action_type": "UPDATE"})
    async def updateInterfaceTestCase(
        uuid: str,
        testCaseUuid: Annotated[str, Field(description="Test case UUID (from listInterfaceTestCases)")],
        name: Annotated[str, Field(description="Updated test case name")],
        inputs: Annotated[
            list[dict] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description='List of input objects. Each has "name" (parameter name), "value" (SAIL expression string), and optional "type" (e.g. "Text", "Number (Integer)"). Example: [{"name": "tier", "value": "\\"Gold\\""}, {"name": "amount", "value": "100.0"}]'
            ),
        ] = None,
        description: Annotated[str | None, Field(description="Optional description")] = None,
        isDefault: Annotated[bool | None, Field(description="Whether this is the default test case")] = None,
    ) -> dict:
        """Update an existing interface test case. Duplicate names are rejected with 409."""
        try:
            payload = {"name": name}
            if inputs is not None:
                payload["inputs"] = inputs
            if description is not None:
                payload["description"] = description
            if isDefault is not None:
                payload["isDefault"] = isDefault
            body = CreateTestCaseRequest.from_dict(payload)
            resp = await update_interface_test_case.asyncio_detailed(
                uuid=uuid, test_case_uuid=testCaseUuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Interface", "action_type": "DELETE"})
    async def deleteInterfaceTestCase(
        uuid: str,
        testCaseUuid: Annotated[str, Field(description="Test case UUID (from listInterfaceTestCases)")],
    ) -> str:
        """Delete a saved test case from an interface."""
        try:
            resp = await delete_interface_test_case.asyncio_detailed(
                uuid=uuid, test_case_uuid=testCaseUuid, client=client
            )
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Interface", "action_type": "GET"})
    async def runInterfaceTestCase(
        uuid: str,
        testCaseUuid: Annotated[str, Field(description="Test case UUID (from listInterfaceTestCases)")],
    ) -> dict:
        """Run a single saved test case for an interface.

        Returns success/failure, output, duration, and any test errors.
        """
        try:
            resp = await run_interface_test_case.asyncio_detailed(
                uuid=uuid, test_case_uuid=testCaseUuid, client=client
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Interface", "action_type": "GET"})
    async def runAllInterfaceTestCases(uuid: str) -> dict:
        """Run all saved test cases for an interface.

        Returns pass/fail results for each test case with totalCount, passCount, failCount.
        """
        try:
            resp = await run_all_interface_test_cases.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e
