"""Record Types domain MCP tools."""

import asyncio
from collections import defaultdict
from typing import Annotated

from lcp_api_plugin_client.api.applications import list_application_record_types
from lcp_api_plugin_client.api.record_types import (
    add_record_type_action,
    add_record_type_field,
    add_record_type_relationship,
    add_record_type_user_filter,
    add_record_type_view,
    configure_record_events,
    create_record_type,
    delete_record_type,
    delete_record_type_action,
    delete_record_type_field,
    delete_record_type_relationship,
    delete_record_type_user_filter,
    delete_record_type_view,
    get_record_events_config,
    get_record_type_by_uuid,
    get_record_type_field,
    list_record_type_actions,
    list_record_type_fields,
    list_record_type_relationships,
    list_record_type_user_filters,
    list_record_type_views,
    list_record_types,
    reorder_record_type_views,
    update_record_type,
    update_record_type_action,
    update_record_type_field,
    update_record_type_relationship,
    update_record_type_user_filter,
    update_record_type_view,
)
from lcp_api_plugin_client.models.add_record_type_field_request import (
    AddRecordTypeFieldRequest,
)
from lcp_api_plugin_client.models.add_record_type_field_request_field_type import (
    AddRecordTypeFieldRequestFieldType,
)
from lcp_api_plugin_client.models.add_record_type_relationship_request import (
    AddRecordTypeRelationshipRequest,
)
from lcp_api_plugin_client.models.add_record_type_relationship_request_relationship_type import (
    AddRecordTypeRelationshipRequestRelationshipType,
)
from lcp_api_plugin_client.models.add_user_filter_request import (
    AddUserFilterRequest,
)
from lcp_api_plugin_client.models.add_user_filter_request_facet_type import (
    AddUserFilterRequestFacetType,
)
from lcp_api_plugin_client.models.add_user_filter_request_related_record_sort import (
    AddUserFilterRequestRelatedRecordSort,
)
from lcp_api_plugin_client.models.configure_record_events_request import (
    ConfigureRecordEventsRequest,
)
from lcp_api_plugin_client.models.create_record_action_request import (
    CreateRecordActionRequest,
)
from lcp_api_plugin_client.models.create_record_action_request_action_type import (
    CreateRecordActionRequestActionType,
)
from lcp_api_plugin_client.models.create_record_action_request_dialog_height import (
    CreateRecordActionRequestDialogHeight,
)
from lcp_api_plugin_client.models.create_record_action_request_dialog_width import (
    CreateRecordActionRequestDialogWidth,
)
from lcp_api_plugin_client.models.create_record_type_request import (
    CreateRecordTypeRequest,
)
from lcp_api_plugin_client.models.create_record_type_request_source_type import (
    CreateRecordTypeRequestSourceType,
)
from lcp_api_plugin_client.models.create_record_view_request import (
    CreateRecordViewRequest,
)
from lcp_api_plugin_client.models.create_record_view_request_launch_type import (
    CreateRecordViewRequestLaunchType,
)
from lcp_api_plugin_client.models.delete_record_type_field_request import (
    DeleteRecordTypeFieldRequest,
)
from lcp_api_plugin_client.models.facet_option import FacetOption
from lcp_api_plugin_client.models.facet_option_operator import FacetOptionOperator
from lcp_api_plugin_client.models.record_security_rule import RecordSecurityRule
from lcp_api_plugin_client.models.reorder_record_views_request import (
    ReorderRecordViewsRequest,
)
from lcp_api_plugin_client.models.update_record_action_request import (
    UpdateRecordActionRequest,
)
from lcp_api_plugin_client.models.update_record_action_request_dialog_height import (
    UpdateRecordActionRequestDialogHeight,
)
from lcp_api_plugin_client.models.update_record_action_request_dialog_width import (
    UpdateRecordActionRequestDialogWidth,
)
from lcp_api_plugin_client.models.update_record_type_field_request import (
    UpdateRecordTypeFieldRequest,
)
from lcp_api_plugin_client.models.update_record_type_field_request_field_type import (
    UpdateRecordTypeFieldRequestFieldType,
)
from lcp_api_plugin_client.models.update_record_type_relationship_request import (
    UpdateRecordTypeRelationshipRequest,
)
from lcp_api_plugin_client.models.update_record_type_relationship_request_relationship_type import (
    UpdateRecordTypeRelationshipRequestRelationshipType,
)
from lcp_api_plugin_client.models.update_record_type_request import (
    UpdateRecordTypeRequest,
)
from lcp_api_plugin_client.models.update_record_view_request import (
    UpdateRecordViewRequest,
)
from lcp_api_plugin_client.models.update_record_view_request_launch_type import (
    UpdateRecordViewRequestLaunchType,
)
from lcp_api_plugin_client.models.update_user_filter_request import (
    UpdateUserFilterRequest,
)
from lcp_api_plugin_client.models.update_user_filter_request_facet_type import (
    UpdateUserFilterRequestFacetType,
)
from lcp_api_plugin_client.models.update_user_filter_request_related_record_sort import (
    UpdateUserFilterRequestRelatedRecordSort,
)
from lcp_api_plugin_client.types import UNSET
from pydantic import BeforeValidator, Field

from ..validators import ValidationError
from fastmcp.exceptions import ToolError
from . import (
    _coerce_json_str_to_list,
    _safe_to_dict,
    tool_error,
    unwrap_response,
)
from .models import FacetOptionInput, RecordFieldInput, RelationshipInput, SecurityRuleInput


def _to_dict(result):
    """Handle mixed return types: dict, list, or SDK model."""
    if isinstance(result, dict):
        return result
    if isinstance(result, list):
        return [r.to_dict() if hasattr(r, "to_dict") else r for r in result]
    return _safe_to_dict(result)


def _ensure_label_quoted(label: str | None) -> str | None:
    """Auto-wrap bare text labels as SAIL string literals.

    labelExpression fields are evaluated as SAIL expressions.  A bare word
    like ``Membership Status`` is NOT a valid string literal — it must be
    ``"Membership Status"`` (i.e. wrapped in escaped double-quotes).

    This helper detects common bare-text patterns and wraps them so the
    agent doesn't need to remember the quoting convention.
    """
    if label is None:
        return None
    stripped = label.strip()
    if not stripped:
        return label
    # Already a quoted string literal — leave it alone
    if stripped.startswith('"') and stripped.endswith('"'):
        return label
    # Looks like a SAIL expression (function call, operator, keyword) — leave it
    if any(c in stripped for c in ("(", "!", "=", "+", "&")):
        return label
    # Bare text — wrap as a SAIL string literal
    escaped = stripped.replace('"', '\\"')
    return f'"{escaped}"'


async def _get_version_id(uuid: str, client) -> str | None:
    resp = await get_record_type_by_uuid.asyncio_detailed(uuid=uuid, client=client)
    return _safe_to_dict(unwrap_response(resp)).get("versionId")


def register_tools(mcp, client):
    # Per-record-type lock to serialize mutations (prevents parallel calls from racing)
    _rt_locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)

    @mcp.tool(meta={"object_type": "Record Type", "action_type": "GET"})
    async def listRecordTypes(
        appUuid: str,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
        uuids: str | None = None,
    ) -> dict:
        """List Appian record types with optional filtering. Use appUuid to scope to an application.

        Each record type includes a typeReference field that can be used as the type value
        when creating process model variables, expression rule inputs, or interface inputs.
        """
        try:
            if appUuid:
                resp = await list_application_record_types.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            else:
                resp = await list_record_types.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                    uuids=uuids or UNSET,
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Type", "action_type": "GET"})
    async def getRecordType(uuid: str) -> dict:
        """Get a single Appian record type by UUID.

        The response includes sourceType, tableName, dataSourceUuid, schema, and fields
        at the top level. For DATABASE-backed types, tableName and dataSourceUuid are populated;
        for other source types they are null. Field objects include isUnique, sourceFieldName,
        and sourceFieldType (the concrete DB column type, e.g. VARCHAR(255)).

        The response also includes a typeReference field — use this value as the type when
        creating process model variables, expression rule inputs, or interface inputs
        typed as this record type.

        Appian provides built-in system record types: SYSTEM_RECORD_TYPE_USER (Users)
        and SYSTEM_RECORD_TYPE_DOCUMENT (Documents). Use these UUIDs to look up their
        fields for relationship creation.
        """
        try:
            resp = await get_record_type_by_uuid.asyncio_detailed(
                uuid=uuid, client=client
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    VALID_SOURCE_TYPES = {"DATABASE", "WEB_SERVICE", "PROCESS", "SALESFORCE"}

    @mcp.tool(meta={"object_type": "Record Type", "action_type": "CREATE"})
    async def createRecordType(
        name: str,
        sourceType: Annotated[
            str,
            Field(
                description=(
                    "The type of data source. DATABASE connects to or creates a database table "
                    "(use createTable to control DDL). "
                    "Valid values: DATABASE, WEB_SERVICE, PROCESS, SALESFORCE."
                )
            ),
        ],
        appUuid: Annotated[
            str,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object to the app and applies the app's default security."
            ),
        ],
        createTable: Annotated[
            bool,
            Field(
                description=(
                    "When true, Appian creates the database table (mirrors the 'Create Table' "
                    "checkbox in Appian Designer). When false, returns an error — non-CDM tables "
                    "are not yet supported."
                )
            ),
        ] = True,
        tableName: Annotated[
            str,
            Field(
                description=(
                    "CDM: table name to create (defaults to snake_case of record type name). "
                    "DATABASE: existing table name to connect to."
                )
            ),
        ] = None,
        dataSourceUuid: Annotated[
            str,
            Field(
                description="DATABASE: UUID of the data source containing the table. CDM: auto-resolved if omitted."
            ),
        ] = None,
        schema: Annotated[
            str,
            Field(description="DATABASE: schema name. CDM: auto-resolved if omitted."),
        ] = None,
        description: str | None = None,
        pluralName: Annotated[
            str, Field(description="Plural display name for the record type.")
        ] = None,
        fields: Annotated[
            list[RecordFieldInput] | None,
            BeforeValidator(_coerce_json_str_to_list),
        ] = None,
        relationships: Annotated[
            list[RelationshipInput] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description=(
                    "Relationships to wire after creation. Uses sourceFieldName (resolved to UUID "
                    "from the creation response) and targetFieldName (resolved from target record type). "
                    "Both source and target record types must exist. "
                    "Pass targetRecordTypeUuid as SYSTEM_RECORD_TYPE_USER for User relationships."
                )
            ),
        ] = None,
    ) -> dict:
        """Create a new Appian record type.

        Optionally pass fields to create them in one call (avoids separate addRecordTypeField calls).
        Optionally pass relationships to wire after creation using field names as placeholders.
        """
        try:
            # Validate sourceType
            normalized_source_type = sourceType.strip().upper()
            if normalized_source_type not in VALID_SOURCE_TYPES:
                raise ValidationError(
                    f"Invalid sourceType: '{sourceType}'. "
                    f"Valid values are: {', '.join(sorted(VALID_SOURCE_TYPES))}"
                )

            from lcp_api_plugin_client.models.record_type_field_definition import (
                RecordTypeFieldDefinition,
            )

            source_type_enum = CreateRecordTypeRequestSourceType(normalized_source_type)

            # Auto-inject primary key if createTable=true and no PK in fields
            if createTable and fields is not None:
                has_pk = any(f.isPrimaryKey for f in fields)
                if not has_pk:
                    id_field = next((f for f in fields if f.fieldName == "id"), None)
                    if id_field:
                        # id field exists without isPrimaryKey — set it
                        id_field.isPrimaryKey = True
                    else:
                        # No id field at all — prepend one
                        pk_field = RecordFieldInput(
                            fieldName="id", fieldType="INTEGER", isPrimaryKey=True
                        )
                        fields = [pk_field] + list(fields)

            field_models = (
                [
                    RecordTypeFieldDefinition.from_dict(f.model_dump(exclude_none=True))
                    for f in fields
                ]
                if fields is not None
                else UNSET
            )

            body = CreateRecordTypeRequest(
                name=name,
                source_type=source_type_enum,
                create_table=createTable,
                table_name=tableName or UNSET,
                data_source_uuid=dataSourceUuid or UNSET,
                schema=schema or UNSET,
                description=description or UNSET,
                plural_name=pluralName or UNSET,
                app_uuid=appUuid,
                fields=field_models,
            )
            resp = await create_record_type.asyncio_detailed(client=client, body=body)
            result = _safe_to_dict(unwrap_response(resp))

            # Wire relationships if provided
            if relationships and isinstance(result, dict) and "uuid" in result:
                rel_results = await _wire_relationships(
                    client, result, relationships
                )
                if rel_results:
                    failed = [r for r in rel_results if "error" in r]
                    result["relationshipsWired"] = rel_results
                    if failed:
                        result["relationshipErrors"] = failed

            return result
        except ValidationError as ve:
            raise ToolError(str(ve)) from ve
        except Exception as e:
            raise tool_error(e) from e

    async def _wire_relationships(
        client,
        creation_result: dict,
        relationships: list[RelationshipInput],
    ) -> list[dict]:
        """Resolve field-name placeholders to UUIDs and wire relationships."""
        record_uuid = creation_result["uuid"]
        source_fields = creation_result.get("fields") or []
        version_id = creation_result.get("versionId")

        # Build name→uuid map for source record type fields
        source_field_map = {f["fieldName"]: f["uuid"] for f in source_fields if "fieldName" in f and "uuid" in f}

        results = []
        for rel in relationships:
            # Resolve source field UUID
            source_uuid = source_field_map.get(rel.sourceFieldName)
            if not source_uuid:
                results.append({
                    "relationshipName": rel.relationshipName,
                    "error": f"Field '{rel.sourceFieldName}' not found in creation response. Available: {list(source_field_map.keys())}",
                })
                continue

            # Resolve target field UUID
            target_uuid = rel.targetRecordTypeUuid
            target_field_uuid = None

            # Handle system record types
            if target_uuid == "SYSTEM_RECORD_TYPE_USER":
                target_field_uuid = "SYSTEM_RECORD_TYPE_USER_FIELD_username"
            elif target_uuid == "SYSTEM_RECORD_TYPE_DOCUMENT":
                target_field_uuid = "SYSTEM_RECORD_TYPE_DOCUMENT_FIELD_id"
            else:
                # Fetch target record type to resolve field name → UUID
                target_resp = await get_record_type_by_uuid.asyncio_detailed(
                    uuid=target_uuid, client=client
                )
                target_rt = _safe_to_dict(unwrap_response(target_resp))
                if isinstance(target_rt, dict):
                    target_fields = target_rt.get("fields") or []
                    target_field_map = {f["fieldName"]: f["uuid"] for f in target_fields if "fieldName" in f and "uuid" in f}
                    target_field_uuid = target_field_map.get(rel.targetFieldName)
                    if not target_field_uuid:
                        results.append({
                            "relationshipName": rel.relationshipName,
                            "error": f"Target field '{rel.targetFieldName}' not found on record type {target_uuid}. Available: {list(target_field_map.keys())}",
                        })
                        continue

            if not target_field_uuid:
                results.append({
                    "relationshipName": rel.relationshipName,
                    "error": f"Could not resolve target field UUID",
                })
                continue

            # Wire the relationship
            rel_type_enum = AddRecordTypeRelationshipRequestRelationshipType(
                rel.relationshipType.strip().upper()
            )
            body = AddRecordTypeRelationshipRequest(
                version_id=version_id or UNSET,
                relationship_name=rel.relationshipName,
                source_record_type_field_uuid=source_uuid,
                target_record_type_field_uuid=target_field_uuid,
                target_record_type_uuid=target_uuid,
                relationship_type=rel_type_enum,
            )
            try:
                async with _rt_locks[record_uuid]:
                    resp = await add_record_type_relationship.asyncio_detailed(
                        uuid=record_uuid, client=client, body=body
                    )
                    rel_result = unwrap_response(resp)
                    rel_dict = rel_result if isinstance(rel_result, dict) else _safe_to_dict(rel_result)
                    # Update versionId for next relationship
                    if isinstance(rel_dict, dict) and "versionId" in rel_dict:
                        version_id = rel_dict["versionId"]
                    results.append({"relationshipName": rel.relationshipName, "success": True})
            except Exception as e:
                results.append({"relationshipName": rel.relationshipName, "error": str(e)})

        return results

    @mcp.tool(meta={"object_type": "Record Type", "action_type": "UPDATE"})
    async def updateRecordType(
        uuid: str,
        name: str | None = None,
        description: str | None = None,
        pluralName: Annotated[
            str, Field(description="Plural display name for the record type.")
        ] = None,
        securityRules: Annotated[
            list[SecurityRuleInput] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description="Full replacement of security rules. List order = evaluation order (first match wins). Empty list clears all rules."
            ),
        ] = None,
        securityExpression: Annotated[
            str,
            Field(
                description="SAIL expression for record-level security. Set to null to clear. Omit to preserve current value. Record types using expressions cannot be referenced via RELATED_RECORDS membership."
            ),
        ] = None,
        titleExpression: Annotated[
            str | None,
            Field(
                description="SAIL expression for the record title. Format: rv!record['recordType!{uuid}RecordName.fields.{fieldUuid}fieldName']. Pass empty string to clear. Omit to preserve current value."
            ),
        ] = None,
        hideRecordHeader: Annotated[
            bool | None,
            Field(
                description="Whether to hide the default record header on record views. Requires at least one record view to be configured."
            ),
        ] = None,
        hideNewsView: Annotated[
            bool | None,
            Field(description="Whether to hide the News view tab on this record type."),
        ] = None,
        hideRelatedActionsView: Annotated[
            bool | None,
            Field(
                description="Whether to hide the Related Actions view tab on this record type."
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Update an existing Appian record type. Only provided fields are changed."""
        try:
            # Convert SecurityRuleInput models to SDK RecordSecurityRule models
            sdk_security_rules = (
                [
                    RecordSecurityRule.from_dict(r.model_dump(exclude_none=True))
                    for r in securityRules
                ]
                if securityRules is not None
                else UNSET
            )

            # securityExpression: None = clear, UNSET = don't change
            sdk_security_expression = (
                securityExpression if securityExpression is not None else UNSET
            )

            body = UpdateRecordTypeRequest(
                version_id=versionId or UNSET,
                name=name or UNSET,
                description=description or UNSET,
                plural_name=pluralName or UNSET,
                security_rules=sdk_security_rules,
                security_expression=sdk_security_expression,
                # titleExpression: empty string = clear, None = don't change, string = set
                title_expression=None
                if titleExpression == ""
                else (titleExpression if titleExpression is not None else UNSET),
                hide_record_header=hideRecordHeader
                if hideRecordHeader is not None
                else UNSET,
                hide_news_view=hideNewsView if hideNewsView is not None else UNSET,
                hide_related_actions_view=hideRelatedActionsView
                if hideRelatedActionsView is not None
                else UNSET,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_record_type.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Type", "action_type": "DELETE"})
    async def deleteRecordType(uuid: str) -> str:
        """Permanently delete an Appian record type."""
        try:
            resp = await delete_record_type.asyncio_detailed(uuid=uuid, client=client)
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Field", "action_type": "GET"})
    async def listRecordTypeFields(uuid: str) -> list:
        """List all fields for an Appian record type."""
        try:
            resp = await list_record_type_fields.asyncio_detailed(
                uuid=uuid, client=client
            )
            result = unwrap_response(resp)
            return _to_dict(result)
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Field", "action_type": "GET"})
    async def getRecordTypeField(uuid: str, field_name: str) -> dict:
        """Get a single field for an Appian record type."""
        try:
            resp = await get_record_type_field.asyncio_detailed(
                uuid=uuid, field_name=field_name, client=client
            )
            result = unwrap_response(resp)
            return result if isinstance(result, dict) else _safe_to_dict(result)
        except Exception as e:
            raise tool_error(e) from e

    VALID_FIELD_TYPES = {
        "TEXT",
        "NUMBER",
        "INTEGER",
        "DECIMAL",
        "DATE",
        "DATETIME",
        "TIME",
        "BOOLEAN",
        "USER",
        "GROUP",
        "DOCUMENT",
        "FOLDER",
        "EXTRA_LONG_TEXT",
    }

    CUSTOM_FIELD_VALID_TYPES = VALID_FIELD_TYPES - {"EXTRA_LONG_TEXT"}

    @mcp.tool(meta={"object_type": "Record Field", "action_type": "UPDATE"})
    async def addRecordTypeField(
        uuid: str,
        fieldName: str,
        fieldType: Annotated[
            str,
            Field(
                description=(
                    "The field data type. Valid values: TEXT, NUMBER, INTEGER, DECIMAL, "
                    "DATE, DATETIME, TIME, BOOLEAN, USER, GROUP, DOCUMENT, FOLDER, EXTRA_LONG_TEXT."
                )
            ),
        ],
        sourceFieldName: Annotated[
            str,
            Field(
                description="Backing store field/column name (defaults to toSnakeCase(fieldName))"
            ),
        ] = None,
        displayName: str | None = None,
        description: str | None = None,
        isPrimaryKey: bool | None = None,
        isUnique: bool | None = None,
        length: Annotated[
            int | None,
            Field(description="Column length for TEXT fields. Set to 4000 to create a Long Text field (for descriptions, notes, comments). Omit for Short Text (255 characters)."),
        ] = None,
        updateTable: Annotated[
            bool,
            Field(
                description=(
                    "When true, Appian ALTERs the database table to add the column "
                    "(mirrors the 'Update Table' checkbox in Appian Designer). "
                    "When false, returns an error — non-CDM operations are not yet supported."
                )
            ),
        ] = True,
        versionId: str | None = None,
    ) -> dict:
        """Add a field to an Appian record type. For CDM-backed record types, creates the corresponding database column.

        Returns the created field including isUnique, sourceFieldName, and sourceFieldType (the concrete DB column type).
        """
        try:
            normalized_field_type = fieldType.strip().upper()
            if normalized_field_type not in VALID_FIELD_TYPES:
                raise ValidationError(
                    f"Invalid fieldType: '{fieldType}'. "
                    f"Valid values are: {', '.join(sorted(VALID_FIELD_TYPES))}"
                )

            field_type_enum = AddRecordTypeFieldRequestFieldType(normalized_field_type)

            body = AddRecordTypeFieldRequest(
                version_id=versionId or UNSET,
                field_name=fieldName,
                field_type=field_type_enum,
                source_field_name=sourceFieldName or UNSET,
                display_name=displayName or UNSET,
                description=description or UNSET,
                is_primary_key=isPrimaryKey if isPrimaryKey is not None else UNSET,
                is_unique=isUnique if isUnique is not None else UNSET,
                length=length if length is not None else UNSET,
                update_table=updateTable,
            )
            previous_version_id = await _get_version_id(uuid, client)
            resp = await add_record_type_field.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except ValidationError as ve:
            raise ToolError(str(ve)) from ve
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Field", "action_type": "UPDATE"})
    async def updateRecordTypeField(
        uuid: str,
        fieldUuid: str,
        fieldName: str | None = None,
        fieldType: Annotated[
            str,
            Field(
                description=(
                    "The field data type. Valid values: TEXT, NUMBER, INTEGER, DECIMAL, "
                    "DATE, DATETIME, TIME, BOOLEAN, USER, GROUP, DOCUMENT, FOLDER, EXTRA_LONG_TEXT. "
                    "Type changes on existing fields are restricted to these interchangeable groups: "
                    "[TEXT, USER, EXTRA_LONG_TEXT], [INTEGER, GROUP, DOCUMENT, FOLDER]. "
                    "BOOLEAN, DATE, DATETIME, TIME, DECIMAL, and NUMBER do not support type changes."
                )
            ),
        ] = None,
        sourceFieldName: Annotated[
            str,
            Field(description="Backing store field/column name"),
        ] = None,
        displayName: str | None = None,
        description: str | None = None,
        isPrimaryKey: bool | None = None,
        isUnique: bool | None = None,
        length: Annotated[
            int | None,
            Field(description="Column length for TEXT fields. Set to 4000 to create a Long Text field (for descriptions, notes, comments). Omit for Short Text (255 characters)."),
        ] = None,
        updateTable: Annotated[
            bool,
            Field(
                description=(
                    "When true, applies the change to the backing database "
                    "(mirrors the 'Update Table' checkbox in Appian Designer). "
                    "When false, returns an error — non-CDM operations are not yet supported."
                )
            ),
        ] = True,
        versionId: str | None = None,
    ) -> dict:
        """Update a field on an Appian record type. Only provided fields are changed.

        Returns the updated field including isUnique, sourceFieldName, and sourceFieldType (the concrete DB column type).
        """
        try:
            field_type_enum = UNSET
            if fieldType is not None:
                normalized_field_type = fieldType.strip().upper()
                if normalized_field_type not in VALID_FIELD_TYPES:
                    raise ValidationError(
                        f"Invalid fieldType: '{fieldType}'. "
                        f"Valid values are: {', '.join(sorted(VALID_FIELD_TYPES))}"
                    )
                field_type_enum = UpdateRecordTypeFieldRequestFieldType(
                    normalized_field_type
                )

            body = UpdateRecordTypeFieldRequest(
                version_id=versionId or UNSET,
                field_name=fieldName or UNSET,
                field_type=field_type_enum,
                source_field_name=sourceFieldName or UNSET,
                display_name=displayName or UNSET,
                description=description or UNSET,
                is_primary_key=isPrimaryKey if isPrimaryKey is not None else UNSET,
                is_unique=isUnique if isUnique is not None else UNSET,
                length=length if length is not None else UNSET,
                update_table=updateTable,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_record_type_field.asyncio_detailed(
                uuid=uuid, field_uuid=fieldUuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except ValidationError as ve:
            raise ToolError(str(ve)) from ve
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Field", "action_type": "DELETE"})
    async def deleteRecordTypeField(
        uuid: str,
        fieldUuid: str,
        updateTable: Annotated[
            bool,
            Field(
                description=(
                    "When true, Appian ALTERs the database table to drop the column "
                    "(mirrors the 'Update Table' checkbox in Appian Designer). "
                    "When false, returns an error — non-CDM operations are not yet supported."
                )
            ),
        ] = True,
    ) -> str:
        """Delete a field from an Appian record type. For CDM-backed record types, drops the database column (destructive). Other source types only unmap the field. Primary key fields cannot be deleted."""
        try:
            body = DeleteRecordTypeFieldRequest(
                update_table=updateTable,
            )
            resp = await delete_record_type_field.asyncio_detailed(
                uuid=uuid, field_uuid=fieldUuid, client=client, body=body
            )
            if resp.status_code.value == 204:
                return "Deleted successfully"
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Field", "action_type": "CREATE"})
    async def addCustomRecordField(
        uuid: str,
        fieldName: str,
        expression: Annotated[
            str,
            Field(
                description=(
                    "SAIL expression that computes the field value. Syntax depends on calculationType:\n"
                    "SYNC_TIME: Use rv!record['recordType!{uuid}RecordName.fields.{fieldUuid}fieldName']. "
                    "Single quotes and {uuid} wrappers are required (same format as titleExpression). "
                    "Use standard functions (concat, a!defaultValue, a!match, arithmetic). "
                    "Do NOT use a!customField*() functions or related record references.\n"
                    "REAL_TIME: Use 'recordType!{rtUuid}RecordName.fields.{fieldUuid}fieldName' or "
                    "'recordType!{rtUuid}RecordName.relationships.{relUuid}relName.fields.{fieldUuid}fieldName'. "
                    "Single quotes and {uuid} wrappers are required. "
                    "MUST include at least one a!customField*() function "
                    "(a!customFieldConcat, a!customFieldMatch, a!customFieldDateDiff, "
                    "a!customFieldSum, a!customFieldSubtract, a!customFieldMultiply, "
                    "a!customFieldDivide, a!customFieldDefaultValue, a!customFieldCondition, "
                    "a!customFieldLogicalExpression). Do NOT use rv!record[...]."
                )
            ),
        ],
        fieldType: Annotated[
            str,
            Field(
                description=(
                    "The return type of the expression. Valid values: TEXT, NUMBER, INTEGER, "
                    "DECIMAL, DATE, DATETIME, TIME, BOOLEAN, USER, GROUP, DOCUMENT, FOLDER."
                )
            ),
        ],
        calculationType: Annotated[
            str,
            Field(
                description=(
                    "When the expression is evaluated.\n"
                    "REAL_TIME: Evaluated on every query. Use for related record fields, "
                    "today(), constants, aggregations. Must use a!customField*() functions.\n"
                    "SYNC_TIME: Evaluated on data sync. Use for base-record-only static "
                    "transformations (concat, grouping, arithmetic). Uses rv!record[...] syntax."
                )
            ),
        ] = "REAL_TIME",
        displayName: str | None = None,
        description: str | None = None,
    ) -> dict:
        """Add a custom (calculated/expression-based) field to a record type. Custom fields are not backed by database columns. SYNC_TIME fields use rv!record[...] with standard functions. REAL_TIME fields use 'recordType!{uuid}X.fields.{uuid}y' with a!customField*() functions. Max 40 custom fields per record type."""
        try:
            from lcp_api_plugin_client.api.record_types import add_custom_record_field
            from lcp_api_plugin_client.models.add_custom_record_field_request import (
                AddCustomRecordFieldRequest,
            )
            from lcp_api_plugin_client.models.add_custom_record_field_request_calculation_type import (
                AddCustomRecordFieldRequestCalculationType,
            )
            from lcp_api_plugin_client.models.add_custom_record_field_request_field_type import (
                AddCustomRecordFieldRequestFieldType,
            )

            normalized_calc = calculationType.strip().upper()
            if normalized_calc not in ("REAL_TIME", "SYNC_TIME"):
                raise ToolError(f"Invalid calculationType: '{calculationType}'. Valid values: REAL_TIME, SYNC_TIME")

            normalized_field_type = fieldType.strip().upper()
            if normalized_field_type not in CUSTOM_FIELD_VALID_TYPES:
                raise ToolError(f"Invalid fieldType: '{fieldType}'. Valid values are: {', '.join(sorted(CUSTOM_FIELD_VALID_TYPES))}")

            body = AddCustomRecordFieldRequest(
                field_name=fieldName,
                expression=expression,
                field_type=AddCustomRecordFieldRequestFieldType(normalized_field_type),
                calculation_type=AddCustomRecordFieldRequestCalculationType(
                    normalized_calc
                ),
                display_name=displayName or UNSET,
                description=description or UNSET,
            )
            resp = await add_custom_record_field.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Field", "action_type": "UPDATE"})
    async def updateCustomRecordField(
        uuid: str,
        fieldUuid: str,
        expression: Annotated[
            str | None,
            Field(
                description=(
                    "Updated SAIL expression. Same syntax rules as addCustomRecordField: "
                    "SYNC_TIME uses rv!record[...], REAL_TIME uses a!customField*() functions."
                )
            ),
        ] = None,
        fieldType: Annotated[
            str | None,
            Field(
                description=(
                    "The return type of the expression. Valid values: TEXT, NUMBER, INTEGER, "
                    "DECIMAL, DATE, DATETIME, TIME, BOOLEAN, USER, GROUP, DOCUMENT, FOLDER."
                )
            ),
        ] = None,
        calculationType: Annotated[
            str | None,
            Field(
                description=(
                    "When the expression is evaluated: REAL_TIME or SYNC_TIME."
                )
            ),
        ] = None,
        fieldName: str | None = None,
        displayName: str | None = None,
        description: str | None = None,
        versionId: str | None = None,
    ) -> dict:
        """Update a custom (calculated/expression-based) field on a record type. Only provided fields are changed. Only custom fields can be updated via this endpoint."""
        try:
            from lcp_api_plugin_client.api.record_types import update_custom_record_field
            from lcp_api_plugin_client.models.update_custom_record_field_request import (
                UpdateCustomRecordFieldRequest,
            )
            from lcp_api_plugin_client.models.update_custom_record_field_request_field_type import (
                UpdateCustomRecordFieldRequestFieldType,
            )
            from lcp_api_plugin_client.models.update_custom_record_field_request_calculation_type import (
                UpdateCustomRecordFieldRequestCalculationType,
            )

            body_kwargs = {}
            if versionId is not None:
                body_kwargs["version_id"] = versionId

            if expression is not None:
                body_kwargs["expression"] = expression

            if fieldType is not None:
                normalized = fieldType.strip().upper()
                if normalized not in CUSTOM_FIELD_VALID_TYPES:
                    raise ToolError(f"Invalid fieldType: '{fieldType}'. Valid values are: {', '.join(sorted(CUSTOM_FIELD_VALID_TYPES))}")
                body_kwargs["field_type"] = UpdateCustomRecordFieldRequestFieldType(normalized)

            if calculationType is not None:
                normalized_calc = calculationType.strip().upper()
                if normalized_calc not in ("REAL_TIME", "SYNC_TIME"):
                    raise ToolError(f"Invalid calculationType: '{calculationType}'. Valid values: REAL_TIME, SYNC_TIME")
                body_kwargs["calculation_type"] = UpdateCustomRecordFieldRequestCalculationType(normalized_calc)

            if fieldName is not None:
                body_kwargs["field_name"] = fieldName
            if displayName is not None:
                body_kwargs["display_name"] = displayName
            if description is not None:
                body_kwargs["description"] = description

            body = UpdateCustomRecordFieldRequest(**body_kwargs)
            resp = await update_custom_record_field.asyncio_detailed(
                uuid=uuid, field_uuid=fieldUuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Field", "action_type": "DELETE"})
    async def deleteCustomRecordField(
        uuid: str,
        fieldUuid: str,
    ) -> str:
        """Delete a custom (calculated/expression-based) field from a record type. No database column is affected. Only custom fields can be deleted via this endpoint."""
        try:
            from lcp_api_plugin_client.api.record_types import delete_custom_record_field

            resp = await delete_custom_record_field.asyncio_detailed(
                uuid=uuid, field_uuid=fieldUuid, client=client
            )
            if resp.status_code.value == 204:
                return "Deleted successfully"
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Relationship", "action_type": "GET"})
    async def listRecordTypeRelationships(uuid: str) -> list:
        """List all relationships for an Appian record type."""
        try:
            resp = await list_record_type_relationships.asyncio_detailed(
                uuid=uuid, client=client
            )
            result = unwrap_response(resp)
            return _to_dict(result)
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Relationship", "action_type": "UPDATE"})
    async def addRecordTypeRelationship(
        uuid: str,
        relationships: Annotated[
            list[dict],
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description=(
                    "Array of relationships to add. Each entry must have: "
                    "relationshipName, sourceRecordTypeFieldUuid (FK field UUID on THIS record type), "
                    "targetRecordTypeFieldUuid (PK field UUID on target — use SYSTEM_RECORD_TYPE_USER_FIELD_username for User), "
                    "targetRecordTypeUuid (target record type UUID — use SYSTEM_RECORD_TYPE_USER for User), "
                    "relationshipType (ONE_TO_MANY | MANY_TO_ONE | ONE_TO_ONE)."
                )
            ),
        ],
    ) -> dict:
        """Add one or more relationships to an Appian record type.

        Pass an array with one entry per relationship. Both the source and target
        record types must already exist. Use the exact field UUIDs returned from
        record type creation or retrieval responses — never fabricate UUIDs.
        """
        results = []
        previous_version_id = None
        for rel in relationships:
            try:
                rel_type_enum = AddRecordTypeRelationshipRequestRelationshipType(
                    rel["relationshipType"].strip().upper()
                )
                async with _rt_locks[uuid]:
                    current_version = await _get_version_id(uuid, client)
                    if previous_version_id is None:
                        previous_version_id = current_version
                    body = AddRecordTypeRelationshipRequest(
                        version_id=current_version or UNSET,
                        relationship_name=rel["relationshipName"],
                        source_record_type_field_uuid=rel["sourceRecordTypeFieldUuid"],
                        target_record_type_field_uuid=rel["targetRecordTypeFieldUuid"],
                        target_record_type_uuid=rel["targetRecordTypeUuid"],
                        relationship_type=rel_type_enum,
                    )
                    resp = await add_record_type_relationship.asyncio_detailed(
                        uuid=uuid, client=client, body=body
                    )
                    result = unwrap_response(resp)
                    rel_dict = result if isinstance(result, dict) else _safe_to_dict(result)
                    results.append({"relationshipName": rel["relationshipName"], "success": True, **rel_dict})
            except Exception as e:
                results.append({"relationshipName": rel.get("relationshipName", "?"), "error": str(e)})

        if len(results) == 1:
            result = results[0]
            result["previousVersionId"] = previous_version_id
            return result
        failed = [r for r in results if "error" in r]
        result = {
            "success": len(failed) == 0,
            "relationships": results,
            "errors": failed if failed else None,
        }
        result["previousVersionId"] = previous_version_id
        return result

    @mcp.tool(meta={"object_type": "Record Relationship", "action_type": "UPDATE"})
    async def updateRecordTypeRelationship(
        uuid: str,
        relationshipUuid: str,
        relationshipName: str | None = None,
        sourceRecordTypeFieldUuid: str | None = None,
        targetRecordTypeFieldUuid: str | None = None,
        targetRecordTypeUuid: str | None = None,
        relationshipType: Annotated[
            str,
            Field(
                description="Type of relationship: ONE_TO_MANY | MANY_TO_ONE | ONE_TO_ONE"
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Update a relationship on an Appian record type. Only provided fields are changed."""
        try:
            body = UpdateRecordTypeRelationshipRequest(
                version_id=versionId or UNSET,
                relationship_name=relationshipName or UNSET,
                source_record_type_field_uuid=sourceRecordTypeFieldUuid or UNSET,
                target_record_type_field_uuid=targetRecordTypeFieldUuid or UNSET,
                target_record_type_uuid=targetRecordTypeUuid or UNSET,
                relationship_type=UpdateRecordTypeRelationshipRequestRelationshipType(
                    relationshipType
                )
                if relationshipType is not None
                else UNSET,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_record_type_relationship.asyncio_detailed(
                uuid=uuid, rel_uuid=relationshipUuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Relationship", "action_type": "DELETE"})
    async def deleteRecordTypeRelationship(uuid: str, relationshipUuid: str) -> str:
        """Delete a relationship from an Appian record type."""
        try:
            resp = await delete_record_type_relationship.asyncio_detailed(
                uuid=uuid, rel_uuid=relationshipUuid, client=client
            )
            if resp.status_code.value == 204:
                return "Deleted successfully"
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    # --- Record Type Actions ---

    @mcp.tool(meta={"object_type": "Record Action", "action_type": "GET"})
    async def listRecordTypeActions(uuid: str) -> list:
        """List all record actions configured on an Appian record type. Returns actions with uuid, displayName, processModelUuid, actionType, description, icon, visibilityExpr, dialogWidth, dialogHeight, contextExpr."""
        try:
            resp = await list_record_type_actions.asyncio_detailed(
                uuid=uuid, client=client
            )
            result = unwrap_response(resp)
            return _to_dict(result)
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Action", "action_type": "UPDATE"})
    async def addRecordTypeAction(
        uuid: str,
        displayName: str,
        processModelUuid: str,
        actionType: Annotated[
            str,
            Field(
                description="Type of record action: LIST_ACTION (record list) or RELATED_ACTION (record view)"
            ),
        ],
        key: Annotated[
            str,
            Field(
                description="Unique key for referencing this action in SAIL (e.g., recordType!Case.actions.editCase)"
            ),
        ],
        description: str | None = None,
        icon: Annotated[
            str,
            Field(
                description=(
                    "Font Awesome icon hex code for the action button (e.g. 'f015' for home, 'f0e7' for bolt). "
                    "NOT semantic names like 'home' — use the 4-character hex code. Default: 'f0e7'."
                )
            ),
        ] = None,
        visibilityExpr: Annotated[
            str,
            Field(
                description='SAIL expression controlling visibility (default "=true()")'
            ),
        ] = None,
        dialogWidth: Annotated[
            str,
            Field(
                description='Dialog width: NARROW | MEDIUM | MEDIUM_PLUS | WIDE | EXTRA_WIDE | FIT (default "MEDIUM_PLUS")'
            ),
        ] = None,
        dialogHeight: Annotated[
            str,
            Field(
                description='Dialog height: AUTO | FIT | SHORT | MEDIUM | TALL | EXTRA_TALL (default "AUTO")'
            ),
        ] = None,
        contextExpr: Annotated[
            str,
            Field(
                description="SAIL expression passing record context to the process model. Only valid for RELATED_ACTION. Use a dictionary to pass record information into the related action. The keys in the dictionary map to the case-sensitive parameter names in the process model."
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Add a record action to an Appian record type. Returns the created action including server-generated uuid."""
        try:
            # Normalize actionType to uppercase with underscores
            normalized = actionType.strip().upper().replace(" ", "_")

            body = CreateRecordActionRequest(
                version_id=versionId or UNSET,
                key=key,
                display_name=displayName,
                process_model_uuid=processModelUuid,
                action_type=CreateRecordActionRequestActionType(normalized),
                description=description if description is not None else UNSET,
                icon=icon if icon is not None else UNSET,
                visibility_expr=visibilityExpr if visibilityExpr is not None else UNSET,
                dialog_width=CreateRecordActionRequestDialogWidth(dialogWidth)
                if dialogWidth is not None
                else UNSET,
                dialog_height=CreateRecordActionRequestDialogHeight(dialogHeight)
                if dialogHeight is not None
                else UNSET,
                context_expr=contextExpr if contextExpr is not None else UNSET,
            )
            previous_version_id = await _get_version_id(uuid, client)
            resp = await add_record_type_action.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = unwrap_response(resp)
            result = result.to_dict() if hasattr(result, "to_dict") else result
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Action", "action_type": "UPDATE"})
    async def updateRecordTypeAction(
        uuid: str,
        actionUuid: str,
        displayName: str | None = None,
        processModelUuid: str | None = None,
        key: Annotated[
            str,
            Field(
                description="Unique key for referencing this action in SAIL (e.g., recordType!Case.actions.editCase)"
            ),
        ] = None,
        description: str | None = None,
        icon: Annotated[
            str,
            Field(
                description=(
                    "Font Awesome icon hex code (e.g. 'f015' for home, 'f0e7' for bolt). "
                    "NOT semantic names like 'home' — use the 4-character hex code."
                )
            ),
        ] = None,
        visibilityExpr: str | None = None,
        dialogWidth: Annotated[
            str,
            Field(
                description='Dialog width: NARROW | MEDIUM | MEDIUM_PLUS | WIDE | EXTRA_WIDE | FIT (default "MEDIUM_PLUS")'
            ),
        ] = None,
        dialogHeight: Annotated[
            str,
            Field(
                description='Dialog height: AUTO | FIT | SHORT | MEDIUM | TALL | EXTRA_TALL (default "AUTO")'
            ),
        ] = None,
        contextExpr: str | None = None,
        versionId: str | None = None,
    ) -> dict:
        """Update a record action by UUID with partial update semantics. Only provided fields are changed. actionType is immutable."""
        try:
            body = UpdateRecordActionRequest(
                version_id=versionId or UNSET,
                key=key or UNSET,
                display_name=displayName or UNSET,
                process_model_uuid=processModelUuid or UNSET,
                description=description if description is not None else UNSET,
                icon=icon if icon is not None else UNSET,
                visibility_expr=visibilityExpr if visibilityExpr is not None else UNSET,
                dialog_width=UpdateRecordActionRequestDialogWidth(dialogWidth)
                if dialogWidth is not None
                else UNSET,
                dialog_height=UpdateRecordActionRequestDialogHeight(dialogHeight)
                if dialogHeight is not None
                else UNSET,
                context_expr=contextExpr if contextExpr is not None else UNSET,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_record_type_action.asyncio_detailed(
                uuid=uuid,
                action_uuid=actionUuid,
                client=client,
                body=body,
            )
            result = unwrap_response(resp)
            result = result.to_dict() if hasattr(result, "to_dict") else result
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Action", "action_type": "DELETE"})
    async def deleteRecordTypeAction(uuid: str, actionUuid: str) -> str:
        """Delete a record action by UUID from an Appian record type."""
        try:
            resp = await delete_record_type_action.asyncio_detailed(
                uuid=uuid,
                action_uuid=actionUuid,
                client=client,
            )
            if resp.status_code.value == 204:
                return "Deleted successfully"
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record View", "action_type": "GET"})
    async def listRecordTypeViews(uuid: str) -> list[dict]:
        """List all views (detail view tabs) for an Appian record type."""
        try:
            resp = await list_record_type_views.asyncio_detailed(
                uuid=uuid, client=client
            )
            return [item.to_dict() for item in unwrap_response(resp)]
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record View", "action_type": "UPDATE"})
    async def addRecordTypeView(
        uuid: str,
        nameExpression: Annotated[
            str,
            Field(
                description=(
                    "SAIL expression for the view tab name. MUST start with '='. "
                    "For static text use ='\"My View\"'. For dynamic use =rv!record['field']."
                )
            ),
        ],
        interfaceExpression: Annotated[
            str,
            Field(
                description=(
                    "SAIL expression that renders the view. Typically a rule! call, "
                    "e.g. rule!MyView(record: rv!record). Available variables: rv!identifier, rv!record."
                )
            ),
        ],
        visibilityExpression: Annotated[
            str, Field(description=("Null = visible to all users."))
        ] = None,
        relatedActionShortcuts: Annotated[
            list[str] | None,
            Field(
                description=(
                    "Related action UUIDs to show as shortcut buttons. Get UUIDs from listRecordTypeActions."
                )
            ),
        ] = None,
        launchType: Annotated[
            str,
            Field(
                description=(
                    "How shortcuts open: SAME_TAB (default), NEW_TAB, or DIALOG."
                )
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Add a custom view (tab) to a record type. The first view added becomes the Summary view (urlStub "summary"); subsequent views get auto-generated urlStubs. All expression parameters accept SAIL expressions. Available variables: `rv!identifier` (record ID), `rv!record` (full record), `loggedInUser()`. For static values, use quoted strings (e.g. `'"Order Details"'`)."""
        try:
            body = CreateRecordViewRequest(
                version_id=versionId or UNSET,
                name_expr=_ensure_label_quoted(nameExpression),
                ui_expr=interfaceExpression,
                visibility_expr=visibilityExpression
                if visibilityExpression is not None
                else UNSET,
                related_action_shortcuts=relatedActionShortcuts
                if relatedActionShortcuts is not None
                else UNSET,
                launch_type=CreateRecordViewRequestLaunchType(launchType)
                if launchType is not None
                else UNSET,
            )
            previous_version_id = await _get_version_id(uuid, client)
            resp = await add_record_type_view.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = unwrap_response(resp).to_dict()
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record View", "action_type": "UPDATE"})
    async def updateRecordTypeView(
        uuid: str,
        urlStub: str,
        nameExpression: Annotated[
            str | None,
            Field(
                description=(
                    "SAIL expression for the view tab name. MUST start with '='. "
                    "For static text use ='\"My View\"'. Omit to preserve current value."
                )
            ),
        ] = None,
        interfaceExpression: Annotated[
            str | None,
            Field(
                description=(
                    "SAIL expression that renders the view. Typically a rule! call, "
                    "e.g. rule!MyView(record: rv!record). Omit to preserve current value."
                )
            ),
        ] = None,
        visibilityExpression: Annotated[
            str,
            Field(
                description=(
                    "Set to null to clear (visible to all). Omit to preserve current value."
                )
            ),
        ] = None,
        relatedActionShortcuts: Annotated[
            list[str] | None,
            Field(
                description=(
                    "Related action UUIDs to show as shortcut buttons. Empty list clears all."
                )
            ),
        ] = None,
        launchType: Annotated[
            str,
            Field(description=("How shortcuts open: SAME_TAB, NEW_TAB, or DIALOG.")),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Update fields on an existing view. Only provided fields are changed; omitted fields are preserved."""
        try:
            body = UpdateRecordViewRequest(
                version_id=versionId or UNSET,
                name_expr=_ensure_label_quoted(nameExpression)
                if nameExpression is not None
                else UNSET,
                ui_expr=interfaceExpression
                if interfaceExpression is not None
                else UNSET,
                visibility_expr=visibilityExpression
                if visibilityExpression is not None
                else UNSET,
                related_action_shortcuts=relatedActionShortcuts
                if relatedActionShortcuts is not None
                else UNSET,
                launch_type=UpdateRecordViewRequestLaunchType(launchType)
                if launchType is not None
                else UNSET,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_record_type_view.asyncio_detailed(
                uuid=uuid, url_stub=urlStub, client=client, body=body
            )
            result = unwrap_response(resp).to_dict()
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record View", "action_type": "DELETE"})
    async def deleteRecordTypeView(uuid: str, urlStub: str) -> str:
        """Permanently delete a view from a record type. The Summary view cannot be deleted."""
        try:
            resp = await delete_record_type_view.asyncio_detailed(
                uuid=uuid, url_stub=urlStub, client=client
            )
            if resp.status_code.value == 204:
                return "Deleted successfully"
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record View", "action_type": "UPDATE"})
    async def reorderRecordTypeViews(
        uuid: str,
        urlStubs: Annotated[
            list[str],
            Field(
                description=(
                    "Ordered list of all view urlStubs representing desired tab order. "
                    "Must include all existing urlStubs. Summary is always pinned first."
                )
            ),
        ],
        versionId: str | None = None,
    ) -> list[dict]:
        """Reorder views on a record type. All existing urlStubs must be included."""
        try:
            body = ReorderRecordViewsRequest(
                version_id=versionId or UNSET, url_stubs=urlStubs
            )
            resp = await reorder_record_type_views.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            return [item.to_dict() for item in unwrap_response(resp)]
        except Exception as e:
            raise tool_error(e) from e

    # --- Record Events ---

    @mcp.tool(meta={"object_type": "Record Events", "action_type": "UPDATE"})
    async def configureRecordEvents(
        uuid: str,
        appUuid: Annotated[
            str,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object "
                "to the app and applies the app's default security."
            ),
        ],
        eventTypes: Annotated[
            list[str] | None,
            Field(
                description="Event types representing key moments in the business lifecycle of this "
                "record. Use past-tense verb phrases (e.g. 'Created Order', 'Approved Application', "
                "'Shipped Order'). Avoid generic recurring operations like 'Updated' — focus on "
                "meaningful business activities that ideally occur once per record in a specific order."
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Configure record events on an Appian record type (one-time setup).

        Creates four supporting record types (Event History, Event Type Lookup, Reply Thread,
        Subscriber), wires relationships, copies security from the base record type, and persists
        the configuration. Returns 409 if record events are already configured.

        Event types can be managed after initial setup by updating the data in the record type
        identified by eventTypeLookupRecordTypeUuid using the record data tools.

        Returns a RecordEventConfig with: four RT UUIDs (eventHistoryRecordTypeUuid,
        eventTypeLookupRecordTypeUuid, replyThreadRecordTypeUuid, subscriberRecordTypeUuid),
        relationship UUIDs (eventRelationshipUuid, eventTypeRelationshipUuid,
        eventReplyRelationshipUuid, subscriberRelationshipUuid), field UUIDs
        (eventTypeValueFieldUuid, eventUserFieldUuid, eventTimestampFieldUuid,
        eventAutomationIdentifierFieldUuid, eventCommentFieldUuid, eventReplyUserFieldUuid,
        eventReplyCommentFieldUuid, eventReplyTimestampFieldUuid, subscriberUserFieldUuid),
        commentEventTypeId, generateCommonEvents, and eventTypes.
        """
        try:
            body = ConfigureRecordEventsRequest(
                version_id=versionId or UNSET,
                app_uuid=appUuid,
                event_types=eventTypes if eventTypes is not None else UNSET,
            )
            previous_version_id = await _get_version_id(uuid, client)
            resp = await configure_record_events.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Events", "action_type": "GET"})
    async def getRecordEventsConfig(uuid: str) -> dict:
        """Get the record event configuration for an Appian record type.

        Returns the full config including: four RT UUIDs, relationship UUIDs
        (eventRelationshipUuid, eventTypeRelationshipUuid, eventReplyRelationshipUuid,
        subscriberRelationshipUuid), field UUIDs (eventTypeValueFieldUuid, eventUserFieldUuid,
        eventTimestampFieldUuid, eventAutomationIdentifierFieldUuid, eventCommentFieldUuid,
        eventReplyUserFieldUuid, eventReplyCommentFieldUuid, eventReplyTimestampFieldUuid,
        subscriberUserFieldUuid), commentEventTypeId, generateCommonEvents, and eventTypes.

        Event types can be managed by updating the data in the record type
        identified by eventTypeLookupRecordTypeUuid using the record data tools.
        """
        try:
            resp = await get_record_events_config.asyncio_detailed(
                uuid=uuid, client=client
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "User Filter", "action_type": "GET"})
    async def listRecordTypeUserFilters(uuid: str) -> list:
        """List user filters configured on a record type."""
        try:
            resp = await list_record_type_user_filters.asyncio_detailed(
                uuid=uuid, client=client
            )
            result = unwrap_response(resp)
            return [_safe_to_dict(r) for r in result] if result else []
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "User Filter", "action_type": "UPDATE"})
    async def addRecordTypeUserFilter(
        uuid: str,
        name: str,
        facetType: Annotated[
            str,
            Field(description="EXPRESSION, LIST_OF_VALUES, or DATE_RANGE"),
        ],
        expression: Annotated[
            str,
            Field(
                description=(
                    "SAIL expression for EXPRESSION filters. "
                    "Use a!recordFilterList() with a!recordFilterListOption() "
                    "or a!recordFilterDateRange()."
                )
            ),
        ] = None,
        labelExpression: Annotated[
            str,
            Field(
                description=(
                    "Display label for the filter. Bare text like "
                    "'Submission Date' is auto-quoted to '\"Submission Date\"'. "
                    "SAIL expressions (containing parentheses, operators, etc.) "
                    "are passed through unchanged."
                )
            ),
        ] = None,
        sourceRef: Annotated[
            str,
            Field(
                description=(
                    "Record field UUID for LIST_OF_VALUES and DATE_RANGE filters. "
                    'For fields on related records: "RELATIONSHIP_UUID/FIELD_UUID".'
                )
            ),
        ] = None,
        visibilityExpression: str | None = None,
        defaultOptionExpression: str | None = None,
        options: list[FacetOptionInput] | None = None,
        startDateExpression: Annotated[
            str,
            Field(
                description="Default start date expression. Used by DATE_RANGE filters."
            ),
        ] = None,
        endDateExpression: Annotated[
            str,
            Field(
                description="Default end date expression. Used by DATE_RANGE filters."
            ),
        ] = None,
        allowMultipleSelections: bool = False,
        useRelatedRecordValues: Annotated[
            bool,
            Field(
                description=(
                    "Applies when sourceRef is a related record field or a foreign key field "
                    "that references a related record. Automatically use the values from the "
                    "related record field as the list options."
                )
            ),
        ] = False,
        relatedRecordDisplayField: Annotated[
            str,
            Field(
                description=(
                    "UUID of a Text field on the related record type to use as filter "
                    "option labels. Required when useRelatedRecordValues is true."
                )
            ),
        ] = None,
        relatedRecordSort: Annotated[
            str,
            Field(
                description=(
                    "Sort order for related record filter options: ASCENDING, DESCENDING, "
                    "or UNSORTED. Required when useRelatedRecordValues is true."
                )
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Add a user filter to a record type."""
        try:
            labelExpression = _ensure_label_quoted(labelExpression)
            sdk_options = (
                [
                    FacetOption(
                        label_expression=_ensure_label_quoted(o.labelExpression),
                        operator=FacetOptionOperator(o.operator),
                        value=o.value,
                        lower_limit_expression=o.lowerLimitExpression,
                        upper_limit_expression=o.upperLimitExpression,
                    )
                    for o in options
                ]
                if options
                else UNSET
            )
            body = AddUserFilterRequest(
                version_id=versionId or UNSET,
                name=name,
                facet_type=AddUserFilterRequestFacetType(facetType),
                expression=expression if expression is not None else UNSET,
                label_expression=labelExpression
                if labelExpression is not None
                else UNSET,
                source_ref=sourceRef if sourceRef is not None else UNSET,
                visibility_expression=visibilityExpression
                if visibilityExpression is not None
                else UNSET,
                default_option_expression=defaultOptionExpression
                if defaultOptionExpression is not None
                else UNSET,
                options=sdk_options,
                start_date_expression=startDateExpression
                if startDateExpression is not None
                else UNSET,
                end_date_expression=endDateExpression
                if endDateExpression is not None
                else UNSET,
                allow_multiple_selections=allowMultipleSelections,
                use_related_record_values=useRelatedRecordValues,
                related_record_display_field=relatedRecordDisplayField
                if relatedRecordDisplayField is not None
                else UNSET,
                related_record_sort=AddUserFilterRequestRelatedRecordSort(
                    relatedRecordSort
                )
                if relatedRecordSort is not None
                else UNSET,
            )
            async with _rt_locks[uuid]:
                previous_version_id = await _get_version_id(uuid, client)
                resp = await add_record_type_user_filter.asyncio_detailed(
                    uuid=uuid, client=client, body=body
                )
                result = _safe_to_dict(unwrap_response(resp))
                result["previousVersionId"] = previous_version_id
                return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "User Filter", "action_type": "UPDATE"})
    async def updateRecordTypeUserFilter(
        uuid: str,
        filterUuid: str,
        name: str | None = None,
        facetType: Annotated[
            str,
            Field(description="EXPRESSION, LIST_OF_VALUES, or DATE_RANGE"),
        ] = None,
        expression: Annotated[
            str,
            Field(
                description=(
                    "SAIL expression for EXPRESSION filters. "
                    "Use a!recordFilterList() with a!recordFilterListOption() "
                    "or a!recordFilterDateRange()."
                )
            ),
        ] = None,
        labelExpression: Annotated[
            str,
            Field(
                description=(
                    "Display label for the filter. Bare text like "
                    "'Submission Date' is auto-quoted to '\"Submission Date\"'. "
                    "SAIL expressions (containing parentheses, operators, etc.) "
                    "are passed through unchanged."
                )
            ),
        ] = None,
        sourceRef: Annotated[
            str,
            Field(
                description=(
                    "Record field UUID for LIST_OF_VALUES and DATE_RANGE filters. "
                    'For fields on related records: "RELATIONSHIP_UUID/FIELD_UUID".'
                )
            ),
        ] = None,
        visibilityExpression: str | None = None,
        defaultOptionExpression: str | None = None,
        options: list[FacetOptionInput] | None = None,
        startDateExpression: Annotated[
            str,
            Field(
                description="Default start date expression. Used by DATE_RANGE filters."
            ),
        ] = None,
        endDateExpression: Annotated[
            str,
            Field(
                description="Default end date expression. Used by DATE_RANGE filters."
            ),
        ] = None,
        orderIndex: int | None = None,
        allowMultipleSelections: bool | None = None,
        useRelatedRecordValues: Annotated[
            bool | None,
            Field(
                description=(
                    "Applies when sourceRef is a related record field or a foreign key field "
                    "that references a related record. Automatically use the values from the "
                    "related record field as the list options."
                )
            ),
        ] = None,
        relatedRecordDisplayField: Annotated[
            str,
            Field(
                description=(
                    "UUID of a Text field on the related record type to use as filter "
                    "option labels. Required when useRelatedRecordValues is true."
                )
            ),
        ] = None,
        relatedRecordSort: Annotated[
            str,
            Field(
                description=(
                    "Sort order for related record filter options: ASCENDING, DESCENDING, "
                    "or UNSORTED. Required when useRelatedRecordValues is true."
                )
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Update a user filter on a record type. Only provided fields are changed."""
        try:
            labelExpression = _ensure_label_quoted(labelExpression)
            sdk_options = (
                [
                    FacetOption(
                        label_expression=_ensure_label_quoted(o.labelExpression),
                        operator=FacetOptionOperator(o.operator),
                        value=o.value,
                        lower_limit_expression=o.lowerLimitExpression,
                        upper_limit_expression=o.upperLimitExpression,
                    )
                    for o in options
                ]
                if options is not None
                else UNSET
            )
            body = UpdateUserFilterRequest(
                version_id=versionId or UNSET,
                name=name if name is not None else UNSET,
                facet_type=UpdateUserFilterRequestFacetType(facetType)
                if facetType is not None
                else UNSET,
                expression=expression if expression is not None else UNSET,
                label_expression=labelExpression
                if labelExpression is not None
                else UNSET,
                source_ref=sourceRef if sourceRef is not None else UNSET,
                visibility_expression=visibilityExpression
                if visibilityExpression is not None
                else UNSET,
                default_option_expression=defaultOptionExpression
                if defaultOptionExpression is not None
                else UNSET,
                options=sdk_options,
                start_date_expression=startDateExpression
                if startDateExpression is not None
                else UNSET,
                end_date_expression=endDateExpression
                if endDateExpression is not None
                else UNSET,
                order_index=orderIndex if orderIndex is not None else UNSET,
                allow_multiple_selections=allowMultipleSelections
                if allowMultipleSelections is not None
                else UNSET,
                use_related_record_values=useRelatedRecordValues
                if useRelatedRecordValues is not None
                else UNSET,
                related_record_display_field=relatedRecordDisplayField
                if relatedRecordDisplayField is not None
                else UNSET,
                related_record_sort=UpdateUserFilterRequestRelatedRecordSort(
                    relatedRecordSort
                )
                if relatedRecordSort is not None
                else UNSET,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_record_type_user_filter.asyncio_detailed(
                uuid=uuid,
                filter_uuid=filterUuid,
                client=client,
                body=body,
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "User Filter", "action_type": "DELETE"})
    async def deleteRecordTypeUserFilter(uuid: str, filterUuid: str) -> str:
        """Remove a user filter from a record type."""
        try:
            resp = await delete_record_type_user_filter.asyncio_detailed(
                uuid=uuid,
                filter_uuid=filterUuid,
                client=client,
            )
            if resp.status_code.value == 204:
                return "Deleted successfully"
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e
