"""Constants domain MCP tools."""

from typing import Annotated

from lcp_api_plugin_client.api.applications import list_application_constants
from lcp_api_plugin_client.api.constants import (
    create_constant,
    delete_constant,
    get_constant_by_uuid,
    list_constants,
    update_constant,
)
from lcp_api_plugin_client.models.create_constant_request import CreateConstantRequest
from lcp_api_plugin_client.models.create_constant_request_type import (
    CreateConstantRequestType,
)
from lcp_api_plugin_client.models.update_constant_request import UpdateConstantRequest
from lcp_api_plugin_client.models.update_constant_request_type import (
    UpdateConstantRequestType,
)
from fastmcp.exceptions import ToolError
from lcp_api_plugin_client.types import UNSET
from pydantic import Field

from . import _safe_to_dict, tool_error, unwrap_response


async def _get_version_id(uuid: str, client) -> str | None:
    resp = await get_constant_by_uuid.asyncio_detailed(uuid=uuid, client=client)
    return _safe_to_dict(unwrap_response(resp)).get("versionId")


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Constant", "action_type": "GET"})
    async def listConstants(
        appUuid: str,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian constants with optional filtering. Use appUuid to scope to an application."""
        try:
            if appUuid:
                resp = await list_application_constants.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            else:
                resp = await list_constants.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Constant", "action_type": "GET"})
    async def getConstant(uuid: str) -> dict:
        """Get a single Appian constant by UUID."""
        try:
            resp = await get_constant_by_uuid.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Constant", "action_type": "CREATE"})
    async def createConstant(
        name: str,
        type: str,
        value: str | int | float | bool | list,
        appUuid: Annotated[
            str | None,
            Field(
                description="Application UUID (see listApplications). Auto-adds "
                "created object to the app and applies the app's default security, "
                "selecting an appropriate Rules and Constants folder. Either appUuid "
                "or parentFolderUuid must be provided."
            ),
        ] = None,
        parentFolderUuid: Annotated[
            str | None,
            Field(
                description="UUID of the parent Rules and Constants folder. Takes "
                "precedence over appUuid for folder selection. Either appUuid or "
                "parentFolderUuid must be provided."
            ),
        ] = None,
        description: str | None = None,
        multiple: Annotated[
            bool,
            Field(
                description="When true, creates a list-typed constant (e.g., List of "
                "Text). Value must be a JSON array. Boolean type does not support "
                "multiple."
            ),
        ] = False,
    ) -> dict:
        """Create a new Appian constant.

        Provide either appUuid (to auto-select the app's Rules and Constants folder) or
        parentFolderUuid (to target a specific folder). If both are given, parentFolderUuid wins.

        When multiple=true, value must be a native JSON array — not a string.
        CORRECT:   value=["Lincoln", "Omaha"], multiple=true
        INCORRECT: value='["Lincoln", "Omaha"]', multiple=true  ← string, will fail

        Valid types and expected values:
        - TEXT, NUMBER, INTEGER, BOOLEAN, DATE, DATETIME, TIME: pass the literal value
        - USER, EMAIL_ADDRESS: pass the literal string (username or email)
        - GROUP: pass the group name
        - USER_OR_GROUP: pass username or group name
        - GROUP_TYPE: pass the group type ID
        - FOLDER, DOCUMENT, PROCESS_MODEL, RECORD_TYPE, CONNECTED_SYSTEM,
          APPLICATION, KNOWLEDGE_CENTER, TEMPO_REPORT, TASK_REPORT,
          DOCUMENT_OR_FOLDER, DATA_STORE_ENTITY: pass the object UUID
        """
        if not appUuid and not parentFolderUuid:
            raise ToolError("Either appUuid or parentFolderUuid must be provided.")
        try:
            body = CreateConstantRequest(
                name=name,
                type_=CreateConstantRequestType(type),
                value=value,
                app_uuid=appUuid or UNSET,
                parent_folder_uuid=parentFolderUuid or UNSET,
                description=description or UNSET,
                multiple=multiple if multiple else UNSET,
            )
            resp = await create_constant.asyncio_detailed(client=client, body=body)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Constant", "action_type": "UPDATE"})
    async def updateConstant(
        uuid: str,
        name: str | None = None,
        description: str | None = None,
        type: str | None = None,
        value: str | int | float | bool | list | None = None,
        multiple: bool | None = None,
        versionId: str | None = None,
    ) -> dict:
        """Update an existing Appian constant. Only provided fields are changed.

        When multiple=true, value must be a native JSON array — not a string.
        CORRECT:   value=["Lincoln", "Omaha"], multiple=true
        INCORRECT: value='["Lincoln", "Omaha"]', multiple=true  ← string, will fail

        Valid types and expected values:
        - TEXT, NUMBER, INTEGER, BOOLEAN, DATE, DATETIME, TIME: pass the literal value
        - USER, EMAIL_ADDRESS: pass the literal string (username or email)
        - GROUP: pass the group name
        - USER_OR_GROUP: pass username or group name
        - GROUP_TYPE: pass the group type ID
        - FOLDER, DOCUMENT, PROCESS_MODEL, RECORD_TYPE, CONNECTED_SYSTEM,
          APPLICATION, KNOWLEDGE_CENTER, TEMPO_REPORT, TASK_REPORT,
          DOCUMENT_OR_FOLDER, DATA_STORE_ENTITY: pass the object UUID
        """
        try:
            body = UpdateConstantRequest(
                name=name or UNSET,
                description=description or UNSET,
                type_=UpdateConstantRequestType(type) if type else UNSET,
                value=value if value is not None else UNSET,
                multiple=multiple if multiple is not None else UNSET,
                version_id=versionId or UNSET,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_constant.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Constant", "action_type": "DELETE"})
    async def deleteConstant(uuid: str) -> str:
        """Permanently delete an Appian constant."""
        try:
            resp = await delete_constant.asyncio_detailed(uuid=uuid, client=client)
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e
