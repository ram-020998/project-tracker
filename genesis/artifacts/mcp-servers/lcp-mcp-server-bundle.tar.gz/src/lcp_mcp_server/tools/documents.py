"""Documents domain MCP tools."""

import base64
from typing import Annotated

from lcp_api_plugin_client.api.applications import list_application_documents
from lcp_api_plugin_client.api.documents import (
    delete_document,
    get_document,
    get_document_content,
    get_document_text,
    replace_document_content,
    search_documents,
    update_document,
    upload_document,
)
from lcp_api_plugin_client.models.create_document_request import CreateDocumentRequest
from lcp_api_plugin_client.models.replace_document_content_request import (
    ReplaceDocumentContentRequest,
)
from lcp_api_plugin_client.models.update_document_request import UpdateDocumentRequest
from lcp_api_plugin_client.types import UNSET
from pydantic import Field

from . import _safe_to_dict, tool_error, unwrap_response


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Document", "action_type": "GET"})
    async def listDocuments(
        appUuid: str,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian documents with optional filtering. Use appUuid to scope to an application."""
        try:
            if appUuid:
                resp = await list_application_documents.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            else:
                resp = await search_documents.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Document", "action_type": "GET"})
    async def getDocument(uuid: str) -> dict:
        """Get a single Appian document by UUID."""
        try:
            resp = await get_document.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Document", "action_type": "UPDATE"})
    async def updateDocument(
        uuid: str, name: str | None = None, description: str | None = None
    ) -> dict:
        """Update an existing Appian document. Only provided fields are changed."""
        try:
            body = UpdateDocumentRequest(
                name=name or UNSET, description=description or UNSET
            )
            resp = await update_document.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Document", "action_type": "DELETE"})
    async def deleteDocument(uuid: str) -> str:
        """Permanently delete an Appian document."""
        try:
            resp = await delete_document.asyncio_detailed(uuid=uuid, client=client)
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Document", "action_type": "GET"})
    async def getDocumentContent(uuid: str) -> dict:
        """Get the binary content of an Appian document."""
        try:
            resp = await get_document_content.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Document", "action_type": "GET"})
    async def getDocumentText(uuid: str, includeMetadata: bool | None = None) -> dict:
        """Get the extracted text content of an Appian document."""
        try:
            resp = await get_document_text.asyncio_detailed(
                uuid=uuid,
                client=client,
                include_metadata=includeMetadata
                if includeMetadata is not None
                else UNSET,
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Document", "action_type": "UPDATE"})
    async def replaceDocumentContent(uuid: str, content: str) -> dict:
        """Replace the content of an Appian document. Content is plain text — it will be base64-encoded automatically."""
        try:
            encoded = base64.b64encode(content.encode()).decode()
            body = ReplaceDocumentContentRequest(file_content=encoded)
            resp = await replace_document_content.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Document", "action_type": "CREATE"})
    async def uploadDocument(
        name: Annotated[
            str,
            Field(
                description='The document name including extension (max 255 characters), e.g. "Annual Report.pdf".'
            ),
        ],
        parentFolderUuid: Annotated[
            str, Field(description="The UUID of the parent folder.")
        ],
        content: Annotated[
            str,
            Field(
                description="The file content as a plain string — it will be base64-encoded automatically."
            ),
        ],
        appUuid: Annotated[
            str,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object to the app and applies the app's default security."
            ),
        ],
        description: str | None = None,
        extension: Annotated[
            str,
            Field(
                description='Optional file extension without dot (auto-detected from name if not provided), e.g. "pdf".'
            ),
        ] = None,
    ) -> dict:
        """Upload a new document with file content to a folder."""
        try:
            encoded = base64.b64encode(content.encode()).decode()
            body = CreateDocumentRequest(
                name=name,
                parent_folder_uuid=parentFolderUuid,
                file_content=encoded,
                app_uuid=appUuid,
                description=description or UNSET,
                extension=extension or UNSET,
            )
            resp = await upload_document.asyncio_detailed(client=client, body=body)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e
