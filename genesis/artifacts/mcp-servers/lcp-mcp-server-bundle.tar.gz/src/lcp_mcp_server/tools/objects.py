"""Objects domain MCP tools — cross-cutting operations on any design object."""

import asyncio
from http import HTTPStatus
from typing import Annotated

from lcp_api_plugin_client.api.applications import (
    list_application_agents,
    list_application_constants,
    list_application_documents,
    list_application_expression_rules,
    list_application_folders,
    list_application_groups,
    list_application_interfaces,
    list_application_process_models,
    list_application_processes,
    list_application_record_types,
    list_application_robotic_tasks,
    list_application_sites,
)
from lcp_api_plugin_client.api.connected_systems import (
    list_application_connected_systems,
)
from lcp_api_plugin_client.api.integrations import list_application_integrations
from lcp_api_plugin_client.api.web_ap_is import list_application_web_apis
from lcp_api_plugin_client.api.objects import (
    get_object_dependents,
    get_object_security,
    update_object_security,
)
from lcp_api_plugin_client.models.role_entry import RoleEntry
from lcp_api_plugin_client.models.security_update_request import SecurityUpdateRequest
from pydantic import Field

from lcp_api_beta_client.api.design_objects_ai_skills import list_ai_skills

from . import _safe_to_dict, logger, tool_error, unwrap_response
from fastmcp.exceptions import ToolError
from .ai_skills import _unwrap_beta_response
from .models import RoleAssignment


from enum import Enum as _Enum


class ObjectType(str, _Enum):
    """Valid object types for filtering listApplicationObjects."""

    RECORD_TYPES = "recordTypes"
    INTERFACES = "interfaces"
    EXPRESSION_RULES = "expressionRules"
    PROCESS_MODELS = "processModels"
    PROCESSES = "processes"
    SITES = "sites"
    GROUPS = "groups"
    CONSTANTS = "constants"
    CONNECTED_SYSTEMS = "connectedSystems"
    INTEGRATIONS = "integrations"
    WEB_APIS = "webApis"
    DOCUMENTS = "documents"
    FOLDERS = "folders"
    AGENTS = "agents"
    AI_SKILLS = "aiSkills"
    ROBOTIC_TASKS = "roboticTasks"


# Max items included inline per object type. Types with more than this are
# summarized with a count + referral to the object-specific list tool instead
# of returning every item, keeping the response small enough for agent context.
_INLINE_LIMIT = 100

# We fetch one extra item so overflow can be detected from the page size alone,
# independently of the server-reported `total`. If a future endpoint ever drops
# `total`, this ensures we still recognize (and flag) a truncated type rather
# than silently returning a capped page as if it were complete.
_FETCH_LIMIT = _INLINE_LIMIT + 1

# Object type key -> the dedicated list tool that supports full limit/offset
# paging. Used to refer callers to complete results when a type is truncated.
# "processes" has no dedicated paging tool (endpoint is not implemented).
_LIST_TOOL_BY_KEY = {
    "recordTypes": "listRecordTypes",
    "interfaces": "listInterfaces",
    "expressionRules": "listExpressionRules",
    "processModels": "listProcessModels",
    "sites": "listSites",
    "groups": "listGroups",
    "constants": "listConstants",
    "connectedSystems": "listConnectedSystems",
    "integrations": "listIntegrations",
    "webApis": "listWebApis",
    "documents": "listDocuments",
    "folders": "listFolders",
    "agents": "listAgents",
    "aiSkills": "listAiSkills",
    "roboticTasks": "listRoboticTasks",
}


def register_tools(mcp, client, beta_client=None):
    @mcp.tool(meta={"object_type": "Application", "action_type": "GET"})
    async def listApplicationObjects(
        appUuid: str,
        objectTypes: Annotated[
            list[ObjectType] | None,
            Field(
                description="Filter to specific object types. Omit or pass empty list to return all types."
            ),
        ] = None,
    ) -> dict:
        """List design objects in an application. Use this for broad discovery instead of calling individual list tools. Optionally filter to specific object types to reduce response size.

        Returns a dict keyed by object type. Each value has a `total` count and
        either an `items` array (when the count is small) or, when a type has
        more than 100 objects, a `truncated` flag and a `message` referring you
        to the object-specific list tool (e.g. listInterfaces) which supports
        full limit/offset paging. This keeps the response compact while never
        silently dropping objects — the true count is always reported.
        """

        def _summarize(key, result):
            """Build the per-type entry: full items if small, else a count + referral."""
            items = result.get("items", []) or []
            total = result.get("total")

            # We requested _FETCH_LIMIT (_INLINE_LIMIT + 1) items, so a full page
            # of that size means there are more than _INLINE_LIMIT — overflow we
            # can detect without trusting `total`. If the endpoint dropped `total`
            # entirely, warn (this path is the one that could silently truncate)
            # and fall back to the page-size signal.
            overflow_from_page = len(items) > _INLINE_LIMIT
            if total is None:
                logger.warning(
                    "listApplicationObjects: '%s' response omitted 'total'; "
                    "using page-size overflow to detect truncation.",
                    key,
                )
                truncated = overflow_from_page
            else:
                truncated = total > _INLINE_LIMIT

            if truncated:
                entry = {"truncated": True}
                if total is not None:
                    entry["total"] = total
                    count_phrase = f"{total} {key}"
                else:
                    count_phrase = f"More than {_INLINE_LIMIT} {key}"
                list_tool = _LIST_TOOL_BY_KEY.get(key)
                if list_tool:
                    entry["message"] = (
                        f"{count_phrase} exceed the inline limit of {_INLINE_LIMIT}. "
                        f"Use {list_tool}(appUuid=...) with limit/offset to page through all of them."
                    )
                else:
                    entry["message"] = (
                        f"{count_phrase} exceed the inline limit of {_INLINE_LIMIT}; "
                        f"no dedicated paging tool is available for this type."
                    )
                return key, entry

            # Not truncated: drop the extra probe item if the endpoint returned it.
            return key, {"total": total if total is not None else len(items),
                         "items": items[:_INLINE_LIMIT]}

        async def _list(coro, key):
            try:
                resp = await coro
                result = _safe_to_dict(unwrap_response(resp))
                return _summarize(key, result)
            except Exception:
                return key, {"total": 0, "items": []}

        async def _list_beta(coro, key):
            try:
                resp = await coro
                result = _safe_to_dict(_unwrap_beta_response(resp))
                return _summarize(key, result)
            except Exception:
                return key, {"total": 0, "items": []}

        all_fetchers = {
            "recordTypes": lambda: list_application_record_types.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "interfaces": lambda: list_application_interfaces.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "expressionRules": lambda: (
                list_application_expression_rules.asyncio_detailed(
                    app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
                )
            ),
            "processModels": lambda: list_application_process_models.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "sites": lambda: list_application_sites.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "groups": lambda: list_application_groups.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "constants": lambda: list_application_constants.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "connectedSystems": lambda: (
                list_application_connected_systems.asyncio_detailed(
                    app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
                )
            ),
            "integrations": lambda: list_application_integrations.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "webApis": lambda: list_application_web_apis.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "documents": lambda: list_application_documents.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "folders": lambda: list_application_folders.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "agents": lambda: list_application_agents.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "aiSkills": lambda: list_ai_skills.asyncio_detailed(
                client=beta_client,
                limit=_FETCH_LIMIT,
                offset=0,
                x_appian_api_version="beta",
            ),
            "roboticTasks": lambda: list_application_robotic_tasks.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
            "processes": lambda: list_application_processes.asyncio_detailed(
                app_uuid=appUuid, client=client, limit=_FETCH_LIMIT, offset=0
            ),
        }

        if objectTypes:
            keys = {t.value for t in objectTypes}
        else:
            keys = set(all_fetchers.keys())

        _beta_keys = {"aiSkills"}
        results = await asyncio.gather(
            *[
                _list_beta(all_fetchers[k](), k)
                if k in _beta_keys
                else _list(all_fetchers[k](), k)
                for k in keys
            ]
        )
        return {key: entry for key, entry in results}

    @mcp.tool(meta={"object_type": "Security", "action_type": "GET"})
    async def getObjectSecurity(uuid: str) -> dict:
        """Get the security role map for any design object by UUID.

        All valid roles for the object type are included — unassigned roles
        have empty groupNames arrays.

        For content-backed objects (constants, expression rules, interfaces,
        documents, folders), the response also includes:
        - inheritSecurity: whether the object inherits security from its parent
        - parentFolderUuid: UUID of the parent folder
        - inheritedGroupNames on each role: groups inherited from parent (read-only)

        These fields are null/empty for non-content objects.
        """
        try:
            resp = await get_object_security.asyncio_detailed(uuid=uuid, client=client)
            status = (
                resp.status_code.value
                if isinstance(resp.status_code, HTTPStatus)
                else int(resp.status_code)
            )
            if status == 403:
                raise ToolError(
                    f"Design object not found or not accessible: {uuid}"
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Security", "action_type": "UPDATE"})
    async def updateObjectSecurity(
        uuid: str,
        roles: list[RoleAssignment],
        inheritSecurity: Annotated[
            bool,
            Field(
                description=(
                    "For content-backed objects (constants, expression rules, interfaces, "
                    "documents, folders), whether this object inherits security from its parent. "
                    "Ignored for non-content objects."
                )
            ),
        ] = True,
    ) -> dict:
        """Set the security role map for a design object by UUID.

        Full replacement — roles not included are cleared.
        Only roleName and groupNames are used; inheritedGroupNames is read-only
        and ignored on PUT.
        """
        try:
            sdk_roles = [
                RoleEntry(role_name=r.roleName, group_names=r.groupNames) for r in roles
            ]
            body = SecurityUpdateRequest(
                roles=sdk_roles,
                inherit_security=inheritSecurity,
            )
            resp = await update_object_security.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            status = (
                resp.status_code.value
                if isinstance(resp.status_code, HTTPStatus)
                else int(resp.status_code)
            )
            if status == 403:
                raise ToolError(
                    f"Design object not found or not accessible: {uuid}"
                )
            if status == 400:
                body_preview = resp.content.decode(errors="replace")[:500]
                raise ToolError(f"Invalid request: {body_preview}")
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Dependencies", "action_type": "GET"})
    async def getObjectDependents(uuid: str) -> dict:
        """Get all design objects that reference the given object by UUID.

        Returns objects that depend on (reference) the specified object. This is useful
        for understanding impact analysis - what would be affected if you changed or
        deleted this object.

        The response includes:
        - uuid: the queried object's UUID
        - dependents: array of objects that reference this object, each with:
          - uuid: dependent object's UUID
          - type: dependent object's type (e.g., FREEFORM_RULE, INTERFACE, PROCESS_MODEL)
          - name: name of the dependent object (first breadcrumb)
          - breadcrumb: full path showing where the reference occurs (e.g., "My Interface > Local Variables > myConstant")
        - totalCount: total number of dependents found

        The breadcrumb field is especially useful as it shows the exact location within
        the dependent object where the reference occurs (e.g., which variable, expression,
        or node contains the reference).

        The server automatically resolves the object type from the UUID.
        """
        try:
            resp = await get_object_dependents.asyncio_detailed(uuid=uuid, client=client)
            status = (
                resp.status_code.value
                if isinstance(resp.status_code, HTTPStatus)
                else int(resp.status_code)
            )
            if status == 404:
                raise ToolError(
                    f"Design object not found or type could not be determined: {uuid}"
                )
            if status == 503:
                raise ToolError(
                    "Design object search service is not available"
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e
