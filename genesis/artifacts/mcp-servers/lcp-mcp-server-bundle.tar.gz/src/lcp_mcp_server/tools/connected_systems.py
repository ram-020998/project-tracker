"""Connected Systems domain MCP tools."""

from typing import Annotated

from lcp_api_plugin_client.api.connected_system_types import (
    get_connected_system_type,
    list_connected_system_types,
)
from lcp_api_plugin_client.api.connected_systems import (
    create_connected_system,
    delete_connected_system,
    get_connected_system,
    list_application_connected_systems,
    list_connected_systems,
    update_connected_system,
)
from lcp_api_plugin_client.models.create_connected_system_request import (
    CreateConnectedSystemRequest,
)
from lcp_api_plugin_client.models.update_connected_system_request import (
    UpdateConnectedSystemRequest,
)
from lcp_api_plugin_client.types import UNSET
from pydantic import Field

from . import _safe_to_dict, tool_error, unwrap_response


async def _get_version_id(uuid: str, client) -> str | None:
    resp = await get_connected_system.asyncio_detailed(uuid=uuid, client=client)
    return _safe_to_dict(unwrap_response(resp)).get("versionId")


def register_tools(mcp, client):
    # ── Connected System Type tools ──────────────────────────────────

    @mcp.tool(meta={"object_type": "Connected System", "action_type": "GET"})
    async def listConnectedSystemTypes() -> list[dict]:
        """List available connected system types.

        Returns typeId, name, and description for each type.
        Use getConnectedSystemType to get the operations list for a specific type.
        """
        try:
            resp = await list_connected_system_types.asyncio_detailed(
                client=client,
            )
            result = unwrap_response(resp)
            return [_safe_to_dict(r) for r in result] if result else []
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Connected System", "action_type": "GET"})
    async def getConnectedSystemType(typeId: str) -> dict:
        """Get a connected system type including its operations.

        Use this to find the operationId you need when creating an integration.
        """
        try:
            resp = await get_connected_system_type.asyncio_detailed(
                type_id=typeId,
                client=client,
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    # ── Connected System CRUD tools ──────────────────────────────────

    @mcp.tool(meta={"object_type": "Connected System", "action_type": "GET"})
    async def listConnectedSystems(
        appUuid: str,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian connected systems with optional filtering. Use appUuid to scope to an application."""
        try:
            if appUuid:
                resp = await list_application_connected_systems.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            else:
                resp = await list_connected_systems.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Connected System", "action_type": "GET"})
    async def getConnectedSystem(uuid: str) -> dict:
        """Get a single Appian connected system by UUID.

        The response includes a `schema` field — the live-evaluated list of valid
        properties for the current configuration state. Use it to see what fields
        are available and which are still null (unset).
        """
        try:
            resp = await get_connected_system.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Connected System", "action_type": "CREATE"})
    async def createConnectedSystem(
        name: str,
        type: Annotated[
            str,
            Field(
                description="Connected system type identifier (see listConnectedSystemTypes)"
            ),
        ],
        appUuid: Annotated[
            str,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object to the app and applies the app's default security."
            ),
        ],
        description: str | None = None,
        properties: Annotated[
            dict | None,
            Field(
                description=(
                    "Configuration properties. You can omit this on initial create — "
                    "the response will include a `schema` field showing which properties "
                    "are available and a `properties` map with null values for unset fields. "
                    "Set the fields you want, call updateConnectedSystem, and repeat until "
                    "all required fields are populated. Changing a discriminator field "
                    "(e.g., authType) may change which fields appear in the next response."
                )
            ),
        ] = None,
    ) -> dict:
        """Create a new Appian connected system.

        The response includes `schema` (live-evaluated property list) and `properties`
        (current values, null for unset fields). Use these to drive an iterative
        configuration loop: read schema → set null fields → call updateConnectedSystem
        → repeat until all required fields are populated.
        """
        try:
            body = CreateConnectedSystemRequest(
                name=name,
                type_=type,
                app_uuid=appUuid,
                description=description or UNSET,
                properties=properties or UNSET,
            )
            resp = await create_connected_system.asyncio_detailed(
                client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Connected System", "action_type": "UPDATE"})
    async def updateConnectedSystem(
        uuid: str,
        name: str | None = None,
        description: str | None = None,
        properties: Annotated[
            dict | None,
            Field(
                description=(
                    "Configuration properties to update. Only provided keys are changed. "
                    "The response includes an updated `schema` and `properties` map — "
                    "if you changed a discriminator field (e.g., authType), the schema "
                    "may change: new fields appear, old fields disappear from both "
                    "`schema` and `properties`."
                )
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Update an existing Appian connected system. Only provided fields are changed."""
        try:
            body = UpdateConnectedSystemRequest(
                name=name or UNSET,
                description=description or UNSET,
                properties=properties or UNSET,
                version_id=versionId or UNSET,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_connected_system.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Connected System", "action_type": "DELETE"})
    async def deleteConnectedSystem(uuid: str) -> str:
        """Permanently delete an Appian connected system."""
        try:
            resp = await delete_connected_system.asyncio_detailed(uuid=uuid, client=client)
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e
