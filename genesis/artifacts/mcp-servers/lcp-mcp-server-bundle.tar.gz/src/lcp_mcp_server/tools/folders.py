"""Folders domain MCP tools."""

from typing import Annotated

from lcp_api_plugin_client.api.applications import list_application_folders
from lcp_api_plugin_client.api.folders import (
    create_folder,
    delete_folder,
    get_folder,
    list_folder_contents,
    search_folders,
    update_folder,
)
from lcp_api_plugin_client.models.create_folder_request import CreateFolderRequest
from lcp_api_plugin_client.models.list_application_folders_folder_type import (
    ListApplicationFoldersFolderType,
)
from lcp_api_plugin_client.models.update_folder_request import UpdateFolderRequest
from lcp_api_plugin_client.types import UNSET
from pydantic import Field

from . import _safe_to_dict, tool_error, unwrap_response


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Folder", "action_type": "GET"})
    async def listFolders(
        appUuid: str,
        query: str | None = None,
        folderType: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian folders with optional filtering. Use appUuid to scope to an application."""
        try:
            if appUuid:
                mapped_folder_type = UNSET
                if folderType is not None:
                    mapped_folder_type = ListApplicationFoldersFolderType(folderType)
                resp = await list_application_folders.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                    folder_type=mapped_folder_type,
                )
            else:
                resp = await search_folders.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Folder", "action_type": "GET"})
    async def getFolder(uuid: str) -> dict:
        """Get a single Appian folder by UUID."""
        try:
            resp = await get_folder.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Folder", "action_type": "CREATE"})
    async def createFolder(
        name: str,
        parentFolderUuid: str,
        appUuid: Annotated[
            str,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object to the app and applies the app's default security."
            ),
        ],
        description: str | None = None,
    ) -> dict:
        """Create a new Appian folder."""
        try:
            body = CreateFolderRequest(
                name=name,
                parent_folder_uuid=parentFolderUuid,
                app_uuid=appUuid,
                description=description or UNSET,
            )
            resp = await create_folder.asyncio_detailed(client=client, body=body)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Folder", "action_type": "UPDATE"})
    async def updateFolder(
        uuid: str, name: str | None = None, description: str | None = None
    ) -> dict:
        """Update an existing Appian folder. Only provided fields are changed."""
        try:
            body = UpdateFolderRequest(
                name=name or UNSET, description=description or UNSET
            )
            resp = await update_folder.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Folder", "action_type": "DELETE"})
    async def deleteFolder(uuid: str) -> str:
        """Permanently delete an Appian folder."""
        try:
            resp = await delete_folder.asyncio_detailed(uuid=uuid, client=client)
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Folder", "action_type": "GET"})
    async def listFolderContents(uuid: str) -> dict:
        """List the contents of an Appian folder."""
        try:
            resp = await list_folder_contents.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e
