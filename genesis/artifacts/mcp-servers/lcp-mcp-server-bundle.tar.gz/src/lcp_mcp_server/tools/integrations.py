"""Integrations domain MCP tools."""

from typing import Annotated

from lcp_api_plugin_client.api.integrations import (
    create_integration,
    delete_integration,
    get_integration,
    list_application_integrations,
    list_integrations,
    update_integration,
)
from lcp_api_plugin_client.models.create_integration_request import (
    CreateIntegrationRequest,
)
from lcp_api_plugin_client.models.integration_input import (
    IntegrationInput as SdkIntegrationInput,
)
from lcp_api_plugin_client.models.integration_test_input import (
    IntegrationTestInput as SdkIntegrationTestInput,
)
from lcp_api_plugin_client.models.update_integration_request import (
    UpdateIntegrationRequest,
)
from fastmcp.exceptions import ToolError
from lcp_api_plugin_client.types import UNSET
from pydantic import Field

from . import _safe_to_dict, tool_error, unwrap_response


async def _get_version_id(uuid: str, client) -> str | None:
    resp = await get_integration.asyncio_detailed(uuid=uuid, client=client)
    return _safe_to_dict(unwrap_response(resp)).get("versionId")


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Integration", "action_type": "GET"})
    async def listIntegrations(
        appUuid: str,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian integrations with optional filtering. Use appUuid to scope to an application."""
        try:
            if appUuid:
                resp = await list_application_integrations.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            else:
                resp = await list_integrations.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Integration", "action_type": "GET"})
    async def getIntegration(uuid: str) -> dict:
        """Get a single Appian integration by UUID.

        The response includes a `schema` field — the live-evaluated list of valid
        properties for the current configuration state. Use it to see what fields
        are available and which are still null (unset).
        """
        try:
            resp = await get_integration.asyncio_detailed(uuid=uuid, client=client)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Integration", "action_type": "CREATE"})
    async def createIntegration(
        name: Annotated[
            str,
            Field(description="Integration name. Must not contain spaces."),
        ],
        connectedSystemUuid: str,
        appUuid: Annotated[
            str | None,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object to the app and applies the app's default security, selecting an appropriate Rules and Constants folder. Either appUuid or parentFolderUuid must be provided."
            ),
        ] = None,
        parentFolderUuid: Annotated[
            str | None,
            Field(
                description="UUID of the parent Rules and Constants folder. Takes precedence over appUuid for folder selection. Either appUuid or parentFolderUuid must be provided."
            ),
        ] = None,
        description: str | None = None,
        operationId: Annotated[
            str,
            Field(
                description=(
                    "Operation identifier from the connected system type's operations list "
                    "(see listConnectedSystemTypes)."
                )
            ),
        ] = None,
        properties: Annotated[
            dict | None,
            Field(
                description=(
                    "Configuration properties. You can omit this on initial create — "
                    "the response will include a `schema` field showing which properties "
                    "are available and a `properties` map with null values for unset fields. "
                    "Set the fields you want, call updateIntegration, and repeat until "
                    "all required fields are populated. Do not guess at property names — "
                    "always inspect the schema from the create response first. "
                    "Properties where schema has isExpressionable=true are Appian expressions. "
                    "For literal strings, wrap in quotes: '\"my value\"'. "
                    "For expressions, pass directly: 'ri!myInput'. "
                    "If you get an expression evaluation error, you likely need to quote a literal. "
                    "\n\n"
                    "MULTIPART BODIES (bodyType 'multipart/form-data'): set the body one of two ways. "
                    "(1) 'bodyFormParts': a list of {name, contentType, value} dicts, one per form "
                    "field — each compiled into an a!httpFormPart(...) call. 'value' is a raw SAIL "
                    "expression (e.g. 'ri!requirements', or a literal like 'true'); 'contentType' is "
                    "the part MIME type (e.g. 'text/plain', or 'auto-detect' for document parts). "
                    "(2) 'bodyContent': a raw SAIL expression that must evaluate to a list of "
                    "a!httpFormPart(...) values; it OVERRIDES bodyFormParts. Use bodyContent when you "
                    "need a conditional part, e.g. "
                    "'if(a!isNotNullOrEmpty(ri!file), a!httpFormPart(name: \"file\", contentType: \"auto-detect\", value: ri!file), {})'. "
                    "A multipart body that is not a list of a!httpFormPart(...) (e.g. a plain "
                    "dictionary) is rejected with a validation error."
                )
            ),
        ] = None,
        inputs: Annotated[
            list[dict] | None,
            Field(
                description="Rule input parameters. Each dict has: name (str), type (str, e.g. 'Text'), description (str, optional)."
            ),
        ] = None,
        testInputs: Annotated[
            list[dict] | None,
            Field(
                description=(
                    "Test input values used during body validation and saved as the "
                    "integration's default test case. Each dict has: name (str, must match "
                    "an input), value (str, a SAIL expression like '\"text\"' or '123'), and "
                    "optional type (str). Supply these when the body is null-unsafe so "
                    "validation runs against real values instead of nulls. Integrations "
                    "support only a default test case (no named cases)."
                )
            ),
        ] = None,
    ) -> dict:
        """Create a new Appian integration.

        Provide either appUuid (to auto-select the app's Rules and Constants folder) or
        parentFolderUuid (to target a specific folder). If both are given, parentFolderUuid wins.

        The response includes `schema` (live-evaluated property list) and `properties`
        (current values, null for unset fields). Use these to drive an iterative
        configuration loop: read schema → set null fields → call updateIntegration
        → repeat until all required fields are populated.

        Do NOT guess at property names or values — inspect the `schema` in the
        response first, then use updateIntegration to set the fields you need.
        """
        if not appUuid and not parentFolderUuid:
            raise ToolError("Either appUuid or parentFolderUuid must be provided.")
        try:
            body = CreateIntegrationRequest(
                name=name,
                connected_system_uuid=connectedSystemUuid,
                app_uuid=appUuid or UNSET,
                parent_folder_uuid=parentFolderUuid or UNSET,
                description=description or UNSET,
                operation_id=operationId or UNSET,
                properties=properties or UNSET,
                inputs=[SdkIntegrationInput.from_dict(i) for i in inputs]
                if inputs is not None
                else UNSET,
                test_inputs=[SdkIntegrationTestInput.from_dict(t) for t in testInputs]
                if testInputs is not None
                else UNSET,
            )
            resp = await create_integration.asyncio_detailed(client=client, body=body)
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Integration", "action_type": "UPDATE"})
    async def updateIntegration(
        uuid: str,
        name: Annotated[
            str,
            Field(description="Integration name. Must not contain spaces."),
        ] = None,
        description: str | None = None,
        operationId: Annotated[
            str,
            Field(
                description="Operation identifier. Changing this switches the integration to a different operation."
            ),
        ] = None,
        properties: Annotated[
            dict | None,
            Field(
                description=(
                    "Configuration properties to update. Only provided keys are changed. "
                    "The response includes an updated `schema` and `properties` map. "
                    "Properties where schema has isExpressionable=true are Appian expressions. "
                    "For literal strings, wrap in quotes: '\"my value\"'. "
                    "For expressions, pass directly: 'ri!myInput'. "
                    "If you get an expression evaluation error, you likely need to quote a literal. "
                    "\n\n"
                    "MULTIPART BODIES (bodyType 'multipart/form-data'): set the body via "
                    "'bodyFormParts' (a list of {name, contentType, value} dicts, one per form "
                    "field, each compiled into a!httpFormPart(...)) or 'bodyContent' (a raw SAIL "
                    "expression evaluating to a list of a!httpFormPart(...) values, which "
                    "OVERRIDES bodyFormParts and supports conditional parts via if(...)). "
                    "A multipart body that is not a list of a!httpFormPart(...) is rejected."
                )
            ),
        ] = None,
        inputs: Annotated[
            list[dict] | None,
            Field(
                description="Rule input parameters (full replacement — replaces all existing inputs)"
            ),
        ] = None,
        testInputs: Annotated[
            list[dict] | None,
            Field(
                description=(
                    "Test input values used during body validation and saved as the "
                    "integration's default test case. Each dict has: name (str), value "
                    "(str, a SAIL expression), and optional type (str). If omitted, the "
                    "previously saved default test case is used for validation."
                )
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Update an existing Appian integration. Only provided fields are changed."""
        try:
            body = UpdateIntegrationRequest(
                name=name or UNSET,
                description=description or UNSET,
                operation_id=operationId or UNSET,
                properties=properties or UNSET,
                inputs=[SdkIntegrationInput.from_dict(i) for i in inputs]
                if inputs is not None
                else UNSET,
                test_inputs=[SdkIntegrationTestInput.from_dict(t) for t in testInputs]
                if testInputs is not None
                else UNSET,
                version_id=versionId or UNSET,
            )
            previous_version_id = versionId or await _get_version_id(uuid, client)
            resp = await update_integration.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = _safe_to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Integration", "action_type": "DELETE"})
    async def deleteIntegration(uuid: str) -> str:
        """Permanently delete an Appian integration."""
        try:
            resp = await delete_integration.asyncio_detailed(uuid=uuid, client=client)
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e
