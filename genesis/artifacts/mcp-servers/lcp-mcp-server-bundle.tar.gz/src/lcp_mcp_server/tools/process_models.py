"""Process Models domain MCP tools."""

from typing import Annotated

from lcp_api_plugin_client.api.applications import (
    list_application_process_models,
)
from lcp_api_plugin_client.api.process_models import (
    create_process_model,
    create_process_model_node,
    delete_process_model,
    delete_process_model_node,
    get_process_model_by_uuid,
    get_process_model_node,
    get_process_model_node_type_schema,
    list_process_model_folders,
    list_process_model_node_types,
    list_process_model_nodes,
    list_process_models,
    test_process_model,
    update_process_model,
    update_process_model_node,
)
from lcp_api_plugin_client.models.create_process_model_request import (
    CreateProcessModelRequest,
)
from lcp_api_plugin_client.models.form_config import FormConfig
from lcp_api_plugin_client.models.process_model_node_input import (
    ProcessModelNodeInput as SDKNodeInput,
)
from lcp_api_plugin_client.models.process_model_variable import ProcessModelVariable
from lcp_api_plugin_client.models.test_process_model_request import (
    TestProcessModelRequest,
)
from lcp_api_plugin_client.models.update_process_model_node_request import (
    UpdateProcessModelNodeRequest,
)
from lcp_api_plugin_client.models.update_process_model_request import (
    UpdateProcessModelRequest,
)
from lcp_api_plugin_client.types import UNSET
from pydantic import BeforeValidator, Field

from . import (
    _coerce_json_str_to_dict,
    _coerce_json_str_to_list,
    _safe_to_dict,
    tool_error,
    unwrap_response,
)
from .models import (
    FormConfigInput,
    NodeAssignmentInput,
    NodeDataInput,
    NodeDecisionInput,
    ProcessModelConnectionInput,
    ProcessModelLaneInput,
    ProcessModelVariableInput,
)
from .models import (
    ProcessModelNodeInput as NodeInput,
)


def _to_dict(result):
    if isinstance(result, (dict, list)):
        return result
    return _safe_to_dict(result)


async def _get_version_id(uuid: str, client) -> str | None:
    resp = await get_process_model_by_uuid.asyncio_detailed(uuid=uuid, client=client)
    return _safe_to_dict(unwrap_response(resp)).get("versionId")


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Process Model", "action_type": "GET"})
    async def listProcessModels(
        appUuid: str,
        query: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        """List Appian process models with optional filtering. Use appUuid to scope to an application."""
        try:
            if appUuid:
                resp = await list_application_process_models.asyncio_detailed(
                    app_uuid=appUuid,
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            else:
                resp = await list_process_models.asyncio_detailed(
                    client=client,
                    query=query or UNSET,
                    limit=limit,
                    offset=offset,
                )
            return _to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "GET"})
    async def listProcessModelFolders(limit: int = 50, offset: int = 0) -> dict:
        """List top-level Process Model Folders. Use these as parentFolderUuid when creating process models. Regular folders cannot contain process models."""
        try:
            resp = await list_process_model_folders.asyncio_detailed(
                client=client, limit=limit, offset=offset
            )
            return _to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "GET"})
    async def getProcessModel(uuid: str) -> dict:
        """Get a single Appian process model by UUID."""
        try:
            resp = await get_process_model_by_uuid.asyncio_detailed(
                uuid=uuid, client=client
            )
            return _to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "CREATE"})
    async def createProcessModel(
        name: Annotated[
            str | dict,
            BeforeValidator(_coerce_json_str_to_dict),
            Field(
                description="Process model name. Can be a simple string (stored in site's primary locale) or a dict mapping locale codes to localized names (e.g., {'en_US': 'Name', 'en_GB': 'Name'})."
            ),
        ],
        description: Annotated[
            str | dict,
            BeforeValidator(_coerce_json_str_to_dict),
            Field(
                description="Process model description. Can be a simple string (stored in site's primary locale) or a dict mapping locale codes to localized descriptions."
            ),
        ],
        parentFolderUuid: Annotated[
            str,
            Field(
                description="Process Model Folder UUID (see listProcessModelFolders)"
            ),
        ],
        errorAlertGroupName: Annotated[
            str, Field(description="Error alert group name (see listGroups)")
        ],
        appUuid: Annotated[
            str,
            Field(
                description="Application UUID (see listApplications). Auto-adds created object to the app and applies the app's default security."
            ),
        ],
    ) -> dict:
        """Create a new Appian process model."""
        try:
            nodes = [
                NodeInput(
                    id=1,
                    type="core.0",
                    name="Start",
                    coordinates=[100, 200],
                    connections=[
                        ProcessModelConnectionInput(targetNodeId=2, activityChained=False)
                    ],
                ),
                NodeInput(
                    id=2,
                    type="core.1",
                    name="End",
                    coordinates=[300, 200],
                    connections=[],
                ),
            ]
            node_dicts = [n.model_dump(exclude_none=True) for n in nodes]
            # Build the body via from_dict (like updateProcessModel) so that name /
            # description are converted explicitly: _parse_name / _parse_description
            # turn a locale-map dict into the typed *NameType1 / *DescriptionType1
            # object, and leave a plain string as-is.
            body = CreateProcessModelRequest.from_dict(
                {
                    "name": name,
                    "description": description,
                    "parentFolderUuid": parentFolderUuid,
                    "errorAlertGroupName": errorAlertGroupName,
                    "nodes": node_dicts,
                    "appUuid": appUuid,
                }
            )
            resp = await create_process_model.asyncio_detailed(client=client, body=body)
            return _to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "DELETE"})
    async def deleteProcessModel(uuid: str) -> str:
        """Permanently delete an Appian process model."""
        try:
            resp = await delete_process_model.asyncio_detailed(uuid=uuid, client=client)
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "UPDATE"})
    async def updateProcessModel(
        uuid: str,
        name: Annotated[
            str | dict | None,
            BeforeValidator(_coerce_json_str_to_dict),
            Field(
                description="Process model name. Can be a simple string (stored in site's primary locale) or a dict mapping locale codes to localized names."
            ),
        ] = None,
        description: Annotated[
            str | dict | None,
            BeforeValidator(_coerce_json_str_to_dict),
            Field(
                description="Process model description. Can be a simple string or a dict mapping locale codes to localized descriptions."
            ),
        ] = None,
        processVariables: Annotated[
            list[ProcessModelVariableInput] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description="Process variables. Set isParameter=true to expose as inputs for record actions, subprocesses, or start forms."
            ),
        ] = None,
        nodes: Annotated[
            list[NodeInput] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description="Process model nodes. Use listProcessModelNodeTypes for available types and getProcessModelNodeTypeSchema for node parameters."
            ),
        ] = None,
        lanes: Annotated[
            list[ProcessModelLaneInput] | None,
            BeforeValidator(_coerce_json_str_to_list),
            Field(
                description="Swimlanes for visual role-based organization. Replaces all existing lanes. Nodes reference lanes by index into this array."
            ),
        ] = None,
        startForm: Annotated[
            FormConfigInput | dict[str, FormConfigInput] | None,
            BeforeValidator(_coerce_json_str_to_dict),
            Field(
                description="Start form configuration. Can be a single FormConfig (stored in site's primary locale) or a dict mapping locale codes to FormConfig objects for multi-locale support. Use inputMap to map interface input names to PV names."
            ),
        ] = None,
        versionId: str | None = None,
    ) -> dict:
        """Update an existing Appian process model. Only provided fields are changed."""
        try:
            # Handle nodes - model_dump recursively serializes nested forms (including
            # locale-map FormConfig values), so no per-form handling is needed here.
            node_dicts = None
            if nodes is not None:
                node_dicts = [
                    n.model_dump(exclude_none=True) if isinstance(n, NodeInput) else n
                    for n in nodes
                ]
            lane_dicts = (
                [lane.model_dump(exclude_none=True) for lane in lanes]
                if lanes is not None
                else None
            )
            # Handle startForm - can be a single FormConfig or a dict of locale -> FormConfig
            start_form_value = None
            if startForm is not None:
                if isinstance(startForm, dict):
                    # Dict of locale codes to FormConfig objects
                    start_form_value = {
                        locale: form.model_dump(exclude_none=True)
                        for locale, form in startForm.items()
                    }
                else:
                    # Single FormConfigInput object
                    start_form_value = startForm.model_dump(exclude_none=True)

            body_dict = {
                k: v
                for k, v in {
                    "name": name,
                    "description": description,
                    "processVariables": [
                        var.model_dump(exclude_none=True) for var in processVariables
                    ]
                    if processVariables is not None
                    else None,
                    "nodes": node_dicts,
                    "lanes": lane_dicts,
                    "startForm": start_form_value,
                    "versionId": versionId,
                }.items()
                if v is not None
            }
            previous_version_id = await _get_version_id(uuid, client)
            body = UpdateProcessModelRequest.from_dict(body_dict)
            resp = await update_process_model.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            result = _to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "GET"})
    async def listProcessModelNodeTypes() -> dict:
        """List available process model node types from the palette.

        Returns all node types including built-in and plugin-provided smart services,
        with type (schema local ID), typeName (display name), category, and assignment mode.
        Use getProcessModelNodeTypeSchema to get the parameter schema for a specific type.

        Nodes with `deprecated: true` are outdated versions — always prefer the
        non-deprecated equivalent (e.g. use "Write Records and Related Records"
        instead of deprecated "Write Records").
        """
        try:
            resp = await list_process_model_node_types.asyncio_detailed(client=client)
            return _to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "GET"})
    async def getProcessModelNodeTypeSchema(
        type: Annotated[  # noqa: A002
            str,
            Field(
                description="Node type schema local ID or display name (see listProcessModelNodeTypes)"
            ),
        ],
        referenceUuid: Annotated[
            str,
            Field(
                description="UUID of the primary reference object (integration, subprocess PM, record type) for schema enrichment"
            ),
        ] = None,
        formInterfaceUuid: Annotated[
            str,
            Field(
                description="UUID of the form interface for attended nodes — adds form inputs to the schema"
            ),
        ] = None,
    ) -> dict:
        """Get the parameter schema for a specific process model node type.

        Returns inputs, outputs, assignment mode, and descriptions for each parameter.
        Use referenceUuid to enrich the schema with context from a referenced object
        (e.g., integration inputs for Call Integration, subprocess PVs for Subprocess).
        Use formInterfaceUuid to discover form inputs for attended nodes (e.g., User Input Task).
        """
        try:
            resp = await get_process_model_node_type_schema.asyncio_detailed(
                type_=type,
                client=client,
                reference_uuid=referenceUuid or UNSET,
                form_interface_uuid=formInterfaceUuid or UNSET,
            )
            return _to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "GET"})
    async def testProcessModel(
        uuid: str,
        inputs: Annotated[
            dict | None,
            Field(
                description="Key/value map of process parameter values to pass on start."
            ),
        ] = None,
        timeoutSeconds: Annotated[
            int | None,
            Field(
                description="Maximum time to wait for the process to complete. Default: 30. Max: 60."
            ),
        ] = None,
        maxResponseSizeBytes: Annotated[
            int | None,
            Field(
                description="Maximum response size to return. Default: 5120 (5KB). Max: 1048576 (1MB)."
            ),
        ] = None,
    ) -> dict:
        """Start a process model, wait for completion, and return process variable values. Only works for unattended process models (no user input tasks). Returns processId, status, and processVariables map."""
        try:
            body = TestProcessModelRequest(
                inputs=inputs or UNSET,
                timeout_seconds=timeoutSeconds if timeoutSeconds is not None else UNSET,
                max_response_size_bytes=maxResponseSizeBytes
                if maxResponseSizeBytes is not None
                else UNSET,
            )
            resp = await test_process_model.asyncio_detailed(
                uuid=uuid, client=client, body=body
            )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "GET"})
    async def listProcessModelNodes(processModelUuid: str) -> dict:
        """List all nodes in a process model with full configuration."""
        try:
            resp = await list_process_model_nodes.asyncio_detailed(
                uuid=processModelUuid, client=client
            )
            return _to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "GET"})
    async def getProcessModelNode(processModelUuid: str, nodeId: int) -> dict:
        """Get a single node with full configuration (data, forms, assignment, connections)."""
        try:
            resp = await get_process_model_node.asyncio_detailed(
                uuid=processModelUuid, node_id=nodeId, client=client
            )
            return _to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "UPDATE"})
    async def createProcessModelNode(
        processModelUuid: str,
        id: int,
        type: str,  # noqa: A002
        name: Annotated[
            str | dict,
            BeforeValidator(_coerce_json_str_to_dict),
            Field(
                description="Node name. Can be a simple string (stored in site's primary locale) or a dict mapping locale codes to localized names."
            ),
        ],
        coordinates: list[int],
        connections: Annotated[
            list[ProcessModelConnectionInput] | None,
            Field(
                description="Outgoing connections. Each specifies targetNodeId and activityChained (required), plus optional overridesAssignment, synchronizeData, and label."
            ),
        ] = None,
        data: Annotated[
            NodeDataInput | None,
            Field(
                description="Data/Setup tab. Use getProcessModelNodeTypeSchema to discover inputs/outputs for the node type."
            ),
        ] = None,
        decision: Annotated[
            NodeDecisionInput | None,
            Field(description="Decision tab for gateways."),
        ] = None,
        assignment: Annotated[
            NodeAssignmentInput | None,
            Field(description="Assignment tab for activity nodes."),
        ] = None,
        forms: Annotated[
            FormConfigInput | dict[str, FormConfigInput] | None,
            BeforeValidator(_coerce_json_str_to_dict),
            Field(
                description="Forms tab for attended activity nodes. Can be a single FormConfig (stored in site's primary locale) or a dict mapping locale codes to FormConfig objects for multi-locale support."
            ),
        ] = None,
    ) -> dict:
        """Add a node to a process model. The agent must serialize per-node operations on the same PM."""
        try:
            node_dict = {
                "id": id,
                "type": type,
                "name": name,
                "coordinates": coordinates,
            }
            if connections is not None:
                node_dict["connections"] = [
                    c.model_dump(exclude_none=True) for c in connections
                ]
            if data is not None:
                node_dict["data"] = data.model_dump(exclude_none=True)
            if decision is not None:
                node_dict["decision"] = decision.model_dump(exclude_none=True)
            if assignment is not None:
                node_dict["assignment"] = assignment.model_dump(exclude_none=True)
            if forms is not None:
                # Handle forms - can be a single FormConfig or a dict of locale -> FormConfig
                if isinstance(forms, dict):
                    node_dict["forms"] = {
                        locale: form.model_dump(exclude_none=True)
                        for locale, form in forms.items()
                    }
                else:
                    node_dict["forms"] = forms.model_dump(exclude_none=True)

            previous_version_id = await _get_version_id(processModelUuid, client)
            body = SDKNodeInput.from_dict(node_dict)
            resp = await create_process_model_node.asyncio_detailed(
                uuid=processModelUuid, client=client, body=body
            )
            result = _to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "UPDATE"})
    async def updateProcessModelNode(
        processModelUuid: str,
        nodeId: int,
        name: Annotated[
            str | dict | None,
            BeforeValidator(_coerce_json_str_to_dict),
            Field(
                description="Node name. Can be a simple string (stored in site's primary locale) or a dict mapping locale codes to localized names."
            ),
        ] = None,
        coordinates: list[int] | None = None,
        connections: Annotated[
            list[ProcessModelConnectionInput] | None,
            Field(
                description="Outgoing connections — replaces all existing connections when provided. Each specifies targetNodeId and activityChained (required), plus optional overridesAssignment, synchronizeData, and label."
            ),
        ] = None,
        data: Annotated[
            NodeDataInput | None,
            Field(
                description="Data/Setup tab — full replacement of the data section when provided."
            ),
        ] = None,
        decision: Annotated[
            NodeDecisionInput | None,
            Field(description="Decision tab — full replacement when provided."),
        ] = None,
        assignment: Annotated[
            NodeAssignmentInput | None,
            Field(description="Assignment tab — full replacement when provided."),
        ] = None,
        forms: Annotated[
            FormConfigInput | dict[str, FormConfigInput] | None,
            BeforeValidator(_coerce_json_str_to_dict),
            Field(
                description="Forms tab — full replacement when provided. Can be a single FormConfig (stored in site's primary locale) or a dict mapping locale codes to FormConfig objects for multi-locale support. Set to null to clear."
            ),
        ] = None,
    ) -> dict:
        """Update a node's configuration. Only provided top-level fields are changed; omitted fields are preserved. type and id cannot be changed."""
        try:
            body_dict = {}
            if name is not None:
                body_dict["name"] = name
            if coordinates is not None:
                body_dict["coordinates"] = coordinates
            if connections is not None:
                body_dict["connections"] = [
                    c.model_dump(exclude_none=True) for c in connections
                ]
            if data is not None:
                body_dict["data"] = data.model_dump(exclude_none=True)
            if decision is not None:
                body_dict["decision"] = decision.model_dump(exclude_none=True)
            if assignment is not None:
                body_dict["assignment"] = assignment.model_dump(exclude_none=True)
            if forms is not None:
                # Handle forms - can be a single FormConfig or a dict of locale -> FormConfig
                if isinstance(forms, dict):
                    body_dict["forms"] = {
                        locale: form.model_dump(exclude_none=True)
                        for locale, form in forms.items()
                    }
                else:
                    body_dict["forms"] = forms.model_dump(exclude_none=True)

            previous_version_id = await _get_version_id(processModelUuid, client)
            body = UpdateProcessModelNodeRequest.from_dict(body_dict)
            resp = await update_process_model_node.asyncio_detailed(
                uuid=processModelUuid, node_id=nodeId, client=client, body=body
            )
            result = _to_dict(unwrap_response(resp))
            result["previousVersionId"] = previous_version_id
            return result
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Process Model", "action_type": "UPDATE"})
    async def deleteProcessModelNode(processModelUuid: str, nodeId: int) -> str:
        """Remove a node and clean up all incoming/outgoing connections."""
        try:
            resp = await delete_process_model_node.asyncio_detailed(
                uuid=processModelUuid, node_id=nodeId, client=client
            )
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e
