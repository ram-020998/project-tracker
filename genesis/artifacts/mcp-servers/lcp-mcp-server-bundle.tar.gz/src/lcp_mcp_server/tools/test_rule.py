"""Unified testRule MCP tool for testing rule-type design objects."""

from typing import Annotated, Literal

from lcp_api_plugin_client.api.expression_rules import test_expression_rule
from lcp_api_plugin_client.api.integrations import test_integration
from lcp_api_plugin_client.models.test_rule_request import TestRuleRequest
from lcp_api_plugin_client.types import UNSET
from pydantic import Field

from . import _safe_to_dict, tool_error, unwrap_response


def register_tools(mcp, client):
    register(mcp, client)


def register(mcp, client):
    @mcp.tool(meta={"object_type": "Test Rule", "action_type": "GET"})
    async def testRule(
        uuid: str,
        type: Annotated[
            Literal["EXPRESSION_RULE", "INTEGRATION"],
            Field(description="Object type: EXPRESSION_RULE or INTEGRATION."),
        ],
        inputs: Annotated[
            dict | None,
            Field(description="Key/value map of input parameters."),
        ] = None,
        timeoutSeconds: Annotated[
            int | None,
            Field(
                description="Maximum time to wait for execution. Default: 5. Max: 60."
            ),
        ] = None,
        maxResponseSizeBytes: Annotated[
            int | None,
            Field(
                description="Maximum response size to return. Default: 5120 (5KB). Max: 1048576 (1MB)."
            ),
        ] = None,
    ) -> dict:
        """Execute an Appian rule with test inputs and return the result. Works for expression rules and integrations — all rule-type objects in Appian. Pass the object's UUID, type, and an optional inputs map."""
        try:
            body = TestRuleRequest(
                inputs=inputs or UNSET,
                timeout_seconds=timeoutSeconds if timeoutSeconds is not None else UNSET,
                max_response_size_bytes=maxResponseSizeBytes
                if maxResponseSizeBytes is not None
                else UNSET,
            )
            if type == "EXPRESSION_RULE":
                resp = await test_expression_rule.asyncio_detailed(
                    uuid=uuid, client=client, body=body
                )
            else:
                resp = await test_integration.asyncio_detailed(
                    uuid=uuid, client=client, body=body
                )
            return _safe_to_dict(unwrap_response(resp))
        except Exception as e:
            raise tool_error(e) from e
