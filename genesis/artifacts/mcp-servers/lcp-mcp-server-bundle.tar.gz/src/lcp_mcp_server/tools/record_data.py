"""Record data domain MCP tools."""

import csv
import io
from http import HTTPStatus
from typing import Annotated

from lcp_api_plugin_client.api.record_data import (
    delete_record_type_data,
    insert_record_type_data,
    list_record_type_data,
    update_record_type_data,
)
from lcp_api_plugin_client.types import UNSET
from pydantic import Field

from . import tool_error, unwrap_response
from fastmcp.exceptions import ToolError


class _CsvBody:
    """Minimal wrapper matching the SDK's File.payload interface, using raw bytes."""

    def __init__(self, csv_data: str) -> None:
        self.payload = csv_data.encode("utf-8")


def _has_data_rows(csv_data: str) -> bool:
    """Check if CSV string has at least one data row beyond the header."""
    reader = csv.reader(io.StringIO(csv_data))
    try:
        next(reader)  # header
    except StopIteration:
        return False
    try:
        next(reader)  # first data row
    except StopIteration:
        return False
    return True


def register_tools(mcp, client):
    @mcp.tool(meta={"object_type": "Record Data", "action_type": "GET"})
    async def listRecordData(
        uuid: str,
        limit: int = 50,
        offset: int = 0,
    ) -> str | dict:
        """List record data as CSV. Returns paginated rows with field-name column headers."""
        try:
            resp = await list_record_type_data.asyncio_detailed(
                uuid=uuid,
                client=client,
                limit=limit,
                offset=offset,
            )
            return unwrap_response(resp)
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Data", "action_type": "CREATE"})
    async def insertRecordData(
        uuid: str,
        csvData: Annotated[
            str,
            Field(
                description=(
                    "CSV data with header row and one or more data rows. "
                    "Header names must match field names exactly as defined on the record type. "
                    "PK column may be omitted (or left empty per row) for auto-generated keys; "
                    "include it with explicit values to insert those keys directly. "
                    "Boolean fields: use 1 (true) or 0 (false) — string values like 'true'/'false' are rejected. "
                    "Date values: YYYY-MM-DD (e.g. 2026-03-20). "
                    "Datetime values: YYYY-MM-DD HH:MM:SS or YYYY-MM-DDTHH:MM:SS (e.g. 2026-03-20 14:30:00). "
                    "Time values: HH:MM:SS (e.g. 14:30:00). "
                    "All date/time values are interpreted as UTC. "
                    "Fields containing commas, quotes, or newlines MUST be enclosed in double quotes per RFC 4180. "
                    "Do NOT embed JSON in CSV fields — use plain text."
                )
            ),
        ],
        versionId: str | None = None,
    ) -> str | dict:
        """Insert one or more rows of record data from CSV.

        Returns inserted rows with assigned primary keys. Save these keys for
        foreign key references in downstream record types.
        """
        try:
            if not csvData or not csvData.strip() or not _has_data_rows(csvData):
                raise ToolError("At least one data row is required")
            resp = await insert_record_type_data.asyncio_detailed(
                uuid=uuid,
                version_id=versionId or UNSET,
                client=client,
                body=_CsvBody(csvData),
            )
            return unwrap_response(resp)
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Data", "action_type": "UPDATE"})
    async def updateRecordData(
        uuid: str,
        csvData: Annotated[
            str,
            Field(
                description=(
                    "CSV data with header row (including PK column) and one or more data rows. "
                    "Date values: ISO 8601 date format YYYY-MM-DD (e.g. 2026-03-20). "
                    "Datetime values: ISO 8601 datetime without timezone: YYYY-MM-DD HH:MM:SS or YYYY-MM-DDTHH:MM:SS "
                    "(e.g. 2026-03-20 14:30:00). "
                    "Time values: ISO 8601 time format HH:MM:SS (e.g. 14:30:00). "
                    "All date/time values are interpreted as UTC."
                )
            ),
        ],
        versionId: str | None = None,
    ) -> str | dict:
        """Update one or more rows of record data by primary key from CSV. Supports partial updates."""
        try:
            if not csvData or not csvData.strip() or not _has_data_rows(csvData):
                raise ToolError("At least one data row is required")
            resp = await update_record_type_data.asyncio_detailed(
                uuid=uuid,
                version_id=versionId or UNSET,
                client=client,
                body=_CsvBody(csvData),
            )
            return unwrap_response(resp)
        except Exception as e:
            raise tool_error(e) from e

    @mcp.tool(meta={"object_type": "Record Data", "action_type": "DELETE"})
    async def deleteRecordData(
        uuid: str,
        csvData: Annotated[
            str,
            Field(
                description="CSV data with PK column header and one or more PK values (one per line)."
            ),
        ],
    ) -> str | dict:
        """Delete one or more rows of record data by primary key from CSV."""
        try:
            resp = await delete_record_type_data.asyncio_detailed(
                uuid=uuid,
                client=client,
                body=_CsvBody(csvData),
            )
            if resp.status_code == HTTPStatus.NO_CONTENT:
                return "Deleted successfully"
            unwrap_response(resp)
            return "Deleted successfully"
        except Exception as e:
            raise tool_error(e) from e
