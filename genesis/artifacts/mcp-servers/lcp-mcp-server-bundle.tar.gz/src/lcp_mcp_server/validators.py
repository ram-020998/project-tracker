"""Validation utilities for LCP MCP server tools."""


class ValidationError(Exception):
    """Raised when tool input validation fails."""

    pass
