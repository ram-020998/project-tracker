"""Logging middleware for all MCP tool calls."""

import json
import logging

import mcp.types as mt
from fastmcp.server.middleware import CallNext, Middleware, MiddlewareContext

logger = logging.getLogger(__name__)


class ToolLoggingMiddleware(Middleware):
    async def on_call_tool(
        self, context: MiddlewareContext[mt.CallToolRequestParams], call_next: CallNext
    ):
        name = context.message.name
        args = context.message.arguments or {}
        logger.info("[TOOL_CALL] %s request: %s", name, json.dumps(args, default=str))
        result = await call_next(context)
        logger.info("[TOOL_CALL] %s response: %s", name, str(result))
        return result
