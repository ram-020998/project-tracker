"""Browser-based SSO authentication for the LCP plugin client.

Launches a real Chromium window for the user to complete Appian SSO/MFA,
captures the resulting session cookies, persists them, and replays them as a
``Cookie`` header on plugin API calls — the auth path for SSO-only sites that
don't accept Basic auth.

Works because the plugin's servlet endpoint
(``/suite/plugins/servlet/stateless/lcp-api/*``) sits on Appian's web-API
security chain, which accepts session-cookie auth (``isFullyAuthenticated()``)
and has CSRF disabled, so a captured SSO session authenticates reads and writes.

Generalized for *arbitrary* Appian SSO environments (not tuned to one site):
  * the signin path is fully configurable (``LCP_SIGNIN_PATH``; the default
    ``/suite/`` relies on the site auto-redirecting to its IdP, and multi-IdP
    sites set the ``?signin=<idp>`` path);
  * session-expiry detection treats any non-5xx **HTML** response on a JSON API
    path as an SSO bounce, instead of whitelisting specific redirect status
    codes that happen to be what one environment emits.

Adapted from the appian-home-mcp / Naveen ``buildwithclaude`` browser-auth flow;
the HomeDev-specific status-code assumptions are deliberately generalized here.

Playwright is a core dependency (``LCP_AUTH_METHOD=browser`` is a supported first-class
auth mode). Run ``uv run playwright install chromium`` once after installation.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import time
import urllib.parse
from collections.abc import AsyncGenerator
from dataclasses import asdict, dataclass
from pathlib import Path

import httpx

logger = logging.getLogger(__name__)

DEFAULT_STATE_DIR = "~/.appian-mcp"
LOGIN_TIMEOUT_SECONDS = 300  # 5 min for SSO + MFA
# Session cookies carry no expiry; cap their replayable lifetime so a captured
# session can't be replayed indefinitely after the user has walked away.
SESSION_COOKIE_MAX_AGE = 8 * 3600  # 8 hours

# Matches standard Appian post-login landing pages. Deliberately does NOT match
# /suite/ alone (the login page) or /personalization/mfa_* (MFA challenge pages),
# so wait_for_url only fires after login is fully complete.
# Extended at runtime with LCP_AUTH_LANDING_PATH for custom landing pages.
_DEFAULT_AUTHENTICATED_URL_RE = re.compile(
    r"/suite/(tempo|design|sites|actions|records|reports)"
)


@dataclass
class SessionCookie:
    name: str
    value: str
    domain: str
    expires: float | None = None  # Unix seconds; None = browser session cookie


def _default_path(base_url: str, name: str) -> str:
    """Per-site state path, so multiple sites don't clobber each other."""
    digest = hashlib.sha256(base_url.encode()).hexdigest()[:12]
    return os.path.join(os.path.expanduser(DEFAULT_STATE_DIR), f"{name}-{digest}")


def _domain_matches(cookie_domain: str, url_hostname: str) -> bool:
    d = (cookie_domain or "").lstrip(".")
    return bool(d) and (url_hostname == d or url_hostname.endswith(f".{d}"))


def _capped_expiry(raw_expires: float | None) -> float:
    """Keep a real future expiry; cap a no-expiry session cookie at 8 hours."""
    if raw_expires and raw_expires > 0:
        return raw_expires
    return time.time() + SESSION_COOKIE_MAX_AGE


def _is_session_expired(response: httpx.Response) -> bool:
    """True if the response looks like an SSO bounce / expired session.

    Generalized across IdPs: re-auth on 401/403, or on ANY non-5xx response
    whose body is HTML — the LCP API only ever returns JSON, so an HTML body
    means we were redirected to a login page, whatever status code the IdP used
    (200, 302, 303, 405, …). 5xx is excluded so a server-rendered HTML *error*
    page doesn't spuriously pop a browser.
    """
    if response.status_code in (401, 403):
        return True
    if response.status_code < 500 and "text/html" in response.headers.get("content-type", ""):
        logger.warning(
            "HTML response (status %d) on a JSON API path — treating as session "
            "expiry and re-authenticating",
            response.status_code,
        )
        return True
    return False


class FileCookieStore:
    """Persists captured session cookies to disk as JSON, dropping expired ones."""

    def __init__(self, path: str):
        self._path = Path(os.path.expanduser(path))

    def load(self) -> list[SessionCookie]:
        try:
            data = json.loads(self._path.read_text())
        except (FileNotFoundError, ValueError):
            return []
        now = time.time()
        return [
            SessionCookie(
                name=c["name"],
                value=c["value"],
                domain=c.get("domain", ""),
                expires=c.get("expires"),
            )
            for c in data.get("cookies", [])
            if c.get("expires") is None or c["expires"] >= now
        ]

    def save(self, cookies: list[SessionCookie]) -> None:
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            payload = {"version": 2, "cookies": [asdict(c) for c in cookies]}
            self._path.write_text(json.dumps(payload, indent=2))
            try:
                os.chmod(self._path, 0o600)  # cookies are credentials
            except OSError:
                pass
        except OSError as e:  # disk issues shouldn't crash a tool call
            logger.warning("Could not persist session cookies: %s", e)

    def clear(self) -> None:
        try:
            self._path.unlink(missing_ok=True)
        except OSError:
            pass


class BrowserSessionAuth(httpx.Auth):
    """httpx auth that replays an Appian SSO session cookie captured via browser.

    Requires an *async* httpx client (the bundle uses one). Loads persisted
    cookies eagerly at construction so the common case opens no browser and the
    MCP stdio handshake isn't blocked; lazily launches Chromium on first use
    only if no valid session exists; re-auths once on session expiry. An
    ``asyncio.Lock`` serialises concurrent logins so racing tool calls open a
    single browser window.
    """

    requires_response_body = False  # we inspect status + content-type only

    def __init__(
        self,
        base_url: str,
        signin_path: str,
        cookie_path: str | None = None,
        browser_profile_path: str | None = None,
        headless: bool = False,
        auth_landing_path: str | None = None,
    ):
        self._base_url = base_url.rstrip("/")
        self._hostname = urllib.parse.urlparse(self._base_url).hostname or ""
        self._signin_path = signin_path
        self._store = FileCookieStore(
            cookie_path or (_default_path(self._base_url, "cookies") + ".json")
        )
        self._profile_path = os.path.expanduser(
            browser_profile_path or _default_path(self._base_url, "browser-profile")
        )
        self._headless = headless
        if auth_landing_path:
            self._authenticated_url_re = re.compile(
                _DEFAULT_AUTHENTICATED_URL_RE.pattern + "|" + re.escape(auth_landing_path)
            )
        else:
            self._authenticated_url_re = _DEFAULT_AUTHENTICATED_URL_RE
        self._cookies: list[SessionCookie] = self._store.load()  # eager startup load
        if self._cookies:
            logger.info("Loaded %d persisted session cookie(s)", len(self._cookies))
        self._lock = asyncio.Lock()

    # ----- cookie header (domain-scoped) -----
    def _cookie_header(self) -> str:
        matching = [c for c in self._cookies if _domain_matches(c.domain, self._hostname)]
        if not matching:
            if self._cookies:
                logger.warning(
                    "No captured cookie matched host %r — check LCP_URL matches the "
                    "domain you authenticated against",
                    self._hostname,
                )
            return ""
        return "; ".join(f"{c.name}={c.value}" for c in matching)

    def _csrf_token(self) -> str | None:
        """Return the captured __appianCsrfToken value, or None if not present.

        Some plugin versions enforce CSRF on mutating requests even on the
        stateless servlet chain. Sending the token as X-APPIAN-CSRF-TOKEN is
        harmless on versions where CSRF is disabled.
        """
        for c in self._cookies:
            if c.name == "__appianCsrfToken" and _domain_matches(c.domain, self._hostname):
                return c.value
        return None

    def _inject_auth_headers(self, request: httpx.Request) -> None:
        request.headers.pop("Cookie", None)
        request.headers.pop("X-APPIAN-CSRF-TOKEN", None)
        header = self._cookie_header()
        if header:
            request.headers["Cookie"] = header
        csrf = self._csrf_token()
        if csrf:
            request.headers["X-APPIAN-CSRF-TOKEN"] = csrf

    # ----- httpx.Auth interface -----
    def sync_auth_flow(self, request):
        raise NotImplementedError(
            "BrowserSessionAuth requires an async httpx client (httpx.AsyncClient)."
        )
        yield  # pragma: no cover  (satisfy the generator protocol)

    async def async_auth_flow(
        self, request: httpx.Request
    ) -> AsyncGenerator[httpx.Request, httpx.Response]:
        if not self._cookies:
            await self._ensure_authenticated()
        self._inject_auth_headers(request)
        response = yield request

        if _is_session_expired(response):
            await self._reauthenticate()
            self._inject_auth_headers(request)
            yield request

    # ----- auth lifecycle (lock-serialised) -----
    async def _ensure_authenticated(self) -> None:
        async with self._lock:
            if self._cookies:
                return
            self._cookies = self._store.load()
            if self._cookies:
                return
            logger.info("No valid session — launching browser for SSO login")
            self._cookies = await self._login_via_browser()
            self._store.save(self._cookies)

    async def _reauthenticate(self) -> None:
        async with self._lock:
            self._cookies = self._store.load()
            if self._cookies:  # a concurrent caller already re-authed
                return
            logger.info("Session expired — re-authenticating via browser")
            self._store.clear()
            self._cookies = await self._login_via_browser()
            self._store.save(self._cookies)

    # ----- browser login -----
    async def _login_via_browser(self) -> list[SessionCookie]:
        try:
            from playwright.async_api import async_playwright
        except ImportError as e:
            raise RuntimeError(
                "Browser auth requires Playwright browser binaries. Install them with:\n"
                "  uv run playwright install chromium"
            ) from e

        signin_url = f"{self._base_url}{self._signin_path}"
        logger.info("Opening browser for Appian SSO login: %s", signin_url)
        Path(self._profile_path).mkdir(parents=True, exist_ok=True)
        async with async_playwright() as p:
            context = await p.chromium.launch_persistent_context(
                self._profile_path, headless=self._headless
            )
            try:
                page = context.pages[0] if context.pages else await context.new_page()
                await page.goto(signin_url)
                cookies = await self._wait_for_session(context, page)
            finally:
                await context.close()

        logger.info("Captured %d session cookie(s) via browser SSO", len(cookies))
        return cookies

    async def _wait_for_session(self, context, page) -> list[SessionCookie]:
        """Wait until the browser navigates to a post-login Appian page.

        Uses Playwright's event-driven wait_for_url rather than polling, so it
        fires exactly when navigation to a matching URL completes — not before.
        Deliberately excludes /suite/ alone (the login page) and
        /personalization/mfa_* (MFA challenge pages), so native MFA flows are
        fully handled before the session is captured.
        """
        try:
            from playwright.async_api import TimeoutError as PlaywrightTimeoutError
            await page.wait_for_url(
                self._authenticated_url_re,
                timeout=LOGIN_TIMEOUT_SECONDS * 1000,
            )
        except PlaywrightTimeoutError as e:
            raise RuntimeError(
                "Browser authentication timed out. "
                "Complete the login (including any MFA prompt) in the browser window. "
                "If your Appian instance has a custom default landing page, set "
                "LCP_AUTH_LANDING_PATH to its path (e.g. /suite/sites/my-portal)."
            ) from e
        raw = await context.cookies()
        cookies = [
            SessionCookie(
                name=c["name"],
                value=c["value"],
                domain=c.get("domain", ""),
                expires=_capped_expiry(c.get("expires", -1)),
            )
            for c in raw
            if c["name"] == "JSESSIONID" or c["name"].startswith("__appian")
        ]
        if not cookies:
            raise RuntimeError(
                "Browser login appeared to succeed but no Appian session cookies "
                "were captured. Check that LCP_URL matches the domain you "
                "authenticated against."
            )
        return cookies
