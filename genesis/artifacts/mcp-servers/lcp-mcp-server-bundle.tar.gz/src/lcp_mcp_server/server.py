"""MCP server implementation for LCP API."""

import logging
import os

import httpx
from fastmcp import FastMCP
from lcp_api_beta_client.client import AuthenticatedClient as LCPAuthenticatedClient
from lcp_api_plugin_client.client import Client as LCPPluginClient

from .config import LCPConfig
from .dynamic_client import DynamicBetaClient, DynamicLCPClient
from .tools import (
    ai_agents,
    ai_skills,
    applications,
    connected_systems,
    constants,
    documents,
    expression_rules,
    folders,
    groups,
    integrations,
    interfaces,
    objects,
    process_models,
    record_data,
    record_types,
    robotic_tasks,
    sites,
    test_rule,
    validation,
    web_apis,
)

logger = logging.getLogger(__name__)

# Domains using plugin client (Basic Auth)
_PLUGIN_CLIENT_DOMAINS = [
    applications,
    connected_systems,
    constants,
    documents,
    expression_rules,
    folders,
    groups,
    integrations,
    interfaces,
    process_models,
    record_data,
    record_types,
    sites,
    test_rule,
    validation,
    web_apis,
]


def create_lcp_mcp_server(config: LCPConfig) -> FastMCP:
    """Create LCP MCP server with explicit tools over generated SDK."""
    logger.info("Initializing LCP MCP Server")
    logger.info(f"Base URL: {config.base_url}")
    logger.info(f"USER_INITIALS: {os.environ.get('USER_INITIALS', '<not set>')}")

    # Plugin client auth: Basic (default) or browser-captured SSO session cookie.
    # Browser mode targets SSO-only sites that don't accept Basic — the servlet
    # endpoint accepts a session cookie, so we replay one captured via the browser.
    if config.auth_method == "browser":
        from .browser_auth import BrowserSessionAuth

        plugin_auth = BrowserSessionAuth(
            base_url=config.lcp_url,
            signin_path=config.signin_path,
            cookie_path=config.cookie_path or None,
            browser_profile_path=config.browser_profile_path or None,
            auth_landing_path=config.auth_landing_path or None,
        )
        logger.info("Plugin Client Auth: Browser SSO (session cookie)")
    else:
        username = os.environ.get("LCP_USERNAME", "")
        password = os.environ.get("LCP_PASSWORD", "")
        plugin_auth = httpx.BasicAuth(username, password) if username and password else None
        logger.info(f"Plugin Client Auth: {'Basic Auth' if plugin_auth else 'None'}")

    plugin_httpx_args = {"auth": plugin_auth} if plugin_auth else {}

    plugin_client = DynamicLCPClient(
        LCPPluginClient(
            base_url=config.base_url,
            timeout=httpx.Timeout(60.0),
            httpx_args=plugin_httpx_args,
        )
    )

    # LCP beta client — per-request JWT from tool_auth is used at call time
    lcp_client = DynamicBetaClient(
        LCPAuthenticatedClient(
            base_url=config.beta_base_url,
            token="per-request",
            timeout=httpx.Timeout(60.0),
        )
    )

    mcp = FastMCP("lcp-mcp-server")

    from .middleware import ToolLoggingMiddleware

    mcp.add_middleware(ToolLoggingMiddleware())

    # Register plugin client domains
    for domain in _PLUGIN_CLIENT_DOMAINS:
        domain.register_tools(mcp, plugin_client)

    # Robotic tasks uses both LCP beta client and plugin client
    robotic_tasks.register_tools(mcp, lcp_client, plugin_client)

    # Objects uses plugin client + beta client (for AI Skills)
    objects.register_tools(mcp, plugin_client, beta_client=lcp_client)

    # AI agents uses both LCP beta client and plugin client
    ai_agents.register_tools(mcp, lcp_client, plugin_client)

    # AI skills uses both LCP beta client and plugin client (app-scoped listing)
    ai_skills.register_tools(mcp, lcp_client, plugin_client)

    logger.info("LCP MCP Server initialization complete")
    return mcp


def create_lcp_internal_server(config: LCPConfig) -> FastMCP:
    """Create internal LCP MCP server with all tools including sub-agent-only ones."""
    mcp = create_lcp_mcp_server(config)

    logger.info("LCP Internal MCP Server initialization complete")
    return mcp
